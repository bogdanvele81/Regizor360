package ro.director360.app;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Citește lista de filmări de pe card (folder ales o dată) sau din telefon. Rulează pe un fir separat. */
public class Library {

    private static final String[] COLS = {
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
    };

    public static List<VideoItem> scanTree(Context ctx, Uri tree) {
        ContentResolver cr = ctx.getContentResolver();
        List<VideoItem> vids = new ArrayList<>();
        Map<String, Uri> lrvs = new HashMap<>();
        Map<String, Uri> lens2 = new HashMap<>();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        walk(cr, tree, rootId, 0, vids, lrvs, lens2);
        for (VideoItem v : vids) {
            Uri l = lrvs.get(VideoItem.stem(v.name));
            if (l != null) { v.lrv = l; v.extra.add(l); }
            if (v.name.toLowerCase().endsWith(".insv")) { Uri l2 = lens2.get(VideoItem.stem(v.name)); if (l2 != null) v.extra.add(l2); }
        }
        Collections.sort(vids, (a, b) -> {
            int c = b.name.compareTo(a.name);
            return c != 0 ? c : Long.compare(b.modified, a.modified);
        });
        return vids;
    }

    private static void walk(ContentResolver cr, Uri tree, String docId, int depth,
                             List<VideoItem> vids, Map<String, Uri> lrvs, Map<String, Uri> lens2) {
        if (depth > 4) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        List<String> dirs = new ArrayList<>();
        try (Cursor c = cr.query(children, COLS, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? 0 : c.getLong(3);
                long mod = c.isNull(4) ? 0 : c.getLong(4);
                if (name == null) continue;
                String low = name.toLowerCase();
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    if (low.startsWith(".") || low.equals("android") || low.equals("lost.dir")) continue;
                    dirs.add(id);
                } else if (low.endsWith(".lrv")) {
                    lrvs.put(VideoItem.stem(name), DocumentsContract.buildDocumentUriUsingTree(tree, id));
                } else if (low.endsWith(".insp") || low.endsWith(".jpg") || low.endsWith(".jpeg")) {
                    vids.add(new VideoItem(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, size, mod));
                } else if (low.endsWith(".mp4") || low.endsWith(".insv") || low.endsWith(".mov")) {
                    // a doua lentilă (_10_) a unei filmări 360 nu apare separat
                    if (low.endsWith(".insv") && name.contains("_10_")) { lens2.put(VideoItem.stem(name), DocumentsContract.buildDocumentUriUsingTree(tree, id)); continue; }
                    vids.add(new VideoItem(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, size, mod));
                }
            }
        } catch (Exception ignored) {
        }
        for (String d : dirs) walk(cr, tree, d, depth + 1, vids, lrvs, lens2);
    }

    /** O filmare aleasă din telefon. */
    public static VideoItem fromPhone(Context ctx, Uri uri) {
        String name = "video.mp4";
        try { String t = ctx.getContentResolver().getType(uri); if (t != null && t.startsWith("image/")) name = "poza.jpg"; } catch (Exception ignored) { }
        long size = 0;
        try (Cursor c = ctx.getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                if (!c.isNull(0)) name = c.getString(0);
                if (!c.isNull(1)) size = c.getLong(1);
            }
        } catch (Exception ignored) {
        }
        return new VideoItem(uri, name, size, 0);
    }
}
