package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

/**
 * Deep Track, ca în Regizor 360: urmărește persoana atinsă după culorile ei (mean-shift pe histogramă),
 * pe panorama 256×128 stabilizată, înainte și înapoi de la momentul atins; dacă o pierde, o caută în jurul ultimei poziții.
 */
public class Track {
    public interface Progress { void on(int pct); boolean cancelled(); }

    static final int AW = 256, AH = 128, NB = 68, BW = 7, BH = 13;
    private static final float LOST = 0.85f, FOUND = 0.94f;
    private static final int NEED = 3;

    /** timpii (secunde în filmare) și direcțiile urmărite (yaw, pitch în radiani, în lumea dreaptă) */
    public double[] t;
    public float[] yaw, pitch;
    public int found, total;

    // ---- direcții pentru fiecare pixel din panoramă ----
    private static float[][] DIRS;

    private static synchronized float[][] dirs() {
        if (DIRS != null) return DIRS;
        float[][] d = new float[AW * AH][];
        for (int y = 0; y < AH; y++) for (int x = 0; x < AW; x++) d[y * AW + x] = pix2dir(x, y);
        DIRS = d;
        return d;
    }

    static float[] pix2dir(double x, double y) {
        double lon = ((x + .5) / AW * 2 - 1) * Math.PI, lat = ((y + .5) / AH * 2 - 1) * Math.PI / 2;
        return new float[]{(float) (Math.cos(lat) * Math.sin(lon)), (float) -Math.sin(lat), (float) (Math.cos(lat) * Math.cos(lon))};
    }

    static double[] dir2pix(float[] d) {
        double lon = Math.atan2(d[0], d[2]), lat = Math.asin(Math.max(-1, Math.min(1, -d[1])));
        return new double[]{(lon / Math.PI + 1) / 2 * AW - .5, (lat / (Math.PI / 2) + 1) / 2 * AH - .5};
    }

    /** panorama la momentul t, în culori grupate (68 de „cutii”), sau null */
    private static byte[] frameBins(MediaMetadataRetriever r, double tSec, Gyro g, float[] pa, float[] pb, float[] O, float fov) {
        Bitmap b = r.getScaledFrameAtTime((long) (tSec * 1e6), MediaMetadataRetriever.OPTION_CLOSEST, 768, 384);
        if (b == null) return null;
        int sw = b.getWidth(), sh = b.getHeight();
        int[] px = new int[sw * sh];
        b.getPixels(px, 0, sw, 0, 0, sw, sh);
        b.recycle();
        float[] C = g != null ? g.at(tSec, false) : new float[]{1, 0, 0, 0, 1, 0, 0, 0, 1};
        float[][] D = dirs();
        byte[] out = new byte[AW * AH];
        for (int i = 0; i < AW * AH; i++) {
            float[] w = D[i];
            float dx = C[0] * w[0] + C[1] * w[1] + C[2] * w[2], dy = C[3] * w[0] + C[4] * w[1] + C[5] * w[2], dz = C[6] * w[0] + C[7] * w[1] + C[8] * w[2];
            int c = sample(px, sw, sh, pa, dx, dy, dz, fov);
            if (c == 0) {
                float ex = O[0] * dx + O[1] * dy + O[2] * dz, ey = O[3] * dx + O[4] * dy + O[5] * dz, ez = O[6] * dx + O[7] * dy + O[8] * dz;
                c = sample(px, sw, sh, pb, ex, ey, ez, fov);
            }
            out[i] = (byte) bin(c);
        }
        return out;
    }

    private static int sample(int[] px, int sw, int sh, float[] P, float dx, float dy, float dz, float fov) {
        double th = Math.acos(Math.max(-1, Math.min(1, dz)));
        if (th > Math.PI / 2 + 0.02) return 0;
        double ph = Math.atan2(dy, dx), r = th / fov;
        int u = (int) ((P[0] + P[2] * r * Math.cos(ph)) * sw), v = (int) ((P[1] + P[3] * r * Math.sin(ph)) * sh);
        if (u < 0 || u >= sw || v < 0 || v >= sh) return 0;
        return px[v * sw + u] | 0xFF000000;
    }

    private static int bin(int c) {
        if (c == 0) return 255;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        if (mx < 50) return 64;
        float s = (mx - mn) / (float) mx;
        if (s < 0.22f) return 65 + Math.min(2, (int) ((mx - 50) / 70f));
        float d = mx - mn, h;
        if (mx == r) h = (((g - b) / d) + 6) % 6; else if (mx == g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        return (((int) (h * 16 / 6)) % 16) * 4 + Math.min(3, (int) (s * 4));
    }

    // ---- histograme și mean-shift (ca în Regizor) ----
    private static float valid;

    private static float[] hist(byte[] bins, double cx, double cy) {
        float[] p = new float[NB];
        float sum = 0, tot = 0;
        for (int dy = -BH; dy <= BH; dy++) {
            int y = (int) Math.round(cy + dy);
            if (y < 0 || y >= AH) continue;
            for (int dx = -BW; dx <= BW; dx++) {
                float k = 1 - (dx * dx) / (float) (BW * BW) - (dy * dy) / (float) (BH * BH);
                if (k <= 0) continue;
                tot += k;
                int x = (((int) Math.round(cx + dx) % AW) + AW) % AW;
                int b = bins[y * AW + x] & 255;
                if (b == 255) continue;
                p[b] += k;
                sum += k;
            }
        }
        if (sum > 0) for (int i = 0; i < NB; i++) p[i] /= sum;
        valid = tot > 0 ? sum / tot : 0;
        return p;
    }

    private static float bhat(float[] p, float[] q) { float s = 0; for (int i = 0; i < NB; i++) s += (float) Math.sqrt(p[i] * q[i]); return s; }

    /** {cx, cy, rho} */
    private static double[] meanShift(byte[] bins, float[] q, double cx, double cy) {
        for (int it = 0; it < 12; it++) {
            float[] p = hist(bins, cx, cy);
            double sx = 0, sy = 0, sw = 0;
            for (int dy = -BH; dy <= BH; dy++) {
                int y = (int) Math.round(cy + dy);
                if (y < 0 || y >= AH) continue;
                for (int dx = -BW; dx <= BW; dx++) {
                    if ((dx * dx) / (double) (BW * BW) + (dy * dy) / (double) (BH * BH) >= 1) continue;
                    int x = (((int) Math.round(cx + dx) % AW) + AW) % AW;
                    int b = bins[y * AW + x] & 255;
                    if (b == 255 || p[b] == 0) continue;
                    double w = Math.sqrt(q[b] / p[b]);
                    sx += w * dx; sy += w * dy; sw += w;
                }
            }
            if (sw == 0) break;
            double mx = sx / sw, my = sy / sw;
            cx = ((cx + mx) % AW + AW) % AW;
            cy = Math.min(AH - 1 - BH / 2.0, Math.max(BH / 2.0, cy + my));
            if (Math.hypot(mx, my) < 0.3) break;
        }
        float[] h = hist(bins, cx, cy);
        return new double[]{cx, cy, valid > 0.5f ? bhat(h, q) : 0};
    }

    private static double[] lsearch(byte[] bins, float[] q, double cx0, double cy0, double R) {
        double[] best = null;
        double br = 0;
        for (int dy = -(int) Math.floor(R); dy <= R; dy += 2) {
            double cy = cy0 + dy;
            if (cy < BH / 2.0 || cy > AH - 1 - BH / 2.0) continue;
            for (int dx = -(int) Math.floor(R); dx <= R; dx += 2) {
                if (dx * dx + dy * dy > R * R) continue;
                double cx = ((cx0 + dx) % AW + AW) % AW;
                float[] h = hist(bins, cx, cy);
                if (valid < 0.6f) continue;
                float r = bhat(h, q);
                if (r > br) { br = r; best = new double[]{cx, cy}; }
            }
        }
        return best == null ? new double[]{cx0, cy0, 0} : meanShift(bins, q, best[0], best[1]);
    }

    private static double wrapDist(double ax, double ay, double bx, double by) {
        double dx = ((ax - bx) % AW + AW * 1.5) % AW - AW / 2.0;
        return Math.hypot(dx, ay - by);
    }

    private static double[][] trackAll(byte[][] F, double[] T, int k0, double x0, double y0) {
        float[] q = hist(F[k0], x0, y0);
        double[][] res = new double[F.length][];
        for (int dir = 1; dir >= -1; dir -= 2) {
            double cx = x0, cy = y0, lastT = T[k0];
            boolean ok = true;
            java.util.List<double[]> cand = new java.util.ArrayList<>();
            for (int k = k0; k >= 0 && k < F.length; k += dir) {
                if (F[k] == null) continue;
                if (ok) {
                    double[] r = meanShift(F[k], q, cx, cy);
                    if (k == k0 || (r[2] >= LOST && wrapDist(r[0], r[1], cx, cy) < 12)) {
                        cx = r[0]; cy = r[1]; res[k] = r; lastT = T[k];
                        continue;
                    }
                    ok = false;
                    cand.clear();
                }
                double R = Math.min(6 + 6 * Math.abs(T[k] - lastT), 30);
                double[] s = lsearch(F[k], q, cx, cy, R);
                if (s[2] >= FOUND && wrapDist(s[0], s[1], cx, cy) <= R + 3 && (cand.isEmpty() || wrapDist(s[0], s[1], cand.get(cand.size() - 1)[1], cand.get(cand.size() - 1)[2]) < 6)) {
                    cand.add(new double[]{k, s[0], s[1], s[2]});
                    if (cand.size() >= NEED) {
                        for (double[] c : cand) res[(int) c[0]] = new double[]{c[1], c[2], c[3]};
                        cx = s[0]; cy = s[1]; ok = true; lastT = T[k];
                        cand.clear();
                    }
                } else cand.clear();
            }
        }
        return res;
    }

    /**
     * Urmărește persoana atinsă la momentul tapSec (direcția d0 în lumea dreaptă), pe bucata [a, b] secunde din filmare.
     * speedSec = cât de lin urmărește (0.6 = normal).
     */
    public static Track run(Context ctx, Uri prev, Gyro g, double a, double b, double tapSec, float[] d0, Progress pr) {
        double step = 0.2;
        int n = (int) Math.max(2, Math.ceil((b - a) / step) + 1);
        double[] T = new double[n];
        byte[][] F = new byte[n][];
        float[] pa = Video360View.calA(), pb = Video360View.calB(), O = Video360View.lensO();
        float fov = Video360View.fovRad();
        int k0 = 0;
        double bd = 1e9;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, prev);
            for (int k = 0; k < n; k++) {
                if (pr.cancelled()) return null;
                T[k] = Math.min(b, a + k * step);
                F[k] = frameBins(r, T[k], g, pa, pb, O, fov);
                if (Math.abs(T[k] - tapSec) < bd) { bd = Math.abs(T[k] - tapSec); k0 = k; }
                pr.on(Math.round(k * 85f / n));
            }
        } catch (Throwable e) {
            return null;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        if (F[k0] == null) return null;
        double[] p0 = dir2pix(d0);
        double[][] res = trackAll(F, T, k0, p0[0], p0[1]);
        pr.on(95);
        float[][] D = new float[n][];
        Track tr = new Track();
        tr.total = n;
        for (int k = 0; k < n; k++) if (res[k] != null) { D[k] = pix2dir(res[k][0], res[k][1]); tr.found++; }
        float[] last = null;
        for (int k = 0; k < n; k++) { if (D[k] != null) last = D[k]; else if (last != null) D[k] = last; }
        float[] first = d0;
        for (int k = 0; k < n; k++) if (D[k] != null) { first = D[k]; break; }
        for (int k = 0; k < n && D[k] == null; k++) D[k] = first;
        // netezire (σ = 0,6 s) și fără să privească prea sus sau prea jos
        double sigma = 0.6 / step;
        int rr = (int) Math.ceil(sigma * 3);
        tr.t = T;
        tr.yaw = new float[n];
        tr.pitch = new float[n];
        for (int k = 0; k < n; k++) {
            double sx = 0, sy = 0, sz = 0;
            for (int i = -rr; i <= rr; i++) {
                int j = Math.min(n - 1, Math.max(0, k + i));
                double w = Math.exp(-i * i / (2 * sigma * sigma));
                sx += D[j][0] * w; sy += D[j][1] * w; sz += D[j][2] * w;
            }
            double l = Math.sqrt(sx * sx + sy * sy + sz * sz);
            sx /= l; sy /= l; sz /= l;
            double el = Math.asin(Math.max(-1, Math.min(1, -sy)));
            double lim = Math.toRadians(28);
            if (Math.abs(el) > lim) {
                double e = Math.signum(el) * lim, hl = Math.sqrt(sx * sx + sz * sz);
                sx = sx / hl * Math.cos(e); sz = sz / hl * Math.cos(e); sy = -Math.sin(e);
            }
            tr.yaw[k] = (float) Math.atan2(sx, sz);
            tr.pitch[k] = (float) Math.asin(Math.max(-1, Math.min(1, -sy)));
        }
        pr.on(100);
        return tr;
    }

    /** direcția privirii (row-major 3×3) la momentul tSec: rotY(yaw)·rotX(pitch) */
    public float[] viewAt(double tSec) {
        int n = t.length;
        double f = (tSec - t[0]) / Math.max(1e-6, (t[n - 1] - t[0])) * (n - 1);
        int i = (int) Math.max(0, Math.min(n - 2, Math.floor(f)));
        double u = Math.max(0, Math.min(1, f - i));
        double y0 = yaw[i], y1 = yaw[i + 1];
        while (y1 - y0 > Math.PI) y1 -= 2 * Math.PI;
        while (y1 - y0 < -Math.PI) y1 += 2 * Math.PI;
        double yv = y0 + (y1 - y0) * u, pv = pitch[i] + (pitch[i + 1] - pitch[i]) * u;
        float cy = (float) Math.cos(yv), sy = (float) Math.sin(yv), cp = (float) Math.cos(pv), sp = (float) Math.sin(pv);
        float[] ry = {cy, 0, sy, 0, 1, 0, -sy, 0, cy};
        float[] rx = {1, 0, 0, 0, cp, -sp, 0, sp, cp};
        float[] r = new float[9];
        for (int a = 0; a < 3; a++) for (int b = 0; b < 3; b++) { float v = 0; for (int k = 0; k < 3; k++) v += ry[a * 3 + k] * rx[k * 3 + b]; r[a * 3 + b] = v; }
        return r;
    }
}
