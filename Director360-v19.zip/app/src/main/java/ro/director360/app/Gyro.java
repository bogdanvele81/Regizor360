package ro.director360.app;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;

/**
 * Stabilizarea filmărilor 360 (ca FlowState la Insta360), din giroscopul salvat de cameră în fișier.
 * Același calcul ca în Regizor 360: rotația camerei în fiecare moment + direcția „sus” din accelerometru.
 * at(t) dă matricea (rând după rând) care duce privirea din lumea dreaptă în lentila camerei.
 */
public class Gyro {
    private static final String MAGIC = "8db42d694ccc418790edff439fe026bf";
    private static final double SCALE = 0.0011490087, OFFSET = 0.198;

    private double[] t;     // secunde
    private float[] q;      // cuaternioni (w,x,y,z) lume → cameră
    private float[] L;      // îndreptarea orizontului
    private double[] hT;    // direcția camerei netezită, la 20 Hz
    private float[] hY;

    /** citește giroscopul din fișierul mare .insv; null dacă nu are */
    public static Gyro read(Context ctx, Uri uri) {
        try (ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
             FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
             FileChannel ch = fis.getChannel()) {
            long n = ch.size();
            if (n < 200) return null;
            ByteBuffer tail = ByteBuffer.allocate(72).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(tail, n - 72);
            if (!new String(tail.array(), 40, 32, "ISO-8859-1").equals(MAGIC)) return null;
            long size = tail.getInt(32) & 0xFFFFFFFFL;
            if (size <= 72 || size > n || size > 80L * 1048576) return null;
            ByteBuffer tb = ByteBuffer.allocate((int) size).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(tb, n - size);
            byte[] b = tb.array();
            for (int i = b.length; i >= 6; i--) {
                if (b[i - 6] != 0x00 || b[i - 5] != 0x03) continue;
                long sz = tb.getInt(i - 4) & 0xFFFFFFFFL;
                if (sz < 2000 || sz > i - 6 || sz % 20 != 0) continue;
                int s = (int) (i - 6 - sz);
                long a = tb.getLong(s), c = tb.getLong(s + 20);
                if (c - a < 500 || c - a > 2000) continue;
                int cnt = (int) (sz / 20);
                double[] tt = new double[cnt];
                float[] raw = new float[cnt * 6];
                for (int k = 0; k < cnt; k++) {
                    int o = s + 20 * k;
                    tt[k] = (tb.getLong(o) - a) / 1e6;
                    for (int j = 0; j < 6; j++) raw[k * 6 + j] = (tb.getShort(o + 8 + 2 * j) & 0xFFFF) - 32768;
                }
                Gyro g = new Gyro();
                g.build(tt, raw);
                return g;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private void build(double[] tt, float[] raw) {
        int n = tt.length;
        t = tt;
        q = new float[n * 4];
        double w = 1, x = 0, y = 0, z = 0;
        q[0] = 1;
        for (int k = 1; k < n; k++) {
            double dt = tt[k] - tt[k - 1];
            double ax = (raw[k * 6 + 5] + raw[(k - 1) * 6 + 5]) / 2 * SCALE, ay = (raw[k * 6 + 3] + raw[(k - 1) * 6 + 3]) / 2 * SCALE, az = (raw[k * 6 + 4] + raw[(k - 1) * 6 + 4]) / 2 * SCALE;
            double vx = -ax * dt, vy = -ay * dt, vz = -az * dt;
            double th = Math.sqrt(vx * vx + vy * vy + vz * vz);
            double rw, rx, ry, rz;
            if (th < 1e-12) { rw = 1; rx = vx / 2; ry = vy / 2; rz = vz / 2; }
            else { double sn = Math.sin(th / 2) / th; rw = Math.cos(th / 2); rx = vx * sn; ry = vy * sn; rz = vz * sn; }
            // q = r * q
            double nw = rw * w - rx * x - ry * y - rz * z;
            double nx = rw * x + rx * w + ry * z - rz * y;
            double ny = rw * y - rx * z + ry * w + rz * x;
            double nz = rw * z + rx * y - ry * x + rz * w;
            w = nw; x = nx; y = ny; z = nz;
            if (k % 64 == 0) { double l = Math.sqrt(w * w + x * x + y * y + z * z); w /= l; x /= l; y /= l; z /= l; }
            q[k * 4] = (float) w; q[k * 4 + 1] = (float) x; q[k * 4 + 2] = (float) y; q[k * 4 + 3] = (float) z;
        }
        // „sus” din accelerometru
        int m = 0;
        float[] norms = new float[(n + 9) / 10];
        for (int k = 0; k < n; k += 10) norms[m++] = (float) Math.sqrt(raw[k * 6] * raw[k * 6] + raw[k * 6 + 1] * raw[k * 6 + 1] + raw[k * 6 + 2] * raw[k * 6 + 2]);
        float[] srt = java.util.Arrays.copyOf(norms, m);
        java.util.Arrays.sort(srt);
        float med = srt[m / 2];
        double ux = 0, uy = 0, uz = 0;
        for (int k = 0; k < n; k += 10) {
            float a0 = raw[k * 6 + 2], a1 = raw[k * 6], a2 = raw[k * 6 + 1];
            float nn = (float) Math.sqrt(a0 * a0 + a1 * a1 + a2 * a2);
            if (Math.abs(nn - med) > 60 || nn < 1) continue;
            float[] M = mat(k);
            float[] wv = Video360View.mvec(Video360View.tr3(M), new float[]{a0 / nn, a1 / nn, a2 / nn});
            ux += wv[0]; uy += wv[1]; uz += wv[2];
        }
        float[] up = norm(new float[]{(float) ux, (float) uy, (float) uz});
        float[] yD = {-up[0], -up[1], -up[2]};
        float[] z0 = {0, 0, 1};
        float d = yD[2];
        z0 = norm(new float[]{z0[0] - d * yD[0], z0[1] - d * yD[1], z0[2] - d * yD[2]});
        float[] xR = {yD[1] * z0[2] - yD[2] * z0[1], yD[2] * z0[0] - yD[0] * z0[2], yD[0] * z0[1] - yD[1] * z0[0]};
        L = new float[]{xR[0], yD[0], z0[0], xR[1], yD[1], z0[1], xR[2], yD[2], z0[2]};
        // direcția în care privește camera, netezită (cât se rotește camera, cadrul o urmează lin)
        double T = tt[n - 1];
        int hn = (int) Math.max(2, T * 20) + 1;
        hT = new double[hn];
        double[] raw2 = new double[hn];
        double prev = 0;
        for (int i = 0; i < hn; i++) {
            double ti = i / 20.0;
            hT[i] = ti;
            float[] C = mul(mat(index(ti + OFFSET)), L);
            float[] f = Video360View.mvec(Video360View.tr3(C), new float[]{0, 0, 1});
            double yaw = Math.atan2(f[0], f[2]);
            if (i > 0) { while (yaw - prev > Math.PI) yaw -= 2 * Math.PI; while (yaw - prev < -Math.PI) yaw += 2 * Math.PI; }
            raw2[i] = yaw;
            prev = yaw;
        }
        hY = new float[hn];
        int win = 20; // ±1 secundă
        for (int i = 0; i < hn; i++) {
            double s = 0; int c = 0;
            for (int j = Math.max(0, i - win); j <= Math.min(hn - 1, i + win); j++) { s += raw2[j]; c++; }
            hY[i] = (float) (s / c);
        }
    }

    private int index(double gt) {
        int lo = 0, hi = t.length - 1;
        while (lo < hi) { int m = (lo + hi) >>> 1; if (t[m] < gt) lo = m + 1; else hi = m; }
        return lo;
    }

    private float[] mat(int k) {
        float w = q[k * 4], x = q[k * 4 + 1], y = q[k * 4 + 2], z = q[k * 4 + 3];
        return new float[]{1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y),
                2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x),
                2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)};
    }

    /**
     * Matricea pentru momentul t (secunde din filmare).
     * follow = true: cadrul urmează lin direcția camerei (ca FlowState); false: privește mereu în aceeași direcție (Direction Lock).
     */
    public float[] at(double tSec, boolean follow) {
        float[] C = mul(mat(index(tSec + OFFSET)), L);
        if (!follow) return C;
        int i = (int) Math.max(0, Math.min(hY.length - 1, Math.round(tSec * 20)));
        double a = hY[i];
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        float[] rotY = {c, 0, s, 0, 1, 0, -s, 0, c};
        return mul(C, rotY);
    }

    private static float[] mul(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }

    private static float[] norm(float[] a) {
        float l = (float) Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (l < 1e-6f) l = 1;
        return new float[]{a[0] / l, a[1] / l, a[2] / l};
    }
}
