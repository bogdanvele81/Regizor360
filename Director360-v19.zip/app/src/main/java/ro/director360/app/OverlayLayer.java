package ro.director360.app;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

/** Stratul de deasupra filmului: arată textele și stickerele; cu degetul le muți, cu două degete le mărești și le rotești. */
public class OverlayLayer extends View {

    public interface Host {
        List<Overlays.Ov> overlays();
        long now();
        Overlays.Ov selected();
        void select(Overlays.Ov o);
        void changed(boolean done);
        /** Deep Track: aștept să fie atinsă o persoană */
        boolean picking();
        void pick(float x, float y);
    }

    private Host host;
    private Overlays.Ov drag;
    private float lx, ly, d0, a0, s0, r0;
    private boolean two, pickDown;

    public OverlayLayer(Context c) { super(c); }

    public void setHost(Host h) { host = h; }

    @Override
    protected void onDraw(Canvas c) {
        if (host == null) return;
        Overlays.drawAll(c, host.overlays(), host.now(), getWidth(), getHeight(), host.selected());
    }

    private Overlays.Ov hit(float x, float y) {
        List<Overlays.Ov> l = host.overlays();
        long T = host.now();
        for (int i = l.size() - 1; i >= 0; i--) {
            Overlays.Ov o = l.get(i);
            if (T < o.a || T >= o.b) continue;
            float[] b = Overlays.box(o, getWidth(), getHeight());
            float pad = 12 * getResources().getDisplayMetrics().density;
            if (Math.abs(x - b[0]) < b[2] / 2 + pad && Math.abs(y - b[1]) < b[3] / 2 + pad) return o;
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (host == null) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (host.picking()) { pickDown = true; return true; }
                drag = hit(e.getX(), e.getY());
                if (drag == null) {
                    if (host.selected() != null) { host.select(null); invalidate(); }
                    return false; // lasă atingerea pentru film (rotire 360)
                }
                host.select(drag);
                lx = e.getX(); ly = e.getY(); two = false;
                getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (drag != null && e.getPointerCount() == 2) {
                    two = true;
                    d0 = dist(e); a0 = angle(e); s0 = drag.s; r0 = drag.rot;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (drag == null) return false;
                if (two && e.getPointerCount() >= 2) {
                    drag.s = Math.max(0.3f, Math.min(4f, s0 * dist(e) / Math.max(1, d0)));
                    drag.rot = r0 + angle(e) - a0;
                } else if (!two) {
                    drag.x = Math.max(0.02f, Math.min(0.98f, drag.x + (e.getX() - lx) / getWidth()));
                    drag.y = Math.max(0.02f, Math.min(0.98f, drag.y + (e.getY() - ly) / getHeight()));
                    lx = e.getX(); ly = e.getY();
                }
                host.changed(false);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pickDown) { pickDown = false; if (e.getActionMasked() == MotionEvent.ACTION_UP) host.pick(e.getX() / getWidth(), e.getY() / getHeight()); return true; }
                if (drag != null) host.changed(true);
                drag = null; two = false;
                return true;
        }
        return drag != null;
    }

    private static float dist(MotionEvent e) { float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1); return (float) Math.sqrt(dx * dx + dy * dy); }
    private static float angle(MotionEvent e) { return (float) Math.atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0)); }
}
