package ro.director360.app;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Citește „coada” fișierelor Insta360 (ca în Regizor 360): modelul camerei, calibrarea lentilelor, direcția „sus” din senzor. */
public class Insp {
    public String model;
    /** calibrarea lentilelor normalizată la imaginea cu două cercuri: {cx, cy, rx, ry} */
    public float[] calA, calB;
    /** matricea care îndreaptă orizontul (rând după rând), sau null dacă poza nu are date de la senzor */
    public float[] level;

    private static final String MAGIC = "8db42d694ccc418790edff439fe026bf";

    public static Insp read(Context ctx, Uri uri) {
        Insp out = new Insp();
        try (ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
             FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
             FileChannel ch = fis.getChannel()) {
            long n = ch.size();
            if (n < 200) return out;
            ByteBuffer tail = ByteBuffer.allocate(72).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(tail, n - 72);
            byte[] tb = tail.array();
            if (!new String(tb, 40, 32, "ISO-8859-1").equals(MAGIC)) return out;
            long size = tail.getInt(32) & 0xFFFFFFFFL;
            if (size <= 72 || size > n || size > 30L * 1048576) return out;
            ByteBuffer t = ByteBuffer.allocate((int) size).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(t, n - size);
            byte[] b = t.array();
            String txt = new String(b, "ISO-8859-1");
            Matcher mm = Pattern.compile("Insta360 [A-Za-z0-9]+(?: [A-Za-z0-9]+)?").matcher(txt);
            out.model = mm.find() ? mm.group() : "Insta360";
            Matcher cm = Pattern.compile("(?:^|[^\\d.])(2(?:_-?\\d+(?:\\.\\d+)?){14,40})").matcher(txt);
            while (cm.find()) {
                String[] p = cm.group(1).split("_");
                if (p.length < 15) continue;
                double[] v = new double[p.length];
                try { for (int i = 0; i < p.length; i++) v[i] = Double.parseDouble(p[i]); } catch (Exception e) { continue; }
                if (v[13] > 1000 && v[14] > 1000 && v[13] >= v[14]) {
                    double W = v[13], H = v[14];
                    out.calA = new float[]{(float) (v[2] / W), (float) (v[3] / H), (float) (v[1] / W), (float) (v[1] / H)};
                    out.calB = new float[]{(float) (v[8] / W), (float) (v[9] / H), (float) (v[7] / W), (float) (v[7] / H)};
                    break;
                }
            }
            // giroscop/accelerometru X5: înregistrare 0x300, eșantioane de 20 de octeți (µs + 6 × u16)
            for (int i = b.length; i >= 6; i--) {
                if (b[i - 6] != 0x00 || b[i - 5] != 0x03) continue;
                long sz = t.getInt(i - 4) & 0xFFFFFFFFL;
                if (sz < 2000 || sz > i - 6 || sz % 20 != 0) continue;
                int s = (int) (i - 6 - sz);
                long a = t.getLong(s), c = t.getLong(s + 20);
                if (c - a < 500 || c - a > 2000) continue;
                int cnt = (int) (sz / 20), m = Math.min(cnt, 40);
                double ax = 0, ay = 0, az = 0;
                for (int k = 0; k < m; k++) {
                    int o = s + 20 * k + 8;
                    float r0 = (t.getShort(o) & 0xFFFF) - 32768, r1 = (t.getShort(o + 2) & 0xFFFF) - 32768, r2 = (t.getShort(o + 4) & 0xFFFF) - 32768;
                    ax += r2; ay += r0; az += r1;
                }
                double len = Math.sqrt(ax * ax + ay * ay + az * az);
                if (len > m * 500) {
                    float[] upL2 = {(float) (ax / len), (float) (ay / len), (float) (az / len)};
                    float[] up = norm(Video360View.mvec(Video360View.tr3(Video360View.lensO()), upL2));
                    float[] yD = {-up[0], -up[1], -up[2]};
                    float[] z0 = {0, 0, 1};
                    float d = yD[2];
                    z0 = norm(new float[]{z0[0] - d * yD[0], z0[1] - d * yD[1], z0[2] - d * yD[2]});
                    float[] xR = {yD[1] * z0[2] - yD[2] * z0[1], yD[2] * z0[0] - yD[0] * z0[2], yD[0] * z0[1] - yD[1] * z0[0]};
                    out.level = new float[]{xR[0], yD[0], z0[0], xR[1], yD[1], z0[1], xR[2], yD[2], z0[2]};
                }
                break;
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static float[] norm(float[] a) {
        float l = (float) Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (l < 1e-6f) l = 1;
        return new float[]{a[0] / l, a[1] / l, a[2] / l};
    }
}
