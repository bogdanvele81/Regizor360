package ro.director360.app;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/**
 * La salvare: din imaginea cu cele două lentile (LRV) face cadrul ales (Custom sau Tiny Planet),
 * iar la filmările normale taie pe format. În ambele cazuri pune filtrul de culoare.
 */
public class ReframeEffect implements GlEffect {

    private final boolean is360, planet;
    private final float yaw, pitch, fov;
    private final float[] look;
    private final int outW, outH;

    private Gyro gyro;
    private boolean follow;
    private double inSec;

    private Track track;
    private int art = 0;

    /** stil desenat (0 = fără), ca la poze */
    public ReframeEffect withArt(int a) { this.art = a; return this; }
    private Look.Recol recol;
    /** culoarea schimbată a unei haine (null = fără) */
    public ReframeEffect withRecolor(Look.Recol r) { this.recol = r == null ? null : r.copy(); return this; }

    /** Deep Track: cadrul urmărește persoana (cu giroscop, dacă există) */
    public ReframeEffect withTrack(Track t, Gyro g, long inMs) { this.track = t; this.gyro = g; this.inSec = inMs / 1000.0; return this; }

    /** stabilizare din giroscop: inMs = de unde începe bucata în filmare */
    public ReframeEffect withGyro(Gyro g, boolean follow, long inMs) { this.gyro = g; this.follow = follow; this.inSec = inMs / 1000.0; return this; }

    public ReframeEffect(boolean is360, float[] view, float[] look, int outW, int outH) {
        this.is360 = is360;
        this.yaw = view[0];
        this.pitch = view[1];
        this.fov = view[2];
        this.planet = view[3] > 0;
        this.look = look == null ? Look.NONE : look;
        this.outW = outW;
        this.outH = outH;
    }

    private static final String VS =
            "attribute vec4 aFramePosition;\n" +
            "varying vec2 vUv;\n" +
            "void main(){ gl_Position = aFramePosition; vUv = vec2(aFramePosition.x*0.5+0.5, 0.5-aFramePosition.y*0.5); }\n";

    private static String fs(boolean art, boolean rc) { return
            "precision highp float;\n" +
            "varying vec2 vUv;\n" +
            "uniform sampler2D uTex;\n" +
            "uniform mat3 uV;\n" +
            "uniform mat3 uO;\n" +
            "uniform vec2 uTan;\n" +
            "uniform vec4 uPA;\n" +
            "uniform vec4 uPB;\n" +
            "uniform float uFov;\n" +
            "uniform float uBlend;\n" +
            "uniform int uMode;\n" +
            "uniform int uFlat;\n" +
            "uniform vec2 uCrop;\n" +
            "uniform float uDns;\n" +
            "uniform vec2 uTexel;\n" +
            "uniform vec4 uA1;\n" +
            "uniform vec4 uA2;\n" +
            (art ? "uniform int uArt;\nuniform vec2 uPx;\n" : "") +
            Look.GLSL +
            "vec4 tex1(vec2 c){ return texture2D(uTex, vec2(c.x, 1.0 - c.y)); }\n" +
            "vec4 tex(vec2 c){ vec4 c0 = tex1(c); if(uDns<=0.0) return c0;\n" +
            "  float sg = mix(0.025,0.11,uDns); vec4 acc = c0; float ws = 1.0;\n" +
                  "  for(int j=-1;j<=1;j++) for(int i=-1;i<=1;i++){ if(i==0&&j==0) continue; vec2 o = vec2(float(i),float(j));\n" +
                  "    vec4 s = tex1(c+o*1.5*uTexel); vec3 df = s.rgb-c0.rgb; float w = exp(-dot(df,df)/(2.0*sg*sg)-dot(o,o)/4.4); acc += s*w; ws += w; }\n" +
                  "  return mix(c0, acc/ws, clamp(uDns*1.6,0.0,1.0)); }\n" +
            "vec3 dirAt(vec2 uv){ vec2 q = (uv*2.0-1.0)*uTan;\n" +
            "  if(uMode==1){ float r2 = dot(q,q); return uV*(vec3(2.0*q.x, 2.0*q.y, 1.0-r2)/(1.0+r2)); }\n" +
            "  return uV*normalize(vec3(q, 1.0)); }\n" +
            "vec3 dir(){ return dirAt(vUv); }\n" +
            "vec4 tex0(vec2 c, float b){ return tex1(c); }\n" +
            "vec2 lc(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov; return vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph)); }\n" +
            "vec3 stitch(vec3 d, float bias){ float ta; float tb; vec3 a = tex1(lc(uPA, d, ta)).rgb; vec3 b = tex1(lc(uPB, uO*d, tb)).rgb;\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0; return mix(b, a, w); }\n" +
            (art || rc ? Look.RC_GLSL : "") + (art ? Look.ART_GLSL : "") +
            "vec4 lens(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov;\n" +
            "  return tex(vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph))); }\n" +
            "void main(){ if(uFlat==1){ gl_FragColor = vec4(" + (art ? "art(" : "") + "grade(" + (rc ? "recol(" : "(") + "tex(vec2(0.5)+(vUv-vec2(0.5))*uCrop).rgb), uA1, uA2, vUv, 0)" + (art ? ", vUv)" : "") + ", 1.0); return; }\n" +
            "  vec3 d = dir(); float ta; float tb; vec4 a = lens(uPA, d, ta); vec4 b = lens(uPB, uO*d, tb);\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0;\n" +
            "  gl_FragColor = vec4(" + (art ? "art(" : "") + "grade(" + (rc ? "recol(" : "(") + "mix(b.rgb, a.rgb, w)), uA1, uA2, vUv, 0)" + (art ? ", vUv)" : "") + ", 1.0); }\n"; }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr) throws VideoFrameProcessingException {
        return new Program(useHdr);
    }

    private static float[] mul3(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }

    private class Program extends BaseGlShaderProgram {
        private final GlProgram gl;
        private float inAspect = 2f;
        private long firstPts = -1;
        private int inW = 1920, inH = 960;

        Program(boolean hdr) throws VideoFrameProcessingException {
            super(hdr, 1);
            try {
                gl = new GlProgram(VS, fs(false, recol != null)); // desenul se face în ArtEffect
                gl.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            inAspect = inputWidth / (float) Math.max(1, inputHeight);
            inW = inputWidth; inH = inputHeight;
            return new Size(outW, outH);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs) throws VideoFrameProcessingException {
            try {
                gl.use();
                gl.setSamplerTexIdUniform("uTex", inputTexId, 0);
                float ty = planet ? (float) Math.tan(Math.toRadians(fov / 4.0)) : (float) Math.tan(Math.toRadians(fov / 2.0));
                float tx = ty * outW / (float) outH;
                gl.setFloatsUniform("uTan", new float[]{tx, ty});
                float[] V = Video360View.viewMatrix(yaw, pitch);
                if (track != null) {
                    if (firstPts < 0) firstPts = presentationTimeUs;
                    double ts = inSec + (presentationTimeUs - firstPts) / 1e6;
                    V = track.viewAt(ts);
                    if (gyro != null) V = mul3(gyro.at(ts, false), V);
                } else if (gyro != null) {
                    if (firstPts < 0) firstPts = presentationTimeUs;
                    V = mul3(gyro.at(inSec + (presentationTimeUs - firstPts) / 1e6, follow), V);
                }
                gl.setFloatsUniform("uV", Video360View.colMajorPublic(V));
                gl.setFloatsUniform("uO", Video360View.colMajorPublic(Video360View.lensMatrix()));
                gl.setFloatsUniform("uPA", Video360View.calA());
                gl.setFloatsUniform("uPB", Video360View.calB());
                gl.setFloatUniform("uFov", Video360View.fovRad());
                float dns = is360 && !planet ? Video360View.autoDenoise(fov) : 0f;
                gl.setFloatUniform("uDns", dns);
                Look.Recol rc = recol;
                if (rc != null) {
                    gl.setIntUniform("uRc", 1);
                    gl.setFloatsUniform("uRcSrc", rc.s());
                    gl.setFloatsUniform("uRcDst", rc.d());
                    gl.setFloatUniform("uRcTol", rc.tol);
                }

                gl.setFloatsUniform("uTexel", new float[]{1f / Math.max(1, inW), 1f / Math.max(1, inH)});
                gl.setFloatUniform("uBlend", (float) Math.toRadians(4));
                gl.setIntUniform("uMode", planet ? 1 : 0);
                gl.setIntUniform("uFlat", is360 ? 0 : 1);
                float sa = outW / (float) outH;
                gl.setFloatsUniform("uCrop", new float[]{Math.min(1f, sa / inAspect), Math.min(1f, inAspect / sa)});
                gl.setFloatsUniform("uA1", Look.a1(look));
                gl.setFloatsUniform("uA2", Look.a2(look));
                gl.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
                GlUtil.checkGlError();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try { gl.delete(); } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
    }
}
