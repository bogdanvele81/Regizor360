package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/**
 * Editarea unei poze, ca în Regizor 360: Ce să facă (Cadru / Tiny Planet / Panoramă 360), Format, Unghi de vedere,
 * Rotire, filtre și reglaje cu sfaturi, Horizon Lock, Salvează poza.
 */
public class PhotoActivity extends AppCompatActivity {

    private Video360View view;
    private AspectFrame stage;
    private LinearLayout body;
    private SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private float dd;

    private Uri uri;
    private String name;
    private boolean is360, loaded = false, gyroOn = true, comparing = false;
    private float photoAspect = 4f / 3f;
    private int srcW = 0, srcH = 0;
    private Insp insp;
    private String mode = "frame"; // frame / planet / pano
    private String format = "16:9";
    private String pfilt = "none";
    /** stil desenat: 0 = fără */
    private int art = 0;
    /** cât de tare e filtrul / desenul (0…100), din coloana de reglaj */
    private int pfiltK = 100, artPct = 100;
    /** ce reglează coloana: "filt:vivid", "art:1", "adj:2" sau null */
    private String colKey;
    /** culoarea schimbată a hainei (null = fără) */
    private Look.Recol recol;
    private final float[] adj = new float[9];
    private int adjK = Look.CON;
    private String loadErr;
    private boolean full = false;
    private int boxH;
    /** poză cu o singură lentilă (1 = stânga, 2 = dreapta): se arată ca poză normală, din lentila cu imagine */
    private int single = 0;

    // sfaturi (ca în Regizor)
    private String tipId;
    private float[] tipUndo;
    private final java.util.Set<String> tipSkip = new java.util.HashSet<>();

    @Override
    protected void onCreate(Bundle b) {
        Th.apply(this);
        super.onCreate(b);
        setContentView(R.layout.activity_photo);
        dd = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        uri = Uri.parse(getIntent().getStringExtra("uri"));
        name = getIntent().getStringExtra("name");
        is360 = getIntent().getBooleanExtra("is360", false);
        single = getIntent().getIntExtra("lens", 0);
        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(Th.A), 9, 12, 0);
        ((TextView) findViewById(R.id.phBrand)).setText(brand);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        stage = findViewById(R.id.stage);
        body = findViewById(R.id.phBody);
        View box = findViewById(R.id.stageBox);
        boxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.34f);
        box.getLayoutParams().height = boxH;
        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        findViewById(R.id.btnFull).setOnClickListener(v -> setFull(!full));
        format = prefs.getString("photoFormat", "16:9");
        applyFormat();
        render();

        new Thread(() -> {
            Bitmap bmp = decode(uri, 6144, single > 0);
            Insp ip = is360 ? Insp.read(this, uri) : null;
            main.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (bmp == null) { render(); return; }
                photoAspect = bmp.getWidth() / (float) bmp.getHeight();
                if (photoAspect < 1.6f) { is360 = false; single = 0; }
                if (single > 0) {
                    // privim drept în lentila care are imagine, ca la o poză obișnuită
                    is360 = false;
                    view.setFlat(false, photoAspect);
                    view.setPhoto(bmp);
                    view.setView(single == 2 ? 180f : 0f, 0f, 100f, false);
                    loaded = true;
                    if (format.equals("orig")) format = "4:3";
                    applyFormat();
                    render();
                    if (land() && !full) setFull(true);
                    return;
                }
                insp = ip;
                if (is360 && insp != null) {
                    view.setCalib(insp.calA, insp.calB);
                    view.setLevel(gyroOn ? insp.level : null);
                }
                view.setFlat(!is360, photoAspect);
                view.setPhoto(bmp);
                loaded = true;
                if (!is360 && format.equals("16:9") && !prefs.contains("photoFormat")) format = "orig";
                applyFormat();
                render();
                if (land() && !full) setFull(true);
            });
        }).start();
    }

    // ---------------- citirea pozei (două metode) ----------------
    private Bitmap decode(Uri u, int maxW, boolean asFisheye) {
        Bitmap b = null;
        StringBuilder why = new StringBuilder();
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
            srcW = o.outWidth; srcH = o.outHeight;
            why.append("mărime ").append(o.outWidth).append("×").append(o.outHeight).append(", tip ").append(o.outMimeType);
            if (o.outWidth > 0) {
                int ss = 1;
                while (o.outWidth / ss > maxW) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = ss;
                try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
            }
        } catch (Throwable e) { why.append(" · ").append(e.getClass().getSimpleName()); }
        if (b == null) {
            // a doua metodă (merge și la poze HEIF / HDR)
            try {
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(getContentResolver(), u);
                b = android.graphics.ImageDecoder.decodeBitmap(src, (dec, info, s) -> {
                    int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                    srcW = w; srcH = h;
                    if (w > maxW) dec.setTargetSize(maxW, Math.max(1, h * maxW / w));
                    dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                });
            } catch (Throwable e) { why.append(" · a doua metodă: ").append(e.getClass().getSimpleName()).append(" ").append(e.getMessage()); }
        }
        if (b == null) {
            long size = -1;
            String head = "";
            try (InputStream in = getContentResolver().openInputStream(u)) {
                byte[] h = new byte[12];
                int n = in.read(h);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Math.max(0, n); i++) sb.append(String.format(Locale.ROOT, "%02X", h[i]));
                head = sb.toString();
            } catch (Throwable ignored) { }
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) size = c.getLong(0);
            } catch (Throwable ignored) { }
            String w0 = why.toString();
            if (w0.contains("No root") || w0.contains("FileNotFound") || w0.contains("IllegalArgument"))
                loadErr = "Nu ajung la card.\nCititorul de card s-a deconectat sau telefonul a pierdut legătura cu el. Scoate-l și conectează-l din nou, apoi deschide poza iar.\n\n(" + name + ")";
            else loadErr = "Nu pot citi poza.\n" + name + "\n" + (size > 0 ? (size / 1048576) + " MB · " : "") + why + "\nînceput: " + head;
            return null;
        }
        if ((!is360 && !asFisheye) || b.getWidth() < b.getHeight() * 1.6f) {
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                int or = new androidx.exifinterface.media.ExifInterface(in).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Throwable ignored) { }
            if (rot != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (rot != 180) { int t = srcW; srcW = srcH; srcH = t; }
            }
        }
        return b;
    }

    // ---------------- interfața ----------------
    private float ratio() {
        if (mode.equals("pano")) return 2f;
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "orig": return single > 0 ? 4f / 3f : photoAspect;
            case "4:3": return 4f / 3f;
            default: return 16f / 9f;
        }
    }

    private void applyFormat() { stage.setRatio(ratio()); }

    private TextView label(String t) {
        TextView l = new TextView(this);
        l.setText(t.toUpperCase(new Locale("ro")));
        l.setTextColor(0xFF9AA0A6);
        l.setTextSize(13);
        l.setLetterSpacing(0.08f);
        l.setPadding(0, (int) (18 * dd), 0, (int) (8 * dd));
        return l;
    }

    private TextView segBtn(String t, boolean on, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(16);
        b.setTextColor(0xFFF2F2F0);
        b.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        b.setBackgroundResource(on ? R.drawable.src_on : R.drawable.src_off);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout segRow(String[][] items, String cur, java.util.function.Consumer<String> pick, int cols) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                if (i > 0) rp.topMargin = (int) (10 * dd);
                col.addView(row, rp);
            }
            final String id = items[i][0];
            TextView b = segBtn(items[i][1], id.equals(cur), v -> pick.accept(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (52 * dd), 1f);
            if (i % cols > 0) lp.setMarginStart((int) (10 * dd));
            row.addView(b, lp);
        }
        // locuri goale pe ultimul rând, ca butoanele să aibă aceeași lățime
        int rem = items.length % cols;
        if (rem != 0) for (int k = rem; k < cols; k++) {
            View sp = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
            lp.setMarginStart((int) (10 * dd));
            row.addView(sp, lp);
        }
        return col;
    }

    private LinearLayout sliderRow(int min, int max, int val, String unit, java.util.function.IntConsumer on, View extra) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(val - min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Th.A));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Th.A));
        TextView v = new TextView(this);
        v.setText(val + unit);
        v.setTextColor(0xFFB9BCBF);
        v.setTextSize(15);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);
        v.setMinWidth((int) (52 * dd));
        v.setGravity(Gravity.END);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { int x = p + min; v.setText((x > 0 && unit.isEmpty() && min < 0 ? "+" : "") + x + unit); if (u) on.accept(x); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { render(); }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, (int) (44 * dd), 1f));
        r.addView(v);
        if (extra != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
            lp.setMarginStart((int) (10 * dd));
            r.addView(extra, lp);
        }
        return r;
    }

    private void render() {
        body.removeAllViews();
        // camera
        TextView cam = new TextView(this);
        String model = insp != null && insp.model != null ? insp.model : is360 ? "Insta360" : single > 0 ? "Insta360 · o singură lentilă" : "poză obișnuită";
        android.text.SpannableString cs = new android.text.SpannableString("cameră  " + model);
        cs.setSpan(new android.text.style.ForegroundColorSpan(0xFFF2F2F0), 8, cs.length(), 0);
        cam.setText(cs);
        cam.setTextColor(0xFF9AA0A6);
        cam.setTypeface(android.graphics.Typeface.MONOSPACE);
        cam.setTextSize(14);
        cam.setPadding(0, (int) (14 * dd), 0, (int) (8 * dd));
        body.addView(cam);
        // îndemn / eroare
        TextView hint = new TextView(this);
        hint.setBackgroundResource(R.drawable.hint_bg);
        hint.setTextColor(0xFFE6D9CF);
        hint.setTextSize(15);
        hint.setPadding((int) (14 * dd), (int) (12 * dd), (int) (14 * dd), (int) (12 * dd));
        if (loadErr != null) {
            hint.setText(loadErr + "\n\nFă o poză la ecranul ăsta și trimite-o lui Claude.");
            hint.setTextIsSelectable(true);
            body.addView(hint);
            return;
        }
        hint.setText(!loaded ? "Se încarcă poza…" : mode.equals("pano") ? "Panorama întreagă 360 (2:1). Trage stânga-dreapta ca să alegi ce e la mijloc, apoi salvează."
                : is360 ? "Trage cu degetul ca să alegi cadrul, apoi salvează."
                : single > 0 ? "Poză făcută cu o singură lentilă. Alege formatul; poți muta puțin cadrul cu degetul, apoi salvează."
                : "Alege formatul, apoi salvează. Poza se taie pe mijloc.");
        body.addView(hint);
        if (!loaded) return;

        if (is360) {
            body.addView(label("Ce să facă"));
            body.addView(segRow(new String[][]{{"frame", "Cadru"}, {"planet", "Tiny Planet"}, {"pano", "Panoramă 360"}}, mode, id -> {
                mode = id;
                view.setPano(id.equals("pano"));
                if (!id.equals("pano")) { boolean pl = id.equals("planet"); if (pl != view.isPlanet()) view.setPlanet(pl); }
                applyFormat();
                render();
            }, 2));
        }
        if (!mode.equals("pano")) {
            body.addView(label("Format"));
            String[][] fm = is360 ? new String[][]{{"16:9", "16:9"}, {"9:16", "9:16 Reels"}, {"1:1", "1:1"}}
                    : single > 0 ? new String[][]{{"4:3", "4:3"}, {"16:9", "16:9"}, {"9:16", "9:16 Reels"}, {"1:1", "1:1"}}
                    : new String[][]{{"orig", "Original"}, {"16:9", "16:9"}, {"9:16", "9:16 Reels"}, {"1:1", "1:1"}};
            body.addView(segRow(fm, format, id -> { format = id; prefs.edit().putString("photoFormat", id).apply(); applyFormat(); render(); }, fm.length));
        }
        if (is360 && !mode.equals("pano")) {
            body.addView(label("Unghi de vedere"));
            int fov = Math.round(view.getFov());
            body.addView(sliderRow(10, mode.equals("planet") ? 170 : 140, Math.max(10, Math.min(170, fov)), "°", x -> view.setFov(x), null));
            body.addView(label("Rotire"));
            MaterialButton rs = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            rs.setText("Îndreaptă");
            rs.setAllCaps(false);
            rs.setTextColor(0xFFF2F2F0);
            rs.setCornerRadius((int) (24 * dd));
            rs.setOnClickListener(v -> { view.setRoll(0); render(); });
            body.addView(sliderRow(-180, 180, Math.round(view.getRoll()), "°", x -> view.setRoll(x), rs));
        }
        body.addView(label("Ca desenată"));
        String[][] an = new String[Look.ART_NAMES.length][];
        for (int i = 0; i < an.length; i++) an[i] = new String[]{String.valueOf(i), Look.ART_NAMES[i]};
        body.addView(segRow(an, String.valueOf(art), id -> { art = Integer.parseInt(id); artPct = 100; applyLook(); render(); }, 3));
        addRecolor();
        addTip();
        addAdjust();
        if (is360) addHorizon();
        MaterialButton save = new MaterialButton(this);
        save.setText("Salvează poza");
        save.setAllCaps(false);
        save.setTextSize(17);
        save.setTypeface(null, android.graphics.Typeface.BOLD);
        save.setTextColor(0xFF1A0A00);
        save.setCornerRadius((int) (30 * dd));
        save.setOnClickListener(v -> save());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (60 * dd));
        sp.topMargin = (int) (22 * dd);
        body.addView(save, sp);
    }

    // ---------------- culoarea hainei ----------------
    private void addRecolor() {
        body.addView(label("Culoarea hainei"));
        if (recol == null) {
            TextView b = segBtn("Atinge haina pe poză", false, v -> pickCloth());
            body.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (52 * dd)));
            return;
        }
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        View was = new View(this);
        GradientDrawable wg = new GradientDrawable();
        wg.setColor(recol.src);
        wg.setCornerRadius(10 * dd);
        wg.setStroke((int) (1.5f * dd), 0x66FFFFFF);
        was.setBackground(wg);
        top.addView(was, new LinearLayout.LayoutParams((int) (40 * dd), (int) (40 * dd)));
        TextView ar = new TextView(this);
        ar.setText("  →  ");
        ar.setTextColor(0xFFF2F2F0);
        ar.setTextSize(18);
        top.addView(ar);
        View now = new View(this);
        GradientDrawable ng = new GradientDrawable();
        ng.setColor(recol.dst);
        ng.setCornerRadius(10 * dd);
        ng.setStroke((int) (1.5f * dd), 0x66FFFFFF);
        now.setBackground(ng);
        top.addView(now, new LinearLayout.LayoutParams((int) (40 * dd), (int) (40 * dd)));
        top.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView other = segBtn("Altă haină", false, v -> pickCloth());
        other.setPadding((int) (14 * dd), 0, (int) (14 * dd), 0);
        top.addView(other, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (44 * dd)));
        TextView off = segBtn("Scoate", false, v -> { recol = null; applyLook(); render(); });
        off.setPadding((int) (14 * dd), 0, (int) (14 * dd), 0);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (44 * dd));
        op.setMarginStart((int) (8 * dd));
        top.addView(off, op);
        body.addView(top);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Look.RC_COLORS.length; i++) {
            final int c = Look.RC_COLORS[i];
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setColor(c);
            g.setShape(GradientDrawable.OVAL);
            g.setStroke((int) ((c == recol.dst ? 3.5f : 1f) * dd), c == recol.dst ? Th.A : 0x66FFFFFF);
            sw.setBackground(g);
            sw.setContentDescription(Look.RC_NAMES[i]);
            sw.setOnClickListener(v -> { recol.dst = c; applyLook(); render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (44 * dd), (int) (44 * dd));
            lp.setMarginEnd((int) (10 * dd));
            row.addView(sw, lp);
        }
        hs.addView(row);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = (int) (12 * dd);
        body.addView(hs, hp);
        body.addView(label("Cât prinde din culoare"));
        body.addView(sliderRow(5, 45, Math.round(recol.tol * 100), "", x -> { if (recol != null) { recol.tol = x / 100f; applyLook(); } }, null));
    }

    private void pickCloth() {
        Toast.makeText(this, "Atinge acum haina pe poză", Toast.LENGTH_LONG).show();
        view.pickColorOnce(c -> {
            int dst = recol != null ? recol.dst : Look.RC_COLORS[0];
            float tol = recol != null ? recol.tol : 0.15f;
            recol = new Look.Recol(c, dst, tol);
            applyLook();
            if (!full) render();
        });
    }

    // ---------------- ecran întreg: poza pe tot ecranul, iconițe mici în lateral, cursorul peste poză ----------------
    /** ce e deschis din coloana de iconițe: null, "filt", "art" sau "adj:N" */
    private String railSel;
    private int sheetScroll;

    private void fillFullBar() { buildRail(); }

    private void buildRail() {
        FrameLayout box = findViewById(R.id.stageBox);
        View o1 = box.findViewWithTag("rail"), o2 = box.findViewWithTag("sheet");
        if (o2 != null) { View hs = o2.findViewWithTag("sheetScroll"); if (hs != null) sheetScroll = hs.getScrollX(); box.removeView(o2); }
        if (o1 != null) box.removeView(o1);
        fsItems.clear();
        thumbViews.clear();
        if (!full || !loaded) return;
        boolean l = land();
        int railW = dp(58);
        LinearLayout rail = new LinearLayout(this);
        rail.setTag("rail");
        rail.setOrientation(l ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        rail.setGravity(Gravity.CENTER);
        rail.setBackgroundColor(0x990A0B0D);
        rail.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout icons = new LinearLayout(this);
        icons.setOrientation(l ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        icons.setGravity(Gravity.CENTER);
        icons.addView(railIcon(R.drawable.ic_exit_full, "Ieși din ecran întreg", false, v -> setFull(false)), railLp(l));
        ImageView cmp = railIcon(R.drawable.a_cmp, "Ține apăsat ca să vezi originalul", false, null);
        cmp.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { comparing = true; applyLook(); }
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { comparing = false; applyLook(); }
            return true;
        });
        icons.addView(cmp, railLp(l));
        if (is360) {
            boolean pn = mode.equals("planet");
            icons.addView(railIcon(R.drawable.ic_planet, pn ? "Înapoi la cadru" : "Tiny Planet", pn, v -> {
                mode = mode.equals("planet") ? "frame" : "planet";
                view.setPano(false);
                boolean p2 = mode.equals("planet");
                if (p2 != view.isPlanet()) view.setPlanet(p2);
                thumbs.clear();
                buildRail();
            }), railLp(l));
        }
        View sep = new View(this);
        sep.setBackgroundColor(0x55FFFFFF);
        icons.addView(sep, l ? new LinearLayout.LayoutParams(dp(26), dp(1)) : new LinearLayout.LayoutParams(dp(1), dp(26)));
        icons.addView(railIcon(R.drawable.ic_filters, "Filtre", "filt".equals(railSel), v -> toggleRail("filt")), railLp(l));
        icons.addView(railIcon(R.drawable.ic_brush, "Desen animat, creion, benzi desenate, acuarelă", "art".equals(railSel), v -> toggleRail("art")), railLp(l));
        for (int i = 0; i < 9; i++) {
            final int k = i;
            icons.addView(railIcon(ICONS[i], Look.ADJ_NAMES[i], ("adj:" + i).equals(railSel), v -> toggleRail("adj:" + k)), railLp(l));
        }
        if (l) {
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.setVerticalScrollBarEnabled(false);
            sv.addView(icons);
            rail.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        } else {
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            hs.addView(icons);
            rail.addView(hs, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        ImageView sv2 = railIcon(R.drawable.ic_save_ok, "Salvează poza", false, v -> save());
        GradientDrawable sg = new GradientDrawable();
        sg.setShape(GradientDrawable.OVAL);
        sg.setColor(Th.A);
        sv2.setBackground(sg);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(46), dp(46));
        if (l) sp.topMargin = dp(6); else sp.setMarginStart(dp(6));
        rail.addView(sv2, sp);
        box.addView(rail, l ? new FrameLayout.LayoutParams(railW, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END)
                : new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, railW, Gravity.BOTTOM));
        if (railSel != null) buildSheet(box, l, railW);
    }

    private LinearLayout.LayoutParams railLp(boolean l) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(42), dp(42));
        if (l) lp.setMargins(0, dp(4), 0, dp(4)); else lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    private ImageView railIcon(int icon, String desc, boolean on, View.OnClickListener cl) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setContentDescription(desc);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(on ? 0xFF2A2C30 : 0xFF141518);
        if (on) g.setStroke(dp(2), Th.A);
        b.setBackground(g);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (cl != null) b.setOnClickListener(cl);
        return b;
    }

    private void toggleRail(String k) {
        railSel = k.equals(railSel) ? null : k;
        if (railSel != null && railSel.startsWith("adj:")) adjK = Integer.parseInt(railSel.substring(4));
        sheetScroll = 0;
        buildRail();
    }

    /** peste poză, jos: pozele mici (filtre / desen) și cursorul lung */
    private void buildSheet(FrameLayout box, boolean l, int railW) {
        LinearLayout sh = new LinearLayout(this);
        sh.setTag("sheet");
        sh.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xA60A0B0D);
        bg.setCornerRadius(dp(20));
        sh.setBackground(bg);
        sh.setPadding(dp(12), dp(10), dp(12), dp(8));
        boolean thumbsTab = railSel.equals("filt") || railSel.equals("art");
        if (thumbsTab) {
            fsTab = railSel;
            boolean art0 = railSel.equals("art");
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setTag("sheetScroll");
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            int n = art0 ? Look.ART_NAMES.length : Look.IDS.length;
            for (int i = 0; i < n; i++) {
                final String id = art0 ? String.valueOf(i) : Look.IDS[i];
                final String name = art0 ? Look.ART_NAMES[i] : Look.NAMES[i];
                final String key = railSel + ":" + id;
                LinearLayout it = new LinearLayout(this);
                it.setOrientation(LinearLayout.VERTICAL);
                it.setGravity(Gravity.CENTER_HORIZONTAL);
                FrameLayout fr = new FrameLayout(this);
                fr.setPadding(dp(2), dp(2), dp(2), dp(2));
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                GradientDrawable ph = new GradientDrawable();
                ph.setColor(0xFF1E2024);
                ph.setCornerRadius(dp(9));
                iv.setBackground(ph);
                iv.setClipToOutline(true);
                Bitmap b = thumbs.get(key);
                if (b != null) iv.setImageBitmap(b);
                fr.addView(iv, new FrameLayout.LayoutParams(dp(72), dp(46)));
                it.addView(fr);
                TextView lb = new TextView(this);
                lb.setText(name);
                lb.setTextSize(10.5f);
                lb.setSingleLine(true);
                lb.setEllipsize(android.text.TextUtils.TruncateAt.END);
                lb.setGravity(Gravity.CENTER);
                lb.setPadding(0, dp(2), 0, 0);
                it.addView(lb, new LinearLayout.LayoutParams(dp(76), ViewGroup.LayoutParams.WRAP_CONTENT));
                it.setTag(key);
                it.setOnClickListener(v -> {
                    if (art0) { art = Integer.parseInt(id); artPct = 100; }
                    else { pfilt = id; pfiltK = 100; System.arraycopy(Look.of(id, 100), 0, adj, 0, 9); tipReset(); thumbs.keySet().removeIf(k -> k.startsWith("art:")); }
                    applyLook();
                    buildRail();
                });
                fsItems.add(new View[]{it, fr, lb});
                thumbViews.put(key, iv);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(6));
                row.addView(it, lp);
                if (b == null) {
                    float[] lk = art0 ? adj.clone() : Look.of(id, 100);
                    int a = art0 ? Integer.parseInt(id) : 0;
                    view.capture(dp(72), dp(46), lk, a, bmp -> {
                        if (bmp == null) return;
                        thumbs.put(key, bmp);
                        ImageView t = thumbViews.get(key);
                        if (t != null) t.setImageBitmap(bmp);
                    });
                }
            }
            hs.addView(row);
            final int sx = sheetScroll;
            hs.post(() -> hs.scrollTo(sx, 0));
            sh.addView(hs);
        }
        // cursorul: pentru filtrul / desenul ales sau pentru reglaj
        String kind = railSel.startsWith("adj:") ? "adj" : railSel;
        boolean show = kind.equals("adj") || (kind.equals("filt") && !pfilt.equals("none")) || (kind.equals("art") && art > 0);
        if (show) {
            final String title;
            final int min, v;
            if (kind.equals("filt")) { title = Look.NAMES[Look.index(pfilt)]; min = 0; v = pfiltK; }
            else if (kind.equals("art")) { title = Look.ART_NAMES[art]; min = 0; v = artPct; }
            else { title = Look.ADJ_NAMES[adjK]; min = adjK == Look.DNS || adjK == Look.VIG ? 0 : -100; v = Math.round(adj[adjK]); }
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            r.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout lab = new LinearLayout(this);
            lab.setOrientation(LinearLayout.VERTICAL);
            TextView nm = new TextView(this);
            nm.setText(title);
            nm.setTextColor(0xFFB9BCBF);
            nm.setTextSize(11);
            nm.setSingleLine(true);
            lab.addView(nm);
            TextView val = new TextView(this);
            val.setTextColor(0xFFF2F2F0);
            val.setTextSize(17);
            val.setTypeface(null, android.graphics.Typeface.BOLD);
            val.setText(min < 0 ? sgn(v) : String.valueOf(v));
            lab.addView(val);
            r.addView(lab, new LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT));
            VSlider sl = new VSlider(this, false);
            sl.set(min, 100, v, (x, done) -> {
                val.setText(min < 0 ? sgn(x) : String.valueOf(x));
                if (kind.equals("filt")) { pfiltK = x; System.arraycopy(Look.of(pfilt, x), 0, adj, 0, 9); applyLook(); }
                else if (kind.equals("art")) { artPct = x; view.setArtStrength(x / 100f); }
                else { adj[adjK] = x; applyLook(); }
                if (done && !kind.equals("art")) thumbs.keySet().removeIf(k -> k.startsWith("art:"));
            });
            r.addView(sl, new LinearLayout.LayoutParams(0, dp(44), 1f));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (thumbsTab) rp.topMargin = dp(6);
            sh.addView(r, rp);
        }
        if (sh.getChildCount() == 0) return;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        if (l) lp.setMargins(dp(12), 0, railW + dp(12), dp(12));
        else lp.setMargins(dp(10), 0, dp(10), railW + dp(10));
        box.addView(sh, lp);
        markSel();
    }

    // ---------------- ecran întreg: poza mare, comenzile într-o bandă alături (nu peste poză) ----------------
    private String fsTab = "filt";
    private final java.util.Map<String, Bitmap> thumbs = new java.util.HashMap<>();
    private final java.util.Map<String, ImageView> thumbViews = new java.util.HashMap<>();
    private final java.util.List<View[]> fsItems = new java.util.ArrayList<>();

    private int dp(float v) { return Math.round(v * dd); }

    private boolean land() { return getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE; }

    private void setFull(boolean f) {
        full = f;
        colKey = null;
        if (!f) railSel = null;
        int v = f ? View.GONE : View.VISIBLE;
        findViewById(R.id.phHead).setVisibility(v);
        findViewById(R.id.phLine).setVisibility(v);
        findViewById(R.id.phScroll).setVisibility(v);
        findViewById(R.id.btnFull).setVisibility(v);
        layoutFull();
        buildCol();
        buildRail();
        getWindow().getDecorView().setSystemUiVisibility(f ? (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) : 0);
        setRequestedOrientation(f ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (f) { thumbs.clear(); fillFullBar(); } else render();
        if (f) Toast.makeText(this, is360 || single > 0 ? "Trage ca să muți cadrul · două degete = zoom · întoarce telefonul pentru poză lată" : "Întoarce telefonul pentru poză lată", Toast.LENGTH_LONG).show();
    }

    /** așază poza și banda: culcat = banda în dreapta, drept = banda dedesubt */
    private void layoutFull() {
        LinearLayout row = findViewById(R.id.fsRow);
        View box = findViewById(R.id.stageBox), panel = findViewById(R.id.fsPanel);
        if (full) {
            row.setOrientation(LinearLayout.VERTICAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            box.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            panel.setVisibility(View.GONE);
        } else {
            row.setOrientation(LinearLayout.VERTICAL);
            row.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, boxH);
            lp.setMargins(dp(14), dp(12), dp(14), 0);
            box.setLayoutParams(lp);
            panel.setVisibility(View.GONE);
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        // telefonul culcat = direct pe tot ecranul, cu comenzile mici în dreapta
        if (!full && loaded && c.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) { setFull(true); return; }
        if (full) { layoutFull(); thumbs.clear(); fillFullBar(); }
    }

    private ImageView roundIcon(int icon, String desc, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setContentDescription(desc);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF1E2024);
        b.setBackground(g);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        if (l != null) b.setOnClickListener(l);
        return b;
    }

    private View saveButton() {
        LinearLayout s = new LinearLayout(this);
        s.setOrientation(LinearLayout.HORIZONTAL);
        s.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Th.A);
        g.setCornerRadius(dp(22));
        s.setBackground(g);
        s.setPadding(dp(14), 0, dp(16), 0);
        ImageView ic = new ImageView(this);
        ic.setImageResource(R.drawable.ic_save_ok);
        s.addView(ic, new LinearLayout.LayoutParams(dp(18), dp(18)));
        TextView t = new TextView(this);
        t.setText("Salvează");
        t.setTextColor(0xFF1A0A00);
        t.setTextSize(14);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(dp(6), 0, 0, 0);
        s.addView(t);
        s.setContentDescription("Salvează poza");
        s.setOnClickListener(v -> save());
        return s;
    }

    /** coloana de reglaj: apare lângă poză (culcat) sau deasupra benzii (drept) pentru ce ai atins */
    private void buildCol() {
        LinearLayout row = findViewById(R.id.fsRow);
        View old = row.findViewWithTag("fsCol");
        if (old != null) row.removeView(old);
        if (!full || colKey == null) return;
        boolean l = land();
        String kind = colKey.substring(0, colKey.indexOf(':'));
        final String title;
        final int min, max, v;
        if (kind.equals("filt")) { title = Look.NAMES[Look.index(pfilt)]; min = 0; max = 100; v = pfiltK; }
        else if (kind.equals("art")) { title = Look.ART_NAMES[art]; min = 0; max = 100; v = artPct; }
        else { title = Look.ADJ_NAMES[adjK]; min = adjK == Look.DNS || adjK == Look.VIG ? 0 : -100; max = 100; v = Math.round(adj[adjK]); }
        LinearLayout col = new LinearLayout(this);
        col.setTag("fsCol");
        col.setBackgroundColor(0xFF16171A);
        col.setOrientation(l ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(6), dp(8), dp(6), dp(8));
        LinearLayout lab = new LinearLayout(this);
        lab.setOrientation(LinearLayout.VERTICAL);
        lab.setGravity(Gravity.CENTER);
        TextView nm = new TextView(this);
        nm.setText(title);
        nm.setTextColor(0xFF9AA0A6);
        nm.setTextSize(10.5f);
        nm.setGravity(Gravity.CENTER);
        nm.setMaxLines(2);
        lab.addView(nm);
        TextView val = new TextView(this);
        val.setTextColor(0xFFF2F2F0);
        val.setTextSize(15);
        val.setTypeface(null, android.graphics.Typeface.BOLD);
        val.setGravity(Gravity.CENTER);
        val.setText(min < 0 ? sgn(v) : String.valueOf(v));
        lab.addView(val);
        col.addView(lab, l ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                : new LinearLayout.LayoutParams(dp(78), ViewGroup.LayoutParams.MATCH_PARENT));
        VSlider sl = new VSlider(this, l);
        sl.set(min, max, v, (x, done) -> {
            val.setText(min < 0 ? sgn(x) : String.valueOf(x));
            if (kind.equals("filt")) { pfiltK = x; System.arraycopy(Look.of(pfilt, x), 0, adj, 0, 9); applyLook(); }
            else if (kind.equals("art")) { artPct = x; view.setArtStrength(x / 100f); }
            else { adj[adjK] = x; applyLook(); }
            if (done && !kind.equals("art")) thumbs.keySet().removeIf(k -> k.startsWith("art:"));
        });
        col.addView(sl, l ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
                : new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        ImageView xb = roundIcon(R.drawable.ic_close, "Închide reglajul", vv -> { colKey = null; buildCol(); });
        xb.setPadding(dp(9), dp(9), dp(9), dp(9));
        LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(36), dp(36));
        if (l) xp.topMargin = dp(6); else xp.setMarginStart(dp(6));
        col.addView(xb, xp);
        int idx = Math.max(0, row.indexOfChild(findViewById(R.id.fsPanel)));
        row.addView(col, idx, l ? new LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.MATCH_PARENT)
                : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
    }

    /** pozele mici: fiecare filtru / desen pus pe cadrul tău */
    private void fillThumbs(LinearLayout list, boolean l) {
        boolean art0 = fsTab.equals("art");
        int n = art0 ? Look.ART_NAMES.length : Look.IDS.length;
        int tw = l ? 78 : 76, th = l ? 52 : 50;
        LinearLayout row = null;
        for (int i = 0; i < n; i++) {
            final String id = art0 ? String.valueOf(i) : Look.IDS[i];
            final String name = art0 ? Look.ART_NAMES[i] : Look.NAMES[i];
            final String key = fsTab + ":" + id;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            FrameLayout fr = new FrameLayout(this);
            fr.setPadding(dp(2), dp(2), dp(2), dp(2));
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable ph = new GradientDrawable();
            ph.setColor(0xFF1E2024);
            ph.setCornerRadius(dp(10));
            iv.setBackground(ph);
            iv.setClipToOutline(true);
            Bitmap b = thumbs.get(key);
            if (b != null) iv.setImageBitmap(b);
            fr.addView(iv, new FrameLayout.LayoutParams(dp(tw), dp(th)));
            it.addView(fr);
            TextView lb = new TextView(this);
            lb.setText(name);
            lb.setTextSize(11);
            lb.setSingleLine(true);
            lb.setEllipsize(android.text.TextUtils.TruncateAt.END);
            lb.setGravity(Gravity.CENTER);
            lb.setPadding(0, dp(3), 0, 0);
            it.addView(lb, new LinearLayout.LayoutParams(dp(tw + 4), ViewGroup.LayoutParams.WRAP_CONTENT));
            it.setOnClickListener(v -> {
                if (art0) { art = Integer.parseInt(id); artPct = 100; colKey = art == 0 ? null : "art:" + art; }
                else { pfilt = id; pfiltK = 100; System.arraycopy(Look.of(id, 100), 0, adj, 0, 9); tipReset(); thumbs.keySet().removeIf(k -> k.startsWith("art:")); colKey = id.equals("none") ? null : "filt:" + id; }
                applyLook();
                markSel();
                buildCol();
            });
            fsItems.add(new View[]{it, fr, lb});
            it.setTag(key);
            thumbViews.put(key, iv);
            if (l) {
                if (i % 2 == 0) {
                    row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    rp.bottomMargin = dp(8);
                    list.addView(row, rp);
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                row.addView(it, lp);
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(8));
                list.addView(it, lp);
            }
            if (b == null) {
                float[] lk = art0 ? adj.clone() : Look.of(id, 100);
                int a = art0 ? Integer.parseInt(id) : 0;
                view.capture(dp(tw), dp(th), lk, a, bmp -> {
                    if (bmp == null) return;
                    thumbs.put(key, bmp);
                    ImageView t = thumbViews.get(key);
                    if (t != null) t.setImageBitmap(bmp);
                });
            }
        }
    }

    /** reglajele: simbolurile lor, apoi glisorul pentru cel ales */
    private void fillAdjTiles(LinearLayout list, boolean l) {
        LinearLayout row = null;
        for (int i = 0; i < 9; i++) {
            final int k = i;
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            FrameLayout fr = new FrameLayout(this);
            fr.setPadding(dp(2), dp(2), dp(2), dp(2));
            ImageView iv = new ImageView(this);
            iv.setImageResource(ICONS[i]);
            iv.setPadding(dp(10), dp(10), dp(10), dp(10));
            GradientDrawable g = new GradientDrawable();
            g.setColor(0xFF1E2024);
            g.setCornerRadius(dp(12));
            iv.setBackground(g);
            fr.addView(iv, new FrameLayout.LayoutParams(dp(44), dp(44)));
            it.addView(fr);
            TextView lb = new TextView(this);
            lb.setText(Look.ADJ_NAMES[i]);
            lb.setTextSize(10);
            lb.setSingleLine(true);
            lb.setEllipsize(android.text.TextUtils.TruncateAt.END);
            lb.setGravity(Gravity.CENTER);
            lb.setPadding(0, dp(2), 0, 0);
            it.addView(lb, new LinearLayout.LayoutParams(dp(54), ViewGroup.LayoutParams.WRAP_CONTENT));
            it.setTag("adj:" + i);
            it.setOnClickListener(v -> { adjK = k; colKey = "adj:" + k; markSel(); buildCol(); });
            fsItems.add(new View[]{it, fr, lb});
            if (l) {
                if (i % 3 == 0) {
                    row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    rp.bottomMargin = dp(6);
                    list.addView(row, rp);
                }
                row.addView(it, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            } else {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(6));
                list.addView(it, lp);
            }
        }
    }

    private View adjSlider() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        final int min = adjK == Look.DNS || adjK == Look.VIG ? 0 : -100;
        SeekBar sb = new SeekBar(this);
        sb.setMax(100 - min);
        sb.setProgress(Math.round(adj[adjK]) - min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Th.A));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Th.A));
        TextView val = new TextView(this);
        val.setTextColor(0xFFB9BCBF);
        val.setTextSize(12);
        val.setTypeface(android.graphics.Typeface.MONOSPACE);
        val.setText(sgn(adj[adjK]));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int pr, boolean u) { if (!u) return; adj[adjK] = pr + min; val.setText(sgn(adj[adjK])); applyLook(); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { thumbs.keySet().removeIf(k -> k.startsWith("art:")); }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(val);
        return r;
    }

    /** chenarul portocaliu pe ce e ales (fără să refac banda, ca să nu sară lista) */
    private void markSel() {
        for (View[] v : fsItems) {
            String key = (String) v[0].getTag();
            boolean on = key.equals("filt:" + pfilt) || key.equals("art:" + art) || key.equals("adj:" + adjK);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(12));
            if (on) g.setStroke(dp(2), Th.A);
            v[1].setBackground(g);
            TextView lb = (TextView) v[2];
            lb.setTextColor(on ? 0xFFF2F2F0 : 0xFF9AA0A6);
            lb.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
    }

    @Override
    public void onBackPressed() {
        if (full) { setFull(false); return; }
        super.onBackPressed();
    }

    // ---------------- reglaje ----------------
    private static final int[] ICONS = {R.drawable.a_exp, R.drawable.a_con, R.drawable.a_sh, R.drawable.a_hi, R.drawable.a_sat, R.drawable.a_warm, R.drawable.a_cla, R.drawable.a_dns, R.drawable.a_vig};

    private void applyLook() { view.setLook(comparing ? Look.NONE : adj.clone()); view.setArt(comparing ? 0 : art); view.setRecolor(comparing ? null : recol); view.setArtStrength(artPct / 100f); }

    private static String sgn(float v) { int i = Math.round(v); return i > 0 ? "+" + i : String.valueOf(i); }

    private ImageView miniTool(int icon, String desc, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setContentDescription(desc);
        b.setBackgroundResource(R.drawable.tile_off);
        int p = (int) (14 * dd);
        b.setPadding(p, p, p, p);
        b.setOnClickListener(l);
        return b;
    }

    private void addAdjust() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundResource(R.drawable.box_bg);
        int p = (int) (16 * dd);
        box.setPadding(p, p, p, p);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView nm = new TextView(this);
        nm.setText(Look.ADJ_NAMES[adjK].toUpperCase(new Locale("ro")));
        nm.setTextColor(0xFF9AA0A6);
        nm.setTextSize(13);
        nm.setLetterSpacing(0.08f);
        head.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        int ts = (int) (52 * dd);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ts, ts);
        tp.setMarginStart((int) (8 * dd));
        head.addView(miniTool(R.drawable.a_auto, "Auto: îmbunătățește singur", v -> { System.arraycopy(Look.AUTO, 0, adj, 0, 9); pfilt = "none"; tipReset(); applyLook(); render(); }), tp);
        ImageView cmp = miniTool(R.drawable.a_cmp, "Ține apăsat ca să vezi originalul", null);
        cmp.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { comparing = true; applyLook(); }
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { comparing = false; applyLook(); }
            return true;
        });
        head.addView(cmp, new LinearLayout.LayoutParams(tp));
        head.addView(miniTool(R.drawable.a_reset, "Resetează reglajele", v -> { java.util.Arrays.fill(adj, 0); pfilt = "none"; art = 0; recol = null; tipReset(); applyLook(); render(); }), new LinearLayout.LayoutParams(tp));
        box.addView(head);

        // filtrele
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout fl = new LinearLayout(this);
        fl.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Look.IDS.length; i++) {
            final String id = Look.IDS[i];
            boolean on = id.equals(pfilt);
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            GradientDrawable frame = new GradientDrawable();
            frame.setCornerRadius(16 * dd);
            if (on) frame.setStroke((int) (2.5f * dd), Th.A);
            it.setBackground(frame);
            it.setPadding((int) (3 * dd), (int) (3 * dd), (int) (3 * dd), (int) (8 * dd));
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, Look.SWATCH[i]);
            g.setCornerRadii(new float[]{14 * dd, 14 * dd, 14 * dd, 14 * dd, 0, 0, 0, 0});
            sw.setBackground(g);
            it.addView(sw, new LinearLayout.LayoutParams((int) (88 * dd), (int) (54 * dd)));
            TextView l = new TextView(this);
            l.setText(Look.NAMES[i]);
            l.setTextSize(15);
            l.setTextColor(0xFFF2F2F0);
            l.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, (int) (8 * dd), 0, 0);
            it.addView(l);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (12 * dd));
            it.setOnClickListener(v -> {
                pfilt = id;
                float[] f = Look.of(id, 100);
                System.arraycopy(f, 0, adj, 0, 9);
                tipReset();
                applyLook();
                render();
            });
            fl.addView(it, lp);
        }
        hs.addView(fl);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = (int) (14 * dd);
        box.addView(hs, hp);

        // reglajele: 5 pe rând
        LinearLayout row = null;
        for (int i = 0; i < 9; i++) {
            if (i % 5 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.topMargin = (int) (12 * dd);
                box.addView(row, rp);
            }
            final int k = i;
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.CENTER);
            t.setBackgroundResource(k == adjK ? R.drawable.tile_on : R.drawable.tile_off);
            t.setContentDescription(Look.ADJ_NAMES[k]);
            ImageView ic = new ImageView(this);
            ic.setImageResource(ICONS[k]);
            t.addView(ic, new LinearLayout.LayoutParams((int) (26 * dd), (int) (26 * dd)));
            TextView v = new TextView(this);
            v.setText(Math.round(adj[k]) != 0 ? sgn(adj[k]) : " ");
            v.setTextColor(Th.A);
            v.setTextSize(13);
            v.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
            v.setPadding(0, (int) (4 * dd), 0, 0);
            t.addView(v);
            t.setOnClickListener(x -> { adjK = k; render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (68 * dd), 1f);
            if (i % 5 > 0) lp.setMarginStart((int) (8 * dd));
            row.addView(t, lp);
        }
        for (int k = 9; k < 10; k++) { View sp = new View(this); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f); lp.setMarginStart((int) (8 * dd)); row.addView(sp, lp); }

        LinearLayout sr = sliderRow(adjK == Look.DNS || adjK == Look.VIG ? 0 : -100, 100, Math.round(adj[adjK]), "", x -> { adj[adjK] = x; applyLook(); }, null);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = (int) (12 * dd);
        box.addView(sr, sp);
    }

    // ---------------- sfaturi ----------------
    private String tipText(String id) {
        float[] A = adj;
        switch (id) {
            case "noise": {
                StringBuilder w = new StringBuilder();
                int n = 0;
                if (A[Look.CLA] > 25) { w.append("Claritate ").append(sgn(A[Look.CLA])); n++; }
                if (A[Look.EXP] > 30) { if (n > 0) w.append(" și "); w.append("Luminozitate ").append(sgn(A[Look.EXP])); n++; }
                return "Ai mărit mult poza. " + w + (n > 1 ? " scot" : " scoate") + " la iveală purecii (zgomotul). Sfatul meu: claritate cel mult +20" + (A[Look.EXP] > 30 ? ", luminozitate +25" : "") + " și reducere zgomot 35.";
            }
            case "burn": return "Cu Luminozitate " + sgn(A[Look.EXP]) + ", cerul și hainele albe se ard (devin alb complet). Sfatul meu: luminozitate +25 și Lumini −30, ca să păstrezi detaliile.";
            case "warm": return "Căldura " + sgn(A[Look.WARM]) + " colorează prea tare pielea" + (A[Look.WARM] > 0 ? " (iese portocalie)" : " (iese vânătă)") + ". Sfatul meu: " + (A[Look.WARM] > 0 ? "+20" : "−20") + ".";
            case "sat": return "Saturație " + sgn(A[Look.SAT]) + ": culorile sunt prea țipătoare și fețele arată nenatural. Sfatul meu: +25.";
            case "con": return "Contrast " + sgn(A[Look.CON]) + " înnegrește umbrele și fețele din umbră se pierd. Sfatul meu: contrast +30 și Umbre +25.";
            case "vig": return "Vignetare " + Math.round(A[Look.VIG]) + ": colțurile ies prea negre. Sfatul meu: 30.";
            default: return "Poza a ieșit prea întunecată. Sfatul meu: luminozitate −20 și Umbre +20.";
        }
    }

    private String findTip() {
        float[] A = adj;
        float fov = is360 ? view.getFov() : 90;
        String[] order = {"noise", "burn", "warm", "sat", "con", "vig", "dark"};
        for (String id : order) {
            if (tipSkip.contains(id)) continue;
            boolean w;
            switch (id) {
                case "noise": w = fov <= 55 && (A[Look.CLA] > 25 || A[Look.EXP] > 30) && A[Look.DNS] < 25; break;
                case "burn": w = A[Look.EXP] > 45 && A[Look.HI] > -20; break;
                case "warm": w = Math.abs(A[Look.WARM]) > 55; break;
                case "sat": w = A[Look.SAT] > 55; break;
                case "con": w = A[Look.CON] > 50 && A[Look.SH] < 15; break;
                case "vig": w = A[Look.VIG] > 65; break;
                default: w = A[Look.EXP] < -45 && A[Look.SH] < 20;
            }
            if (w) return id;
        }
        return null;
    }

    private void fixTip(String id) {
        float[] A = adj;
        switch (id) {
            case "noise": A[Look.CLA] = Math.min(A[Look.CLA], 20); if (A[Look.EXP] > 30) A[Look.EXP] = 25; A[Look.DNS] = Math.max(A[Look.DNS], 35); break;
            case "burn": A[Look.EXP] = 25; A[Look.HI] = -30; break;
            case "warm": A[Look.WARM] = A[Look.WARM] > 0 ? 20 : -20; break;
            case "sat": A[Look.SAT] = 25; break;
            case "con": A[Look.CON] = 30; A[Look.SH] = Math.max(A[Look.SH], 25); break;
            case "vig": A[Look.VIG] = 30; break;
            default: A[Look.EXP] = -20; A[Look.SH] = 20;
        }
    }

    private void tipReset() { tipId = null; tipUndo = null; tipSkip.clear(); }

    private void addTip() {
        if (mode.equals("pano")) return;
        String text;
        boolean applied = tipUndo != null;
        if (applied) text = "Am aplicat sfatul. Compară: poți reveni oricând la varianta ta.";
        else {
            tipId = findTip();
            if (tipId == null) return;
            text = tipText(tipId);
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2A1810);
        g.setCornerRadius(20 * dd);
        g.setStroke((int) (1.5f * dd), Th.A);
        box.setBackground(g);
        int p = (int) (16 * dd);
        box.setPadding(p, p, p, p);
        TextView t = new TextView(this);
        t.setText("💡  " + text);
        t.setTextColor(0xFFF2F2F0);
        t.setTextSize(16);
        box.addView(t);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, (int) (12 * dd), 0, 0);
        if (!applied) {
            TextView yes = segBtn("Fă cum zici tu", true, v -> { tipUndo = adj.clone(); fixTip(tipId); applyLook(); render(); });
            GradientDrawable yg = new GradientDrawable();
            yg.setColor(Th.A);
            yg.setCornerRadius(26 * dd);
            yes.setBackground(yg);
            yes.setTextColor(0xFF1A0A00);
            yes.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
            row.addView(yes, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd)));
        }
        TextView no = segBtn(applied ? "Înapoi la varianta mea" : "Lasă cum am făcut eu", false, v -> {
            if (tipUndo != null) { System.arraycopy(tipUndo, 0, adj, 0, 9); tipUndo = null; if (tipId != null) tipSkip.add(tipId); applyLook(); }
            else if (tipId != null) tipSkip.add(tipId);
            render();
        });
        GradientDrawable ng = new GradientDrawable();
        ng.setCornerRadius(26 * dd);
        ng.setStroke((int) (1 * dd), 0xFF3A4048);
        no.setBackground(ng);
        no.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
        if (!applied) np.setMarginStart((int) (10 * dd));
        row.addView(no, np);
        if (applied) {
            TextView ok = segBtn("Bine", false, v -> { tipUndo = null; if (tipId != null) tipSkip.add(tipId); render(); });
            ok.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
            op.setMarginStart((int) (10 * dd));
            row.addView(ok, op);
        }
        box.addView(row);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);
    }

    // ---------------- Horizon Lock ----------------
    private void addHorizon() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackgroundResource(R.drawable.box_bg);
        int p = (int) (18 * dd);
        box.setPadding(p, p, p, p);
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = new TextView(this);
        t1.setText("Horizon Lock (orizont drept)");
        t1.setTextColor(0xFFF2F2F0);
        t1.setTextSize(17);
        TextView t2 = new TextView(this);
        boolean has = insp != null && insp.level != null;
        t2.setText(has ? "îndreptat din senzorul camerei" : "poza nu are date de la senzor");
        t2.setTextColor(0xFF9AA0A6);
        t2.setTextSize(14);
        tx.addView(t1);
        tx.addView(t2);
        box.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setChecked(has && gyroOn);
        cb.setEnabled(has);
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(Th.A));
        cb.setOnCheckedChangeListener((b, on) -> { gyroOn = on; view.setLevel(on && insp != null ? insp.level : null); });
        box.addView(cb);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);
    }

    // ---------------- salvare ----------------
    private void save() {
        if (!loaded) { Toast.makeText(this, "Așteaptă să se încarce poza.", Toast.LENGTH_SHORT).show(); return; }
        comparing = false;
        applyLook();
        float r = ratio();
        int w, h;
        if (mode.equals("pano")) { w = 4096; h = 2048; }
        else {
            int longSide;
            if (is360) longSide = 3840;
            else {
                int cw = srcW, ch = srcH;
                if (photoAspect > r) cw = Math.round(ch * r); else ch = Math.round(cw / r);
                longSide = Math.min(4096, Math.max(cw, ch));
            }
            if (r >= 1) { w = longSide; h = Math.round(longSide / r); } else { h = longSide; w = Math.round(longSide * r); }
        }
        w = Math.max(2, w & ~1); h = Math.max(2, h & ~1);
        final int fw = w, fh = h;
        Toast.makeText(this, "Salvez poza…", Toast.LENGTH_SHORT).show();
        view.capture(fw, fh, bmp -> {
            if (bmp == null) { Toast.makeText(this, "Nu am reușit să salvez. Încearcă din nou.", Toast.LENGTH_LONG).show(); return; }
            new Thread(() -> {
                Uri dst = publish(bmp);
                main.post(() -> {
                    if (dst == null) { Toast.makeText(this, "Nu am reușit să salvez în Galerie.", Toast.LENGTH_LONG).show(); return; }
                    new AlertDialog.Builder(this)
                            .setTitle("Gata! Poza e salvată")
                            .setMessage("O găsești în Galerie, în albumul Director360." + (mode.equals("pano") ? " Fiind panoramă 360, o poți urca pe Facebook ca poză 360." : ""))
                            .setPositiveButton("Deschide", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setDataAndType(dst, "image/jpeg");
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(i); } catch (Exception ignored) { }
                            })
                            .setNeutralButton("Trimite", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType("image/jpeg");
                                i.putExtra(Intent.EXTRA_STREAM, dst);
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(Intent.createChooser(i, "Trimite poza")); } catch (Exception ignored) { }
                            })
                            .setNegativeButton("Închide", null)
                            .show();
                });
            }).start();
        });
    }

    private Uri publish(Bitmap bmp) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".jpg";
            v.put(MediaStore.Images.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Director360");
            v.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) return null;
            try (OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) return null;
                bmp.compress(Bitmap.CompressFormat.JPEG, 93, o);
            }
            v.clear();
            v.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            return dst;
        } catch (Exception e) {
            return null;
        }
    }

    @Override protected void onResume() { super.onResume(); view.onResume(); }
    @Override protected void onPause() { view.onPause(); super.onPause(); }
}
