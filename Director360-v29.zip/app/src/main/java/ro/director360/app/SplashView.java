package ro.director360.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Pornirea ca în Regizor 360: intrăm prin lentila camerei, logo-ul se rotește, camera se micșorează,
 * apare inelul portocaliu mare, numele, apoi „Your 360 Assistant” cu literele aruncate pe rând.
 */
public class SplashView extends View {

    public interface Done { void run(); }

    private final int ACCENT = Th.A;
    private static final int BG = 0xFF111315, INK = 0xFFF2F2F0, SOFT = 0xFFB9BCBF;
    private static final String TAG = "Your 360 Assistant";
    private static final long TOTAL = 6000, OUT = 500;

    private final float d;
    private long t0 = -1, outAt = -1;
    private Done done;
    private boolean finished = false;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();

    public SplashView(Context c) { this(c, null); }

    public SplashView(Context c, AttributeSet a) {
        super(c, a);
        d = getResources().getDisplayMetrics().density;
        setClickable(true);
        tp.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
    }

    public void setOnDone(Done x) { done = x; }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) hide();
        return true;
    }

    private void hide() { if (outAt < 0) { outAt = now(); invalidate(); } }

    private long now() { return android.os.SystemClock.uptimeMillis(); }

    // ---- timpi ----
    private static float clamp(float x) { return x < 0 ? 0 : x > 1 ? 1 : x; }

    /** curbă de animație cubic-bezier(x1,y1,x2,y2), ca în CSS */
    private static float bez(float t, float x1, float y1, float x2, float y2) {
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        float lo = 0, hi = 1, u = t;
        for (int i = 0; i < 24; i++) {
            u = (lo + hi) / 2;
            float x = 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
            if (x < t) lo = u; else hi = u;
        }
        return 3 * (1 - u) * (1 - u) * u * y1 + 3 * (1 - u) * u * u * y2 + u * u * u;
    }

    private static float prog(float ms, float delay, float dur) { return clamp((ms - delay) / dur); }

    @Override
    protected void onDraw(Canvas c) {
        if (t0 < 0) t0 = now();
        float ms = now() - t0;
        if (ms >= TOTAL) hide();
        float outK = 0;
        if (outAt >= 0) {
            outK = clamp((now() - outAt) / (float) OUT);
            if (outK >= 1) {
                if (!finished) { finished = true; setVisibility(GONE); if (done != null) done.run(); }
                return;
            }
        }
        int W = getWidth(), H = getHeight();
        c.save();
        float os = 1 + 0.08f * outK;
        c.scale(os, os, W / 2f, H / 2f);
        int alphaAll = Math.round(255 * (1 - outK));
        c.saveLayerAlpha(0, 0, W, H, alphaAll);

        // fundal
        float gr = Math.max(W, H) * 0.75f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        p.setShader(new RadialGradient(W / 2f, H * 0.42f, gr, new int[]{0xFF24170F, BG, BG}, new float[]{0, 0.65f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);

        // inelul mare din spate
        float rk = bez(prog(ms, 1700, 1800), .2f, .7f, .2f, 1f);
        if (rk > 0) {
            float size = Math.min(W, H) * 1.3f * (0.85f + 0.15f * rk);
            c.save();
            c.translate(W / 2f, H * 0.44f);
            c.rotate(-60 * (1 - rk));
            drawLogo(c, size, Math.round(255 * 0.13f * rk));
            c.restore();
        }

        // cameră + titlu, centrate pe verticală (cameră 210dp, spațiu 22dp, titlu)
        float h1 = 40 * d, tag = 17 * d;
        float blockH = 210 * d + 22 * d + h1 + 12 * d + tag * 1.3f;
        float top = (H - blockH) / 2f;
        float camX = W / 2f - 42 * d, camY = top;

        float zk = bez(prog(ms, 800, 1600), .65f, 0f, .25f, 1f);
        float sc = 12 - 11 * zk;
        float ox = camX + 42 * d, oy = camY + 43.4f * d;
        c.save();
        c.translate(ox, oy);
        c.scale(sc, sc);
        c.translate(-ox, -oy);
        drawCamera(c, camX, camY, 0.7f * d);
        // logo-ul peste lentilă
        float la = 1 - prog(ms, 1300, 600);
        if (la > 0) {
            float spin = -200 * (1 - bez(prog(ms, 0, 1400), .3f, 0f, .2f, 1f));
            c.save();
            c.translate(ox, oy);
            c.rotate(spin);
            drawLogo(c, 42 * d, Math.round(255 * la));
            c.restore();
        }
        c.restore();

        // titlul
        float tk = bez(prog(ms, 2200, 600), .25f, .1f, .25f, 1f);
        float ty = camY + 210 * d + 22 * d;
        if (tk > 0) {
            tp.setTextSize(h1);
            tp.setLetterSpacing(-0.02f);
            String a = "Director ", b = "360";
            float wa = tp.measureText(a), wb = tp.measureText(b);
            float x0 = W / 2f - (wa + wb) / 2f, base = ty + h1 * 0.85f + 12 * d * (1 - tk);
            tp.setAlpha(255);
            tp.setColor(INK);
            tp.setAlpha(Math.round(255 * tk));
            c.drawText(a, x0, base, tp);
            tp.setColor(ACCENT);
            tp.setAlpha(Math.round(255 * tk));
            c.drawText(b, x0 + wa, base, tp);
            tp.setLetterSpacing(0);
        }

        // „Your 360 Assistant” aruncat literă cu literă
        float tgy = ty + h1 + 12 * d + tag * 0.95f;
        tp.setTextSize(tag);
        float sp = 0.06f * tag;
        float[] wsz = new float[TAG.length()];
        float tot = 0;
        for (int i = 0; i < TAG.length(); i++) { wsz[i] = tp.measureText(TAG.substring(i, i + 1)) + sp; tot += wsz[i]; }
        float x = W / 2f - tot / 2f;
        int n = TAG.length();
        for (int k = 0; k < n; k++) {
            float lk = prog(ms, 2500 + k * 55, 1000);
            if (lk > 0 && TAG.charAt(k) != ' ') {
                float e = bez(lk, .16f, .84f, .3f, 1f);
                float op = lk < 0.25f ? 0.85f * (lk / 0.25f) : 0.85f + 0.15f * ((lk - 0.25f) / 0.75f);
                float cx = (k - (n - 1) / 2f) * 34 * d, cy = 120 * d;
                float s = 5 - 4 * e;
                float lx = x + wsz[k] / 2f, ly = tgy;
                c.save();
                c.translate(cx * (1 - e), cy * (1 - e));
                c.scale(s, s, lx, ly - tag * 0.35f);
                tp.setColor(k >= 5 && k <= 7 ? ACCENT : SOFT);
                tp.setAlpha(Math.round(255 * op));
                tp.setTextAlign(Paint.Align.CENTER);
                c.drawText(TAG.substring(k, k + 1), lx, ly, tp);
                tp.setTextAlign(Paint.Align.LEFT);
                c.restore();
            }
            x += wsz[k];
        }

        c.restore(); // layer
        c.restore();
        postInvalidateOnAnimation();
    }

    /** logo-ul: două săgeți pe un cerc (desenat în pătratul size×size, centrat în 0,0) */
    private void drawLogo(Canvas c, float size, int alpha) {
        float k = size / 100f;
        c.save();
        c.scale(k, k);
        c.translate(-50, -50);
        p.setShader(null);
        p.setColor(ACCENT);
        p.setAlpha(alpha);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(8);
        r.set(14, 14, 86, 86);
        c.drawArc(r, 194.96f, 150.08f, false, p);
        c.drawArc(r, 14.96f, 150.08f, false, p);
        p.setStyle(Paint.Style.FILL);
        path.reset(); path.moveTo(86.9f, 48.6f); path.lineTo(91f, 36.6f); path.lineTo(77.6f, 40.9f); path.close();
        c.drawPath(path, p);
        path.reset(); path.moveTo(13.1f, 51.4f); path.lineTo(9f, 63.4f); path.lineTo(22.4f, 59.1f); path.close();
        c.drawPath(path, p);
        c.restore();
    }

    /** camera 360 (ca un X5), desenată în coordonatele 120×300, scalată cu s, colțul stânga-sus în (x,y) */
    private void drawCamera(Canvas c, float x, float y, float s) {
        c.save();
        c.translate(x, y);
        c.scale(s, s);
        p.setStyle(Paint.Style.FILL);
        // umbra
        p.setShader(null); p.setColor(0x73000000);
        r.set(26, 287, 94, 297); c.drawOval(r, p);
        // corpul
        p.setColor(0xFF000000);
        p.setShader(new LinearGradient(28, 0, 92, 0, new int[]{0xFF2B2F34, 0xFF16181B, 0xFF0B0C0E}, new float[]{0, .45f, 1}, Shader.TileMode.CLAMP));
        r.set(28, 16, 92, 286); c.drawRoundRect(r, 28, 28, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(0xFF3A4048);
        c.drawRoundRect(r, 28, 28, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x0DFFFFFF); r.set(31, 20, 37, 270); c.drawRoundRect(r, 3, 3, p);
        // lentila
        p.setColor(0xFF0A0B0D); c.drawCircle(60, 62, 31, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(0xFF3A4048); c.drawCircle(60, 62, 31, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        p.setShader(new RadialGradient(60 - 27 + 0.38f * 54, 62 - 27 + 0.34f * 54, 0.75f * 54, new int[]{0xFF5B7489, 0xFF1C2A36, 0xFF06090C, 0xFF000000}, new float[]{0, .35f, .8f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(60, 62, 27, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.2f); p.setColor(0xD9FF6A2B); c.drawCircle(60, 62, 22, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF020304); c.drawCircle(60, 62, 11, p);
        p.setColor(0xFF0D1A24); c.drawCircle(60, 62, 5, p);
        c.save(); c.rotate(-30, 50, 51); p.setColor(0x59FFFFFF); r.set(42, 46, 58, 56); c.drawOval(r, p); c.restore();
        p.setColor(0x40FFFFFF); c.drawCircle(68, 72, 2, p);
        // ecranul
        p.setColor(0xFF000000);
        p.setShader(new LinearGradient(0, 112, 0, 164, 0xFF2A3B4A, 0xFF0E1419, Shader.TileMode.CLAMP));
        r.set(40, 112, 80, 164); c.drawRoundRect(r, 6, 6, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(0xFF2A2E33); c.drawRoundRect(r, 6, 6, p);
        p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(2); p.setColor(0xCCFF6A2B);
        c.drawLine(44, 150, 56, 150, p); c.drawLine(44, 156, 64, 156, p);
        // butonul
        p.setStyle(Paint.Style.FILL); p.setColor(0xFF1F2226); c.drawCircle(60, 190, 8, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.6f); p.setColor(ACCENT); c.drawCircle(60, 190, 8, p);
        // grila difuzorului
        p.setStrokeWidth(2.5f); p.setColor(0xFF24282C);
        c.drawLine(46, 240, 74, 240, p); c.drawLine(46, 248, 74, 248, p); c.drawLine(46, 256, 74, 256, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStyle(Paint.Style.FILL);
        c.restore();
    }
}
