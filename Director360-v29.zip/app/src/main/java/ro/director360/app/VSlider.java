package ro.director360.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** glisor simplu, vertical (sus = mai mult) sau orizontal, cu liniuță la zero când are și minus */
public class VSlider extends View {
    public interface OnChange { void changed(int v, boolean done); }

    private final boolean vertical;
    private int min, max, val;
    private OnChange cb;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public VSlider(Context c, boolean vertical) {
        super(c);
        this.vertical = vertical;
        d = c.getResources().getDisplayMetrics().density;
    }

    public void set(int min, int max, int val, OnChange cb) {
        this.min = min; this.max = max; this.val = Math.max(min, Math.min(max, val)); this.cb = cb;
        invalidate();
    }

    private float frac(int v) { return (v - min) / (float) Math.max(1, max - min); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), r = 3 * d, k = 11 * d;
        float a0, a1, cx;
        if (vertical) { a0 = h - k; a1 = k; cx = w / 2f; } else { a0 = k; a1 = w - k; cx = h / 2f; }
        float pos = a0 + (a1 - a0) * frac(val), zero = a0 + (a1 - a0) * (min < 0 ? frac(0) : 0f);
        p.setColor(0xFF3A3D43);
        if (vertical) c.drawRoundRect(new RectF(cx - r, a1, cx + r, a0), r, r, p);
        else c.drawRoundRect(new RectF(a0, cx - r, a1, cx + r), r, r, p);
        p.setColor(Th.A);
        float s = Math.min(pos, zero), e = Math.max(pos, zero);
        if (vertical) c.drawRoundRect(new RectF(cx - r, s, cx + r, e), r, r, p);
        else c.drawRoundRect(new RectF(s, cx - r, e, cx + r), r, r, p);
        if (min < 0) {
            p.setColor(0xFF9AA0A6);
            p.setStrokeWidth(2 * d);
            if (vertical) c.drawLine(cx - 8 * d, zero, cx + 8 * d, zero, p);
            else c.drawLine(zero, cx - 8 * d, zero, cx + 8 * d, p);
        }
        p.setColor(0xFFF2F2F0);
        if (vertical) c.drawCircle(cx, pos, 10 * d, p); else c.drawCircle(pos, cx, 10 * d, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float k = 11 * d;
        float f = vertical ? (getHeight() - k - e.getY()) / Math.max(1f, getHeight() - 2 * k)
                : (e.getX() - k) / Math.max(1f, getWidth() - 2 * k);
        f = Math.max(0f, Math.min(1f, f));
        int v = Math.round(min + f * (max - min));
        if (min < 0 && Math.abs(v) <= (max - min) / 50) v = 0; // se lipește ușor de zero
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) getParent().requestDisallowInterceptTouchEvent(true);
        boolean done = act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL;
        if (v != val || done) {
            val = v;
            invalidate();
            if (cb != null) cb.changed(v, done);
        }
        return true;
    }
}
