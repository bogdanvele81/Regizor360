package ro.director360.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Afișează o filmare 360 (cele două lentile una lângă alta, ca în fișierul LRV) ca imagine normală:
 * tragi cu degetul ca să alegi cadrul, cu două degete mărești, atingi de două ori pentru Tiny Planet.
 */
public class Video360View extends GLSurfaceView implements GLSurfaceView.Renderer {

    public interface SurfaceReady { void run(Surface s); }

    private SurfaceReady onSurface;
    private SurfaceTexture st;
    private Surface surface;
    private int tex, prog;
    private final float[] stMtx = new float[16];
    private FloatBuffer quad;
    private volatile float yaw = 0f, pitch = 0f, fovV = 80f;
    private volatile boolean planet = false;
    /** filmare normală (nu 360): se afișează direct, tăiată pe formatul ales */
    private volatile boolean flat = false;
    private volatile float videoAspect = 16f / 9f;
    private int vw = 1, vh = 1;
    private final Handler main = new Handler(Looper.getMainLooper());
    /** poză (în loc de film): textură obișnuită */
    private android.graphics.Bitmap pendingBmp, keepBmp;
    private boolean photoMode = false;
    private int tex2 = 0, prog2 = 0;
    private static final float[] FLIPY = {1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1};

    public interface Captured { void run(android.graphics.Bitmap b); }

    // calibrarea lentilelor X5 (din fabrică), raportată la imaginea cu două cercuri
    private static final float[] PA = {2690.67f / 10752f, 2693.78f / 5376f, 2640.44f / 10752f, 2640.44f / 5376f};
    private static final float[] PB = {8066.88f / 10752f, 2690.65f / 5376f, 2650.62f / 10752f, 2650.62f / 5376f};
    private static final float FOV = (float) Math.toRadians(98.5);

    private final ScaleGestureDetector scale;
    private final GestureDetector gest;
    private float lastX, lastY;
    private boolean dragging;

    public Video360View(Context c) {
        super(c);
        setEGLContextClientVersion(3);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (flat) return true;
                fovV = Math.max(12f, Math.min(planet ? 170f : 125f, fovV / d.getScaleFactor()));
                requestRender();
                return true;
            }
        });
        gest = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) { if (!flat) setPlanet(!planet); return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                Picked p = pickOnce; if (p == null) return false;
                pickOnce = null; pickAt(e.getX(), e.getY(), p); return true; }
        });
    }

    /** afișează o poză; poate fi apelat oricând */
    public void setPhoto(android.graphics.Bitmap b) {
        keepBmp = b;
        queueEvent(() -> { pendingBmp = b; photoMode = true; });
        requestRender();
    }

    /** face o poză din ce se vede, la mărimea cerută (pentru salvare) */
    public void capture(int w, int h, Captured cb) { capture(w, h, null, -1, cb); }

    private float[] ovLook; private int ovArt = -1;

    /** ca mai sus, dar cu alt filtru / alt desen doar pentru poza asta (pozele mici din ecranul întreg) */
    public void capture(int w, int h, float[] lk, int a, Captured cb) {
        queueEvent(() -> {
            ovLook = lk; ovArt = a;
            android.graphics.Bitmap out = null;
            try {
                int[] fb = new int[1], rt = new int[1];
                GLES20.glGenFramebuffers(1, fb, 0);
                GLES20.glGenTextures(1, rt, 0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, rt[0]);
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0]);
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, rt[0], 0);
                int ow = vw, oh = vh;
                vw = w; vh = h;
                GLES20.glViewport(0, 0, w, h);
                draw(true);
                ByteBuffer buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder());
                GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf);
                vw = ow; vh = oh;
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                GLES20.glViewport(0, 0, vw, vh);
                GLES20.glDeleteFramebuffers(1, fb, 0);
                GLES20.glDeleteTextures(1, rt, 0);
                android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888);
                buf.position(0);
                b.copyPixelsFromBuffer(buf);
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.preScale(1, -1);
                out = android.graphics.Bitmap.createBitmap(b, 0, 0, w, h, m, false);
                b.recycle();
            } catch (Throwable e) {
                out = null;
            }
            ovLook = null; ovArt = -1;
            final android.graphics.Bitmap r = out;
            main.post(() -> cb.run(r));
            requestRender();
        });
    }

    public static int maxTex() {
        int[] v = new int[1];
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, v, 0);
        return v[0];
    }

    private volatile float[] look = Look.NONE;
    private int texW = 1, texH = 1;
    private volatile int vidW = 1920, vidH = 960;
    /** mărimea filmului (pentru curățarea purecilor) */
    public void setVideoSize(int w, int h) { if (w > 0 && h > 0) { vidW = w; vidH = h; } }
    /** cât curăț purecii la un unghi de vedere: nimic peste 45°, mult la 12° */
    public static float autoDenoise(float fov) { return Math.max(0f, Math.min(0.9f, (60f - fov) / 40f)); }
    private volatile float roll = 0f;
    private volatile boolean pano = false;
    private volatile float[] level = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    private volatile float[] calA, calB;

    /** panorama întreagă 360 (imagine de 2:1) */
    public void setPano(boolean p) { pano = p; requestRender(); }
    public boolean isPano() { return pano; }
    /** rotirea cadrului în jurul privirii (grade) */
    public void setRoll(float r) { roll = r; requestRender(); }
    public float getRoll() { return roll; }
    public float getFov() { return fovV; }
    public void setFov(float f) { fovV = f; requestRender(); }
    public interface LevelProvider { float[] get(); }
    private volatile LevelProvider viewProvider;
    /** Deep Track: privirea întreagă (rând după rând) se cere la fiecare cadru; null = cea obișnuită */
    public void setViewProvider(LevelProvider p) { viewProvider = p; requestRender(); }
    /** privirea folosită acum (pentru atingerea unei persoane) */
    public float[] currentView() { return view(); }
    public float[] tanNow() {
        float ty = planet ? (float) Math.tan(Math.toRadians(fovV / 4.0)) : (float) Math.tan(Math.toRadians(fovV / 2.0));
        return new float[]{ty * vw / (float) vh, ty};
    }
    private volatile LevelProvider levelProvider;
    /** stabilizarea la filme: matricea se cere la fiecare cadru desenat */
    public void setLevelProvider(LevelProvider p) { levelProvider = p; requestRender(); }

    /** îndreptarea orizontului (din senzorul camerei); matrice rând după rând, null = fără */
    public void setLevel(float[] m) { level = m == null ? new float[]{1, 0, 0, 0, 1, 0, 0, 0, 1} : m; requestRender(); }
    /** calibrarea lentilelor citită din fișier (normalizată), null = cea din fabrică */
    public void setCalib(float[] a, float[] b) { calA = a; calB = b; requestRender(); }
    static float[] lensO() { return O_L1toL2; }
    static float[] tr3(float[] a) { return new float[]{a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8]}; }
    static float[] mvec(float[] a, float[] v) { return new float[]{a[0] * v[0] + a[1] * v[1] + a[2] * v[2], a[3] * v[0] + a[4] * v[1] + a[5] * v[2], a[6] * v[0] + a[7] * v[1] + a[8] * v[2]}; }

    /** filtrul de culoare (vezi Look) */
    public interface Picked { void got(int rgb); }
    private volatile Picked pickOnce;
    /** următoarea atingere pe imagine alege o culoare (fără filtre și desen) */
    public void pickColorOnce(Picked p) { pickOnce = p; }
    private volatile Look.Recol recol;
    public void setRecolor(Look.Recol r) { recol = r; requestRender(); }
    private boolean neutral = false;

    private void pickAt(float x, float y, Picked cb) {
        final Handler h = new Handler(Looper.getMainLooper());
        queueEvent(() -> {
            int col = 0;
            try {
                neutral = true;
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                GLES20.glViewport(0, 0, vw, vh);
                draw(false);
                int px = Math.max(2, Math.min(vw - 3, Math.round(x))), py = Math.max(2, Math.min(vh - 3, vh - 1 - Math.round(y)));
                java.nio.ByteBuffer b = java.nio.ByteBuffer.allocateDirect(5 * 5 * 4).order(java.nio.ByteOrder.nativeOrder());
                GLES20.glReadPixels(px - 2, py - 2, 5, 5, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, b);
                int r = 0, g = 0, bl = 0;
                for (int i = 0; i < 25; i++) { r += b.get(i * 4) & 255; g += b.get(i * 4 + 1) & 255; bl += b.get(i * 4 + 2) & 255; }
                col = 0xFF000000 | ((r / 25) << 16) | ((g / 25) << 8) | (bl / 25);
            } catch (Exception ignored) { }
            neutral = false;
            requestRender();
            final int c = col;
            h.post(() -> cb.got(c));
        });
    }

    /** stil desenat: 0 = fără, 1 = desen animat, 2 = creion, 3 = benzi desenate, 4 = acuarelă */
    private volatile int art = 0;
    public void setArt(int a) { art = a; requestRender(); }
    private volatile float artK = 1f;
    /** cât de tare e desenul (0…1) */
    public void setArtStrength(float k) { artK = k; requestRender(); }
    public void setLook(float[] l) { look = l == null ? Look.NONE : l; requestRender(); }

    public void setOnSurface(SurfaceReady r) { onSurface = r; if (surface != null) r.run(surface); }

    public boolean isPlanet() { return planet; }

    public void setFlat(boolean f, float aspect) { flat = f; if (aspect > 0) videoAspect = aspect; requestRender(); }

    public boolean isFlat() { return flat; }

    public void setPlanet(boolean p) {
        planet = p;
        if (p) { pitch = 90f; fovV = 150f; } else { pitch = 0f; fovV = 80f; }
        requestRender();
    }

    public void resetView() { yaw = 0f; setPlanet(false); }

    public float[] getView() { return new float[]{yaw, pitch, fovV, planet ? 1 : 0}; }

    public void setView(float y, float p, float f, boolean pl) { yaw = y; pitch = p; fovV = f; planet = pl; requestRender(); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        gest.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX(); lastY = e.getY(); dragging = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !flat && e.getPointerCount() == 1 && !scale.isInProgress()) {
                    float dx = e.getX() - lastX, dy = e.getY() - lastY;
                    float k = fovV / Math.max(1, getHeight());
                    yaw -= dx * k;
                    pitch += dy * k;
                    pitch = Math.max(-90f, Math.min(90f, pitch));
                    requestRender();
                }
                lastX = e.getX(); lastY = e.getY();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                break;
        }
        return true;
    }

    private static final String VS =
            "attribute vec2 aPos;\n" +
            "varying vec2 vUv;\n" +
            "void main(){ vUv = vec2(aPos.x*0.5+0.5, 0.5-aPos.y*0.5); gl_Position = vec4(aPos,0.0,1.0); }\n";

    /** shaderul: video = textură externă; poză = textură obișnuită, cu claritate și reducere de zgomot */
    private static String fs(boolean photo) {
        return (photo ? "" : "#extension GL_OES_EGL_image_external : require\n") +
            "precision highp float;\n" +
            "varying vec2 vUv;\n" +
            (photo ? "uniform sampler2D uTex;\n" : "uniform samplerExternalOES uTex;\n") +
            "uniform mat4 uMtx;\n" +
            "uniform mat3 uV;\n" +
            "uniform mat3 uO;\n" +
            "uniform vec2 uTan;\n" +
            "uniform vec4 uPA;\n" +
            "uniform vec4 uPB;\n" +
            "uniform float uFov;\n" +
            "uniform float uBlend;\n" +
            "uniform int uMode;\n" +
            "uniform int uFlat;\n" +
            "uniform vec2 uCrop;\n" +
            "uniform vec4 uA1;\n" +
            "uniform vec4 uA2;\n" +
            "uniform float uDns;\n" +
            "uniform vec2 uTexel;\n" +
            "uniform int uArt;\n" +
            "uniform vec2 uPx;\n" +
            Look.GLSL +
            (photo
                ? "vec4 tex0(vec2 c, float b){ return texture2D(uTex, c, b); }\n" +
                  "vec4 tex(vec2 c){ vec4 c0 = texture2D(uTex, c); if(uDns<=0.0) return c0;\n" +
                  "  float sg = mix(0.03,0.13,uDns); vec4 acc = c0; float ws = 1.0;\n" +
                  "  for(int j=-2;j<=2;j++) for(int i=-2;i<=2;i++){ if(i==0&&j==0) continue; vec2 o = vec2(float(i),float(j));\n" +
                  "    vec4 s = texture2D(uTex, c+o*1.2*uTexel); vec3 df = s.rgb-c0.rgb; float w = exp(-dot(df,df)/(2.0*sg*sg)-dot(o,o)/6.0); acc += s*w; ws += w; }\n" +
                  "  return mix(c0, acc/ws, clamp(uDns*1.5,0.0,1.0)); }\n"
                : "vec4 tex1(vec2 c){ vec2 s = (uMtx*vec4(c.x, 1.0-c.y, 0.0, 1.0)).xy; return texture2D(uTex, s); }\n" +
                  "vec4 tex(vec2 c){ vec4 c0 = tex1(c); if(uDns<=0.0) return c0;\n" +
                  "  float sg = mix(0.025,0.11,uDns); vec4 acc = c0; float ws = 1.0;\n" +
                  "  for(int j=-1;j<=1;j++) for(int i=-1;i<=1;i++){ if(i==0&&j==0) continue; vec2 o = vec2(float(i),float(j));\n" +
                  "    vec4 s = tex1(c+o*1.5*uTexel); vec3 df = s.rgb-c0.rgb; float w = exp(-dot(df,df)/(2.0*sg*sg)-dot(o,o)/4.4); acc += s*w; ws += w; }\n" +
                  "  return mix(c0, acc/ws, clamp(uDns*1.6,0.0,1.0)); }\n" +
                  "vec4 tex0(vec2 c, float b){ return tex1(c); }\n") +
            "vec3 dirAt(vec2 uv){ vec2 q = (uv*2.0-1.0)*uTan;\n" +
            "  if(uMode==2){ float lon = (uv.x*2.0-1.0)*3.14159265, lat = (uv.y*2.0-1.0)*1.5707963; return uV*vec3(cos(lat)*sin(lon), sin(lat), cos(lat)*cos(lon)); }\n" +
            "  if(uMode==1){ float r2 = dot(q,q); return uV*(vec3(2.0*q.x, 2.0*q.y, 1.0-r2)/(1.0+r2)); }\n" +
            "  return uV*normalize(vec3(q, 1.0)); }\n" +
            "vec3 dir(){ return dirAt(vUv); }\n" +
            "vec2 lc(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov; return vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph)); }\n" +
            "vec3 stitch(vec3 d, float bias){ float ta; float tb; vec2 ca = lc(uPA, d, ta); vec2 cb = lc(uPB, uO*d, tb);\n" +
            "  vec3 a = bias > 0.0 ? tex0(ca, bias).rgb : tex(ca).rgb; vec3 b = bias > 0.0 ? tex0(cb, bias).rgb : tex(cb).rgb;\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0; return mix(b, a, w); }\n" +
            Look.RC_GLSL + Look.ART_GLSL +
            "void main(){ vec3 x; vec3 bl;\n" +
            "  if(uFlat==1){ vec2 c = vec2(0.5)+(vUv-vec2(0.5))*uCrop; x = tex(c).rgb; bl = uA2.z != 0.0 ? tex0(c, 3.0).rgb : x; }\n" +
            "  else { vec3 d = dir(); x = stitch(d, 0.0); bl = uA2.z != 0.0 ? stitch(d, 3.0) : x; }\n" +
            "  x += uA2.z*1.6*(x-bl);\n" +
            "  gl_FragColor = vec4(art(grade(recol(x), uA1, uA2, vUv, uMode==2 ? 1 : 0), vUv), 1.0); }\n";
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        st = new SurfaceTexture(tex);
        st.setOnFrameAvailableListener(s -> requestRender());
        surface = new Surface(st);
        prog = program(VS, fs(false));
        post = null; // contextul OpenGL e nou
        tex2 = 0;
        if (keepBmp != null) { pendingBmp = keepBmp; photoMode = true; }
        prog2 = program(VS, fs(true));
        float[] v = {-1, -1, 1, -1, -1, 1, 1, 1};
        quad = ByteBuffer.allocateDirect(v.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(v).position(0);
        final Surface s = surface;
        main.post(() -> { if (onSurface != null) onSurface.run(s); });
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w); vh = Math.max(1, h);
        GLES20.glViewport(0, 0, w, h);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        if (pendingBmp != null) {
            int[] t = new int[1];
            if (tex2 != 0) { t[0] = tex2; GLES20.glDeleteTextures(1, t, 0); }
            GLES20.glGenTextures(1, t, 0);
            tex2 = t[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex2);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, pendingBmp, 0);
            GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D);
            texW = pendingBmp.getWidth(); texH = pendingBmp.getHeight();
            pendingBmp = null;
        }
        if (!photoMode) { try { st.updateTexImage(); st.getTransformMatrix(stMtx); } catch (Exception ignored) { } }
        draw(false);
    }

    private Post post;

    /** desenează imaginea; cu stil „ca desenat” trece întâi printr-o imagine intermediară și pașii din Post */
    private void draw(boolean offscreen) {
        int a = ovArt >= 0 ? ovArt : neutral ? 0 : art;
        if (a == 0) { drawMain(); return; }
        int[] cur = new int[1];
        GLES20.glGetIntegerv(GLES20.GL_FRAMEBUFFER_BINDING, cur, 0);
        if (post == null) post = new Post();
        post.bindMain(vw, vh);
        drawMain();
        post.run(post.mainTex(), vw, vh, cur[0], a, ovArt >= 0 ? 1f : artK);
    }

    private void drawMain() {
        int prog = photoMode ? prog2 : this.prog;
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glUseProgram(prog);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        if (photoMode) GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex2);
        else GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMtx"), 1, false, photoMode ? FLIPY : stMtx, 0);
        float ty;
        if (pano) ty = 1f;
        else if (planet) ty = (float) Math.tan(Math.toRadians(fovV / 4.0)); // proiecție stereografică
        else ty = (float) Math.tan(Math.toRadians(fovV / 2.0));
        float tx = ty * vw / (float) vh;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uTan"), tx, ty);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uV"), 1, false, colMajor(view()), 0);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uO"), 1, false, colMajor(O_L1toL2), 0);
        float[] pa = calA != null ? calA : PA, pb = calB != null ? calB : PB;
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPA"), pa[0], pa[1], pa[2], pa[3]);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPB"), pb[0], pb[1], pb[2], pb[3]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uFov"), FOV);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uBlend"), (float) Math.toRadians(4));
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uMode"), pano ? 2 : planet ? 1 : 0);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uFlat"), flat ? 1 : 0);
        float sa = vw / (float) vh, va = videoAspect;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uCrop"), Math.min(1f, sa / va), Math.min(1f, va / sa));
        float[] lk = ovLook != null ? ovLook : neutral ? Look.NONE : look;
        Look.Recol rc = neutral ? null : recol;
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uRc"), rc == null ? 0 : 1);
        if (rc != null) {
            float[] s = rc.s(), d = rc.d();
            GLES20.glUniform3f(GLES20.glGetUniformLocation(prog, "uRcSrc"), s[0], s[1], s[2]);
            GLES20.glUniform3f(GLES20.glGetUniformLocation(prog, "uRcDst"), d[0], d[1], d[2]);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uRcTol"), rc.tol);
        }
        float[] a1 = Look.a1(lk), a2 = Look.a2(lk);
        if (!photoMode) a2[2] = 0f; // claritatea doar la poze
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uA1"), a1[0], a1[1], a1[2], a1[3]);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uA2"), a2[0], a2[1], a2[2], a2[3]);
        // la zoom mare curăț purecii singur (filme); la poze din reglaj
        float auto = flat || pano ? 0f : autoDenoise(planet ? 90f : fovV);
        float dns = photoMode ? Math.max(lk[Look.DNS] / 100f, auto) : auto;
        int art = 0; // stilul desenat se face după, în Post
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uArt"), art);
        float pxs = Math.max(0.75f, Math.min(vw, vh) / 700f) * 1.5f;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uPx"), pxs / Math.max(1, vw), pxs / Math.max(1, vh));
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uDns"), dns);
        int tw = photoMode ? texW : vidW, th = photoMode ? texH : vidH;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uTexel"), 1f / Math.max(1, tw), 1f / Math.max(1, th));
        int loc = GLES20.glGetAttribLocation(prog, "aPos");
        GLES20.glEnableVertexAttribArray(loc);
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    }

    // ---- matrice (rând după rând) ----
    private static float[] rotX(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{1, 0, 0, 0, c, -s, 0, s, c}; }
    private static float[] rotY(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, 0, s, 0, 1, 0, -s, 0, c}; }
    private static float[] rotZ(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, -s, 0, s, c, 0, 0, 0, 1}; }
    private static float[] mul(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }
    static float[] colMajorPublic(float[] m) { return colMajor(m); }
    static float[] viewMatrix(float yaw, float pitch) { return mul(rotY(Math.toRadians(yaw)), rotX(Math.toRadians(pitch))); }
    static float[] lensMatrix() { return O_L1toL2; }
    static float[] calA() { return PA; }
    static float[] calB() { return PB; }
    static float fovRad() { return FOV; }

    private static float[] colMajor(float[] m) { return new float[]{m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8]}; }
    private static final float[] FLIP = {-1, 0, 0, 0, 1, 0, 0, 0, -1};
    private static final float[] R2 = mul(mul(rotY(Math.toRadians(0.5)), rotX(Math.toRadians(-1.5))), rotZ(Math.toRadians(-1)));
    private static final float[] O_L1toL2 = mul(FLIP, R2);

    private float[] view() {
        LevelProvider vp = viewProvider;
        if (vp != null && !pano) {
            float[] m = null;
            try { m = vp.get(); } catch (Throwable ignored) { }
            if (m != null) return m;
        }
        LevelProvider lp = levelProvider;
        if (lp != null) {
            float[] m = null;
            try { m = lp.get(); } catch (Throwable ignored) { }
            level = m != null ? m : new float[]{1, 0, 0, 0, 1, 0, 0, 0, 1};
        }
        if (pano) return mul(level, rotY(Math.toRadians(yaw)));
        return mul(level, mul(mul(rotY(Math.toRadians(yaw)), rotX(Math.toRadians(pitch))), rotZ(Math.toRadians(roll))));
    }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) android.util.Log.e("D360shader", "Shader greșit: " + GLES20.glGetShaderInfoLog(s));
        return s;
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        return p;
    }

    public void release() {
        try { if (surface != null) surface.release(); } catch (Exception ignored) { }
        try { if (st != null) st.release(); } catch (Exception ignored) { }
    }
}
