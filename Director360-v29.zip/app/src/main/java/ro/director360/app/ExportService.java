package ro.director360.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;

import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Face filmul și când ieși din aplicație; arată progresul în notificări și pune filmul în Galerie. */
public class ExportService extends Service {

    public interface UI {
        void progress(int p);
        void done(Uri uri);
        void error(String msg);
    }

    private static final String CH = "export";
    private static final int ID = 360;
    private static Composition pending;
    private static ExportService inst;
    static UI ui;
    static volatile boolean running = false;
    static int progress = 0;
    /** rezultatul ultimei salvări, dacă editorul nu era deschis când s-a terminat */
    static Uri doneUri;
    static String doneErr;

    private final Handler main = new Handler(Looper.getMainLooper());
    private Transformer transformer;
    private File out;

    public static void start(Context ctx, Composition comp) {
        pending = comp;
        running = true;
        progress = 0;
        doneUri = null;
        doneErr = null;
        Intent i = new Intent(ctx, ExportService.class);
        ctx.startForegroundService(i);
    }

    public static void cancel() {
        if (inst != null) inst.stopAll(true);
        running = false;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private Notification notif(String title, String text, boolean ongoing, int prog, PendingIntent tap) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(new NotificationChannel(CH, "Salvarea filmelor", NotificationManager.IMPORTANCE_LOW));
        Notification.Builder b = new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .setColor(Th.A);
        if (ongoing) b.setProgress(100, prog, prog <= 0);
        if (tap != null) b.setContentIntent(tap).setAutoCancel(true);
        else {
            Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            b.setContentIntent(PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE));
        }
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        inst = this;
        Notification n = notif("Director360 face filmul", "0%", true, 0, null);
        startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        Composition comp = pending;
        pending = null;
        if (comp == null || transformer != null) return START_NOT_STICKY;
        out = new File(getCacheDir(), "director360_" + System.currentTimeMillis() + ".mp4");
        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult result) {
                        transformer = null;
                        update(100, "Pun filmul în Galerie…");
                        new Thread(() -> {
                            Uri u = publish(out);
                            main.post(() -> finish(u, u == null ? "Nu am putut pune filmul în Galerie." : null));
                        }).start();
                    }

                    @Override public void onError(Composition composition, ExportResult result, ExportException e) {
                        transformer = null;
                        if (out != null) out.delete();
                        finish(null, "Încearcă din nou sau alege calitatea „Rapid 720p”.\n\n(cod " + e.errorCode + ": " + e.getMessage() + ")");
                    }
                })
                .build();
        try {
            transformer.start(comp, out.getAbsolutePath());
        } catch (Throwable e) {
            transformer = null;
            finish(null, "Nu am putut porni salvarea: " + e.getMessage());
            return START_NOT_STICKY;
        }
        final ProgressHolder ph = new ProgressHolder();
        main.post(new Runnable() {
            @Override public void run() {
                if (transformer == null) return;
                if (transformer.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) update(ph.progress, ph.progress + "%");
                main.postDelayed(this, 500);
            }
        });
        return START_NOT_STICKY;
    }

    private void update(int p, String text) {
        progress = p;
        getSystemService(NotificationManager.class).notify(ID, notif("Director360 face filmul", text, true, p, null));
        if (ui != null) ui.progress(p);
    }

    private void finish(Uri u, String err) {
        running = false;
        NotificationManager nm = getSystemService(NotificationManager.class);
        stopForeground(STOP_FOREGROUND_REMOVE);
        if (u != null) {
            Intent v = new Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent tap = PendingIntent.getActivity(this, 2, v, PendingIntent.FLAG_IMMUTABLE);
            nm.notify(ID + 1, notif("Filmul e gata ✓", "E în Galerie, albumul Director360. Atinge ca să-l vezi.", false, 0, tap));
        } else if (err != null) {
            nm.notify(ID + 1, notif("Nu am putut face filmul", "Deschide Director360 și încearcă din nou.", false, 0, null));
        }
        if (ui != null) { if (u != null) ui.done(u); else if (err != null) ui.error(err); }
        else { doneUri = u; doneErr = err; }
        inst = null;
        stopSelf();
    }

    private void stopAll(boolean user) {
        if (transformer != null) { transformer.cancel(); transformer = null; }
        if (out != null) out.delete();
        running = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        inst = null;
        stopSelf();
    }

    private Uri publish(File f) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".mp4";
            v.put(MediaStore.Video.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Director360");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) return null;
            try (InputStream in = new FileInputStream(f); OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) return null;
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            v.clear();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            f.delete();
            return dst;
        } catch (Throwable e) {
            return null;
        }
    }
}
