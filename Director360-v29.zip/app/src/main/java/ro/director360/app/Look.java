package ro.director360.app;

/**
 * Culorile pozei și ale filmului, exact ca în Regizor 360.
 * Reglajele (−100…100): luminozitate, contrast, umbre, lumini, saturație, căldură, claritate, reducere zgomot, vignetare.
 */
public class Look {
    public static final int EXP = 0, CON = 1, SH = 2, HI = 3, SAT = 4, WARM = 5, CLA = 6, DNS = 7, VIG = 8;
    public static final String[] ADJ_IDS = {"exp", "con", "sh", "hi", "sat", "warm", "cla", "dns", "vig"};
    public static final String[] ADJ_NAMES = {"Luminozitate", "Contrast", "Umbre", "Lumini", "Saturație", "Căldură", "Claritate", "Reducere zgomot", "Vignetare"};
    public static final float[] NONE = new float[9];
    /** butonul „Auto” din Regizor */
    public static final float[] AUTO = {5, 15, 25, -15, 15, 5, 20, 25, 15};

    public static final String[] IDS = {"none", "vivid", "snow", "warm", "cool", "cine", "night", "bw"};
    public static final String[] NAMES = {"Natural", "Viu", "Zăpadă", "Cald", "Rece", "Cinematic", "Noapte", "Alb-negru"};
    public static final int[][] SWATCH = {
            {0xFF6B8FB5, 0xFFC9B48A}, {0xFF1E90FF, 0xFFFF6A2B}, {0xFFDFE9F3, 0xFF7FB2E5}, {0xFFF6B26B, 0xFFE06C2B},
            {0xFF7FB2E5, 0xFF3D5A80}, {0xFF2B3A42, 0xFFC08552}, {0xFF1B2735, 0xFF5B7A9A}, {0xFFEEEEEE, 0xFF333333}};
    // filtrele din Regizor: exp, con, sh, hi, sat, warm, cla, dns, vig
    private static final float[][] F = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 15, 0, 0, 30, 0, 0, 0, 10},
            {-10, 10, 0, -40, 18, 0, 0, 0, 0},
            {0, 10, 0, 0, 10, 40, 0, 0, 0},
            {0, 10, 0, 0, 5, -35, 0, 0, 0},
            {0, 25, 15, -20, -15, 10, 0, 0, 35},
            {35, 5, 45, -20, 0, 0, 0, 40, 0},
            {0, 25, 0, 0, -100, 0, 0, 0, 15}};

    public static int index(String id) {
        for (int j = 0; j < IDS.length; j++) if (IDS[j].equals(id)) return j;
        return 0;
    }

    /** reglajele filtrului (tăria 70 = ca în Regizor) */
    public static float[] of(String id, int k) {
        float[] q = F[index(id)], r = new float[9];
        for (int i = 0; i < 9; i++) r[i] = q[i] * k / 70f;
        if (q[SAT] <= -100) r[SAT] = Math.max(-100, r[SAT]);
        return r;
    }

    /** filtrul plus reglajele mâinii, între −100 și 100 */
    public static float[] sum(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 9; i++) r[i] = Math.max(-100, Math.min(100, (a == null ? 0 : a[i]) + (b == null ? 0 : b[i])));
        return r;
    }

    /** aceeași formulă ca în Regizor; a1 = (lum, contrast, umbre, lumini)/100, a2 = (saturație, căldură, claritate, vignetare)/100 */
    public static final String GLSL =
            "vec3 grade(vec3 x, vec4 a1, vec4 a2, vec2 uv, int pano){\n" +
            "  x *= exp2(a1.x);\n" +
            "  float L = dot(clamp(x,0.0,1.0), vec3(0.299,0.587,0.114));\n" +
            "  x += a1.z*0.45*(1.0-smoothstep(0.0,0.55,L))*(1.0-L);\n" +
            "  x += a1.w*0.35*smoothstep(0.45,1.0,L);\n" +
            "  x = (x-0.5)*(1.0+a1.y)+0.5;\n" +
            "  L = dot(x, vec3(0.299,0.587,0.114)); x = mix(vec3(L), x, 1.0+a2.x);\n" +
            "  x += vec3(0.07,0.015,-0.07)*a2.y;\n" +
            "  if(pano==0 && a2.w!=0.0){ float r = length(uv-0.5)*1.414; x *= 1.0-a2.w*0.75*smoothstep(0.35,1.0,r); }\n" +
            "  return clamp(x,0.0,1.0); }\n";

    /** stilurile „ca desenat”: numele pe butoane (0 = fără) */
    public static final String[] ART_NAMES = {"Fără", "Desen animat", "Creion", "Benzi desenate", "Acuarelă"};

    /** schimbarea culorii unei haine: culoarea atinsă (src) devine altă culoare (dst), cu umbrele păstrate */
    public static class Recol {
        public int src, dst; public float tol;
        public Recol(int src, int dst, float tol) { this.src = src; this.dst = dst; this.tol = tol; }
        public Recol copy() { return new Recol(src, dst, tol); }
        float[] s() { return rgb(src); }
        float[] d() { return rgb(dst); }
        static float[] rgb(int c) { return new float[]{((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f}; }
    }
    /** culorile din care alegi haina nouă */
    public static final int[] RC_COLORS = {0xFFD62828, 0xFF1E5BD6, 0xFF2E9E44, 0xFFF2C230, 0xFFF07A1E, 0xFFE05AA8, 0xFF7B3FC4, 0xFF7A4A2A, 0xFF1A1A1A, 0xFFF2F2F2, 0xFF8A8F96, 0xFF0E2A5A};
    public static final String[] RC_NAMES = {"Roșu", "Albastru", "Verde", "Galben", "Portocaliu", "Roz", "Mov", "Maro", "Negru", "Alb", "Gri", "Bleumarin"};

    /** desenul: contururi din schimbările de lumină + culori puțin pe trepte (rulează după culori) */
    public static final String RC_GLSL =
            "float lu(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }\n" +
            "uniform int uRc; uniform vec3 uRcSrc; uniform vec3 uRcDst; uniform float uRcTol;\n" +
            "vec3 recol(vec3 x){ if(uRc==0) return x; float La = lu(x), Ls = lu(uRcSrc);\n" +
            "  vec3 ca = x-La, cs = uRcSrc-Ls; float d = length(vec4((ca-cs)*1.8, (La-Ls)*1.0));\n" +
            "  float m = 1.0-smoothstep(uRcTol, uRcTol+0.10, d);\n" +
            "  vec3 n = clamp(uRcDst*clamp(La/max(Ls,0.04), 0.0, 2.5), 0.0, 1.0); return mix(x, n, m); }\n";
    public static final String ART_GLSL =
            "vec3 sampleAt(vec2 uv){ if(uFlat==1){ vec2 c = vec2(0.5)+(uv-vec2(0.5))*uCrop; return tex0(c, 0.5).rgb; } return stitch(dirAt(uv), 0.5); }\n" +
            "float edge(vec2 uv){ vec2 p = uPx;\n" +
            "  float tl = lu(sampleAt(uv+vec2(-p.x,-p.y))), t = lu(sampleAt(uv+vec2(0.0,-p.y))), tr = lu(sampleAt(uv+vec2(p.x,-p.y)));\n" +
            "  float l = lu(sampleAt(uv+vec2(-p.x,0.0))), r = lu(sampleAt(uv+vec2(p.x,0.0)));\n" +
            "  float bl = lu(sampleAt(uv+vec2(-p.x,p.y))), b = lu(sampleAt(uv+vec2(0.0,p.y))), br = lu(sampleAt(uv+vec2(p.x,p.y)));\n" +
            "  float gx = -tl-2.0*l-bl+tr+2.0*r+br; float gy = -tl-2.0*t-tr+bl+2.0*b+br; return length(vec2(gx,gy)); }\n" +
            "vec3 steps(vec3 x, float n, float k){ float L = max(lu(x), 0.001); float q = floor(L*n+0.5)/n; return clamp(x/L*mix(L, q, k), 0.0, 1.0); }\n" +
            "vec3 sat(vec3 c, float s){ return clamp(mix(vec3(lu(c)), c, s), 0.0, 1.0); }\n" +
            "vec3 art(vec3 x, vec2 uv){\n" +
            "  if(uArt==0) return x;\n" +
            "  float e = edge(uv); float L = lu(x); vec2 pp = uv/uPx;\n" +
            "  if(uArt==1){ vec3 c = sat(steps(x, 5.0, 0.85), 1.35); float ln = smoothstep(0.16,0.42,e); return c*(1.0-0.88*ln); }\n" +
            "  if(uArt==2){ float ln = smoothstep(0.08,0.50,e);\n" +
            "    float s1 = step(0.72, fract((pp.x+pp.y)/4.0)), s2 = step(0.72, fract((pp.x-pp.y)/4.0));\n" +
            "    float v = 0.72+0.28*smoothstep(0.05,0.85,L);\n" +
            "    v -= 0.35*s1*(1.0-smoothstep(0.30,0.62,L)); v -= 0.35*s2*(1.0-smoothstep(0.12,0.38,L)); v -= 0.8*ln;\n" +
            "    return mix(vec3(0.20,0.20,0.24), vec3(0.98,0.96,0.91), clamp(v,0.0,1.0)); }\n" +
            "  if(uArt==3){ vec3 c = sat(steps(x, 4.0, 0.9), 1.6);\n" +
            "    vec2 f = fract(pp/4.0)-0.5; float rr = sqrt(clamp(1.0-L,0.0,1.0))*0.55; float dt = 1.0-smoothstep(rr-0.08, rr+0.08, length(f));\n" +
            "    c *= 1.0-0.4*dt*(1.0-smoothstep(0.25,0.75,L)); float ln = smoothstep(0.13,0.32,e); return c*(1.0-ln); }\n" +
            "  vec3 c = sat(steps(x, 8.0, 0.25), 1.15); c = mix(c, vec3(1.0), 0.12); c *= 1.0-0.3*smoothstep(0.10,0.50,e);\n" +
            "  float n = fract(sin(dot(floor(pp/1.5), vec2(12.9898,78.233)))*43758.5453); return clamp(c+(n-0.5)*0.05, 0.0, 1.0); }\n";

    static float[] a1(float[] l) { return new float[]{l[EXP] / 100f, l[CON] / 100f, l[SH] / 100f, l[HI] / 100f}; }
    static float[] a2(float[] l) { return new float[]{l[SAT] / 100f, l[WARM] / 100f, l[CLA] / 100f, l[VIG] / 100f}; }
}
