package ro.director360.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/** Semnul de lucru ca în Regizor 360: inelul cu săgeți se rotește, în mijloc un punct alb care strălucește. */
public class LoaderView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private final long t0 = android.os.SystemClock.uptimeMillis();

    public LoaderView(Context c) { this(c, null); }

    public LoaderView(Context c, AttributeSet a) { super(c, a); }

    @Override
    protected void onDraw(Canvas c) {
        float ms = android.os.SystemClock.uptimeMillis() - t0;
        float w = getWidth(), h = getHeight(), s = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f;
        // strălucirea din spate
        float pulse = 0.5f + 0.5f * (float) Math.sin(ms / 420.0);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        p.setShader(new RadialGradient(cx, cy, s * (0.42f + 0.06f * pulse),
                new int[]{0x99FFE2CC, 0x40FF6A2B, 0x00FF6A2B}, new float[]{0, 0.45f, 1}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, s * 0.5f, p);
        p.setShader(null);
        // inelul
        c.save();
        c.translate(cx, cy);
        c.rotate((ms / 1400f * 360f) % 360f);
        float k = s / 100f;
        c.scale(k, k);
        c.translate(-50, -50);
        p.setColor(Th.A);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(8);
        r.set(14, 14, 86, 86);
        c.drawArc(r, 194.96f, 150.08f, false, p);
        c.drawArc(r, 14.96f, 150.08f, false, p);
        p.setStyle(Paint.Style.FILL);
        path.reset(); path.moveTo(86.9f, 48.6f); path.lineTo(91f, 36.6f); path.lineTo(77.6f, 40.9f); path.close();
        c.drawPath(path, p);
        path.reset(); path.moveTo(13.1f, 51.4f); path.lineTo(9f, 63.4f); path.lineTo(22.4f, 59.1f); path.close();
        c.drawPath(path, p);
        c.restore();
        // punctul alb
        p.setColor(0xFFF8F6F2);
        c.drawCircle(cx, cy, s * (0.15f + 0.01f * pulse), p);
        postInvalidateOnAnimation();
    }
}
