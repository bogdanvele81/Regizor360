package ro.director360.app;

import android.app.Activity;
import android.content.Context;

/** culoarea aplicației (tema), aleasă de utilizator la Ajutor → Culoarea aplicației */
public final class Th {
    public static final String[] IDS = {"orange", "blue", "green", "purple", "red", "pink", "teal", "yellow"};
    public static final String[] NAMES = {"Portocaliu", "Albastru", "Verde", "Mov", "Roșu", "Roz", "Turcoaz", "Galben"};
    public static final int[] ACCENT = {0xFFFF6A2B, 0xFF3D9BFF, 0xFF2ECC71, 0xFFA77BFF, 0xFFFF4D5E, 0xFFFF5FA8, 0xFF1FC8C8, 0xFFFFC21F};
    private static final int[] SOFT = {0xFFFFD2B8, 0xFFC9E2FF, 0xFFC4F1D7, 0xFFE3D6FF, 0xFFFFCDD2, 0xFFFFD0E6, 0xFFC2F0F0, 0xFFFFEDB8};
    private static final int[] STYLE = {R.style.Theme_Director, R.style.Theme_Director_Blue, R.style.Theme_Director_Green, R.style.Theme_Director_Purple,
            R.style.Theme_Director_Red, R.style.Theme_Director_Pink, R.style.Theme_Director_Teal, R.style.Theme_Director_Yellow};

    /** culoarea principală și varianta ei deschisă */
    public static int A = ACCENT[0], S = SOFT[0];
    private static int cur = 0;

    public static void init(Context c) {
        String id = c.getSharedPreferences("main", Context.MODE_PRIVATE).getString("theme", "orange");
        cur = 0;
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) cur = i;
        A = ACCENT[cur]; S = SOFT[cur];
    }

    public static int index() { return cur; }

    public static void set(Context c, int i) {
        c.getSharedPreferences("main", Context.MODE_PRIVATE).edit().putString("theme", IDS[i]).apply();
        init(c);
    }

    /** se apelează în onCreate, înainte de super.onCreate */
    public static void apply(Activity a) {
        init(a);
        a.setTheme(STYLE[cur]);
    }
}
