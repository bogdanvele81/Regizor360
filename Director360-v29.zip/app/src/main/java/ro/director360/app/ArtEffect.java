package ro.director360.app;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/** La salvarea filmului: stilul „ca desenat” (după încadrare și culori), aceiași pași ca pe ecran. */
public class ArtEffect implements GlEffect {
    private final int art;
    private final float str;

    public ArtEffect(int art) { this(art, 1f); }
    public ArtEffect(int art, float str) { this.art = art; this.str = str; }

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr) throws VideoFrameProcessingException {
        return new BaseGlShaderProgram(useHdr, 1) {
            private final Post post = new Post();
            private int w = 1, h = 1;

            @Override
            public Size configure(int inputWidth, int inputHeight) {
                w = inputWidth; h = inputHeight;
                return new Size(inputWidth, inputHeight);
            }

            @Override
            public void drawFrame(int inputTexId, long presentationTimeUs) {
                int[] cur = new int[1];
                GLES20.glGetIntegerv(GLES20.GL_FRAMEBUFFER_BINDING, cur, 0);
                post.run(inputTexId, w, h, cur[0], art, str);
            }

            @Override
            public void release() throws VideoFrameProcessingException {
                super.release();
                post.release();
            }
        };
    }
}
