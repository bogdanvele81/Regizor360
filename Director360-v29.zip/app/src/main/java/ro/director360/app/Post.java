package ro.director360.app;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * Stilurile „ca desenat”, făcute pe imaginea deja încadrată și colorată, în mai mulți pași:
 * de 3 ori netezire care păstrează marginile (culorile devin plate), apoi contururi curate și stilul.
 * Se folosește și la previzualizare (Video360View) și la salvarea filmului (ArtEffect).
 * Totul trebuie apelat pe firul OpenGL.
 */
final class Post {
    private static final String VS =
            "attribute vec2 aPos;\n" +
            "varying vec2 vT;\n" +
            "void main(){ vT = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }\n";

    private static final String BIL =
            "precision highp float;\n" +
            "varying vec2 vT;\n" +
            "uniform sampler2D uT;\n" +
            "uniform vec2 uStep;\n" +
            "void main(){ vec3 c0 = texture2D(uT, vT).rgb; vec3 acc = c0; float ws = 1.0;\n" +
            "  for(int j=-2;j<=2;j++) for(int i=-2;i<=2;i++){ if(i==0&&j==0) continue; vec2 o = vec2(float(i),float(j));\n" +
            "    vec3 s = texture2D(uT, vT+o*uStep).rgb; vec3 d = s-c0; float w = exp(-dot(d,d)/0.0162-dot(o,o)/4.5); acc += s*w; ws += w; }\n" +
            "  gl_FragColor = vec4(acc/ws, 1.0); }\n";

    private static final String FIN =
            "precision highp float;\n" +
            "varying vec2 vT;\n" +
            "uniform sampler2D uK;\n" +
            "uniform sampler2D uO;\n" +
            "uniform float uStr;\n" +
            "uniform int uArt;\n" +
            "uniform vec2 uPx;\n" +
            "float lu(vec3 c){ return dot(c, vec3(0.299,0.587,0.114)); }\n" +
            "float ring(float r){ float a = lu(texture2D(uK, vT).rgb);\n" +
            "  for(int k=0;k<8;k++){ float an = float(k)*0.7853982; a += lu(texture2D(uK, vT+vec2(cos(an),sin(an))*r*uPx).rgb); }\n" +
            "  return a/9.0; }\n" +
            "vec3 sat(vec3 c, float s){ float L = lu(c); return clamp(vec3(L)+(c-vec3(L))*s, 0.0, 1.0); }\n" +
            "vec3 sq(vec3 c, float n, float m){ float L = max(lu(c), 0.001); float q = L*n; float fl = floor(q);\n" +
            "  float qs = (fl+smoothstep(0.35,0.65,q-fl))/n; return clamp(c/L*(L*(1.0-m)+qs*m), 0.0, 1.0); }\n" +
            "void main(){ vec3 k = texture2D(uK, vT).rgb; float L = lu(k); float dog = ring(2.4)-ring(0.9); vec2 pp = vT/uPx; vec3 c;\n" +
            "  if(uArt==1){ c = pow(sat(sq(k,6.0,0.75),1.5), vec3(0.85)); c *= 1.0-0.9*smoothstep(0.010,0.025,dog); }\n" +
            "  else if(uArt==2){ float ad = abs(dog);\n" +
            "    float s1 = step(0.72, fract((pp.x+pp.y)/4.0)), s2 = step(0.72, fract((pp.x-pp.y)/4.0));\n" +
            "    float v = 0.75+0.25*smoothstep(0.05,0.85,L);\n" +
            "    v -= 0.22*s1*(1.0-smoothstep(0.30,0.62,L)); v -= 0.22*s2*(1.0-smoothstep(0.12,0.38,L)); v -= 0.85*smoothstep(0.006,0.020,ad);\n" +
            "    c = mix(vec3(0.20,0.20,0.24), vec3(0.98,0.96,0.91), clamp(v,0.0,1.0)); }\n" +
            "  else if(uArt==3){ c = sat(sq(k,4.0,0.9),1.7);\n" +
            "    vec2 f = fract(pp/4.0)-0.5; float rr = sqrt(clamp(1.0-L,0.0,1.0))*0.55; float dt = 1.0-smoothstep(rr-0.08, rr+0.08, length(f));\n" +
            "    c *= 1.0-0.35*dt*(1.0-smoothstep(0.25,0.75,L)); c *= 1.0-smoothstep(0.008,0.020,dog); }\n" +
            "  else { c = sat(sq(k,8.0,0.3),1.2); c = mix(c, vec3(1.0), 0.15); c *= 1.0-0.35*smoothstep(0.006,0.020,abs(dog));\n" +
            "    float n = fract(sin(dot(floor(pp/1.5), vec2(12.9898,78.233)))*43758.5453); c = clamp(c+(n-0.5)*0.05, 0.0, 1.0); }\n" +
            "  gl_FragColor = vec4(mix(texture2D(uO, vT).rgb, c, uStr), 1.0); }\n";

    private static final FloatBuffer QUAD;
    static {
        float[] q = {-1, -1, 1, -1, -1, 1, 1, 1};
        QUAD = ByteBuffer.allocateDirect(q.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        QUAD.put(q).position(0);
    }

    private int pBil, pFin;
    /** M = imaginea principală (doar la previzualizare), A și B = pentru pașii de netezire */
    private final int[] fb = new int[3], tx = new int[3];
    private int w, h;

    /** pregătește ținta în care se desenează imaginea principală; o lasă activă */
    void bindMain(int w, int h) {
        ensure(w, h);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0]);
        GLES20.glViewport(0, 0, w, h);
    }

    int mainTex() { return tx[0]; }

    /** din textura src (w×h) face stilul și îl desenează în ținta dst */
    void run(int src, int w, int h, int dst, int art, float str) {
        ensure(w, h);
        if (pBil == 0) { pBil = program(VS, BIL); pFin = program(VS, FIN); }
        float pxs = Math.max(0.75f, Math.min(w, h) / 700f) * 1.5f;
        float sx = pxs / w, sy = pxs / h;
        GLES20.glDisable(GLES20.GL_BLEND);
        pass(pBil, src, fb[1], sx * 1.0f, sy * 1.0f);
        pass(pBil, tx[1], fb[2], sx * 1.6f, sy * 1.6f);
        pass(pBil, tx[2], fb[1], sx * 2.4f, sy * 2.4f);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, dst);
        GLES20.glViewport(0, 0, w, h);
        GLES20.glUseProgram(pFin);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tx[1]);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pFin, "uK"), 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, src);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pFin, "uO"), 1);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(pFin, "uStr"), Math.max(0f, Math.min(1f, str)));
        GLES20.glUniform1i(GLES20.glGetUniformLocation(pFin, "uArt"), art);
        GLES20.glUniform2f(GLES20.glGetUniformLocation(pFin, "uPx"), sx, sy);
        quad(pFin);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
    }

    private void pass(int p, int src, int dstFb, float stx, float sty) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, dstFb);
        GLES20.glViewport(0, 0, w, h);
        GLES20.glUseProgram(p);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, src);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(p, "uT"), 0);
        GLES20.glUniform2f(GLES20.glGetUniformLocation(p, "uStep"), stx, sty);
        quad(p);
    }

    private static void quad(int p) {
        int loc = GLES20.glGetAttribLocation(p, "aPos");
        GLES20.glEnableVertexAttribArray(loc);
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, QUAD);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
        GLES20.glDisableVertexAttribArray(loc);
    }

    private void ensure(int nw, int nh) {
        if (nw == w && nh == h && fb[0] != 0) return;
        freeTargets();
        w = nw; h = nh;
        GLES20.glGenFramebuffers(3, fb, 0);
        GLES20.glGenTextures(3, tx, 0);
        for (int i = 0; i < 3; i++) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tx[i]);
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[i]);
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tx[i], 0);
        }
    }

    private void freeTargets() {
        if (fb[0] != 0) {
            GLES20.glDeleteFramebuffers(3, fb, 0);
            GLES20.glDeleteTextures(3, tx, 0);
            fb[0] = fb[1] = fb[2] = 0;
        }
    }

    void release() {
        freeTargets();
        if (pBil != 0) { GLES20.glDeleteProgram(pBil); GLES20.glDeleteProgram(pFin); pBil = pFin = 0; }
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        return p;
    }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) android.util.Log.e("D360shader", "Desen greșit: " + GLES20.glGetShaderInfoLog(s));
        return s;
    }
}
