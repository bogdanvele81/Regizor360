package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline.Window;
import androidx.media3.common.VideoSize;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.common.collect.ImmutableList;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Editorul ca în Regizor 360 (și Insta360): filmul sus, banda jos, uneltele Template / Text / Sticker / Muzică / Filtru / Împarte. */
public class EditorActivity extends AppCompatActivity implements OverlayLayer.Host {

    /** o bucată din montaj */
    static class Clip {
        Uri uri, prev;
        String name, key;
        boolean is360;
        float[] view = {0f, 0f, 80f, 0f};
        final Timeline.Clip t = new Timeline.Clip();
        boolean durKnown = false;
        Gyro gyro;
        Track track;
        /** oamenii găsiți de AI în bucată (null = încă necăutați) */
        List<People.Sample> people;
        /** efectul de mișcare (Fx) și cât durează, în secunde */
        String fx = "none";
        float fxDur = 2.5f;
        /** viteza bucății (1 = normal) */
        float speed = 1f;

        Clip copy() {
            Clip c = new Clip();
            c.gyro = gyro;
            c.track = track;
            c.people = people;
            c.fx = fx; c.fxDur = fxDur; c.speed = speed;
            c.uri = uri; c.prev = prev; c.name = name; c.key = key; c.is360 = is360;
            c.view = view.clone();
            c.t.dur = t.dur; c.t.in = t.in; c.t.out = t.out; c.t.frames = t.frames;
            c.durKnown = durKnown;
            return c;
        }
    }

    /** o filmare aleasă (sursa) */
    static class Src {
        Uri uri, prev;
        String name, key;
        boolean is360;
        long dur = 0;
        float[] score;
        Bitmap[] frames = new Bitmap[0];
    }

    /** o stare pentru Înapoi / Refă */
    static class Snap {
        List<Clip> clips = new ArrayList<>();
        List<Overlays.Ov> ovs = new ArrayList<>();
        String filt;
        int filtK, art;
        Look.Recol recol;
    }

    private final List<Clip> clips = new ArrayList<>();
    private final List<Src> srcs = new ArrayList<>();
    private final List<Overlays.Ov> ovs = new ArrayList<>();
    private final List<Snap> undo = new ArrayList<>(), redo = new ArrayList<>();
    private Overlays.Ov selOv;
    private boolean auto = false, analyzing = false, analyzed = false, framesStarted = false, persist = true, full = false;
    private Runnable afterAnalyze;
    private boolean analyzeCancelled = false;
    private Overlays.Ov tplTitle, tplBars;
    private String autoDur = "30", autoStyle = "normal", filt = "none";
    private int filtK = 70, musicVol = 80, art = 0;
    private Look.Recol recol;
    private boolean origSound = true;
    private Uri music;
    private String musicName;
    private ExoPlayer musicPlayer;
    private String tool = null, tplCat = "Noi", tplSel = null;
    private final java.util.Map<String, Bitmap> tplThumbs = new java.util.HashMap<>();
    private static final int REQ_MUSIC = 31;

    private ExoPlayer player;
    private Video360View view;
    private OverlayLayer layer;
    private AspectFrame stage;
    private Timeline timeline;
    private TextView time, hint;
    private MaterialButton btnPlay, btnFormat;
    private MaterialButtonToggleGroup modeGroup;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences edits, prefs;
    private Transformer transformer;
    private int curIdx = -1;
    private float videoAspect = 16f / 9f;
    private String format = "orig";
    private boolean trimming = false;
    private float dd;
    // stabilizare (ca FlowState): poziția din filmare la ultimul pas, pentru cadrul desenat
    private volatile long posSrcMs = 0, posAt = 0;
    private volatile boolean posPlaying = false;
    private volatile Clip posClip;
    private boolean stab = true, dirLock = false;
    private final java.util.Map<String, Gyro> gyros = new java.util.concurrent.ConcurrentHashMap<>();
    private MaterialButton btnStab, btnDir;
    private boolean picking = false, trackCancel = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null && !clips.isEmpty()) {
                int i = player.getCurrentMediaItemIndex();
                long g = timeline.startOf(i) + Math.max(0, player.getCurrentPosition());
                timeline.setPos(g);
                time.setText(fmt(timeline.getPos()) + " / " + fmt(timeline.total()));
                if (i != curIdx) onClipChanged(i);
                if (!auto) fillDurations();
                syncMusic(g);
                if (!ovs.isEmpty()) layer.invalidate();
                Clip pc = i >= 0 && i < clips.size() ? clips.get(i) : null;
                posClip = pc;
                posSrcMs = (pc == null ? 0 : pc.t.in) + Math.max(0, player.getCurrentPosition());
                posAt = android.os.SystemClock.uptimeMillis();
                posPlaying = player.isPlaying();
                float sp = pc == null ? 1f : pc.speed;
                if (Math.abs(player.getPlaybackParameters().speed - sp) > 0.01f) player.setPlaybackParameters(new androidx.media3.common.PlaybackParameters(sp));
            }
            main.postDelayed(this, 40);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        Th.apply(this);
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        dd = getResources().getDisplayMetrics().density;
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        String[] uris = getIntent().getStringArrayExtra("uris");
        String[] lrvs = getIntent().getStringArrayExtra("lrvs");
        String[] names = getIntent().getStringArrayExtra("names");
        String[] keys = getIntent().getStringArrayExtra("keys");
        if (uris == null || uris.length == 0) { finish(); return; }
        auto = getIntent().getBooleanExtra("auto", false);
        persist = !auto;
        for (int i = 0; i < uris.length; i++) {
            Src sr = new Src();
            sr.uri = Uri.parse(uris[i]);
            sr.name = names[i];
            sr.key = keys[i];
            sr.prev = (lrvs != null && lrvs[i] != null && !lrvs[i].isEmpty()) ? Uri.parse(lrvs[i]) : sr.uri;
            sr.is360 = sr.name.toLowerCase().endsWith(".insv") && sr.prev != sr.uri;
            srcs.add(sr);
            if (!auto) {
                Clip c = new Clip();
                c.uri = sr.uri; c.prev = sr.prev; c.name = sr.name; c.key = sr.key; c.is360 = sr.is360;
                String sv = edits.getString(c.key + ":view", null);
                if (sv != null) try { String[] q = sv.split(","); c.view = new float[]{Float.parseFloat(q[0]), Float.parseFloat(q[1]), Float.parseFloat(q[2]), q[3].equals("1") ? 1f : 0f, q.length > 4 ? Float.parseFloat(q[4]) : 0f}; } catch (Exception ignored) { }
                String s = edits.getString(c.key, null);
                if (s != null) try { String[] p = s.split(","); c.t.in = Long.parseLong(p[0]); c.t.out = Long.parseLong(p[1]); } catch (Exception ignored) { }
                clips.add(c);
            }
        }

        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(Th.A), 9, 12, 0);
        ((TextView) findViewById(R.id.edBrand)).setText(brand);
        stage = findViewById(R.id.stage);
        timeline = findViewById(R.id.timeline);
        time = findViewById(R.id.time);
        hint = findViewById(R.id.hint);
        setupHelp();
        btnPlay = findViewById(R.id.btnPlay);
        btnFormat = findViewById(R.id.btnFormat);
        modeGroup = findViewById(R.id.modeGroup);

        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        layer = new OverlayLayer(this);
        layer.setHost(this);
        stage.addView(layer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        stab = prefs.getBoolean("stab", true);
        dirLock = prefs.getBoolean("dirLock", false);
        view.setLevelProvider(() -> {
            Clip c = posClip;
            if (!stab || c == null || !c.is360 || c.gyro == null) return null;
            long ms = posSrcMs + (posPlaying ? (long) ((android.os.SystemClock.uptimeMillis() - posAt) * c.speed) : 0);
            return c.gyro.at(ms / 1000.0, !dirLock);
        });
        buildStabButtons();
        view.setViewProvider(() -> {
            Clip c = posClip;
            if (c == null || !c.is360 || c.track == null) return null;
            double ts = (posSrcMs + (posPlaying ? (long) ((android.os.SystemClock.uptimeMillis() - posAt) * c.speed) : 0)) / 1000.0;
            float[] V = c.track.viewAt(ts);
            return c.gyro != null ? mul3(c.gyro.at(ts, false), V) : V;
        });
        view.setFxProvider(() -> {
            Clip c = posClip;
            if (c == null || !c.is360 || c.fx == null || "none".equals(c.fx)) return null;
            long ms = posSrcMs + (posPlaying ? (long) ((android.os.SystemClock.uptimeMillis() - posAt) * c.speed) : 0);
            return Fx.at(c.fx, c.fxDur, (ms - c.t.in) / 1000.0, c.view);
        });
        player = new ExoPlayer.Builder(this).build();
        view.setOnSurface(s -> { if (player != null) player.setVideoSurface(s); });
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { btnPlay.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play); }
            @Override public void onVideoSizeChanged(VideoSize v) {
                if (v.width > 0 && v.height > 0) {
                    videoAspect = v.width * v.pixelWidthHeightRatio / v.height;
                    view.setVideoSize(v.width, v.height);
                    Clip c = cur();
                    view.setFlat(c == null || !c.is360, videoAspect);
                    applyFormat();
                }
            }
            @Override public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_ENDED) { player.pause(); player.seekTo(0, 0); }
            }
        });

        format = prefs.getString("format", "orig");
        applyFormat();
        btnFormat.setOnClickListener(v -> chooseFormat());
        modeGroup.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked) return;
            Clip c = cur();
            if (c == null || !c.is360) return;
            boolean planet = id == R.id.mPlanet;
            if (planet != view.isPlanet()) view.setPlanet(planet);
            saveView(c);
        });
        findViewById(R.id.btnLevel).setOnClickListener(v -> { view.resetView(); modeGroup.check(R.id.mCustom); Clip c = cur(); if (c != null) saveView(c); });
        btnPlay.setOnClickListener(v -> { if (clips.isEmpty()) return; if (player.isPlaying()) player.pause(); else { if (timeline.getPos() >= timeline.total() - 150) seekGlobal(0); player.play(); } });
        findViewById(R.id.btnBack).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.btnSave).setOnClickListener(v -> askSave());
        findViewById(R.id.btnUndo).setOnClickListener(v -> doUndo());
        findViewById(R.id.btnRedo).setOnClickListener(v -> doRedo());
        findViewById(R.id.btnFull).setOnClickListener(v -> setFull(!full));
        if (getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
            findViewById(R.id.stageBox).post(() -> setFull(true));
        findViewById(R.id.sheetOk).setOnClickListener(v -> closeSheet());

        timeline.setListener(new Timeline.Listener() {
            @Override public void onScrub(long g, boolean done) { if (player.isPlaying()) player.pause(); seekGlobal(g); }
            @Override public void onBand(Object tag) { EditorActivity.this.onBand(tag); }
            @Override public void onSelect(int i) {
                if (i >= 0) { selOv = null; closeSheet(); seekGlobal(timeline.startOf(i) + 50); }
                buildToolbar();
                setHint();
            }
            @Override public void onTrim(int i, boolean left, boolean done) {
                if (player.isPlaying()) player.pause();
                if (!trimming) { trimming = true; pushUndo(); }
                Clip c = clips.get(i);
                if (done) {
                    trimming = false;
                    if (persist) edits.edit().putString(c.key, c.t.in + "," + c.t.out).apply();
                    rebuildPlayer(timeline.startOf(i) + (left ? 0 : c.t.len() - 300));
                } else if (player.getCurrentMediaItemIndex() == i) {
                    player.seekTo(i, left ? 0 : Math.max(0, c.t.len() - 50));
                }
            }
        });

        new Thread(() -> {
            for (Src sr : srcs) {
                if (!sr.is360 || isFinishing()) continue;
                Gyro g = Gyro.read(this, sr.uri);
                if (g == null) continue;
                gyros.put(sr.uri.toString(), g);
                main.post(this::attachGyros);
            }
        }).start();
        musicPlayer = new ExoPlayer.Builder(this).build();
        musicPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        buildToolbar();
        updateUndoButtons();
        main.post(tick);

        if (auto) {
            hint.setText("Montajul automat");
            analyzing = true;
            showBusy("Analizez scenele 0%", "Caut cele mai vii momente din fiecare filmare", this::finish);
            new Thread(this::analyze).start();
            return;
        }
        timeline.setClips(timelineClips());
        new Thread(this::loadInfo).start();
        setHint();
        rebuildPlayer(0);
    }

    // ---------------- stabilizare ----------------
    private void attachGyros() {
        for (Clip c : clips) if (c.gyro == null) c.gyro = gyros.get(c.uri.toString());
        updateStabButtons();
        view.requestRender();
    }

    private void buildStabButtons() {
        LinearLayout modes = (LinearLayout) ((ViewGroup) findViewById(R.id.modes)).getChildAt(0);
        btnStab = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        btnStab.setAllCaps(false);
        btnStab.setMaxLines(1);
        btnStab.setOnClickListener(v -> {
            stab = !stab;
            prefs.edit().putBoolean("stab", stab).apply();
            updateStabButtons();
            view.requestRender();
            Toast.makeText(this, stab ? "Stabilizare pornită: filmul stă liniștit și orizontul e drept." : "Stabilizare oprită.", Toast.LENGTH_SHORT).show();
        });
        btnDir = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        btnDir.setAllCaps(false);
        btnDir.setOnClickListener(v -> {
            dirLock = !dirLock;
            prefs.edit().putBoolean("dirLock", dirLock).apply();
            updateStabButtons();
            view.requestRender();
            Toast.makeText(this, dirLock ? "Direcție fixă: cadrul privește mereu în același loc, oricum s-ar întoarce camera." : "Cadrul urmează lin direcția camerei.", Toast.LENGTH_LONG).show();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginStart((int) (6 * dd));
        modes.addView(btnStab, lp);
        modes.addView(btnDir, new LinearLayout.LayoutParams(lp));
        updateStabButtons();
    }

    private void updateStabButtons() {
        if (btnStab == null) return;
        Clip c = cur();
        boolean has = c != null && c.is360 && c.gyro != null;
        btnStab.setVisibility(has ? View.VISIBLE : View.GONE);
        btnDir.setVisibility(has && stab ? View.VISIBLE : View.GONE);
        btnStab.setText(stab ? "✓ Stabilizare" : "Stabilizare");
        btnDir.setText(dirLock ? "✓ Direcție fixă" : "Direcție fixă");
        int on = Th.A, off = 0xFF3A4048;
        btnStab.setStrokeColor(android.content.res.ColorStateList.valueOf(stab ? on : off));
        btnStab.setTextColor(stab ? on : 0xFFF2F2F0);
        btnDir.setStrokeColor(android.content.res.ColorStateList.valueOf(dirLock ? on : off));
        btnDir.setTextColor(dirLock ? on : 0xFFF2F2F0);
    }

    // ---------------- OverlayLayer.Host ----------------
    @Override public List<Overlays.Ov> overlays() { return ovs; }
    @Override public long now() { return timeline.getPos(); }
    @Override public Overlays.Ov selected() { return selOv; }
    @Override public void select(Overlays.Ov o) {
        if (o != null && o != selOv) pushUndo();
        selOv = o;
        if (o != null) { timeline.setSelected(-1); openSheet(o.emoji ? "sticker" : "text"); }
        else if ("text".equals(tool) || "sticker".equals(tool)) closeSheet();
        buildToolbar();
    }
    @Override public void changed(boolean done) { }
    @Override public boolean picking() { return picking; }
    @Override public void pick(float x, float y) {
        picking = false;
        Clip c = cur();
        if (c == null || !c.is360) return;
        if (view.isPlanet()) { Toast.makeText(this, "Treci pe Custom ca să atingi persoana.", Toast.LENGTH_LONG).show(); return; }
        if (player.isPlaying()) player.pause();
        float[] tn = view.tanNow();
        float qx = (x * 2 - 1) * tn[0], qy = (y * 2 - 1) * tn[1];
        float n = (float) Math.sqrt(qx * qx + qy * qy + 1);
        float[] dv = {qx / n, qy / n, 1 / n};
        float[] U = view.currentView();
        float[] dc = Video360View.mvec(U, dv);
        double ts = posSrcMs / 1000.0;
        float[] d0 = c.gyro != null ? Video360View.mvec(Video360View.tr3(c.gyro.at(ts, false)), dc) : dc;
        final Clip clip = c;
        final int idx = curIdx;
        trackCancel = false;
        showBusy("Urmăresc persoana 0%", "Caut persoana în fiecare clipă a cadrului " + (idx + 1), () -> trackCancel = true);
        new Thread(() -> {
            // 1) AI: recunosc omul atins și îl urmăresc ca om (nu după culoare)
            if (clip.people == null) {
                List<People.Sample> ps = People.detect(this, clip.prev, clip.gyro, clip.t.in / 1000.0, clip.t.out / 1000.0, 0.5, new People.Progress() {
                    @Override public void on(int pct) { main.post(() -> setBusy("Recunosc oamenii " + pct + "%", null)); }
                    @Override public boolean cancelled() { return trackCancel || isFinishing(); }
                });
                if (ps != null) clip.people = ps;
            }
            Track tp = People.followFrom(clip.people, ts, d0, 25);
            // 2) dacă n-a fost un om (o mașină, un câine…), urmăresc după culori, ca înainte
            Track tr = tp != null ? tp : Track.run(this, clip.prev, clip.gyro, clip.t.in / 1000.0, clip.t.out / 1000.0, ts, d0, new Track.Progress() {
                @Override public void on(int pct) { main.post(() -> setBusy("Urmăresc persoana " + pct + "%", null)); }
                @Override public boolean cancelled() { return trackCancel || isFinishing(); }
            });
            main.post(() -> {
                hideBusy();
                if (tr == null) { if (!trackCancel) Toast.makeText(this, "Nu am reușit să urmăresc. Încearcă să atingi persoana mai pe mijloc.", Toast.LENGTH_LONG).show(); return; }
                pushUndo();
                clip.track = tr;
                int pct = Math.round(tr.found * 100f / Math.max(1, tr.total));
                hint.setText("Deep Track: urmăresc persoana în cadrul " + (idx + 1) + " (am găsit-o în " + pct + "% din timp). Apasă ▶.");
                openSheet("track");
                seekGlobal(timeline.startOf(idx));
                player.play();
            });
        }).start();
    }

    private static float[] mul3(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }

    private List<Timeline.Clip> timelineClips() { List<Timeline.Clip> l = new ArrayList<>(); for (Clip c : clips) l.add(c.t); return l; }

    private Clip cur() { return curIdx >= 0 && curIdx < clips.size() ? clips.get(curIdx) : null; }

    private void setHint() {
        Clip c = cur();
        if (timeline.getSelected() >= 0) hint.setText("Cadrul " + (timeline.getSelected() + 1) + " e ales: trage mânerele albe ca să-l scurtezi, sau jos: Împarte, Mută, Șterge.");
        // explicațiile generale sunt acum în ajutorul cu „?” de pe film
    }

    // ---------------- ajutor: mesaje scurte pe film + „?” ----------------
    private final Runnable hideHint = () -> hint.animate().alpha(0f).setDuration(300).start();

    private void setupHelp() {
        ViewGroup box = findViewById(R.id.stageBox);
        // mesajele devin o etichetă mică jos pe film, care dispare singură după 3 secunde
        ((ViewGroup) hint.getParent()).removeView(hint);
        hint.setBackground(pill(0xD9000000));
        hint.setTextColor(0xFFFFFFFF);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding((int) (16 * dd0()), (int) (8 * dd0()), (int) (16 * dd0()), (int) (8 * dd0()));
        hint.setAlpha(0f);
        hint.setMaxLines(3);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        int m = (int) (12 * dd0());
        hl.setMargins(m, m, m, m);
        box.addView(hint, hl);
        hint.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void onTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void afterTextChanged(android.text.Editable e) {
                hint.removeCallbacks(hideHint);
                if (e.length() == 0) { hint.setAlpha(0f); return; }
                hint.animate().alpha(1f).setDuration(200).start();
                hint.postDelayed(hideHint, 3500);
            }
        });
        // butonul „?”
        TextView q = new TextView(this);
        q.setText("?");
        q.setTextColor(0xFFFFFFFF);
        q.setTextSize(17);
        q.setTypeface(null, android.graphics.Typeface.BOLD);
        q.setGravity(Gravity.CENTER);
        q.setBackground(pill(0xB3000000));
        int qs = (int) (36 * dd0());
        FrameLayout.LayoutParams ql = new FrameLayout.LayoutParams(qs, qs, Gravity.TOP | Gravity.END);
        ql.setMargins(0, m, m, 0);
        box.addView(q, ql);
        q.setOnClickListener(v -> showHelp());
        q.setTag("helpQ");
        // „Vezi rezultatul”: filmul curat, pe tot ecranul
        TextView pv = new TextView(this);
        pv.setText("▶  Vezi rezultatul");
        pv.setTextColor(0xFFFFFFFF);
        pv.setTextSize(13);
        pv.setTypeface(null, android.graphics.Typeface.BOLD);
        pv.setGravity(Gravity.CENTER);
        pv.setBackground(pill(0xB3000000));
        pv.setPadding((int) (14 * dd0()), 0, (int) (14 * dd0()), 0);
        pv.setTag("previewBtn");
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, qs, Gravity.TOP | Gravity.START);
        pl.setMargins(m, m, 0, 0);
        box.addView(pv, pl);
        pv.setOnClickListener(v -> startPreview());
        if (!getSharedPreferences("app", MODE_PRIVATE).getBoolean("helpSeen", false)) box.post(this::showHelp);
    }

    private boolean previewing;
    private View previewCatcher;

    private void startPreview() {
        if (clips.isEmpty() || previewing) return;
        if (tool != null) closeSheet();
        previewing = true;
        selOv = null;
        layer.invalidate();
        if (!full) setFull(true);
        FrameLayout box = findViewById(R.id.stageBox);
        if (band != null) band.setVisibility(View.GONE);
        if (rail != null) rail.setVisibility(View.GONE);
        for (String t : new String[]{"helpQ", "previewBtn"}) { View v = box.findViewWithTag(t); if (v != null) v.setVisibility(View.GONE); }
        hint.setText("");
        // un strat invizibil peste film: o atingere te întoarce la editare
        previewCatcher = new View(this);
        previewCatcher.setOnClickListener(v -> stopPreview());
        box.addView(previewCatcher, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        seekGlobal(0);
        player.play();
        hint.setText("Atinge ecranul ca să revii la editare");
    }

    private void stopPreview() {
        if (!previewing) return;
        previewing = false;
        player.pause();
        FrameLayout box = findViewById(R.id.stageBox);
        if (previewCatcher != null) { box.removeView(previewCatcher); previewCatcher = null; }
        if (band != null) band.setVisibility(View.VISIBLE);
        if (rail != null) rail.setVisibility(View.VISIBLE);
        for (String t : new String[]{"helpQ", "previewBtn"}) { View v = box.findViewWithTag(t); if (v != null) v.setVisibility(View.VISIBLE); }
        boolean land = getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        if (!land && full) setFull(false);
    }

    private float dd0() { return getResources().getDisplayMetrics().density; }

    private GradientDrawable pill(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(100 * dd0());
        return g;
    }

    /** ajutorul peste film: ce poți face din degete */
    private void showHelp() {
        ViewGroup box = findViewById(R.id.stageBox);
        View old = box.findViewWithTag("help");
        if (old != null) { box.removeView(old); return; }
        float d = dd0();
        FrameLayout ov = new FrameLayout(this);
        ov.setTag("help");
        ov.setBackgroundColor(0xB3000000);
        ov.setClickable(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        String[][] it = {{"☝️", "Trage cu un deget", "rotești privirea"}, {"🤏", "Ciupește cu două degete", "zoom"},
                {"🔄", "Răsucește cu două degete", "rotești imaginea"}, {"👆", "Atinge de două ori", "Tiny Planet"}};
        LinearLayout row = null;
        for (int i = 0; i < it.length; i++) {
            if (i % 2 == 0) { row = new LinearLayout(this); col.addView(row); }
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding((int) (6 * d), (int) (6 * d), (int) (6 * d), (int) (6 * d));
            TextView ic = new TextView(this); ic.setText(it[i][0]); ic.setTextSize(26); ic.setGravity(Gravity.CENTER);
            TextView t1 = new TextView(this); t1.setText(it[i][1]); t1.setTextColor(0xFFFFFFFF); t1.setTextSize(12.5f); t1.setTypeface(null, android.graphics.Typeface.BOLD); t1.setGravity(Gravity.CENTER);
            TextView t2 = new TextView(this); t2.setText(it[i][2]); t2.setTextColor(0xFFD2D4D6); t2.setTextSize(12); t2.setGravity(Gravity.CENTER);
            cell.addView(ic); cell.addView(t1); cell.addView(t2);
            row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        TextView ok = new TextView(this);
        ok.setText("Am înțeles");
        ok.setTextColor(0xFFFFFFFF);
        ok.setTypeface(null, android.graphics.Typeface.BOLD);
        ok.setGravity(Gravity.CENTER);
        ok.setBackground(pill(Th.A));
        ok.setPadding((int) (22 * d), (int) (8 * d), (int) (22 * d), (int) (8 * d));
        LinearLayout.LayoutParams okl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        okl.topMargin = (int) (8 * d);
        okl.gravity = Gravity.CENTER_HORIZONTAL;
        col.addView(ok, okl);
        ok.setOnClickListener(v -> {
            getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("helpSeen", true).apply();
            box.removeView(ov);
        });
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(col);
        ov.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        box.addView(ov, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ---------------- înapoi / refă ----------------
    private Snap snap() {
        Snap s = new Snap();
        for (Clip c : clips) s.clips.add(c.copy());
        for (Overlays.Ov o : ovs) s.ovs.add(o.copy());
        s.filt = filt; s.filtK = filtK; s.art = art; s.recol = recol == null ? null : recol.copy();
        return s;
    }

    private void pushUndo() {
        undo.add(snap());
        if (undo.size() > 40) undo.remove(0);
        redo.clear();
        updateUndoButtons();
    }

    private void restore(Snap s) {
        clips.clear();
        for (Clip c : s.clips) clips.add(c.copy());
        ovs.clear();
        for (Overlays.Ov o : s.ovs) ovs.add(o.copy());
        filt = s.filt; filtK = s.filtK; art = s.art; recol = s.recol == null ? null : s.recol.copy();
        selOv = null;
        applyLook();
        long pos = timeline.getPos();
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        if (!clips.isEmpty()) rebuildPlayer(Math.min(pos, Math.max(0, timeline.total() - 100)));
        closeSheet();
        buildToolbar();
        layer.invalidate();
    }

    private void doUndo() { if (undo.isEmpty()) return; redo.add(snap()); restore(undo.remove(undo.size() - 1)); updateUndoButtons(); }

    private void doRedo() { if (redo.isEmpty()) return; undo.add(snap()); restore(redo.remove(redo.size() - 1)); updateUndoButtons(); }

    private void updateUndoButtons() {
        findViewById(R.id.btnUndo).setAlpha(undo.isEmpty() ? 0.35f : 1f);
        findViewById(R.id.btnRedo).setAlpha(redo.isEmpty() ? 0.35f : 1f);
    }

    // ---------------- ecran mare ----------------
    private void setFull(boolean f) {
        full = f;
        getWindow().getDecorView().setSystemUiVisibility(f ? (View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) : 0);
        int v = f ? View.GONE : View.VISIBLE;
        for (int id : new int[]{R.id.edHead, R.id.edLine, R.id.edBar, R.id.hint, R.id.toolScroll}) findViewById(id).setVisibility(v);
        findViewById(R.id.btnFull).setVisibility(v);
        moveControls(f);
        View sh = findViewById(R.id.sheet);
        FrameLayout.LayoutParams slp = (FrameLayout.LayoutParams) sh.getLayoutParams();
        slp.rightMargin = f ? dpx(58) : 0;
        sh.setLayoutParams(slp);
        if (f) { findViewById(R.id.modes).setVisibility(View.GONE); buildRail(); }
        else {
            // ieșire din ecran întreg ținând telefonul culcat: editorul are nevoie de telefonul drept
            if (getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                findViewById(R.id.stageBox).postDelayed(() -> setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED), 2500);
            }
            if (rail != null) { ((FrameLayout) findViewById(R.id.stageBox)).removeView(rail); rail = null; }
            Clip c = cur(); findViewById(R.id.modes).setVisibility(c != null && c.is360 ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        // telefonul culcat = filmul pe tot ecranul; drept = înapoi la editor
        boolean l = c.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        if (l != full) setFull(l);
    }

    @Override
    public void onBackPressed() {
        if (previewing) { stopPreview(); return; }
        if (full) { setFull(false); return; }
        if (tool != null) { closeSheet(); return; }
        super.onBackPressed();
    }

    // ---------------- bara de unelte ----------------
    /** uneltele de acum: {id, nume, iconiță} */
    private List<Object[]> toolList() {
        List<Object[]> l = new ArrayList<>();
        if (timeline.getSelected() >= 0) {
            l.add(new Object[]{"back", "Înapoi", R.drawable.ic_back});
            l.add(new Object[]{"split", "Împarte", R.drawable.t_split});
            l.add(new Object[]{"left", "Mută stânga", R.drawable.ic_left});
            l.add(new Object[]{"right", "Mută dreapta", R.drawable.ic_right});
            l.add(new Object[]{"del", "Șterge", R.drawable.ic_del});
            return l;
        }
        l.add(new Object[]{"ai", "AI", R.drawable.t_ai});
        if (auto) l.add(new Object[]{"montaj", "Montaj", R.drawable.t_montage});
        l.add(new Object[]{"voice", "Voce", R.drawable.t_mic});
        l.add(new Object[]{"fx", "Efecte", R.drawable.t_fx});
        l.add(new Object[]{"template", "Template", R.drawable.t_template});
        l.add(new Object[]{"text", "Text", R.drawable.t_text});
        l.add(new Object[]{"sticker", "Sticker", R.drawable.t_sticker});
        l.add(new Object[]{"music", "Muzică", R.drawable.t_music});
        l.add(new Object[]{"filt", "Filtru și desen", R.drawable.t_filter});
        l.add(new Object[]{"track", "Track", R.drawable.t_track});
        l.add(new Object[]{"split", "Împarte", R.drawable.t_split});
        return l;
    }

    /** benzile de sub filmări: textele, efectele și filtrul puse */
    private void refreshBands() {
        List<Timeline.Band> l = new ArrayList<>();
        for (Overlays.Ov o : ovs) {
            if ("letterbox".equals(o.style)) continue;
            String t = o.text == null ? "" : o.text.split("\n")[0];
            l.add(new Timeline.Band(0, o.a, o.b, (o.emoji ? "" : "T  ") + t, o.emoji ? 0xFFD08A1E : 0xFF4670C8, o));
        }
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            if (c.fx == null || c.fx.equals("none")) continue;
            int k = java.util.Arrays.asList(Fx.IDS).indexOf(c.fx);
            String n = k >= 0 ? Fx.NAMES[k] : c.fx;
            long a = timeline.startOf(i);
            l.add(new Timeline.Band(1, a, a + c.t.len(), "✦ " + n, 0xFF9450C8, "fx:" + i));
        }
        boolean bars = false;
        for (Overlays.Ov o : ovs) if ("letterbox".equals(o.style)) bars = true;
        List<String> f = new ArrayList<>();
        if (filt != null && !filt.equals("none")) f.add("Filtru");
        if (art > 0 && art < Look.ART_NAMES.length) f.add(Look.ART_NAMES[art]);
        if (recol != null) f.add("Culoarea hainei");
        if (bars) f.add("Benzi de film");
        if (!f.isEmpty()) l.add(new Timeline.Band(2, 0, Math.max(1, timeline.total()), "● " + android.text.TextUtils.join(" · ", f), 0xFF2E9670, "filt"));
        int before = timeline.bandRows();
        timeline.setBands(l);
        if (timeline.bandRows() != before) {
            ViewGroup.LayoutParams lp = timeline.getLayoutParams();
            if (lp != null) { lp.height = (band != null ? dpx(70) : dpx(100)) + dpx(22) * timeline.bandRows(); timeline.setLayoutParams(lp); }
        }
    }

    private void onBand(Object tag) {
        if (tag instanceof Overlays.Ov) {
            Overlays.Ov o = (Overlays.Ov) tag;
            selOv = o;
            layer.invalidate();
            seekGlobal(o.a + 100);
            openSheet(o.emoji ? "sticker" : "text");
        } else if (tag instanceof String && ((String) tag).startsWith("fx:")) {
            int i = Integer.parseInt(((String) tag).substring(3));
            seekGlobal(timeline.startOf(i) + 50);
            openSheet("fx");
        } else if ("filt".equals(tag)) openSheet("filt");
    }

    private void buildToolbar() {
        refreshBands();
        LinearLayout bar = findViewById(R.id.toolbar);
        bar.removeAllViews();
        for (Object[] t : toolList()) addTool(bar, (String) t[0], (String) t[1], (Integer) t[2]);
        if (full) buildRail();
    }

    // ---------------- ecran întreg: filmul mare, iconițe în dreapta, banda cu timpul jos peste film ----------------
    private LinearLayout rail, band;
    private int ctrlIdx = -1, tlIdx = -1;

    private int dpx(float v) { return Math.round(v * dd); }

    private void buildRail() {
        FrameLayout box = findViewById(R.id.stageBox);
        if (rail != null) box.removeView(rail);
        rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_HORIZONTAL);
        rail.setBackgroundColor(0x990A0B0D);
        rail.setPadding(dpx(6), dpx(6), dpx(6), dpx(6));
        LinearLayout icons = new LinearLayout(this);
        icons.setOrientation(LinearLayout.VERTICAL);
        icons.setGravity(Gravity.CENTER_HORIZONTAL);
        icons.addView(railBtn(R.drawable.ic_exit_full, "Ieși din ecran întreg", false, v -> setFull(false)), railLp());
        Clip c = cur();
        if (c != null && c.is360) {
            boolean pl = view.isPlanet();
            icons.addView(railBtn(R.drawable.ic_planet, pl ? "Înapoi la cadru" : "Tiny Planet", pl, v -> {
                modeGroup.check(view.isPlanet() ? R.id.mCustom : R.id.mPlanet);
                buildRail();
            }), railLp());
            icons.addView(railBtn(R.drawable.ic_stab, stab ? "Stabilizare pornită" : "Stabilizare", stab, v -> { btnStab.performClick(); buildRail(); }), railLp());
        }
        for (Object[] t : toolList()) {
            String id = (String) t[0];
            icons.addView(railBtn((Integer) t[2], (String) t[1], id.equals(tool), v -> onTool(id)), railLp());
        }
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(icons);
        rail.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        ImageView save = railBtn(R.drawable.ic_save_ok, "Salvează filmul", false, v -> askSave());
        android.graphics.drawable.GradientDrawable sg = new android.graphics.drawable.GradientDrawable();
        sg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        sg.setColor(Th.A);
        save.setBackground(sg);
        save.setImageTintList(null);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dpx(46), dpx(46));
        sp.topMargin = dpx(6);
        rail.addView(save, sp);
        box.addView(rail, new FrameLayout.LayoutParams(dpx(58), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
    }

    private LinearLayout.LayoutParams railLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpx(42), dpx(42));
        lp.setMargins(0, dpx(4), 0, dpx(4));
        return lp;
    }

    private ImageView railBtn(int icon, String desc, boolean on, View.OnClickListener cl) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setImageTintList(android.content.res.ColorStateList.valueOf(0xFFF2F2F0));
        b.setContentDescription(desc);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(on ? 0xFF2A2C30 : 0xFF141518);
        if (on) g.setStroke(dpx(2), Th.A);
        b.setBackground(g);
        b.setPadding(dpx(10), dpx(10), dpx(10), dpx(10));
        b.setOnClickListener(cl);
        return b;
    }

    /** mută butoanele de redare și banda cu filmul peste film, jos (și înapoi la ieșire) */
    private void moveControls(boolean intoBand) {
        LinearLayout mainCol = findViewById(R.id.edMain);
        View ctrl = findViewById(R.id.edCtrl);
        FrameLayout box = findViewById(R.id.stageBox);
        if (intoBand) {
            if (band != null) return;
            ctrlIdx = mainCol.indexOfChild(ctrl);
            tlIdx = mainCol.indexOfChild(timeline);
            mainCol.removeView(ctrl);
            mainCol.removeView(timeline);
            band = new LinearLayout(this);
            band.setOrientation(LinearLayout.VERTICAL);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setColor(0xA60A0B0D);
            g.setCornerRadius(dpx(18));
            band.setBackground(g);
            band.setPadding(dpx(6), dpx(2), dpx(6), dpx(6));
            band.addView(ctrl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            band.addView(timeline, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(70) + dpx(22) * timeline.bandRows()));
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
            lp.setMargins(dpx(10), 0, dpx(58) + dpx(10), dpx(8));
            box.addView(band, lp);
        } else {
            if (band == null) return;
            band.removeView(ctrl);
            band.removeView(timeline);
            box.removeView(band);
            band = null;
            mainCol.addView(ctrl, Math.min(ctrlIdx, mainCol.getChildCount()), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            mainCol.addView(timeline, Math.min(tlIdx, mainCol.getChildCount()), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(100) + dpx(22) * timeline.bandRows()));
        }
    }

    private void addTool(LinearLayout bar, String id, String label, int icon) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setContentDescription(label);
        boolean on = id.equals(tool);
        if (on) t.setBackgroundResource(R.drawable.tool_on);
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        iv.setImageTintList(android.content.res.ColorStateList.valueOf(0xFFF2F2F0));
        t.addView(iv, new LinearLayout.LayoutParams((int) (24 * dd), (int) (24 * dd)));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(0xFFF2F2F0);
        tv.setTextSize(12);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, (int) (4 * dd), 0, 0);
        tv.setMaxLines(1);
        t.addView(tv);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (78 * dd), (int) (62 * dd));
        lp.setMargins((int) (2 * dd), 0, (int) (2 * dd), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> onTool(id));
        bar.addView(t);
    }

    private void onTool(String id) {
        switch (id) {
            case "back": timeline.setSelected(-1); buildToolbar(); setHint(); return;
            case "split": splitAtPlayhead(); return;
            case "voice": startVoice(); return;
            case "left": moveSel(-1); return;
            case "right": moveSel(1); return;
            case "del": deleteSel(); return;
            case "text":
                if (selOv == null || selOv.emoji) addText();
                openSheet("text");
                return;
            default:
                if (id.equals(tool)) closeSheet(); else openSheet(id);
        }
    }

    // ---------------- foaia de jos ----------------
    private void openSheet(String id) {
        tool = id;
        View sh = findViewById(R.id.sheet);
        sh.setVisibility(View.VISIBLE);
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.5f);
        View sc = findViewById(R.id.sheetScroll);
        sc.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        sc.requestLayout();
        sc.post(() -> { if (sc.getHeight() > maxH) { sc.getLayoutParams().height = maxH; sc.requestLayout(); } });
        fillSheet();
        buildToolbar();
    }

    private void closeSheet() {
        tool = null;
        findViewById(R.id.sheet).setVisibility(View.GONE);
        buildToolbar();
    }

    private TextView title(LinearLayout body, String t) {
        TextView l = new TextView(this);
        l.setText(t.toUpperCase(new Locale("ro")));
        l.setTextColor(0xFF7C8186);
        l.setTextSize(11.5f);
        l.setLetterSpacing(0.1f);
        l.setPadding(0, (int) (12 * dd), 0, (int) (6 * dd));
        body.addView(l);
        return l;
    }

    private LinearLayout chipRow(LinearLayout body) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(row);
        body.addView(hs);
        return row;
    }

    private TextView chip(String text, boolean on, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13.5f);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.chip_bg);
        t.setTextColor(getResources().getColorStateList(R.color.chip_text, getTheme()));
        t.setPadding((int) (16 * dd), 0, (int) (16 * dd), 0);
        t.setSelected(on);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (38 * dd));
        lp.setMarginEnd((int) (8 * dd));
        t.setLayoutParams(lp);
        return t;
    }

    private MaterialButton bigButton(LinearLayout body, String text, boolean accent, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setCornerRadius((int) (26 * dd));
        if (!accent) {
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF262A2E));
            b.setTextColor(0xFFF2F2F0);
        }
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (54 * dd));
        lp.topMargin = (int) (10 * dd);
        body.addView(b, lp);
        return b;
    }

    private TextView note(LinearLayout body, String t) {
        TextView n = new TextView(this);
        n.setText(t);
        n.setTextColor(0xFFB9BCBF);
        n.setTextSize(13);
        n.setPadding(0, (int) (8 * dd), 0, 0);
        body.addView(n);
        return n;
    }

    private void fillSheet() {
        LinearLayout body = findViewById(R.id.sheetBody);
        body.removeAllViews();
        TextView ttl = findViewById(R.id.sheetTitle);
        if (tool == null) return;
        switch (tool) {
            case "montaj": {
                ttl.setText("Montaj automat");
                title(body, "Cât să dureze");
                LinearLayout r1 = chipRow(body);
                String[][] o = {{"15", "15 s"}, {"30", "30 s"}, {"60", "60 s"}, {"0", "Tot"}};
                for (String[] x : o) r1.addView(chip(x[1], x[0].equals(autoDur), v -> { autoDur = x[0]; fillSheet(); }));
                title(body, "Stil");
                LinearLayout r2 = chipRow(body);
                String[][] st = {{"fast", "Rapid"}, {"normal", "Normal"}, {"calm", "Relaxat"}};
                for (String[] x : st) r2.addView(chip(x[1], x[0].equals(autoStyle), v -> { autoStyle = x[0]; fillSheet(); }));
                note(body, "Aleg din fiecare filmare bucățile cele mai vii (2 s la Rapid, 3 s la Normal, 5 s la Relaxat).");
                bigButton(body, "Refă montajul", true, v -> rebuildAuto());
                break;
            }
            case "ai": fillAi(body, ttl); break;
            case "template": fillTemplate(body, ttl); break;
            case "fx": fillFx(body, ttl); break;
            case "track": fillTrack(body, ttl); break;
            case "text": fillText(body, ttl); break;
            case "sticker": fillSticker(body, ttl); break;
            case "music": fillMusic(body, ttl); break;
            case "filt": fillFilter(body, ttl); break;
        }
    }

    // ---- AI ----
    private void fillAi(LinearLayout body, TextView ttl) {
        ttl.setText("AI");
        title(body, "Montaj automat");
        LinearLayout r1 = chipRow(body);
        String[][] o = {{"15", "15 s"}, {"30", "30 s"}, {"60", "60 s"}, {"0", "Tot"}};
        for (String[] x : o) r1.addView(chip(x[1], x[0].equals(autoDur), v -> { autoDur = x[0]; fillSheet(); }));
        LinearLayout r2 = chipRow(body);
        String[][] st = {{"fast", "Rapid"}, {"normal", "Normal"}, {"calm", "Relaxat"}};
        for (String[] x : st) r2.addView(chip(x[1], x[0].equals(autoStyle), v -> { autoStyle = x[0]; fillSheet(); }));
        bigButton(body, "✨ Fă montajul automat", true, v -> aiMontage());
        note(body, "AI-ul alege singur cele mai vii momente din filmări și le pune una după alta.");
        Clip c = cur();
        if (c != null && c.is360) {
            title(body, "Încadrare");
            bigButton(body, "✨ Urmărește oamenii în bucata asta", false, v -> withPeople(c, () -> {
                Track tr = People.follow(c.people, null, 40);
                if (tr == null) { Toast.makeText(this, "Nu am găsit oameni în bucata asta.", Toast.LENGTH_LONG).show(); return; }
                pushUndo();
                c.track = tr;
                hint.setText("Cadrul urmărește oamenii în bucata " + (curIdx + 1) + ". Apasă ▶.");
                seekGlobal(timeline.startOf(curIdx));
                closeSheet();
            }));
            bigButton(body, "Alege eu persoana de urmărit", false, v -> startPick());
        }
    }

    private void aiMontage() {
        closeSheet();
        Runnable apply = () -> {
            boolean was = auto;
            auto = true;
            rebuildAuto();
            if (!was) buildToolbar();
            Toast.makeText(this, "Montajul AI e gata. Apasă ▶.", Toast.LENGTH_LONG).show();
        };
        if (analyzed) apply.run();
        else {
            afterAnalyze = apply;
            analyzing = true;
            showBusy("Analizez scenele 0%", "Caut cele mai vii momente din fiecare filmare", () -> { afterAnalyze = null; analyzeCancelled = true; });
            new Thread(this::analyze).start();
        }
    }

    // ---- Deep Track ----
    private void fillTrack(LinearLayout body, TextView ttl) {
        ttl.setText("Deep Track");
        Clip c = cur();
        if (c == null || !c.is360) { note(body, "Deep Track merge la filmările 360. Mută banda pe un cadru 360."); return; }
        if (c.track != null) {
            int pct = Math.round(c.track.found * 100f / Math.max(1, c.track.total));
            note(body, "Cadrul " + (curIdx + 1) + " urmărește persoana aleasă (găsită în " + pct + "% din timp).");
            bigButton(body, "Alege altă persoană", true, v -> startPick());
            bigButton(body, "Oprește urmărirea", false, v -> { pushUndo(); c.track = null; view.requestRender(); fillSheet(); });
        } else {
            note(body, "Mută banda până apare persoana, apoi apasă butonul și atinge persoana pe film. Cadrul o va urmări singur.");
            bigButton(body, "👆 Atinge persoana pe film", true, v -> startPick());
        }
        title(body, "AI pe telefon");
        bigButton(body, "✨ Încadrare automată: urmărește oamenii", c.track == null, v -> withPeople(c, () -> {
            Track tr = People.follow(c.people, null, 40);
            if (tr == null) { Toast.makeText(this, "Nu am găsit oameni în bucata asta.", Toast.LENGTH_LONG).show(); return; }
            pushUndo();
            c.track = tr;
            hint.setText("Încadrare automată: cadrul urmărește oamenii în bucata " + (curIdx + 1) + ". Apasă ▶.");
            seekGlobal(timeline.startOf(curIdx));
            fillSheet();
        }));
        if (c.people != null) {
            List<float[]> sg = People.suggest(c.people);
            if (sg.isEmpty()) note(body, "Nu am găsit oameni în bucata asta.");
            else {
                title(body, "Unghiuri sugerate (unde sunt oamenii)");
                LinearLayout r = chipRow(body);
                for (int i = 0; i < sg.size(); i++) {
                    final float[] a = sg.get(i);
                    r.addView(chip("Unghiul " + (i + 1), false, v -> {
                        pushUndo();
                        c.track = null;
                        c.view = new float[]{a[0], a[1], 95f, 0f};
                        view.setView(a[0], a[1], 95f, false);
                        fillSheet();
                    }));
                }
            }
        } else {
            bigButton(body, "Arată unghiurile unde sunt oamenii", false, v -> withPeople(c, this::fillSheet));
        }
    }

    /** caută oamenii în bucată o singură dată (AI pe telefon), apoi face `then` */
    private void withPeople(Clip c, Runnable then) {
        if (c.people != null) { then.run(); return; }
        if (player.isPlaying()) player.pause();
        trackCancel = false;
        showBusy("Caut oamenii 0%", "AI-ul se uită în toate direcțiile filmării", () -> trackCancel = true);
        new Thread(() -> {
            List<People.Sample> s = People.detect(this, c.prev, c.gyro, c.t.in / 1000.0, c.t.out / 1000.0, 0.5, new People.Progress() {
                @Override public void on(int pct) { main.post(() -> setBusy("Caut oamenii " + pct + "%", null)); }
                @Override public boolean cancelled() { return trackCancel || isFinishing(); }
            });
            main.post(() -> {
                hideBusy();
                if (s == null) { if (!trackCancel) Toast.makeText(this, "Nu am putut citi filmarea.", Toast.LENGTH_LONG).show(); return; }
                c.people = s;
                then.run();
            });
        }).start();
    }

    private void startPick() {
        if (player.isPlaying()) player.pause();
        picking = true;
        closeSheet();
        hint.setText("👆 Atinge persoana pe film, ca s-o urmăresc.");
        Toast.makeText(this, "Atinge persoana pe film", Toast.LENGTH_SHORT).show();
    }

    // ---- Template ----
    private Bitmap tplCard(Overlays.Tpl t, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setShader(new android.graphics.LinearGradient(0, 0, w, h, t.g0, t.g1, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new android.graphics.LinearGradient(0, h / 2f, 0, h, 0x00000000, 0x59000000, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        Overlays.Ov o = new Overlays.Ov();
        o.text = t.title; o.style = t.ts; o.anim = "none"; o.x = 0.5f; o.y = 0.48f; o.s = 0.95f; o.a = 0; o.b = 99000;
        Overlays.drawOne(c, o, 5000, w, h, false);
        return b;
    }

    /** cardul șablonului desenat peste un cadru din filmarea ta (cu filtrul, benzile și titlul lui) */
    private Bitmap tplOnFrame(Overlays.Tpl t, Bitmap frame, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        c.drawBitmap(frame, null, new android.graphics.Rect(0, 0, w, h), new android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG));
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setShader(new android.graphics.LinearGradient(0, h * 0.55f, 0, h, 0x00000000, 0x66000000, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        if (t.bars) { Overlays.Ov bars = new Overlays.Ov(); bars.style = "letterbox"; Overlays.drawOne(c, bars, 0, w, h, false); }
        if (t.plan.contains("split")) { p.setShader(null); p.setColor(0xFFFFFFFF); c.drawRect(0, h / 2f - dd, w, h / 2f + dd, p); }
        Overlays.Ov o = new Overlays.Ov();
        boolean min = "minimal".equals(t.ts);
        o.text = t.title; o.style = t.ts; o.anim = "none"; o.x = 0.5f; o.y = min ? 0.74f : 0.5f; o.s = min ? 0.7f : 0.85f; o.a = 0; o.b = 99000;
        Overlays.drawOne(c, o, 5000, w, h, false);
        if (t.beat > 0) { // bare de ritm
            p.setShader(null); p.setColor(0xFFFFFFFF);
            for (int i = 0; i < 7; i++) { float bh = (6 + (float) Math.abs(Math.sin(i * 1.3)) * 18) * dd; c.drawRoundRect(new android.graphics.RectF((8 + i * 7) * dd, (h - 10 * dd) - bh, (12 + i * 7) * dd, h - 10 * dd), 2 * dd, 2 * dd, p); }
        }
        return b;
    }

    private void fillTemplate(LinearLayout body, TextView ttl) {
        ttl.setText("Template");
        LinearLayout tabs = chipRow(body);
        for (String cat : Overlays.TPL_CATS) {
            TextView t = new TextView(this);
            t.setText(cat);
            t.setTextSize(15);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setTextColor(cat.equals(tplCat) ? 0xFFF2F2F0 : 0xFF7C8186);
            t.setPadding(0, (int) (4 * dd), (int) (18 * dd), (int) (8 * dd));
            if (cat.equals(tplCat)) t.setPaintFlags(t.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
            t.setOnClickListener(v -> { tplCat = cat; fillSheet(); });
            tabs.addView(t);
        }
        LinearLayout cards = chipRow(body);
        int cw = (int) (118 * dd), ch = (int) (168 * dd);
        Overlays.Tpl chosen = null;
        for (Overlays.Tpl t : Overlays.TPLS) {
            if (t.id.equals(tplSel)) chosen = t;
            if (!t.cat.equals(tplCat)) continue;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView iv = new ImageView(this);
            Bitmap th = tplThumbs.get(t.id);
            iv.setImageBitmap(th != null ? th : tplCard(t, cw, ch));
            if (th == null && !clips.isEmpty()) {
                final int fw = cw, fh = ch;
                final Overlays.Tpl ft = t;
                final ImageView fiv = iv;
                view.capture(fw, fh, Look.of(ft.filt, 70), ft.art, bmp -> {
                    if (bmp == null || isFinishing()) return;
                    Bitmap pic = tplOnFrame(ft, bmp, fw, fh);
                    tplThumbs.put(ft.id, pic);
                    fiv.setImageBitmap(pic);
                });
            }
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), 12 * dd); }
            });
            if (t.id.equals(tplSel)) {
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(14 * dd);
                g.setStroke((int) (2.5f * dd), 0xFFF2F2F0);
                card.setBackground(g);
            }
            card.setPadding((int) (3 * dd), (int) (3 * dd), (int) (3 * dd), (int) (3 * dd));
            card.addView(iv, new LinearLayout.LayoutParams(cw, ch));
            TextView n = new TextView(this);
            n.setText(t.name);
            n.setTextColor(t.id.equals(tplSel) ? 0xFFF2F2F0 : 0xFFB9BCBF);
            n.setTextSize(13);
            n.setTypeface(null, t.id.equals(tplSel) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            n.setPadding(0, (int) (6 * dd), 0, 0);
            card.addView(n);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (10 * dd));
            card.setLayoutParams(lp);
            card.setOnClickListener(v -> { tplSel = t.id; fillSheet(); });
            cards.addView(card);
        }
        if (chosen == null) {
            note(body, "Alege un șablon: face singur montajul din filmările tale, cu ritm, filtru și titlu animat. Apoi poți schimba orice.");
            return;
        }
        String sty = chosen.style.equals("fast") ? "ritm rapid" : chosen.style.equals("calm") ? "ritm lent" : "ritm normal";
        String fn = Look.NAMES[java.util.Arrays.asList(Look.IDS).indexOf(chosen.filt)];
        note(body, chosen.name + " · " + sty + " · " + chosen.dur + " s · filtru " + fn + " · titlu animat");
        final Overlays.Tpl tp = chosen;
        bigButton(body, "Folosește șablonul", true, v -> useTemplate(tp));
    }

    private void useTemplate(Overlays.Tpl t) {
        closeSheet();
        autoStyle = t.style;
        autoDur = String.valueOf(t.dur);
        Runnable apply = () -> {
            boolean was = auto;
            auto = true;
            rebuildAuto();
            filt = t.filt;
            applyLook();
            if (tplTitle != null) ovs.remove(tplTitle);
            if (tplBars != null) { ovs.remove(tplBars); tplBars = null; }
            // efectele șablonului, pe rând pe bucăți (mișcările de cadru doar pe filmări 360)
            String[] plan = t.plan.isEmpty() ? new String[0] : t.plan.split(",");
            for (int i = 0; i < clips.size(); i++) {
                Clip c = clips.get(i);
                String f = plan.length == 0 ? "none" : plan[i % plan.length];
                if (!c.is360 && !Fx.isSpeed(f)) f = "none";
                c.fx = f;
                c.speed = Fx.isSpeed(f) ? Fx.speedFor(f, 4) : 1f;
                c.fxDur = 2.5f;
            }
            // „Ritm”: tăiem bucățile pe bătăi, fiecare cu alt unghi și o intrare rapidă
            if (t.beat > 0 && !plan[0].isEmpty()) {
                float[] ang = {0f, 110f, -70f, 200f, 40f, -150f};
                List<Clip> cut = new ArrayList<>();
                long limit = (long) t.dur * 1000L, sum = 0;
                for (Clip c : clips) {
                    for (long s0 = c.t.in; s0 + t.beat <= c.t.out && sum < limit; s0 += t.beat) {
                        Clip n = c.copy();
                        n.key = c.key + "@" + s0;
                        n.t.in = s0; n.t.out = s0 + t.beat;
                        int k = cut.size();
                        if (n.is360) {
                            n.view = new float[]{c.view[0] + ang[k % ang.length], c.view[1], c.view[2], 0f};
                            String f = plan[k % plan.length];
                            n.fx = Fx.isSpeed(f) ? "punch" : f;
                            if (k == 0) n.fx = "planetfade";
                            n.fxDur = k == 0 ? 0.5f : 2.5f;
                        } else n.fx = "none";
                        n.speed = 1f;
                        cut.add(n);
                        sum += t.beat;
                    }
                }
                if (cut.size() > 1) {
                    // ultima bucată mai lungă, încetinită, pentru titlu
                    Clip last = cut.get(cut.size() - 1);
                    last.t.out = Math.min(last.t.dur, last.t.in + 2400);
                    last.fx = last.is360 ? "freeze" : "none";
                    clips.clear();
                    clips.addAll(cut);
                    timeline.setClips(timelineClips());
                    curIdx = -1;
                    rebuildPlayer(0);
                }
            }
            art = t.art;
            applyLook();
            if (t.bars) {
                Overlays.Ov bars = new Overlays.Ov();
                bars.style = "letterbox"; bars.text = ""; bars.anim = "none"; bars.a = 0; bars.b = Math.max(1000, timeline.total() + 60000);
                ovs.add(0, bars);
                tplBars = bars;
            }
            Overlays.Ov o = new Overlays.Ov();
            tplTitle = o;
            boolean min = "minimal".equals(t.ts);
            o.text = t.sub.isEmpty() ? t.title : t.title + "\n" + t.sub; o.style = t.ts; o.anim = t.an; o.x = 0.5f; o.y = min ? 0.70f : 0.42f; o.s = min ? 0.8f : 1f;
            if (!t.plan.isEmpty() && !min) o.loop = "float";
            if ("cine360".equals(t.id) || "moment".equals(t.id)) o.font = "thinwide";
            long tot = timeline.total();
            if (min && t.beat > 0) { o.a = Math.max(0, tot - 2400); o.b = tot; }   // titlul la final, pe bucata încetinită
            else { o.a = 0; o.b = Math.min(3500, Math.max(1500, tot)); }
            ovs.add(o);
            layer.invalidate();
            if (!was) buildToolbar();
            Toast.makeText(this, "Am făcut montajul „" + t.name + "”. Apasă ▶.", Toast.LENGTH_LONG).show();
        };
        if (analyzed) apply.run();
        else {
            afterAnalyze = apply;
            analyzing = true;
            showBusy("Analizez scenele 0%", "Caut cele mai vii momente din fiecare filmare", () -> { afterAnalyze = null; analyzeCancelled = true; });
            new Thread(this::analyze).start();
        }
    }

    // ---- Text ----
    private void addText() {
        pushUndo();
        Overlays.Ov o = new Overlays.Ov();
        o.text = "Textul tău";
        long tot = timeline.total();
        o.a = timeline.getPos();
        if (tot > 0 && o.a > tot - 1500) o.a = Math.max(0, tot - 3000);
        o.b = o.a + 3000;
        ovs.add(o);
        selOv = o;
        layer.invalidate();
    }

    private void fillText(LinearLayout body, TextView ttl) {
        ttl.setText("Text");
        final Overlays.Ov o = selOv;
        if (o == null || o.emoji) { note(body, "Atinge „Text” ca să pui un text nou pe film."); return; }
        EditText et = new EditText(this);
        et.setText(o.text);
        et.setTextColor(0xFFF2F2F0);
        et.setTextSize(17);
        et.setBackgroundResource(R.drawable.src_off);
        et.setPadding((int) (14 * dd), (int) (12 * dd), (int) (14 * dd), (int) (12 * dd));
        et.setMinLines(2);
        et.setSelectAllOnFocus(true);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void afterTextChanged(Editable s) { o.text = s.toString(); layer.invalidate(); }
        });
        body.addView(et);
        title(body, "Stil");
        LinearLayout r1 = chipRow(body);
        for (String[] s : Overlays.STYLES) r1.addView(chip(s[1], s[0].equals(o.style), v -> { pushUndo(); o.style = s[0]; if (s[0].equals("subtitrare")) o.y = 0.86f; layer.invalidate(); fillSheet(); }));
        title(body, "Font");
        LinearLayout rf = chipRow(body);
        for (String[] s : Overlays.FONTS) {
            View ch = chip(s[1], s[0].equals(o.font), v -> { pushUndo(); o.font = s[0]; layer.invalidate(); fillSheet(); });
            if (ch instanceof TextView) { Overlays.applyFont((TextView) ch, s[0]); }
            rf.addView(ch);
        }
        title(body, "Animație la intrare");
        LinearLayout r2 = chipRow(body);
        for (String[] s : Overlays.ANIMS) r2.addView(chip(s[1], s[0].equals(o.anim), v -> { o.anim = s[0]; replayOv(o); fillSheet(); }));
        title(body, "Mișcare după aceea");
        LinearLayout r2b = chipRow(body);
        for (String[] s : Overlays.LOOPS) r2b.addView(chip(s[1], s[0].equals(o.loop), v -> { o.loop = s[0]; replayOv(o); fillSheet(); }));
        title(body, "Culoare");
        LinearLayout r3 = chipRow(body);
        for (int col : Overlays.COLORS) {
            View c = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            g.setStroke((int) ((col == o.color ? 3 : 1) * dd), col == o.color ? Th.A : 0xFF3A4048);
            c.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (36 * dd), (int) (36 * dd));
            lp.setMarginEnd((int) (10 * dd));
            c.setOnClickListener(v -> { o.color = col; layer.invalidate(); fillSheet(); });
            r3.addView(c, lp);
        }
        durationChips(body, o);
        bigButton(body, "＋ Alt text", false, v -> { addText(); fillSheet(); });
        bigButton(body, "Șterge textul", false, v -> { pushUndo(); ovs.remove(o); selOv = null; layer.invalidate(); closeSheet(); });
    }

    private void durationChips(LinearLayout body, Overlays.Ov o) {
        title(body, "Cât stă pe ecran");
        LinearLayout r = chipRow(body);
        long len = o.b - o.a;
        long[] ds = {2000, 3000, 5000};
        for (long d : ds) r.addView(chip((d / 1000) + " s", Math.abs(len - d) < 50, v -> { o.b = o.a + d; layer.invalidate(); fillSheet(); }));
        long end = Math.max(o.a + 500, timeline.total());
        r.addView(chip("Până la final", o.b >= end - 50, v -> { o.b = Math.max(o.a + 500, timeline.total()); layer.invalidate(); fillSheet(); }));
    }

    /** arată animația din nou: mută filmul la începutul textului */
    private void replayOv(Overlays.Ov o) {
        if (player.isPlaying()) player.pause();
        seekGlobal(o.a);
        timeline.setPos(o.a);
        player.play();
        main.postDelayed(() -> { if (player != null && player.isPlaying() && timeline.getPos() > o.a + 1500) player.pause(); }, 1600);
    }

    // ---- Sticker ----
    private void fillSticker(LinearLayout body, TextView ttl) {
        ttl.setText("Sticker");
        note(body, "Atinge un sticker ca să-l pui pe film. Apoi îl tragi cu degetul și îl mărești cu două degete.");
        LinearLayout row = null;
        for (int i = 0; i < Overlays.EMOJIS.length; i++) {
            if (i % 8 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                body.addView(row);
            }
            final String e = Overlays.EMOJIS[i];
            TextView t = new TextView(this);
            t.setText(e);
            t.setTextSize(26);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                pushUndo();
                Overlays.Ov o = new Overlays.Ov();
                o.emoji = true; o.text = e; o.anim = "pop"; o.loop = "float";
                o.x = 0.5f + (float) (Math.random() - 0.5) * 0.3f; o.y = 0.5f + (float) (Math.random() - 0.5) * 0.3f;
                o.a = timeline.getPos();
                long tot = timeline.total();
                if (tot > 0 && o.a > tot - 1500) o.a = Math.max(0, tot - 3000);
                o.b = o.a + 3000;
                ovs.add(o);
                selOv = o;
                layer.invalidate();
                fillSheet();
            });
            row.addView(t, new LinearLayout.LayoutParams(0, (int) (48 * dd), 1f));
        }
        if (selOv != null && selOv.emoji) {
            final Overlays.Ov o = selOv;
            title(body, "Cum intră");
            LinearLayout ra = chipRow(body);
            for (String[] s : Overlays.ANIMS) if (!s[0].equals("type")) ra.addView(chip(s[1], s[0].equals(o.anim), v -> { o.anim = s[0]; replayOv(o); fillSheet(); }));
            title(body, "Cum se mișcă");
            LinearLayout rl = chipRow(body);
            for (String[] s : Overlays.LOOPS) rl.addView(chip(s[1], s[0].equals(o.loop), v -> { o.loop = s[0]; replayOv(o); fillSheet(); }));
            durationChips(body, o);
            bigButton(body, "Șterge stickerul", false, v -> { pushUndo(); ovs.remove(o); selOv = null; layer.invalidate(); fillSheet(); });
        }
    }

    // ---- Muzică ----
    private void fillMusic(LinearLayout body, TextView ttl) {
        ttl.setText("Sunet și muzică");
        bigButton(body, music == null ? "＋ Alege o melodie din telefon" : "♫ " + musicName + " · schimbă", music == null, v -> pickMusic());
        if (music != null) bigButton(body, "Fără muzică", false, v -> setMusic(null, null));
        android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("Păstrează sunetul filmărilor");
        cb.setTextColor(0xFFF2F2F0);
        cb.setTextSize(15);
        cb.setChecked(origSound);
        cb.setPadding(0, (int) (8 * dd), 0, (int) (8 * dd));
        cb.setOnCheckedChangeListener((x, on) -> { origSound = on; applyVolumes(); });
        body.addView(cb);
        if (music != null) body.addView(slider("Volum muzică", musicVol, 100, v -> { musicVol = v; applyVolumes(); }));
    }

    // ---- Filtru ----
    /** efectele de mișcare, pe bucata de la cursor */
    private void fillFx(LinearLayout body, TextView ttl) {
        ttl.setText("Efecte");
        Clip c = cur();
        if (c == null) return;
        title(body, "Efect pe bucata " + (clips.indexOf(c) + 1));
        LinearLayout r = chipRow(body);
        for (int i = 0; i < Fx.IDS.length; i++) {
            final String id = Fx.IDS[i];
            if (!c.is360 && !id.equals("none") && !Fx.isSpeed(id)) continue; // mișcările de cadru cer filmare 360
            r.addView(chip(Fx.NAMES[i], id.equals(c.fx), v -> {
                pushUndo();
                c.fx = id;
                c.speed = Fx.isSpeed(id) ? Fx.speedFor(id, 4) : 1f;
                seekGlobal(timeline.startOf(clips.indexOf(c)) + 30);
                view.requestRender();
                fillSheet();
            }));
        }
        if (Fx.isSpeed(c.fx)) {
            TextView sv = new TextView(this);
            sv.setTextColor(0xFFF2F2F0);
            sv.setTextSize(15);
            sv.setText(String.format(java.util.Locale.US, "Viteză ×%.1f", c.speed));
            body.addView(sv);
            body.addView(slider("", Math.max(0, Math.min(9, Fx.sliderFor(c.fx, c.speed))), 9, x -> {
                c.speed = Fx.speedFor(c.fx, x);
                sv.setText(String.format(java.util.Locale.US, "Viteză ×%.1f", c.speed));
            }));
            TextView h = new TextView(this);
            h.setText("Se aplică pe toată bucata. Ca să accelerezi doar o parte, împarte bucata întâi (Împarte).");
            h.setTextColor(0xFF9AA0A6);
            h.setTextSize(12.5f);
            body.addView(h);
        } else if (!"none".equals(c.fx)) {
            // viteza: 1 = foarte lent (6 s) … 10 = foarte rapid (0,8 s)
            int sp = Math.round(10 - (c.fxDur - 0.8f) / (6f - 0.8f) * 9);
            body.addView(slider("Viteză ", Math.max(1, Math.min(10, sp)) - 1, 9, x -> {
                c.fxDur = 6f - x / 9f * (6f - 0.8f);
                view.requestRender();
            }));
            TextView h = new TextView(this);
            h.setText("Apasă pornire ca să vezi efectul de la începutul bucății.");
            h.setTextColor(0xFF9AA0A6);
            h.setTextSize(12.5f);
            body.addView(h);
        }
    }

    private void fillFilter(LinearLayout body, TextView ttl) {
        ttl.setText("Filtru pentru tot filmul");
        LinearLayout sub = chipRow(body);
        for (int i = 0; i < Look.IDS.length; i++) {
            final String id = Look.IDS[i];
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, Look.SWATCH[i]);
            g.setCornerRadius(12 * dd);
            if (id.equals(filt)) g.setStroke((int) (2.5f * dd), Th.A);
            sw.setBackground(g);
            it.addView(sw, new LinearLayout.LayoutParams((int) (72 * dd), (int) (52 * dd)));
            TextView l = new TextView(this);
            l.setText(Look.NAMES[i]);
            l.setTextSize(12.5f);
            l.setTextColor(id.equals(filt) ? 0xFFF2F2F0 : 0xFFB9BCBF);
            l.setTypeface(null, id.equals(filt) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, (int) (5 * dd), 0, 0);
            it.addView(l);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (10 * dd));
            it.setLayoutParams(lp);
            it.setOnClickListener(v -> { pushUndo(); filt = id; applyLook(); fillSheet(); });
            sub.addView(it);
        }
        title(body, "Intensitate");
        body.addView(slider("", filtK, 100, v -> { filtK = v; applyLook(); }));
        title(body, "Ca desenat");
        LinearLayout ar = chipRow(body);
        for (int i = 0; i < Look.ART_NAMES.length; i++) {
            final int k = i;
            ar.addView(chip(Look.ART_NAMES[i], art == k, v -> { pushUndo(); art = k; applyLook(); fillSheet(); }));
        }
        title(body, "Culoarea hainei");
        LinearLayout cr = chipRow(body);
        cr.addView(chip(recol == null ? "Atinge haina pe film" : "Altă haină", false, v -> {
            Toast.makeText(this, "Atinge acum haina pe film, sus", Toast.LENGTH_LONG).show();
            view.pickColorOnce(c -> {
                pushUndo();
                recol = new Look.Recol(c, recol != null ? recol.dst : Look.RC_COLORS[0], recol != null ? recol.tol : 0.15f);
                applyLook();
                if ("filt".equals(tool)) fillSheet();
            });
        }));
        if (recol != null) {
            cr.addView(chip("Scoate", false, v -> { pushUndo(); recol = null; applyLook(); fillSheet(); }));
            LinearLayout pr = chipRow(body);
            for (int i = 0; i < Look.RC_COLORS.length; i++) {
                final int c = Look.RC_COLORS[i];
                View sw = new View(this);
                GradientDrawable g = new GradientDrawable();
                g.setColor(c);
                g.setShape(GradientDrawable.OVAL);
                g.setStroke((int) ((c == recol.dst ? 3.5f : 1f) * dd), c == recol.dst ? Th.A : 0x66FFFFFF);
                sw.setBackground(g);
                sw.setContentDescription(Look.RC_NAMES[i]);
                sw.setOnClickListener(v -> { pushUndo(); recol.dst = c; applyLook(); fillSheet(); });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (40 * dd), (int) (40 * dd));
                lp.setMarginEnd((int) (10 * dd));
                lp.topMargin = (int) (8 * dd);
                sw.setLayoutParams(lp);
                pr.addView(sw);
            }
            body.addView(slider("Cât prinde ", Math.round(recol.tol * 100) - 5, 40, x -> { if (recol != null) { recol.tol = (x + 5) / 100f; applyLook(); } }));
        }
    }

    interface IntSet { void set(int v); }

    private View slider(String label, int val, int max, IntSet cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        if (!label.isEmpty()) {
            TextView t = new TextView(this);
            t.setText(label);
            t.setTextColor(0xFFB9BCBF);
            t.setTextSize(13);
            r.addView(t);
        }
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(max);
        sb.setProgress(val);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Th.A));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Th.A));
        TextView v = new TextView(this);
        v.setText(String.valueOf(val));
        v.setTextColor(0xFFB9BCBF);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s1, int p, boolean u) { v.setText(String.valueOf(p)); cb.set(p); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s1) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s1) { }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(v);
        return r;
    }

    private void applyLook() { view.setLook(Look.of(filt, filtK)); view.setArt(art); view.setRecolor(recol); }

    private void pickMusic() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        try { startActivityForResult(i, REQ_MUSIC); } catch (Exception e) { Toast.makeText(this, "Nu pot deschide alegerea melodiei.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VOICE && res == RESULT_OK && data != null) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) voiceCommand(r);
            return;
        }
        if (req == REQ_MUSIC && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            String n = "melodie";
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) n = c.getString(0).replaceAll("\\.[^.]+$", "");
            } catch (Exception ignored) { }
            setMusic(u, n);
        }
    }

    // ---------------- comenzi vocale ----------------
    private static final int REQ_VOICE = 4711;

    private void startVoice() {
        if (player.isPlaying()) player.pause();
        Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "ro-RO");
        i.putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Spune ce să fac: „urmărește oamenii”, „mai lent”, „Tiny Planet”, „desen animat”, „salvează”…");
        try { startActivityForResult(i, REQ_VOICE); }
        catch (Exception e) { Toast.makeText(this, "Telefonul nu are recunoaștere vocală pornită (aplicația Google).", Toast.LENGTH_LONG).show(); }
    }

    private static String plain(String x) {
        return java.text.Normalizer.normalize(x.toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
    }

    /** înțelege ce ai spus și face; întoarce ce a făcut sau null */
    private String voiceDo(String said) {
        String w = plain(said);
        Clip c = cur();
        java.util.function.Predicate<String> has = k -> w.contains(k);
        if (has.test("anuleaza") || has.test("inapoi") || has.test("undo")) { doUndo(); return "Am anulat ultima schimbare"; }
        if (has.test("salveaza") || has.test("export")) { askSave(); return "Salvez filmul"; }
        if (has.test("porneste") || has.test("play") || has.test("reda")) { player.play(); return "Pornesc filmul"; }
        if (has.test("opreste") || has.test("pauza") || has.test("stop")) { player.pause(); return "Am oprit"; }
        if (c != null && c.is360 && (has.test("urmareste") || has.test("incadreaza") || has.test("incadrare"))) {
            withPeople(c, () -> {
                Track tr = People.follow(c.people, null, 40);
                if (tr == null) { Toast.makeText(this, "Nu am găsit oameni în bucata asta.", Toast.LENGTH_LONG).show(); return; }
                pushUndo(); c.track = tr; seekGlobal(timeline.startOf(curIdx)); player.play();
            });
            return "Caut oamenii și îi urmăresc";
        }
        if (c != null && c.is360 && (has.test("tiny") || has.test("planet"))) { modeGroup.check(R.id.mPlanet); return "Tiny Planet"; }
        if (c != null && (has.test("normal") || has.test("custom"))) { modeGroup.check(R.id.mCustom); c.fx = "none"; c.speed = 1f; return "Înapoi la normal"; }
        if (c != null && c.is360 && has.test("stabiliz")) { if (!stab) btnStab.performClick(); return "Stabilizare pornită"; }
        String fx = null; float sp = 1f;
        if (has.test("mai lent") || has.test("incetin") || has.test("slow") || has.test("freeze")) { fx = "freeze"; sp = 0.3f; }
        else if (has.test("fly") || has.test("hyperlapse") || has.test("drona")) { fx = "flylapse"; sp = 8f; }
        else if (has.test("mai repede") || has.test("acceler") || has.test("rapid") || has.test("timeshift")) { fx = "timeshift"; sp = 4f; }
        else if (has.test("barrel") || has.test("rostogol") || has.test("intoarce")) fx = "barrel";
        else if (has.test("roll planet") || has.test("planeta se roteste")) fx = "rollplanet";
        if (fx != null && c != null) {
            if (!Fx.isSpeed(fx) && !c.is360) return null;
            pushUndo(); c.fx = fx; c.speed = Fx.isSpeed(fx) ? sp : 1f;
            seekGlobal(timeline.startOf(clips.indexOf(c)) + 30); player.play();
            return Fx.NAMES[java.util.Arrays.asList(Fx.IDS).indexOf(fx)];
        }
        if (has.test("fara efect") || has.test("sterge efectul")) { if (c != null) { pushUndo(); c.fx = "none"; c.speed = 1f; } return "Am scos efectul"; }
        String[][] arts = {{"desen animat", "1"}, {"animat", "1"}, {"creion", "2"}, {"benzi", "3"}, {"acuarel", "4"}};
        for (String[] a : arts) if (has.test(a[0])) { pushUndo(); art = Integer.parseInt(a[1]); applyLook(); return Look.ART_NAMES[art]; }
        if (has.test("fara desen")) { pushUndo(); art = 0; applyLook(); return "Fără desen"; }
        for (int i = 0; i < Look.IDS.length; i++) if (w.contains(plain(Look.NAMES[i]))) { pushUndo(); filt = Look.IDS[i]; applyLook(); return "Filtru " + Look.NAMES[i]; }
        int ti = w.indexOf("text ");
        if (ti >= 0 && said.length() > ti + 5) {
            String tx = said.substring(ti + 5).trim();
            if (!tx.isEmpty()) {
                pushUndo();
                Overlays.Ov o = new Overlays.Ov();
                o.text = tx.substring(0, 1).toUpperCase() + tx.substring(1); o.style = "vlog"; o.anim = "pop"; o.loop = "float";
                o.a = timeline.getPos(); o.b = o.a + 3000;
                ovs.add(o); layer.invalidate();
                return "Am pus textul „" + o.text + "”";
            }
        }
        return null;
    }

    private void voiceCommand(List<String> alts) {
        for (String a : alts) {
            String done = voiceDo(a);
            if (done != null) { Toast.makeText(this, "✓ " + done, Toast.LENGTH_SHORT).show(); return; }
        }
        Toast.makeText(this, "N-am înțeles „" + alts.get(0) + "”. Încearcă: urmărește oamenii, mai lent, Tiny Planet, desen animat, salvează.", Toast.LENGTH_LONG).show();
    }

    private void setMusic(Uri u, String name) {
        music = u;
        musicName = name;
        if (musicPlayer != null) {
            musicPlayer.stop();
            if (u != null) { musicPlayer.setMediaItem(MediaItem.fromUri(u)); musicPlayer.prepare(); }
        }
        applyVolumes();
        if ("music".equals(tool)) fillSheet();
    }

    private void applyVolumes() {
        if (player != null) player.setVolume(origSound ? 1f : 0f);
        if (musicPlayer != null) musicPlayer.setVolume(musicVol / 100f);
    }

    private void syncMusic(long g) {
        if (musicPlayer == null || music == null) return;
        boolean play = player != null && player.isPlaying();
        long md = musicPlayer.getDuration();
        if (!play) { if (musicPlayer.isPlaying()) musicPlayer.pause(); return; }
        if (md <= 0) { if (!musicPlayer.isPlaying()) musicPlayer.play(); return; }
        long want = g % md;
        if (Math.abs(musicPlayer.getCurrentPosition() - want) > 400) musicPlayer.seekTo(want);
        if (!musicPlayer.isPlaying()) musicPlayer.play();
    }

    // ---------------- cadre: împarte, mută, șterge ----------------
    private void splitAtPlayhead() {
        if (clips.isEmpty()) return;
        long g = timeline.getPos();
        int i = timeline.indexAt(g);
        Clip c = clips.get(i);
        long local = c.t.in + (g - timeline.startOf(i));
        if (local - c.t.in < 400 || c.t.out - local < 400) { Toast.makeText(this, "Mută banda mai spre mijlocul cadrului, apoi apasă „Împarte”.", Toast.LENGTH_LONG).show(); return; }
        pushUndo();
        persist = false;
        Clip n = c.copy();
        n.key = c.key + "#s" + System.currentTimeMillis();
        c.t.out = local;
        n.t.in = local;
        clips.add(i + 1, n);
        timeline.setClips(timelineClips());
        timeline.setSelected(i + 1);
        curIdx = -1;
        rebuildPlayer(g + 10);
        buildToolbar();
        setHint();
    }

    private void moveSel(int dir) {
        int i = timeline.getSelected(), j = i + dir;
        if (i < 0 || j < 0 || j >= clips.size()) return;
        pushUndo();
        Clip c = clips.remove(i);
        clips.add(j, c);
        timeline.setClips(timelineClips());
        timeline.setSelected(j);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(j) + 50);
    }

    private void deleteSel() {
        int i = timeline.getSelected();
        if (i < 0) return;
        if (clips.size() < 2) { Toast.makeText(this, "Montajul are un singur cadru, nu-l pot șterge.", Toast.LENGTH_SHORT).show(); return; }
        pushUndo();
        clips.remove(i);
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(Math.min(i, clips.size() - 1)));
        buildToolbar();
        setHint();
    }

    // ---------------- montaj automat ----------------

    private void analyze() {
        int n = srcs.size();
        for (int i = 0; i < n && !isFinishing(); i++) {
            Src sr = srcs.get(i);
            final int pct = Math.round(i * 60f / n);
            main.post(() -> setBusy("Analizez scenele " + pct + "%", "Citesc Video " + (srcs.indexOf(sr) + 1) + " din " + n));
            long d = Thumbs.duration(this, sr.prev);
            if (d <= 0) d = Thumbs.duration(this, sr.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.uri);
            sr.dur = Math.max(0, d);
            sr.score = liveScore(sr, i, n);
            if (sr.is360 && sr.dur > 0 && !isFinishing()) {
                // AI: secundele cu oameni primesc un bonus, ca rezumatul să-i prindă
                try {
                    float[] pp = People.presence(this, sr.prev, null, sr.dur);
                    for (int k = 0; k < sr.score.length && k < pp.length; k++) if (pp[k] > 0) sr.score[k] *= 1.6f;
                } catch (Throwable ignored) { }
            }
        }
        main.post(() -> {
            if (isDestroyed() || player == null) return;
            analyzing = false;
            analyzed = true;
            setBusy("Analizez scenele 100%", "Am ales cadrele. Fac previzualizarea…");
            main.postDelayed(this::hideBusy, 500);
            Runnable r = afterAnalyze;
            afterAnalyze = null;
            if (analyzeCancelled) analyzeCancelled = false;
            else if (r != null) r.run(); else rebuildAuto();
            if (!framesStarted) { framesStarted = true; new Thread(this::loadSrcFrames).start(); }
        });
    }

    /** cât de „viu” e fiecare secundă: cât se schimbă imaginea + cât de colorată e */
    private float[] liveScore(Src sr, int idx, int n) {
        int secs = (int) Math.max(1, Math.ceil(sr.dur / 1000.0));
        float[] sc = new float[secs];
        java.util.Arrays.fill(sc, 1f);
        if (sr.dur <= 0) return sc;
        long step = Math.max(1000, sr.dur / 90);
        int samples = (int) Math.max(1, sr.dur / step);
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, sr.prev);
            int[] prev = null;
            float[] val = new float[samples];
            for (int k = 0; k < samples && !isFinishing(); k++) {
                long at = k * step + step / 2;
                Bitmap b = r.getScaledFrameAtTime(at * 1000, MediaMetadataRetriever.OPTION_CLOSEST, 64, 32);
                if (b == null) continue;
                int w = b.getWidth(), h = b.getHeight();
                int[] px = new int[w * h];
                b.getPixels(px, 0, w, 0, 0, w, h);
                b.recycle();
                float diff = 0, col = 0;
                for (int j = 0; j < px.length; j++) {
                    int c = px[j], rr = (c >> 16) & 255, gg = (c >> 8) & 255, bb = c & 255;
                    int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
                    col += mx - mn;
                    if (prev != null && prev.length == px.length) {
                        int p = prev[j];
                        diff += Math.abs(((p >> 16) & 255) - rr) + Math.abs(((p >> 8) & 255) - gg) + Math.abs((p & 255) - bb);
                    }
                }
                val[k] = (prev == null ? 0 : diff / px.length / 3f) + 0.25f * col / px.length;
                prev = px;
                if (k % 8 == 0) {
                    final int pct = Math.round((idx + k / (float) samples) * 60f / n);
                    main.post(() -> setBusy("Analizez scenele " + pct + "%", "Caut cele mai vii momente din Video " + (idx + 1)));
                }
            }
            if (samples > 1) val[0] = val[1];
            for (int s2 = 0; s2 < secs; s2++) {
                int k = (int) Math.min(samples - 1, (s2 * 1000L) / step);
                sc[s2] = 1 + val[k];
            }
        } catch (Throwable ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        return sc;
    }

    /** alege k bucăți de câte S secunde, cele mai vii, care nu se suprapun (ca în Regizor 360) */
    private static List<long[]> pickShots(Src sr, int k, float S) {
        List<long[]> out = new ArrayList<>();
        double D = sr.dur / 1000.0;
        if (D < S + 0.6) { if (D > 1.2) out.add(new long[]{0, sr.dur}); return out; }
        float[] sc = sr.score;
        int n = Math.max(1, Math.round(S));
        List<double[]> win = new ArrayList<>();
        for (int s0 = 0; s0 + n <= sc.length; s0++) {
            if (s0 + S > D - 0.3) break;
            double q = 0;
            for (int j = 0; j < n; j++) q += sc[s0 + j];
            win.add(new double[]{q, s0});
        }
        java.util.Collections.sort(win, (a, b) -> Double.compare(b[0], a[0]));
        List<Integer> starts = new ArrayList<>();
        for (double[] w : win) {
            if (starts.size() >= k) break;
            int s0 = (int) w[1];
            boolean ok = true;
            for (int o : starts) if (Math.abs(o - s0) < S + 0.5) { ok = false; break; }
            if (ok) starts.add(s0);
        }
        java.util.Collections.sort(starts);
        for (int s0 : starts) {
            long a = (long) (Math.max(0, s0 + 0.25) * 1000), z = (long) (Math.min(D, s0 + 0.25 + S) * 1000);
            out.add(new long[]{a, z});
        }
        return out;
    }

    private void rebuildAuto() {
        if (analyzing || player == null || isDestroyed()) return;
        float S = autoStyle.equals("fast") ? 2 : autoStyle.equals("calm") ? 5 : 3;
        List<Src> vids = new ArrayList<>();
        for (Src sr : srcs) if (sr.dur > 0) vids.add(sr);
        if (vids.isEmpty()) { hint.setText("Telefonul nu reușește să citească filmările alese. Verifică dacă e conectat cardul."); return; }
        double sum = 0;
        for (Src sr : vids) sum += sr.dur / 1000.0;
        int durS = Integer.parseInt(autoDur);
        double total = durS > 0 ? durS : sum * 0.35;
        int K = (int) Math.max(vids.size(), Math.round(total / S));
        double ws = 0;
        double[] w = new double[vids.size()];
        for (int i = 0; i < vids.size(); i++) { w[i] = Math.pow(vids.get(i).dur / 1000.0, 0.7); ws += w[i]; }
        if (player != null) player.pause();
        pushUndo();
        persist = false;
        clips.clear();
        for (int i = 0; i < vids.size(); i++) {
            Src sr = vids.get(i);
            int k = (int) Math.max(1, Math.round(K * w[i] / ws));
            for (long[] sh : pickShots(sr, k, S)) {
                Clip c = new Clip();
                c.uri = sr.uri; c.prev = sr.prev; c.is360 = sr.is360; c.name = sr.name;
                c.key = sr.key + "#" + clips.size();
                c.t.dur = sr.dur; c.t.in = sh[0]; c.t.out = sh[1];
                c.t.frames = sr.frames;
                c.durKnown = true;
                c.gyro = gyros.get(sr.uri.toString());
                c.view = new float[]{0f, -5f, 85f, 0f};
                clips.add(c);
            }
        }
        // la stilul Relaxat începem cu Tiny Planet, ca în Regizor
        if (S >= 5 && !clips.isEmpty() && clips.get(0).is360 && clips.get(0).t.len() > 3500) clips.get(0).view = new float[]{0f, 90f, 150f, 1f};
        if (clips.isEmpty()) { hint.setText("Filmările sunt prea scurte pentru montaj. Alege „Editez eu”."); return; }
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        rebuildPlayer(0);
        long tot = timeline.total();
        hint.setText("Montajul tău automat: " + clips.size() + " cadre din " + vids.size() + (vids.size() == 1 ? " filmare" : " filmări") + " · " + fmt(tot)
                + ". Apasă ▶. Jos: Montaj, Template, Text, Sticker, Muzică, Filtru. Atinge un cadru pe bandă ca să-l tai, muți sau ștergi.");
        buildToolbar();
        player.play();
    }

    private void loadSrcFrames() {
        for (Src sr : srcs) {
            if (sr.dur <= 0 || isFinishing()) continue;
            int n = (int) Math.max(4, Math.min(40, sr.dur / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, sr.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * sr.dur * 1000);
                    if (sr.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
            main.post(() -> {
                sr.frames = frames;
                for (Clip c : clips) if (c.prev.equals(sr.prev)) c.t.frames = frames;
                timeline.invalidate();
            });
        }
    }

    private void loadInfo() {
        for (Clip c : clips) {
            long d = Thumbs.duration(this, c.prev);
            if (d <= 0) d = Thumbs.duration(this, c.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, c.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, c.uri);
            if (d > 0) {
                final long dd2 = d;
                main.post(() -> setDur(c, dd2));
            }
        }
        for (Clip c : new ArrayList<>(clips)) {
            long d = c.t.dur;
            for (int w = 0; w < 50 && !c.durKnown && !isFinishing(); w++) { try { Thread.sleep(200); } catch (InterruptedException ignored) { } d = c.t.dur; }
            int n = (int) Math.max(4, Math.min(40, d / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * d * 1000);
                    if (c.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                    if (i % 4 == 3 || i == n - 1) {
                        final Bitmap[] cp = frames.clone();
                        main.post(() -> { for (Clip k : clips) if (k.prev.equals(c.prev)) k.t.frames = cp; timeline.invalidate(); });
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
    }

    private void setDur(Clip c, long d) {
        if (c.durKnown || d <= 0) return;
        c.durKnown = true;
        c.t.dur = d;
        if (c.t.out <= 1 || c.t.out > d) c.t.out = d;
        if (c.t.in >= c.t.out) c.t.in = 0;
        for (Src s : srcs) if (s.prev.equals(c.prev) && s.dur <= 0) s.dur = d;
        timeline.invalidate();
    }

    private void fillDurations() {
        androidx.media3.common.Timeline tl = player.getCurrentTimeline();
        if (tl.isEmpty()) return;
        boolean any = false;
        for (int i = 0; i < clips.size() && i < tl.getWindowCount(); i++) {
            Clip c = clips.get(i);
            if (c.durKnown) continue;
            Window w = tl.getWindow(i, new Window());
            if (w.durationUs != C.TIME_UNSET && w.durationUs > 0) {
                setDur(c, c.t.in + w.durationUs / 1000);
                any = true;
            }
        }
        if (any) timeline.invalidate();
    }

    private void rebuildPlayer(long globalPos) {
        if (clips.isEmpty() || player == null) return;
        List<MediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            items.add(new MediaItem.Builder().setUri(c.prev).setClippingConfiguration(cb.build()).build());
        }
        int idx = timeline.indexAt(globalPos);
        long local = Math.max(0, globalPos - timeline.startOf(idx));
        player.setMediaItems(items, idx, local);
        player.prepare();
        applyVolumes();
    }

    private void seekGlobal(long g) {
        if (clips.isEmpty()) return;
        int i = timeline.indexAt(g);
        player.seekTo(i, Math.max(0, g - timeline.startOf(i)));
    }

    private void onClipChanged(int i) {
        Clip old = cur();
        if (old != null && old.is360) saveView(old);
        curIdx = i;
        Clip c = cur();
        if (c == null) return;
        if (!full) findViewById(R.id.modes).setVisibility(c.is360 ? View.VISIBLE : View.GONE);
        view.setFlat(!c.is360, videoAspect);
        if (c.is360) {
            view.setView(c.view[0], c.view[1], c.view[2], c.view[3] > 0);
            view.setRoll(c.view.length > 4 ? c.view[4] : 0f);
            modeGroup.check(c.view[3] > 0 ? R.id.mPlanet : R.id.mCustom);
        }
        applyFormat();
        updateStabButtons();
        if (timeline.getSelected() < 0 && tool == null) setHint();
    }

    private void saveView(Clip c) {
        if (curIdx < 0 || curIdx >= clips.size() || clips.get(curIdx) != c) return;
        c.view = view.getView();
        if (!persist) return;
        edits.edit().putString(c.key + ":view", c.view[0] + "," + c.view[1] + "," + c.view[2] + "," + (c.view[3] > 0 ? "1" : "0") + "," + (c.view.length > 4 ? c.view[4] : 0f)).apply();
    }

    private float formatRatio() {
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "16:9": return 16f / 9f;
            default: return has360() ? 16f / 9f : videoAspect;
        }
    }

    private void applyFormat() {
        btnFormat.setText((format.equals("orig") ? "Original" : format) + " ▾");
        stage.setRatio(formatRatio());
    }

    private void chooseFormat() {
        final String[] ids = {"orig", "16:9", "9:16", "1:1"};
        String[] labels = {"Original", "16:9 · YouTube, TV", "9:16 · Reels, TikTok", "1:1 · pătrat"};
        new AlertDialog.Builder(this).setTitle("Format").setItems(labels, (d, w) -> {
            format = ids[w];
            prefs.edit().putString("format", format).apply();
            applyFormat();
        }).show();
    }

    // ---------------- salvare ----------------
    private boolean has360() { for (Clip c : clips) if (c.is360) return true; return false; }

    private void askSave() {
        if (clips.isEmpty()) return;
        final String[] ids = {"720", "1080", "max"};
        boolean h = has360();
        String[] labels = {"Rapid · 720p (bun pentru WhatsApp)", "Normal · 1080p", h ? "Maxim · 1080p (filmările 360)" : "Maxim · calitatea filmării"};
        String q = prefs.getString("quality", "1080");
        int sel = q.equals("720") ? 0 : q.equals("max") ? 2 : 1;
        new AlertDialog.Builder(this).setTitle("Salvează filmul").setSingleChoiceItems(labels, sel, (d, w) -> prefs.edit().putString("quality", ids[w]).apply())
                .setPositiveButton("Salvează", (d, w) -> save())
                .setNegativeButton("Renunț", null).show();
        if (h) Toast.makeText(this, "Filmările 360 se salvează din fișierul de previzualizare de pe card (până la 1080p).", Toast.LENGTH_LONG).show();
    }

    private void save() {
        if (ExportService.running || clips.isEmpty()) { if (ExportService.running) showBusy("Fac filmul " + ExportService.progress + "%", "Un film se face deja. Te anunț când e gata.", ExportService::cancel); return; }
        player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        selOv = null;
        String q = prefs.getString("quality", "1080");
        float ratio = formatRatio();
        int shortSide = q.equals("720") ? 720 : q.equals("1080") ? 1080 : 2160;
        if (has360()) shortSide = Math.min(shortSide, 1080);
        int outW, outH;
        if (ratio >= 1f) { outH = shortSide; outW = Math.round(shortSide * ratio); } else { outW = shortSide; outH = Math.round(shortSide / ratio); }
        outW = outW / 2 * 2; outH = outH / 2 * 2;
        float[] look = Look.of(filt, filtK);
        List<Overlays.Ov> ovCopy = new ArrayList<>();
        for (Overlays.Ov o : ovs) ovCopy.add(o.copy());
        List<EditedMediaItem> items = new ArrayList<>();
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            MediaItem mi = new MediaItem.Builder().setUri(c.is360 ? c.prev : c.uri).setClippingConfiguration(cb.build()).build();
            List<Effect> fx = new ArrayList<>();
            ReframeEffect rf = new ReframeEffect(c.is360, c.view, look, outW, outH).withArt(art).withRecolor(recol).withFx(c.fx, c.fxDur);
            if (c.is360 && c.track != null) rf.withTrack(c.track, c.gyro, c.t.in);
            else if (c.is360 && stab && c.gyro != null) rf.withGyro(c.gyro, !dirLock, c.t.in);
            fx.add(rf);
            if (art > 0) fx.add(new ArtEffect(art));
            long g0 = timeline.startOf(i), g1 = g0 + c.t.len();
            boolean anyOv = false;
            for (Overlays.Ov o : ovCopy) if (o.a < g1 && o.b > g0) { anyOv = true; break; }
            if (anyOv) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(new OvEffect(ovCopy, g0, outW, outH))));
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(1f));
            if (Math.abs(c.speed - 1f) > 0.01f) {
                // viteza la urmă: efectele de mai sus văd timpul filmării, nu pe cel accelerat
                fx.add(new androidx.media3.effect.SpeedChangeEffect(c.speed));
                androidx.media3.common.audio.SonicAudioProcessor so = new androidx.media3.common.audio.SonicAudioProcessor();
                so.setSpeed(c.speed);
                ap.add(so);
            }
            items.add(new EditedMediaItem.Builder(mi).setRemoveAudio(!origSound).setEffects(new Effects(ap, fx)).build());
        }
        Composition.Builder cbld;
        if (music != null) {
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(musicVol / 100f));
            EditedMediaItem mus = new EditedMediaItem.Builder(MediaItem.fromUri(music)).setRemoveVideo(true)
                    .setEffects(new Effects(ap, new ArrayList<Effect>())).build();
            List<EditedMediaItem> ml = new ArrayList<>();
            ml.add(mus);
            cbld = new Composition.Builder(new EditedMediaItemSequence(items), new EditedMediaItemSequence(ml, true));
        } else cbld = new Composition.Builder(new EditedMediaItemSequence(items));
        Composition comp = cbld.experimentalSetForceAudioTrack(true).build();
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7);
        ExportService.ui = exportUi;
        ExportService.start(this, comp);
        showBusy("Fac filmul 0%", "Poți ieși din aplicație: filmul se face mai departe și te anunț în notificări când e gata.", ExportService::cancel);
    }

    private final ExportService.UI exportUi = new ExportService.UI() {
        @Override public void progress(int p) { main.post(() -> setBusy(p >= 100 ? "Gata 100%" : "Fac filmul " + p + "%", p >= 100 ? "Pun filmul în Galerie…" : null)); }
        @Override public void done(Uri u) { main.post(() -> { hideBusy(); showSaved(u); }); }
        @Override public void error(String msg) {
            main.post(() -> {
                hideBusy();
                new AlertDialog.Builder(EditorActivity.this).setTitle("Nu am putut face filmul").setMessage(msg).setPositiveButton("Bine", null).show();
            });
        }
    };

    private void showSaved(Uri done) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this)
                .setTitle("Gata! Filmul e salvat")
                .setMessage("Îl găsești în Galerie, în albumul Director360.")
                .setPositiveButton("Deschide", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(done, "video/mp4");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(i); } catch (Exception ignored) { }
                })
                .setNeutralButton("Trimite", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("video/mp4");
                    i.putExtra(Intent.EXTRA_STREAM, done);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Trimite filmul")); } catch (Exception ignored) { }
                })
                .setNegativeButton("Închide", null)
                .show();
    }

    private static AudioProcessor stereo(float gain) {
        androidx.media3.common.audio.ChannelMixingAudioProcessor m = new androidx.media3.common.audio.ChannelMixingAudioProcessor();
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(1, 2).scaleBy(gain));
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(2, 2).scaleBy(gain));
        return m;
    }

    // ---- ecranul de lucru (ca în Regizor 360): inelul care se rotește, titlu, explicație, Anulează ----
    private View busy;
    private TextView busyTitle, busySub;
    private Runnable busyCancel;

    private void showBusy(String title, String sub, Runnable onCancel) {
        busyCancel = onCancel;
        if (busy == null) {
            float dd = getResources().getDisplayMetrics().density;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(android.view.Gravity.CENTER);
            box.setBackgroundColor(0xEB0C0D0F);
            box.setClickable(true);
            box.setElevation(30 * dd);
            LoaderView lv = new LoaderView(this);
            box.addView(lv, new LinearLayout.LayoutParams((int) (150 * dd), (int) (150 * dd)));
            busyTitle = new TextView(this);
            busyTitle.setTextColor(0xFFF2F2F0);
            busyTitle.setTextSize(26);
            busyTitle.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
            busyTitle.setGravity(android.view.Gravity.CENTER);
            busyTitle.setPadding((int) (20 * dd), (int) (18 * dd), (int) (20 * dd), 0);
            box.addView(busyTitle);
            busySub = new TextView(this);
            busySub.setTextColor(0xFFB9BCBF);
            busySub.setTextSize(15);
            busySub.setGravity(android.view.Gravity.CENTER);
            busySub.setPadding((int) (28 * dd), (int) (10 * dd), (int) (28 * dd), (int) (22 * dd));
            box.addView(busySub);
            TextView cancel = new TextView(this);
            cancel.setText("Anulează");
            cancel.setTextColor(0xFFF2F2F0);
            cancel.setTextSize(17);
            cancel.setTypeface(null, android.graphics.Typeface.BOLD);
            cancel.setGravity(android.view.Gravity.CENTER);
            cancel.setBackgroundResource(R.drawable.pill_bg);
            cancel.setOnClickListener(v -> { Runnable r = busyCancel; hideBusy(); if (r != null) r.run(); });
            box.addView(cancel, new LinearLayout.LayoutParams((int) (170 * dd), (int) (54 * dd)));
            addContentView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            busy = box;
        }
        busy.setVisibility(View.VISIBLE);
        busy.setAlpha(0f);
        busy.animate().alpha(1f).setDuration(200).start();
        setBusy(title, sub);
    }

    private void setBusy(String title, String sub) {
        if (busyTitle == null) return;
        if (title != null) busyTitle.setText(title);
        if (sub != null) busySub.setText(sub);
    }

    private void hideBusy() { if (busy != null) busy.setVisibility(View.GONE); }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        Clip c = cur();
        if (c != null && c.is360) saveView(c);
        if (view != null) view.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (view != null) view.onResume();
        ExportService.ui = exportUi;
        if (ExportService.running) showBusy("Fac filmul " + ExportService.progress + "%", "Poți ieși din aplicație: filmul se face mai departe și te anunț în notificări când e gata.", ExportService::cancel);
        else if (ExportService.doneUri != null) { Uri u = ExportService.doneUri; ExportService.doneUri = null; hideBusy(); showSaved(u); }
        else if (ExportService.doneErr != null) { String e = ExportService.doneErr; ExportService.doneErr = null; hideBusy(); exportUi.error(e); }
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (ExportService.ui == exportUi) ExportService.ui = null;
        if (player != null) { player.release(); player = null; }
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; }
        if (view != null) view.release();
        super.onDestroy();
    }
}
