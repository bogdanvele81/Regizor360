package ro.director360.app;

/** citește un mesaj protobuf fără să-i știm forma și îl scrie scurt: câmp=valoare, {…} pentru mesaje în mesaj */
final class Pb {
    private Pb() { }

    static String dump(byte[] b) {
        StringBuilder o = new StringBuilder();
        if (!parse(b, 0, b.length, o, 0)) { o.setLength(0); o.append("hex:").append(hex(b, 0, Math.min(b.length, 48))); }
        return o.toString();
    }

    private static boolean parse(byte[] b, int off, int end, StringBuilder o, int depth) {
        int i = off;
        int start = o.length();
        while (i < end) {
            long[] t = varint(b, i, end);
            if (t == null) { o.setLength(start); return false; }
            i = (int) t[1];
            int fn = (int) (t[0] >>> 3), wt = (int) (t[0] & 7);
            if (fn <= 0) { o.setLength(start); return false; }
            if (o.length() > start) o.append(' ');
            o.append(fn).append('=');
            if (wt == 0) {
                long[] v = varint(b, i, end);
                if (v == null) { o.setLength(start); return false; }
                o.append(v[0]);
                i = (int) v[1];
            } else if (wt == 2) {
                long[] l = varint(b, i, end);
                if (l == null) { o.setLength(start); return false; }
                int len = (int) l[0];
                i = (int) l[1];
                if (len < 0 || i + len > end) { o.setLength(start); return false; }
                int mark = o.length();
                o.append('{');
                if (len > 0 && depth < 6 && parse(b, i, i + len, o, depth + 1)) o.append('}');
                else {
                    o.setLength(mark);
                    String txt = text(b, i, len);
                    o.append(txt != null ? "\"" + txt + "\"" : "x" + hex(b, i, Math.min(len, 16)) + (len > 16 ? "…" : ""));
                }
                i += len;
            } else if (wt == 5) {
                if (i + 4 > end) { o.setLength(start); return false; }
                o.append("f").append(hex(b, i, 4)); i += 4;
            } else if (wt == 1) {
                if (i + 8 > end) { o.setLength(start); return false; }
                o.append("d").append(hex(b, i, 8)); i += 8;
            } else { o.setLength(start); return false; }
        }
        return true;
    }

    private static long[] varint(byte[] b, int i, int end) {
        long v = 0; int sh = 0;
        while (i < end && sh < 64) {
            int x = b[i++] & 0xFF;
            v |= (long) (x & 0x7F) << sh;
            if ((x & 0x80) == 0) return new long[]{v, i};
            sh += 7;
        }
        return null;
    }

    private static String text(byte[] b, int off, int len) {
        if (len == 0 || len > 80) return null;
        for (int k = off; k < off + len; k++) { int c = b[k] & 0xFF; if (c < 32 || c > 126) return null; }
        return new String(b, off, len, java.nio.charset.StandardCharsets.US_ASCII);
    }

    private static String hex(byte[] b, int off, int n) {
        StringBuilder s = new StringBuilder();
        for (int k = off; k < off + n && k < b.length; k++) s.append(String.format(java.util.Locale.ROOT, "%02x", b[k]));
        return s.toString();
    }
}
