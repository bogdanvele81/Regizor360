package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;

import java.util.ArrayList;
import java.util.List;

/**
 * AI-ul nostru, pe telefon, fără internet: găsește oamenii în filmarea 360.
 * Din fiecare moment face 4 imagini drepte (față, dreapta, spate, stânga) și caută în ele un om
 * cu recunoașterea de corp de la Google (ML Kit). Întoarce direcția și mărimea fiecărui om găsit.
 */
public final class People {
    public interface Progress { void on(int pct); boolean cancelled(); }

    /** un om găsit: direcția în lumea dreaptă (x dreapta, y jos, z înainte) și cât de mare e (0…1) */
    public static final class Hit {
        public final float[] dir;
        public final float size;
        Hit(float[] d, float s) { dir = d; size = s; }
    }

    public static final class Sample {
        public final double t;
        public final List<Hit> hits = new ArrayList<>();
        Sample(double t) { this.t = t; }
    }

    private static final int S = 320;
    private static final float VIEW_FOV = 100f;

    public interface ViewFn { float[] at(double t); }

    /**
     * Imaginea e cu susul în jos? Ne uităm unde e cerul: în imaginea finală (privirea V la câteva momente)
     * comparăm partea de sus cu cea de jos. true = trebuie întoarsă cu 180°.
     */
    public static boolean upsideDown(Context ctx, Uri prev, double[] times, ViewFn f) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        float[] pa = Video360View.calA(), pb = Video360View.calB(), O = Video360View.lensO();
        float fov = Video360View.fovRad();
        final int N = 48;
        double tan = Math.tan(Math.toRadians(45));
        int up = 0, down = 0;
        try {
            r.setDataSource(ctx, prev);
            for (double t : times) {
                Bitmap fr = r.getScaledFrameAtTime((long) (t * 1e6), MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 512, 256);
                if (fr == null) continue;
                int sw = fr.getWidth(), sh = fr.getHeight();
                int[] px = new int[sw * sh];
                fr.getPixels(px, 0, sw, 0, 0, sw, sh);
                fr.recycle();
                float[] V = f.at(t);
                if (V == null) continue;
                double top = 0, bot = 0;
                int nt = 0, nb = 0;
                for (int yy = 0; yy < N; yy++) {
                    if (yy >= N / 3 && yy < N * 2 / 3) continue;
                    for (int xx = 0; xx < N; xx++) {
                        float qx = (float) (((xx + 0.5) / N * 2 - 1) * tan), qy = (float) (((yy + 0.5) / N * 2 - 1) * tan);
                        float l = (float) Math.sqrt(qx * qx + qy * qy + 1);
                        float[] w = Video360View.mvec(V, new float[]{qx / l, qy / l, 1 / l});
                        int c = Track.sample(px, sw, sh, pa, w[0], w[1], w[2], fov);
                        if (c == 0) {
                            float ex = O[0] * w[0] + O[1] * w[1] + O[2] * w[2], ey = O[3] * w[0] + O[4] * w[1] + O[5] * w[2], ez = O[6] * w[0] + O[7] * w[1] + O[8] * w[2];
                            c = Track.sample(px, sw, sh, pb, ex, ey, ez, fov);
                        }
                        if (c == 0) continue;
                        int R = (c >> 16) & 255, G = (c >> 8) & 255, B = c & 255;
                        double sky = 0.5 * (0.299 * R + 0.587 * G + 0.114 * B) + 0.8 * (B - R);
                        if (yy < N / 3) { top += sky; nt++; } else { bot += sky; nb++; }
                    }
                }
                if (nt == 0 || nb == 0) continue;
                double d = top / nt - bot / nb;
                if (d > 12) up++; else if (d < -12) down++;
            }
        } catch (Exception ignored) {
        } finally { try { r.release(); } catch (Exception ignored) { } }
        return down > up;
    }

    /** caută oameni pe bucata [a, b] secunde, la fiecare `step` secunde */
    public static List<Sample> detect(Context ctx, Uri prev, Gyro g, double a, double b, double step, Progress pr) {
        List<Sample> out = new ArrayList<>();
        PoseDetector det = PoseDetection.getClient(new PoseDetectorOptions.Builder()
                .setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE).build());
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        float[] pa = Video360View.calA(), pb = Video360View.calB(), O = Video360View.lensO();
        float fov = Video360View.fovRad();
        double tan = Math.tan(Math.toRadians(VIEW_FOV / 2));
        try {
            r.setDataSource(ctx, prev);
            int n = (int) Math.max(1, Math.ceil((b - a) / step) + 1);
            int[] img = new int[S * S];
            for (int k = 0; k < n; k++) {
                if (pr != null && pr.cancelled()) return null;
                double t = Math.min(b, a + k * step);
                Sample smp = new Sample(t);
                out.add(smp);
                Bitmap fr = r.getScaledFrameAtTime((long) (t * 1e6), MediaMetadataRetriever.OPTION_CLOSEST, 1024, 512);
                if (fr == null) continue;
                int sw = fr.getWidth(), sh = fr.getHeight();
                int[] px = new int[sw * sh];
                fr.getPixels(px, 0, sw, 0, 0, sw, sh);
                fr.recycle();
                float[] C = g != null ? g.at(t, false) : new float[]{1, 0, 0, 0, 1, 0, 0, 0, 1};
                for (int v = 0; v < 4; v++) {
                    float[] V = Video360View.viewMatrix(v * 90f, 0f);
                    for (int yy = 0; yy < S; yy++) {
                        for (int xx = 0; xx < S; xx++) {
                            float qx = (float) (((xx + 0.5) / S * 2 - 1) * tan), qy = (float) (((yy + 0.5) / S * 2 - 1) * tan);
                            float l = (float) Math.sqrt(qx * qx + qy * qy + 1);
                            float[] w = Video360View.mvec(V, new float[]{qx / l, qy / l, 1 / l});
                            float dx = C[0] * w[0] + C[1] * w[1] + C[2] * w[2], dy = C[3] * w[0] + C[4] * w[1] + C[5] * w[2], dz = C[6] * w[0] + C[7] * w[1] + C[8] * w[2];
                            int c = Track.sample(px, sw, sh, pa, dx, dy, dz, fov);
                            if (c == 0) {
                                float ex = O[0] * dx + O[1] * dy + O[2] * dz, ey = O[3] * dx + O[4] * dy + O[5] * dz, ez = O[6] * dx + O[7] * dy + O[8] * dz;
                                c = Track.sample(px, sw, sh, pb, ex, ey, ez, fov);
                            }
                            img[yy * S + xx] = c == 0 ? 0xFF000000 : c;
                        }
                    }
                    Bitmap bm = Bitmap.createBitmap(img, S, S, Bitmap.Config.ARGB_8888);
                    try {
                        Pose pose = Tasks.await(det.process(InputImage.fromBitmap(bm, 0)));
                        float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
                        int cnt = 0;
                        for (PoseLandmark lm : pose.getAllPoseLandmarks()) {
                            if (lm.getInFrameLikelihood() < 0.6f) continue;
                            float x = lm.getPosition().x, y = lm.getPosition().y;
                            minX = Math.min(minX, x); maxX = Math.max(maxX, x);
                            minY = Math.min(minY, y); maxY = Math.max(maxY, y);
                            cnt++;
                        }
                        if (cnt >= 6) {
                            float cx = (minX + maxX) / 2f, cy = minY + (maxY - minY) * 0.35f; // spre piept / cap
                            float qx = (float) ((cx / S * 2 - 1) * tan), qy = (float) ((cy / S * 2 - 1) * tan);
                            float l = (float) Math.sqrt(qx * qx + qy * qy + 1);
                            float[] w = Video360View.mvec(V, new float[]{qx / l, qy / l, 1 / l});
                            smp.hits.add(new Hit(w, Math.max(0f, Math.min(1f, (maxY - minY) / S))));
                        }
                    } catch (Exception ignored) {
                    } finally { bm.recycle(); }
                }
                if (pr != null) pr.on(Math.round((k + 1) * 100f / n));
            }
        } catch (Throwable e) {
            return out.isEmpty() ? null : out;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
            det.close();
        }
        return out;
    }

    static double angle(float[] a, float[] b) {
        double d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        return Math.acos(Math.max(-1, Math.min(1, d)));
    }

    /**
     * Drumul privirii: începe de la `start` (sau de la omul cel mai mare) și merge din om în om,
     * mereu la cel mai apropiat de unde se uita; dacă nu găsește pe nimeni, rămâne pe loc.
     */
    public static Track follow(List<Sample> s, float[] start, double maxJumpDeg) {
        if (s == null || s.isEmpty()) return null;
        int n = s.size();
        double[] T = new double[n];
        float[][] D = new float[n][];
        float[] cur = start;
        int found = 0;
        if (cur == null) {
            float best = 0;
            for (Sample x : s) for (Hit h : x.hits) if (h.size > best) { best = h.size; cur = h.dir; }
            if (cur == null) return null;
        }
        double lim = Math.toRadians(maxJumpDeg);
        for (int k = 0; k < n; k++) {
            Sample x = s.get(k);
            T[k] = x.t;
            Hit best = null;
            double bd = lim;
            for (Hit h : x.hits) {
                double a = angle(h.dir, cur);
                if (a < bd) { bd = a; best = h; }
            }
            if (best != null) { cur = best.dir; found++; }
            D[k] = cur;
        }
        if (found == 0) return null;
        Track tr = Track.fromDirs(T, D, 0.8);
        tr.found = found;
        tr.total = n;
        return tr;
    }

    /** Deep Track pe om: pornește de la omul atins (direcția d0 la momentul tSec), merge înainte și înapoi */
    public static Track followFrom(List<Sample> s, double tSec, float[] d0, double nearDeg) {
        if (s == null || s.isEmpty()) return null;
        int n = s.size(), k0 = 0;
        double bt = 1e9;
        for (int k = 0; k < n; k++) if (Math.abs(s.get(k).t - tSec) < bt) { bt = Math.abs(s.get(k).t - tSec); k0 = k; }
        // omul atins trebuie să fie aproape de deget (în jur de clipa atingerii)
        Hit start = null;
        double bd = Math.toRadians(nearDeg);
        for (int k = Math.max(0, k0 - 1); k <= Math.min(n - 1, k0 + 1); k++)
            for (Hit h : s.get(k).hits) { double a = angle(h.dir, d0); if (a < bd) { bd = a; start = h; } }
        if (start == null) return null;
        double[] T = new double[n];
        float[][] D = new float[n][];
        int found = 0;
        double lim = Math.toRadians(35);
        float[] cur = start.dir;
        for (int k = k0; k < n; k++) { Hit h = nearest(s.get(k), cur, lim); if (h != null) { cur = h.dir; found++; } D[k] = cur; T[k] = s.get(k).t; }
        cur = start.dir;
        for (int k = k0 - 1; k >= 0; k--) { Hit h = nearest(s.get(k), cur, lim); if (h != null) { cur = h.dir; found++; } D[k] = cur; T[k] = s.get(k).t; }
        Track tr = Track.fromDirs(T, D, 0.6);
        tr.found = found;
        tr.total = n;
        return tr;
    }

    private static Hit nearest(Sample x, float[] cur, double lim) {
        Hit best = null;
        double bd = lim;
        for (Hit h : x.hits) { double a = angle(h.dir, cur); if (a < bd) { bd = a; best = h; } }
        return best;
    }

    /** unde apar oamenii cel mai des: până la 3 direcții {yaw°, pitch°} */
    public static List<float[]> suggest(List<Sample> s) {
        List<float[]> out = new ArrayList<>();
        if (s == null) return out;
        float[] score = new float[12];
        float[][] sum = new float[12][3];
        for (Sample x : s) for (Hit h : x.hits) {
            double yaw = Math.toDegrees(Math.atan2(h.dir[0], h.dir[2]));
            int b = (int) Math.floor(((yaw + 360) % 360) / 30.0) % 12;
            score[b] += 0.5f + h.size;
            for (int i = 0; i < 3; i++) sum[b][i] += h.dir[i];
        }
        for (int pick = 0; pick < 3; pick++) {
            int bi = -1;
            float bv = 0.5f;
            for (int b = 0; b < 12; b++) if (score[b] > bv) { bv = score[b]; bi = b; }
            if (bi < 0) break;
            float[] d = sum[bi];
            double l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
            float yaw = (float) Math.toDegrees(Math.atan2(d[0], d[2]));
            float pitch = (float) Math.toDegrees(Math.asin(Math.max(-1, Math.min(1, -d[1] / l))));
            out.add(new float[]{yaw, Math.max(-25, Math.min(25, pitch))});
            score[bi] = 0;
            score[(bi + 1) % 12] *= 0.3f;
            score[(bi + 11) % 12] *= 0.3f;
        }
        return out;
    }

    /** câte secunde au oameni: pentru montajul automat (1 = are oameni) */
    public static float[] presence(Context ctx, Uri prev, Gyro g, long durMs) {
        int secs = (int) Math.max(1, Math.ceil(durMs / 1000.0));
        float[] p = new float[secs];
        double end = Math.min(durMs / 1000.0, 40.0);
        List<Sample> s = detect(ctx, prev, g, 0.5, Math.max(0.5, end - 0.2), 2.0, null);
        if (s == null) return p;
        for (Sample x : s) {
            if (x.hits.isEmpty()) continue;
            int sec = (int) x.t;
            for (int i = Math.max(0, sec - 1); i <= Math.min(secs - 1, sec + 1); i++) p[i] = 1f;
        }
        return p;
    }
}
