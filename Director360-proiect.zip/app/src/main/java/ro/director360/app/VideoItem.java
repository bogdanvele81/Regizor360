package ro.director360.app;

import android.net.Uri;

/** O filmare din bibliotecă (de pe card sau din telefon). */
public class VideoItem {
    public final Uri uri;
    public final String name;
    public final long size;
    public final long modified;
    /** fișierul mic (LRV) de lângă o filmare de pe cameră, dacă există */
    public Uri lrv;
    public long durationMs = -1;

    public VideoItem(Uri uri, String name, long size, long modified) {
        this.uri = uri;
        this.name = name == null ? "" : name;
        this.size = size;
        this.modified = modified;
    }

    /** filmare 360 de pe cameră (.insv) */
    public boolean is360() {
        return name.toLowerCase().endsWith(".insv");
    }

    /** cheia folosită pentru pozele mici și pentru editările salvate */
    public String key() {
        return name + "|" + size;
    }

    /** VID_20260827_162848_00_643.insv -> 20260827_162848_643 (ca să găsim perechea LRV) */
    public static String stem(String name) {
        String n = name;
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        String[] p = n.split("_");
        if (p.length >= 5) return p[1] + "_" + p[2] + "_" + p[p.length - 1];
        return n;
    }
}
