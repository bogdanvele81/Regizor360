package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Deschide o poză: cele 360 se rotesc cu degetul (Custom / Tiny Planet), apoi se salvează cadrul ales. */
public class PhotoActivity extends AppCompatActivity {

    private Video360View view;
    private AspectFrame stage;
    private MaterialButton btnFormat;
    private MaterialButtonToggleGroup modeGroup;
    private TextView hint;
    private SharedPreferences prefs, edits;
    private String format = "16:9", key;
    private boolean is360;
    private float photoAspect = 4f / 3f;
    private int srcW = 0, srcH = 0;
    private boolean loaded = false;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_photo);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        final Uri uri = Uri.parse(getIntent().getStringExtra("uri"));
        String name = getIntent().getStringExtra("name");
        is360 = getIntent().getBooleanExtra("is360", false);
        key = "photo:" + name;

        stage = findViewById(R.id.stage);
        hint = findViewById(R.id.hint);
        btnFormat = findViewById(R.id.btnFormat);
        modeGroup = findViewById(R.id.modeGroup);
        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        format = prefs.getString("photoFormat", "16:9");
        applyFormat();
        btnFormat.setOnClickListener(v -> chooseFormat());
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
        findViewById(R.id.modes).setVisibility(is360 ? View.VISIBLE : View.GONE);
        modeGroup.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked || !is360) return;
            boolean planet = id == R.id.mPlanet;
            if (planet != view.isPlanet()) view.setPlanet(planet);
            saveView();
        });
        findViewById(R.id.btnLevel).setOnClickListener(v -> { view.resetView(); modeGroup.check(R.id.mCustom); saveView(); });
        hint.setText(is360 ? "Se încarcă poza…" : "Se încarcă poza…");

        String sv = edits.getString(key + ":view", null);
        if (sv != null && is360) {
            try {
                String[] p = sv.split(",");
                view.setView(Float.parseFloat(p[0]), Float.parseFloat(p[1]), Float.parseFloat(p[2]), "1".equals(p[3]));
                modeGroup.check("1".equals(p[3]) ? R.id.mPlanet : R.id.mCustom);
            } catch (Exception ignored) { }
        } else modeGroup.check(R.id.mCustom);

        new Thread(() -> {
            Bitmap bmp = decode(uri, is360 ? 6144 : 4096);
            main.post(() -> {
                if (isFinishing()) return;
                if (bmp == null) { hint.setText("Nu pot deschide poza. Verifică dacă e conectat cardul."); return; }
                photoAspect = bmp.getWidth() / (float) bmp.getHeight();
                if (is360 && photoAspect < 1.6f) is360 = false; // nu e o poză cu două lentile
                findViewById(R.id.modes).setVisibility(is360 ? View.VISIBLE : View.GONE);
                view.setFlat(!is360, photoAspect);
                view.setPhoto(bmp);
                loaded = true;
                applyFormat();
                hint.setText(is360
                        ? "Trage cu degetul ca să alegi cadrul · două degete = zoom · atinge de două ori = Tiny Planet. Apoi „Salvează”."
                        : "Alege formatul sus, apoi „Salvează”. Poza se taie pe mijloc.");
            });
        }).start();
    }

    private Bitmap decode(Uri uri, int maxW) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            if (o.outWidth <= 0) return null;
            srcW = o.outWidth; srcH = o.outHeight;
            int ss = 1;
            while (o.outWidth / ss > maxW) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            if (is360) o2.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) return null;
            if (!is360) {
                int rot = 0;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    int or = new androidx.exifinterface.media.ExifInterface(in).getAttributeInt(
                            androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
                    rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
                } catch (Throwable ignored) { }
                if (rot != 0) {
                    android.graphics.Matrix m = new android.graphics.Matrix();
                    m.postRotate(rot);
                    b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                    if (rot != 180) { int t = srcW; srcW = srcH; srcH = t; }
                }
            }
            return b;
        } catch (Throwable e) {
            return null;
        }
    }

    private void saveView() {
        float[] v = view.getView();
        edits.edit().putString(key + ":view", v[0] + "," + v[1] + "," + v[2] + "," + (v[3] > 0 ? "1" : "0")).apply();
    }

    private float formatRatio() {
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "4:3": return 4f / 3f;
            case "orig": return is360 ? 16f / 9f : photoAspect;
            default: return 16f / 9f;
        }
    }

    private void applyFormat() {
        btnFormat.setText((format.equals("orig") ? "Original" : format) + " ▾");
        stage.setRatio(formatRatio());
    }

    private void chooseFormat() {
        final String[] ids = {"16:9", "9:16", "1:1", "4:3", "orig"};
        String[] labels = {"16:9 · lat", "9:16 · Story, TikTok", "1:1 · pătrat", "4:3 · clasic", "Original"};
        new AlertDialog.Builder(this).setTitle("Format").setItems(labels, (d, w) -> {
            format = ids[w];
            prefs.edit().putString("photoFormat", format).apply();
            applyFormat();
        }).show();
    }

    private void save() {
        if (!loaded) { Toast.makeText(this, "Așteaptă să se încarce poza.", Toast.LENGTH_SHORT).show(); return; }
        if (is360) saveView();
        float r = formatRatio();
        int longSide;
        if (is360) longSide = 3840;
        else {
            // cât permite poza: partea tăiată din original
            float pr = photoAspect;
            int cw = srcW, ch = srcH;
            if (pr > r) cw = Math.round(ch * r); else ch = Math.round(cw / r);
            longSide = Math.min(4096, Math.max(cw, ch));
        }
        int w, h;
        if (r >= 1) { w = longSide; h = Math.round(longSide / r); } else { h = longSide; w = Math.round(longSide * r); }
        w = Math.max(2, w & ~1); h = Math.max(2, h & ~1);
        hint.setText("Salvez poza…");
        view.capture(w, h, bmp -> {
            if (bmp == null) { hint.setText("Nu am reușit să salvez. Încearcă din nou."); return; }
            new Thread(() -> {
                Uri dst = publish(bmp);
                main.post(() -> {
                    if (dst == null) { hint.setText("Nu am reușit să salvez în Galerie."); return; }
                    hint.setText("Salvată în Galerie › Director360.");
                    new AlertDialog.Builder(this)
                            .setTitle("Gata! Poza e salvată")
                            .setMessage("O găsești în Galerie, în albumul Director360.")
                            .setPositiveButton("Deschide", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setDataAndType(dst, "image/jpeg");
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(i); } catch (Exception ignored) { }
                            })
                            .setNeutralButton("Trimite", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType("image/jpeg");
                                i.putExtra(Intent.EXTRA_STREAM, dst);
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(Intent.createChooser(i, "Trimite poza")); } catch (Exception ignored) { }
                            })
                            .setNegativeButton("Închide", null)
                            .show();
                });
            }).start();
        });
    }

    private Uri publish(Bitmap bmp) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".jpg";
            v.put(MediaStore.Images.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Director360");
            v.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) return null;
            try (OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) return null;
                bmp.compress(Bitmap.CompressFormat.JPEG, 92, o);
            }
            v.clear();
            v.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            return dst;
        } catch (Exception e) {
            return null;
        }
    }

    @Override protected void onResume() { super.onResume(); view.onResume(); }
    @Override protected void onPause() { view.onPause(); super.onPause(); }
}
