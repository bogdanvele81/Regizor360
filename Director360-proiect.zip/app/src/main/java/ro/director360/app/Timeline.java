package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Banda cu filmele, ca la Insta360: linia albă stă fixă la mijloc, tragi banda ca să mergi prin film,
 * atingi o filmare ca s-o alegi și tragi mânerele albe ca s-o scurtezi. Cu două degete o mărești.
 */
public class Timeline extends View {

    public static class Clip {
        public long dur = 1, in = 0, out = 1;
        public Bitmap[] frames = new Bitmap[0];
        public long len() { return Math.max(0, out - in); }
    }

    public interface Listener {
        void onScrub(long globalMs, boolean done);
        void onSelect(int index);
        void onTrim(int index, boolean left, boolean done);
    }

    private final List<Clip> clips = new ArrayList<>();
    private long pos = 0;
    private int sel = -1;
    private float ppms; // pixeli pe milisecundă
    private Listener listener;
    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ScaleGestureDetector scale;

    public Timeline(Context c, AttributeSet a) {
        super(c, a);
        d = getResources().getDisplayMetrics().density;
        ppms = 40 * d / 1000f;
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector g) {
                ppms = Math.max(2 * d / 1000f, Math.min(260 * d / 1000f, ppms * g.getScaleFactor()));
                invalidate();
                return true;
            }
        });
    }

    public void setListener(Listener l) { listener = l; }

    public List<Clip> getClips() { return clips; }

    public void setClips(List<Clip> c) { clips.clear(); clips.addAll(c); if (sel >= clips.size()) sel = -1; invalidate(); }

    public int getSelected() { return sel; }

    public void setSelected(int i) { sel = i; invalidate(); }

    public long total() { long t = 0; for (Clip c : clips) t += c.len(); return t; }

    public long startOf(int i) { long t = 0; for (int k = 0; k < i && k < clips.size(); k++) t += clips.get(k).len(); return t; }

    public long getPos() { return pos; }

    public void setPos(long ms) { if (!touching) { pos = Math.max(0, Math.min(total(), ms)); invalidate(); } }

    /** indexul filmării de la un moment din bandă */
    public int indexAt(long ms) {
        long t = 0;
        for (int i = 0; i < clips.size(); i++) { long l = clips.get(i).len(); if (ms < t + l || i == clips.size() - 1) return i; t += l; }
        return 0;
    }

    private static String fmt(long ms) { long s = Math.max(0, ms) / 1000; return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60); }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f;
        float rulerH = 18 * d, top = rulerH + 6 * d, bot = getHeight() - 8 * d;
        // riglă cu secunde
        long tot = total();
        long step = ppms * 1000 >= 70 * d ? 1000 : ppms * 1000 >= 30 * d ? 2000 : ppms * 1000 >= 12 * d ? 5000 : ppms * 1000 >= 5 * d ? 10000 : 30000;
        p.setColor(0xFF7C8186);
        p.setTextSize(10 * d);
        p.setTextAlign(Paint.Align.CENTER);
        for (long t = 0; t <= tot; t += step) {
            float x = cx + (t - pos) * ppms;
            if (x < -40 || x > getWidth() + 40) continue;
            c.drawText(fmt(t), x, 11 * d, p);
            c.drawRect(x - 0.5f * d, rulerH - 3 * d, x + 0.5f * d, rulerH, p);
        }
        // filmările
        long start = 0;
        for (int i = 0; i < clips.size(); i++) {
            Clip k = clips.get(i);
            float x0 = cx + (start - pos) * ppms, x1 = x0 + k.len() * ppms - 2 * d;
            start += k.len();
            if (x1 < 0 || x0 > getWidth()) continue;
            RectF r = new RectF(x0, top, Math.max(x0 + 2, x1), bot);
            c.save();
            c.clipRect(r);
            p.setColor(0xFF262A2E);
            c.drawRect(r, p);
            if (k.frames.length > 0) {
                float full = k.dur * ppms, fx0 = x0 - k.in * ppms, fw = full / k.frames.length;
                for (int f = 0; f < k.frames.length; f++) {
                    float a = fx0 + f * fw, b = a + fw;
                    if (b < r.left || a > r.right) continue;
                    Bitmap bm = k.frames[f];
                    if (bm == null) continue;
                    float bw = bm.getWidth(), bh = bm.getHeight(), H = bot - top;
                    float sc = Math.max(fw / bw, H / bh);
                    float sw = fw / sc, sh = H / sc;
                    Rect src = new Rect((int) ((bw - sw) / 2), (int) ((bh - sh) / 2), (int) ((bw + sw) / 2), (int) ((bh + sh) / 2));
                    c.drawBitmap(bm, src, new RectF(a, top, b, bot), null);
                }
            }
            // număr și durată
            p.setTextAlign(Paint.Align.LEFT);
            p.setTextSize(11 * d);
            p.setColor(0x99000000);
            String n = String.valueOf(i + 1);
            float tw = p.measureText(n);
            c.drawRoundRect(new RectF(x0 + 4 * d, top + 3 * d, x0 + 12 * d + tw, top + 19 * d), 5 * d, 5 * d, p);
            p.setColor(0xFFFFFFFF);
            p.setFakeBoldText(true);
            c.drawText(n, x0 + 8 * d, top + 15 * d, p);
            p.setShadowLayer(3 * d, 0, 0, 0xFF000000);
            c.drawText(String.format(Locale.ROOT, "%.1fs", k.len() / 1000f), x0 + 5 * d, bot - 6 * d, p);
            p.clearShadowLayer();
            p.setFakeBoldText(false);
            c.restore();
            if (i == sel) {
                p.setColor(0xFFFFFFFF);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3 * d);
                c.drawRect(r, p);
                p.setStyle(Paint.Style.FILL);
                float hw = 16 * d;
                c.drawRoundRect(new RectF(x0 - hw, top, x0 + 1, bot), 7 * d, 7 * d, p);
                c.drawRoundRect(new RectF(x1 - 1, top, x1 + hw, bot), 7 * d, 7 * d, p);
                p.setColor(0xFF111315);
                float mid = (top + bot) / 2;
                c.drawRoundRect(new RectF(x0 - hw / 2 - 1.5f * d, mid - 9 * d, x0 - hw / 2 + 1.5f * d, mid + 9 * d), d, d, p);
                c.drawRoundRect(new RectF(x1 + hw / 2 - 1.5f * d, mid - 9 * d, x1 + hw / 2 + 1.5f * d, mid + 9 * d), d, d, p);
            }
        }
        // linia albă fixă
        p.setColor(0xFFFFFFFF);
        p.setShadowLayer(4 * d, 0, 0, 0xAA000000);
        c.drawRect(cx - 1 * d, 2 * d, cx + 1 * d, getHeight(), p);
        p.clearShadowLayer();
    }

    private boolean touching = false;
    private float downX, lastX;
    private long downT;
    private int handle = 0; // 1 stânga, 2 dreapta
    private long handleIn, handleOut, handlePos;
    private boolean moved;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        if (e.getPointerCount() > 1 || scale.isInProgress()) { moved = true; return true; }
        float x = e.getX();
        float cx = getWidth() / 2f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                touching = true; moved = false; downX = lastX = x; downT = System.currentTimeMillis(); handle = 0;
                if (sel >= 0 && sel < clips.size()) {
                    float x0 = cx + (startOf(sel) - pos) * ppms, x1 = x0 + clips.get(sel).len() * ppms - 2 * d;
                    if (Math.abs(x - (x0 - 8 * d)) < 22 * d) handle = 1;
                    else if (Math.abs(x - (x1 + 8 * d)) < 22 * d) handle = 2;
                    if (handle > 0) { handleIn = clips.get(sel).in; handleOut = clips.get(sel).out; handlePos = pos; }
                }
                return true;
            case MotionEvent.ACTION_MOVE: {
                if (Math.abs(x - downX) > 8 * d) moved = true;
                if (!moved) return true;
                if (handle > 0) {
                    Clip k = clips.get(sel);
                    long dms = (long) ((x - downX) / ppms);
                    if (handle == 1) {
                        k.in = Math.max(0, Math.min(handleOut - 500, handleIn + dms));
                        pos = startOf(sel);
                    } else {
                        k.out = Math.max(handleIn + 500, Math.min(k.dur, handleOut + dms));
                        pos = startOf(sel) + k.len() - 1;
                    }
                    if (listener != null) listener.onTrim(sel, handle == 1, false);
                } else {
                    pos = Math.max(0, Math.min(total(), pos - (long) ((x - lastX) / ppms)));
                    if (listener != null) listener.onScrub(pos, false);
                }
                lastX = x;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                touching = false;
                if (!moved && System.currentTimeMillis() - downT < 400) {
                    long at = pos + (long) ((x - cx) / ppms);
                    int hit = -1;
                    if (at >= 0 && at <= total()) hit = indexAt(at);
                    sel = (hit == sel) ? -1 : hit;
                    invalidate();
                    if (listener != null) listener.onSelect(sel);
                } else if (handle > 0) {
                    if (listener != null) listener.onTrim(sel, handle == 1, true);
                } else if (moved) {
                    if (listener != null) listener.onScrub(pos, true);
                }
                handle = 0;
                return true;
        }
        return super.onTouchEvent(e);
    }
}
