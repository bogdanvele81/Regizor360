package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Banda cu poze din film: tragi ca să mergi prin film, tragi mânerele albe ca să tai capetele. */
public class TrimBar extends View {

    public interface Listener {
        void onSeek(long ms);
        void onTrim(long inMs, long outMs, boolean leftHandle);
        void onTouchEnd();
    }

    private long dur = 1, in = 0, out = 1, pos = 0;
    private Bitmap[] frames = new Bitmap[0];
    private Listener listener;
    private int drag = 0; // 1 = mânerul stâng, 2 = mânerul drept, 3 = derulare
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float d;

    public TrimBar(Context c, AttributeSet a) {
        super(c, a);
        d = getResources().getDisplayMetrics().density;
    }

    public void setListener(Listener l) { listener = l; }

    public void setDuration(long ms) { dur = Math.max(1, ms); if (out <= 0 || out > dur) out = dur; invalidate(); }

    public void setRange(long a, long b) { in = Math.max(0, a); out = Math.min(dur, Math.max(in + 300, b)); invalidate(); }

    public void setPos(long ms) { pos = ms; invalidate(); }

    public void setFrames(Bitmap[] f) { frames = f; invalidate(); }

    public long getIn() { return in; }

    public long getOut() { return out; }

    private float pad() { return 22 * d; }

    private float x(long ms) { return pad() + (getWidth() - 2 * pad()) * (ms / (float) dur); }

    private long ms(float x) {
        float w = getWidth() - 2 * pad();
        long v = (long) ((x - pad()) / w * dur);
        return Math.max(0, Math.min(dur, v));
    }

    @Override
    protected void onDraw(Canvas c) {
        float top = 14 * d, bot = getHeight() - 10 * d, l = pad(), r = getWidth() - pad();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF262A2E);
        c.drawRoundRect(new RectF(l, top, r, bot), 8 * d, 8 * d, p);
        if (frames.length > 0) {
            float fw = (r - l) / frames.length;
            for (int i = 0; i < frames.length; i++) {
                Bitmap b = frames[i];
                if (b == null) continue;
                float bw = b.getWidth(), bh = b.getHeight();
                float scale = Math.max(fw / bw, (bot - top) / bh);
                float sw = fw / scale, sh = (bot - top) / scale;
                Rect src = new Rect((int) ((bw - sw) / 2), (int) ((bh - sh) / 2), (int) ((bw + sw) / 2), (int) ((bh + sh) / 2));
                c.drawBitmap(b, src, new RectF(l + i * fw, top, l + (i + 1) * fw, bot), null);
            }
        }
        float xi = x(in), xo = x(out);
        p.setColor(0xA6000000);
        c.drawRect(l, top, xi, bot, p);
        c.drawRect(xo, top, r, bot, p);
        // ramă albă și mânere
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * d);
        c.drawRect(xi, top, xo, bot, p);
        p.setStyle(Paint.Style.FILL);
        float hw = 14 * d;
        c.drawRoundRect(new RectF(xi - hw, top, xi, bot), 6 * d, 6 * d, p);
        c.drawRoundRect(new RectF(xo, top, xo + hw, bot), 6 * d, 6 * d, p);
        p.setColor(0xFF111315);
        float mid = (top + bot) / 2;
        c.drawRoundRect(new RectF(xi - hw / 2 - 1.5f * d, mid - 9 * d, xi - hw / 2 + 1.5f * d, mid + 9 * d), d, d, p);
        c.drawRoundRect(new RectF(xo + hw / 2 - 1.5f * d, mid - 9 * d, xo + hw / 2 + 1.5f * d, mid + 9 * d), d, d, p);
        // linia de redare
        float xp = x(pos);
        p.setColor(0xFFFF6A2B);
        c.drawRect(xp - 1.5f * d, top - 8 * d, xp + 1.5f * d, bot + 6 * d, p);
        c.drawCircle(xp, top - 8 * d, 5 * d, p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float ex = e.getX();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                if (Math.abs(ex - (x(in) - 7 * d)) < 26 * d) drag = 1;
                else if (Math.abs(ex - (x(out) + 7 * d)) < 26 * d) drag = 2;
                else drag = 3;
                move(ex);
                return true;
            case MotionEvent.ACTION_MOVE:
                move(ex);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drag = 0;
                if (listener != null) listener.onTouchEnd();
                return true;
        }
        return super.onTouchEvent(e);
    }

    private void move(float ex) {
        long v = ms(ex);
        if (drag == 1) {
            in = Math.min(v, out - 500);
            if (in < 0) in = 0;
            pos = in;
            if (listener != null) listener.onTrim(in, out, true);
        } else if (drag == 2) {
            out = Math.max(v, in + 500);
            if (out > dur) out = dur;
            pos = out;
            if (listener != null) listener.onTrim(in, out, false);
        } else if (drag == 3) {
            pos = Math.max(in, Math.min(out, v));
            if (listener != null) listener.onSeek(pos);
        }
        invalidate();
    }
}
