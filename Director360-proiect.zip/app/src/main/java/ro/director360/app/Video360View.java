package ro.director360.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Afișează o filmare 360 (cele două lentile una lângă alta, ca în fișierul LRV) ca imagine normală:
 * tragi cu degetul ca să alegi cadrul, cu două degete mărești, atingi de două ori pentru Tiny Planet.
 */
public class Video360View extends GLSurfaceView implements GLSurfaceView.Renderer {

    public interface SurfaceReady { void run(Surface s); }

    private SurfaceReady onSurface;
    private SurfaceTexture st;
    private Surface surface;
    private int tex, prog;
    private final float[] stMtx = new float[16];
    private FloatBuffer quad;
    private volatile float yaw = 0f, pitch = 0f, fovV = 80f;
    private volatile boolean planet = false;
    private int vw = 1, vh = 1;
    private final Handler main = new Handler(Looper.getMainLooper());

    // calibrarea lentilelor X5 (din fabrică), raportată la imaginea cu două cercuri
    private static final float[] PA = {2690.67f / 10752f, 2693.78f / 5376f, 2640.44f / 10752f, 2640.44f / 5376f};
    private static final float[] PB = {8066.88f / 10752f, 2690.65f / 5376f, 2650.62f / 10752f, 2650.62f / 5376f};
    private static final float FOV = (float) Math.toRadians(98.5);

    private final ScaleGestureDetector scale;
    private final GestureDetector gest;
    private float lastX, lastY;
    private boolean dragging;

    public Video360View(Context c) {
        super(c);
        setEGLContextClientVersion(2);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                fovV = Math.max(35f, Math.min(planet ? 170f : 125f, fovV / d.getScaleFactor()));
                requestRender();
                return true;
            }
        });
        gest = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) { setPlanet(!planet); return true; }
        });
    }

    public void setOnSurface(SurfaceReady r) { onSurface = r; if (surface != null) r.run(surface); }

    public boolean isPlanet() { return planet; }

    public void setPlanet(boolean p) {
        planet = p;
        if (p) { pitch = 90f; fovV = 150f; } else { pitch = 0f; fovV = 80f; }
        requestRender();
    }

    public void resetView() { yaw = 0f; setPlanet(false); }

    public float[] getView() { return new float[]{yaw, pitch, fovV, planet ? 1 : 0}; }

    public void setView(float y, float p, float f, boolean pl) { yaw = y; pitch = p; fovV = f; planet = pl; requestRender(); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        gest.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX(); lastY = e.getY(); dragging = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && e.getPointerCount() == 1 && !scale.isInProgress()) {
                    float dx = e.getX() - lastX, dy = e.getY() - lastY;
                    float k = fovV / Math.max(1, getHeight());
                    yaw -= dx * k;
                    pitch += dy * k;
                    pitch = Math.max(-90f, Math.min(90f, pitch));
                    requestRender();
                }
                lastX = e.getX(); lastY = e.getY();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                break;
        }
        return true;
    }

    private static final String VS =
            "attribute vec2 aPos;\n" +
            "varying vec2 vUv;\n" +
            "void main(){ vUv = vec2(aPos.x*0.5+0.5, 0.5-aPos.y*0.5); gl_Position = vec4(aPos,0.0,1.0); }\n";

    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision highp float;\n" +
            "varying vec2 vUv;\n" +
            "uniform samplerExternalOES uTex;\n" +
            "uniform mat4 uMtx;\n" +
            "uniform mat3 uV;\n" +
            "uniform mat3 uO;\n" +
            "uniform vec2 uTan;\n" +
            "uniform vec4 uPA;\n" +
            "uniform vec4 uPB;\n" +
            "uniform float uFov;\n" +
            "uniform float uBlend;\n" +
            "uniform int uMode;\n" +
            "vec4 tex(vec2 c){ vec2 s = (uMtx*vec4(c.x, 1.0-c.y, 0.0, 1.0)).xy; return texture2D(uTex, s); }\n" +
            "vec3 dir(){ vec2 q = (vUv*2.0-1.0)*uTan;\n" +
            "  if(uMode==1){ float r2 = dot(q,q); return uV*(vec3(2.0*q.x, 2.0*q.y, 1.0-r2)/(1.0+r2)); }\n" +
            "  return uV*normalize(vec3(q, 1.0)); }\n" +
            "vec4 lens(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov;\n" +
            "  return tex(vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph))); }\n" +
            "void main(){ vec3 d = dir(); float ta; float tb; vec4 a = lens(uPA, d, ta); vec4 b = lens(uPB, uO*d, tb);\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0;\n" +
            "  gl_FragColor = vec4(mix(b.rgb, a.rgb, w), 1.0); }\n";

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        st = new SurfaceTexture(tex);
        st.setOnFrameAvailableListener(s -> requestRender());
        surface = new Surface(st);
        prog = program(VS, FS);
        float[] v = {-1, -1, 1, -1, -1, 1, 1, 1};
        quad = ByteBuffer.allocateDirect(v.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(v).position(0);
        final Surface s = surface;
        main.post(() -> { if (onSurface != null) onSurface.run(s); });
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w); vh = Math.max(1, h);
        GLES20.glViewport(0, 0, w, h);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        try { st.updateTexImage(); st.getTransformMatrix(stMtx); } catch (Exception ignored) { }
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glUseProgram(prog);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMtx"), 1, false, stMtx, 0);
        float ty;
        if (planet) ty = (float) Math.tan(Math.toRadians(fovV / 4.0)); // proiecție stereografică
        else ty = (float) Math.tan(Math.toRadians(fovV / 2.0));
        float tx = ty * vw / (float) vh;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uTan"), tx, ty);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uV"), 1, false, colMajor(view()), 0);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uO"), 1, false, colMajor(O_L1toL2), 0);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPA"), PA[0], PA[1], PA[2], PA[3]);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPB"), PB[0], PB[1], PB[2], PB[3]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uFov"), FOV);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uBlend"), (float) Math.toRadians(4));
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uMode"), planet ? 1 : 0);
        int loc = GLES20.glGetAttribLocation(prog, "aPos");
        GLES20.glEnableVertexAttribArray(loc);
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    }

    // ---- matrice (rând după rând) ----
    private static float[] rotX(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{1, 0, 0, 0, c, -s, 0, s, c}; }
    private static float[] rotY(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, 0, s, 0, 1, 0, -s, 0, c}; }
    private static float[] rotZ(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, -s, 0, s, c, 0, 0, 0, 1}; }
    private static float[] mul(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }
    private static float[] colMajor(float[] m) { return new float[]{m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8]}; }
    private static final float[] FLIP = {-1, 0, 0, 0, 1, 0, 0, 0, -1};
    private static final float[] R2 = mul(mul(rotY(Math.toRadians(0.5)), rotX(Math.toRadians(-1.5))), rotZ(Math.toRadians(-1)));
    private static final float[] O_L1toL2 = mul(FLIP, R2);

    private float[] view() { return mul(rotY(Math.toRadians(yaw)), rotX(Math.toRadians(pitch))); }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        return p;
    }

    public void release() {
        try { if (surface != null) surface.release(); } catch (Exception ignored) { }
        try { if (st != null) st.release(); } catch (Exception ignored) { }
    }
}
