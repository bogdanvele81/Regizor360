package ro.director360.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.GestureDetector;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Afișează o filmare 360 (cele două lentile una lângă alta, ca în fișierul LRV) ca imagine normală:
 * tragi cu degetul ca să alegi cadrul, cu două degete mărești, atingi de două ori pentru Tiny Planet.
 */
public class Video360View extends GLSurfaceView implements GLSurfaceView.Renderer {

    public interface SurfaceReady { void run(Surface s); }

    private SurfaceReady onSurface;
    private SurfaceTexture st;
    private Surface surface;
    private int tex, prog;
    private final float[] stMtx = new float[16];
    private FloatBuffer quad;
    private volatile float yaw = 0f, pitch = 0f, fovV = 80f;
    private volatile boolean planet = false;
    /** filmare normală (nu 360): se afișează direct, tăiată pe formatul ales */
    private volatile boolean flat = false;
    private volatile float videoAspect = 16f / 9f;
    private int vw = 1, vh = 1;
    private final Handler main = new Handler(Looper.getMainLooper());
    /** poză (în loc de film): textură obișnuită */
    private android.graphics.Bitmap pendingBmp, keepBmp;
    private boolean photoMode = false;
    private int tex2 = 0, prog2 = 0;
    private static final float[] FLIPY = {1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1};

    public interface Captured { void run(android.graphics.Bitmap b); }

    // calibrarea lentilelor X5 (din fabrică), raportată la imaginea cu două cercuri
    private static final float[] PA = {2690.67f / 10752f, 2693.78f / 5376f, 2640.44f / 10752f, 2640.44f / 5376f};
    private static final float[] PB = {8066.88f / 10752f, 2690.65f / 5376f, 2650.62f / 10752f, 2650.62f / 5376f};
    private static final float FOV = (float) Math.toRadians(98.5);

    private final ScaleGestureDetector scale;
    private final GestureDetector gest;
    private float lastX, lastY;
    private boolean dragging;

    public Video360View(Context c) {
        super(c);
        setEGLContextClientVersion(2);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
        scale = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if (flat) return true;
                fovV = Math.max(35f, Math.min(planet ? 170f : 125f, fovV / d.getScaleFactor()));
                requestRender();
                return true;
            }
        });
        gest = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) { if (!flat) setPlanet(!planet); return true; }
        });
    }

    /** afișează o poză; poate fi apelat oricând */
    public void setPhoto(android.graphics.Bitmap b) {
        keepBmp = b;
        queueEvent(() -> { pendingBmp = b; photoMode = true; });
        requestRender();
    }

    /** face o poză din ce se vede, la mărimea cerută (pentru salvare) */
    public void capture(int w, int h, Captured cb) {
        queueEvent(() -> {
            android.graphics.Bitmap out = null;
            try {
                int[] fb = new int[1], rt = new int[1];
                GLES20.glGenFramebuffers(1, fb, 0);
                GLES20.glGenTextures(1, rt, 0);
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, rt[0]);
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0]);
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, rt[0], 0);
                int ow = vw, oh = vh;
                vw = w; vh = h;
                GLES20.glViewport(0, 0, w, h);
                draw(true);
                ByteBuffer buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder());
                GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf);
                vw = ow; vh = oh;
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
                GLES20.glViewport(0, 0, vw, vh);
                GLES20.glDeleteFramebuffers(1, fb, 0);
                GLES20.glDeleteTextures(1, rt, 0);
                android.graphics.Bitmap b = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888);
                buf.position(0);
                b.copyPixelsFromBuffer(buf);
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.preScale(1, -1);
                out = android.graphics.Bitmap.createBitmap(b, 0, 0, w, h, m, false);
                b.recycle();
            } catch (Throwable e) {
                out = null;
            }
            final android.graphics.Bitmap r = out;
            main.post(() -> cb.run(r));
            requestRender();
        });
    }

    public static int maxTex() {
        int[] v = new int[1];
        GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, v, 0);
        return v[0];
    }

    private volatile float[] look = Look.NONE;

    /** filtrul de culoare (vezi Look) */
    public void setLook(float[] l) { look = l == null ? Look.NONE : l; requestRender(); }

    public void setOnSurface(SurfaceReady r) { onSurface = r; if (surface != null) r.run(surface); }

    public boolean isPlanet() { return planet; }

    public void setFlat(boolean f, float aspect) { flat = f; if (aspect > 0) videoAspect = aspect; requestRender(); }

    public boolean isFlat() { return flat; }

    public void setPlanet(boolean p) {
        planet = p;
        if (p) { pitch = 90f; fovV = 150f; } else { pitch = 0f; fovV = 80f; }
        requestRender();
    }

    public void resetView() { yaw = 0f; setPlanet(false); }

    public float[] getView() { return new float[]{yaw, pitch, fovV, planet ? 1 : 0}; }

    public void setView(float y, float p, float f, boolean pl) { yaw = y; pitch = p; fovV = f; planet = pl; requestRender(); }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        scale.onTouchEvent(e);
        gest.onTouchEvent(e);
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX(); lastY = e.getY(); dragging = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                dragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (dragging && !flat && e.getPointerCount() == 1 && !scale.isInProgress()) {
                    float dx = e.getX() - lastX, dy = e.getY() - lastY;
                    float k = fovV / Math.max(1, getHeight());
                    yaw -= dx * k;
                    pitch += dy * k;
                    pitch = Math.max(-90f, Math.min(90f, pitch));
                    requestRender();
                }
                lastX = e.getX(); lastY = e.getY();
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                break;
        }
        return true;
    }

    private static final String VS =
            "attribute vec2 aPos;\n" +
            "varying vec2 vUv;\n" +
            "void main(){ vUv = vec2(aPos.x*0.5+0.5, 0.5-aPos.y*0.5); gl_Position = vec4(aPos,0.0,1.0); }\n";

    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision highp float;\n" +
            "varying vec2 vUv;\n" +
            "uniform samplerExternalOES uTex;\n" +
            "uniform mat4 uMtx;\n" +
            "uniform mat3 uV;\n" +
            "uniform mat3 uO;\n" +
            "uniform vec2 uTan;\n" +
            "uniform vec4 uPA;\n" +
            "uniform vec4 uPB;\n" +
            "uniform float uFov;\n" +
            "uniform float uBlend;\n" +
            "uniform int uMode;\n" +
            "uniform int uFlat;\n" +
            "uniform vec2 uCrop;\n" +
            "uniform vec4 uGrade;\n" +
            "uniform float uVig;\n" +
            Look.GLSL +
            "vec4 tex(vec2 c){ vec2 s = (uMtx*vec4(c.x, 1.0-c.y, 0.0, 1.0)).xy; return texture2D(uTex, s); }\n" +
            "vec3 dir(){ vec2 q = (vUv*2.0-1.0)*uTan;\n" +
            "  if(uMode==1){ float r2 = dot(q,q); return uV*(vec3(2.0*q.x, 2.0*q.y, 1.0-r2)/(1.0+r2)); }\n" +
            "  return uV*normalize(vec3(q, 1.0)); }\n" +
            "vec4 lens(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov;\n" +
            "  return tex(vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph))); }\n" +
            "void main(){ if(uFlat==1){ gl_FragColor = vec4(grade(tex(vec2(0.5)+(vUv-vec2(0.5))*uCrop).rgb, uGrade, uVig, vUv), 1.0); return; }\n" +
            "  vec3 d = dir(); float ta; float tb; vec4 a = lens(uPA, d, ta); vec4 b = lens(uPB, uO*d, tb);\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0;\n" +
            "  gl_FragColor = vec4(grade(mix(b.rgb, a.rgb, w), uGrade, uVig, vUv), 1.0); }\n";

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        tex = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        st = new SurfaceTexture(tex);
        st.setOnFrameAvailableListener(s -> requestRender());
        surface = new Surface(st);
        prog = program(VS, FS);
        tex2 = 0;
        if (keepBmp != null) { pendingBmp = keepBmp; photoMode = true; }
        prog2 = program(VS, FS.replace("#extension GL_OES_EGL_image_external : require\n", "").replace("samplerExternalOES", "sampler2D"));
        float[] v = {-1, -1, 1, -1, -1, 1, 1, 1};
        quad = ByteBuffer.allocateDirect(v.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        quad.put(v).position(0);
        final Surface s = surface;
        main.post(() -> { if (onSurface != null) onSurface.run(s); });
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w); vh = Math.max(1, h);
        GLES20.glViewport(0, 0, w, h);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        if (pendingBmp != null) {
            int[] t = new int[1];
            if (tex2 != 0) { t[0] = tex2; GLES20.glDeleteTextures(1, t, 0); }
            GLES20.glGenTextures(1, t, 0);
            tex2 = t[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex2);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, pendingBmp, 0);
            pendingBmp = null;
        }
        if (!photoMode) { try { st.updateTexImage(); st.getTransformMatrix(stMtx); } catch (Exception ignored) { } }
        draw(false);
    }

    private void draw(boolean offscreen) {
        int prog = photoMode ? prog2 : this.prog;
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        GLES20.glUseProgram(prog);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        if (photoMode) GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex2);
        else GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uMtx"), 1, false, photoMode ? FLIPY : stMtx, 0);
        float ty;
        if (planet) ty = (float) Math.tan(Math.toRadians(fovV / 4.0)); // proiecție stereografică
        else ty = (float) Math.tan(Math.toRadians(fovV / 2.0));
        float tx = ty * vw / (float) vh;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uTan"), tx, ty);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uV"), 1, false, colMajor(view()), 0);
        GLES20.glUniformMatrix3fv(GLES20.glGetUniformLocation(prog, "uO"), 1, false, colMajor(O_L1toL2), 0);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPA"), PA[0], PA[1], PA[2], PA[3]);
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uPB"), PB[0], PB[1], PB[2], PB[3]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uFov"), FOV);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uBlend"), (float) Math.toRadians(4));
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uMode"), planet ? 1 : 0);
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uFlat"), flat ? 1 : 0);
        float sa = vw / (float) vh, va = videoAspect;
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "uCrop"), Math.min(1f, sa / va), Math.min(1f, va / sa));
        float[] lk = look;
        GLES20.glUniform4f(GLES20.glGetUniformLocation(prog, "uGrade"), lk[0], lk[1], lk[2], lk[3]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uVig"), lk[4]);
        int loc = GLES20.glGetAttribLocation(prog, "aPos");
        GLES20.glEnableVertexAttribArray(loc);
        GLES20.glVertexAttribPointer(loc, 2, GLES20.GL_FLOAT, false, 0, quad);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    }

    // ---- matrice (rând după rând) ----
    private static float[] rotX(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{1, 0, 0, 0, c, -s, 0, s, c}; }
    private static float[] rotY(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, 0, s, 0, 1, 0, -s, 0, c}; }
    private static float[] rotZ(double a) { float c = (float) Math.cos(a), s = (float) Math.sin(a); return new float[]{c, -s, 0, s, c, 0, 0, 0, 1}; }
    private static float[] mul(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
            float v = 0;
            for (int k = 0; k < 3; k++) v += a[i * 3 + k] * b[k * 3 + j];
            r[i * 3 + j] = v;
        }
        return r;
    }
    static float[] colMajorPublic(float[] m) { return colMajor(m); }
    static float[] viewMatrix(float yaw, float pitch) { return mul(rotY(Math.toRadians(yaw)), rotX(Math.toRadians(pitch))); }
    static float[] lensMatrix() { return O_L1toL2; }
    static float[] calA() { return PA; }
    static float[] calB() { return PB; }
    static float fovRad() { return FOV; }

    private static float[] colMajor(float[] m) { return new float[]{m[0], m[3], m[6], m[1], m[4], m[7], m[2], m[5], m[8]}; }
    private static final float[] FLIP = {-1, 0, 0, 0, 1, 0, 0, 0, -1};
    private static final float[] R2 = mul(mul(rotY(Math.toRadians(0.5)), rotX(Math.toRadians(-1.5))), rotZ(Math.toRadians(-1)));
    private static final float[] O_L1toL2 = mul(FLIP, R2);

    private float[] view() { return mul(rotY(Math.toRadians(yaw)), rotX(Math.toRadians(pitch))); }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        return p;
    }

    public void release() {
        try { if (surface != null) surface.release(); } catch (Exception ignored) { }
        try { if (st != null) st.release(); } catch (Exception ignored) { }
    }
}
