package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pozele mici ale filmărilor: făcute o dată, ținute minte în telefon. */
public class Thumbs {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final android.util.LruCache<String, Bitmap> MEM = new android.util.LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    public interface Done { void run(Bitmap b, long durationMs); }

    public static void load(Context ctx, VideoItem it, ImageView view) {
        final String key = it.key();
        view.setTag(key);
        Bitmap m = MEM.get(key);
        if (m != null) { view.setImageBitmap(m); return; }
        view.setImageDrawable(null);
        final Context app = ctx.getApplicationContext();
        POOL.execute(() -> {
            Bitmap b = get(app, it);
            if (b == null) return;
            MEM.put(key, b);
            MAIN.post(() -> { if (key.equals(view.getTag())) view.setImageBitmap(b); });
        });
    }

    private static File file(Context ctx, String key) {
        File d = new File(ctx.getFilesDir(), "thumbs");
        d.mkdirs();
        return new File(d, Integer.toHexString(key.hashCode()) + ".jpg");
    }

    private static Bitmap get(Context ctx, VideoItem it) {
        File f = file(ctx, it.key());
        if (f.exists()) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) return b;
        }
        Uri src = it.lrv != null ? it.lrv : it.uri;
        Bitmap b = frame(ctx, src, 1_000_000L, 360, 220);
        if (b == null && src != it.uri) b = frame(ctx, it.uri, 1_000_000L, 360, 220);
        if (b == null) return null;
        try (FileOutputStream o = new FileOutputStream(f)) {
            b.compress(Bitmap.CompressFormat.JPEG, 82, o);
        } catch (Exception ignored) {
        }
        return b;
    }

    /** un cadru din film, micșorat */
    public static Bitmap frame(Context ctx, Uri uri, long atUs, int w, int h) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            return r.getScaledFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h);
        } catch (Throwable e) {
            return null;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    public static long duration(Context ctx, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? -1 : Long.parseLong(d);
        } catch (Throwable e) {
            return -1;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    public static void durationAsync(Context ctx, VideoItem it, Runnable then) {
        if (it.durationMs >= 0) return;
        final Context app = ctx.getApplicationContext();
        POOL.execute(() -> {
            String k = "dur:" + it.key();
            android.content.SharedPreferences sp = app.getSharedPreferences("dur", Context.MODE_PRIVATE);
            long d = sp.getLong(k, -1);
            if (d < 0) {
                d = duration(app, it.lrv != null ? it.lrv : it.uri);
                if (d > 0) sp.edit().putLong(k, d).apply();
            }
            it.durationMs = d < 0 ? 0 : d;
            MAIN.post(then);
        });
    }
}
