package ro.director360.app;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/** Cadru care păstrează formatul ales (16:9, 9:16, 1:1…) și încape în spațiul disponibil. */
public class AspectFrame extends FrameLayout {
    private float ratio = 16f / 9f;

    public AspectFrame(Context c, AttributeSet a) { super(c, a); }

    public void setRatio(float r) { if (r > 0 && Math.abs(r - ratio) > 0.001f) { ratio = r; requestLayout(); } }

    public float getRatio() { return ratio; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec), h = MeasureSpec.getSize(hSpec);
        if (w <= 0 || h <= 0) { super.onMeasure(wSpec, hSpec); return; }
        int cw = w, ch = Math.round(w / ratio);
        if (ch > h) { ch = h; cw = Math.round(h * ratio); }
        super.onMeasure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
    }
}
