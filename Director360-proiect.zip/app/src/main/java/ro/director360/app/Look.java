package ro.director360.app;

/** Filtrele de culoare (ca în Regizor 360). Un filtru = {expunere, contrast, saturație, cald/rece, vignetă}. */
public class Look {
    public static final float[] NONE = {1f, 1f, 1f, 0f, 0f};

    public static final String[] IDS = {"none", "vivid", "snow", "warm", "cool", "cine", "night", "bw"};
    public static final String[] NAMES = {"Natural", "Viu", "Zăpadă", "Cald", "Rece", "Cinematic", "Noapte", "Alb-negru"};
    /** culorile mostrei din listă */
    public static final int[][] SWATCH = {
            {0xFF6B8FB5, 0xFFC9B48A}, {0xFF1E90FF, 0xFFFF6A2B}, {0xFFDFE9F3, 0xFF7FB2E5}, {0xFFF6B26B, 0xFFE06C2B},
            {0xFF7FB2E5, 0xFF3D5A80}, {0xFF2B3A42, 0xFFC08552}, {0xFF1B2735, 0xFF5B7A9A}, {0xFFEEEEEE, 0xFF333333}};
    // parametrii din Regizor: exp, con, sat, warm, vig (în procente)
    private static final float[][] P = {
            {0, 0, 0, 0, 0}, {5, 15, 30, 0, 10}, {-10, 10, 18, 0, 0}, {0, 10, 10, 40, 0},
            {0, 10, 5, -35, 0}, {0, 25, -15, 10, 35}, {35, 5, 0, 0, 0}, {0, 25, -100, 0, 15}};

    /** filtrul cu tăria k (0..100; 70 = normal) */
    public static float[] of(String id, int k) {
        int i = 0;
        for (int j = 0; j < IDS.length; j++) if (IDS[j].equals(id)) i = j;
        float s = k / 70f;
        float[] q = P[i];
        float sat = 1 + q[2] / 100f * s;
        if (q[2] <= -100) sat = Math.max(0, 1 - s); // alb-negru: la tărie mare devine complet gri
        return new float[]{1 + q[0] / 100f * s, 1 + q[1] / 100f * s, Math.max(0, sat), q[3] / 250f * s, q[4] / 100f * s};
    }

    /** aceeași funcție în previzualizare și la salvare */
    public static final String GLSL =
            "vec3 grade(vec3 c, vec4 g, float vig, vec2 uv){\n" +
            "  c *= g.x;\n" +
            "  c = (c - 0.5) * g.y + 0.5;\n" +
            "  float l = dot(c, vec3(0.299, 0.587, 0.114));\n" +
            "  c = mix(vec3(l), c, g.z);\n" +
            "  c.r *= 1.0 + g.w; c.b *= 1.0 - g.w;\n" +
            "  vec2 q = uv - 0.5; c *= 1.0 - vig * smoothstep(0.25, 0.75, dot(q, q) * 2.0);\n" +
            "  return clamp(c, 0.0, 1.0); }\n";
}
