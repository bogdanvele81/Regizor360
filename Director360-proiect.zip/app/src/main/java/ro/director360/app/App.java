package ro.director360.app;

import android.app.Application;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Dacă aplicația se oprește din cauza unei erori, eroarea se păstrează și se arată la pornirea următoare. */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String ver = "?";
                try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
                try (FileWriter w = new FileWriter(new File(getFilesDir(), "crash.txt"))) {
                    w.write("Director360 " + ver + " · Android " + android.os.Build.VERSION.RELEASE + " · " + android.os.Build.MODEL + "\nFir: " + t.getName() + "\n\n" + sw);
                }
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
