package ro.director360.app;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/** Citește durata direct din fișierul MP4 (caseta mvhd), când telefonul nu o spune. */
public class Mp4Info {
    public static long durationMs(Context ctx, Uri uri) {
        try (ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
             FileInputStream in = new FileInputStream(pfd.getFileDescriptor())) {
            FileChannel ch = in.getChannel();
            long size = ch.size(), pos = 0;
            ByteBuffer h = ByteBuffer.allocate(16);
            while (pos + 8 <= size) {
                h.clear(); h.limit(16);
                ch.read(h, pos);
                h.flip();
                if (h.remaining() < 8) break;
                long len = h.getInt() & 0xFFFFFFFFL;
                int type = h.getInt();
                int hdr = 8;
                if (len == 1 && h.remaining() >= 8) { len = h.getLong(); hdr = 16; }
                else if (len == 0) len = size - pos;
                if (len < hdr) break;
                if (type == 0x6D6F6F76) { // moov
                    long p = pos + hdr, end = pos + len;
                    while (p + 8 <= end) {
                        h.clear(); h.limit(8);
                        ch.read(h, p);
                        h.flip();
                        long l = h.getInt() & 0xFFFFFFFFL;
                        int t = h.getInt();
                        if (l < 8) break;
                        if (t == 0x6D766864) { // mvhd
                            ByteBuffer m = ByteBuffer.allocate(32);
                            ch.read(m, p + 8);
                            m.flip();
                            int ver = m.get() & 0xFF;
                            m.position(4);
                            long ts, du;
                            if (ver == 1) { m.position(4 + 16); ts = m.getInt() & 0xFFFFFFFFL; du = m.getLong(); }
                            else { m.position(4 + 8); ts = m.getInt() & 0xFFFFFFFFL; du = m.getInt() & 0xFFFFFFFFL; }
                            return ts > 0 ? du * 1000 / ts : -1;
                        }
                        p += l;
                    }
                    return -1;
                }
                pos += len;
            }
        } catch (Throwable ignored) { }
        return -1;
    }
}
