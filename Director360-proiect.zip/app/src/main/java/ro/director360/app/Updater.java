package ro.director360.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Actualizare direct din aplicație: caută pe GitHub versiunile „director-vN”. */
public class Updater {

    public interface Found { void run(int version); }

    public static void check(Activity a, Found found) {
        new Thread(() -> {
            int best = -1;
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(
                        "https://api.github.com/repos/bogdanvele81/Regizor360/releases?per_page=40").openConnection();
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setRequestProperty("User-Agent", "Director360-app");
                c.setConnectTimeout(8000);
                c.setReadTimeout(8000);
                if (c.getResponseCode() == 200) {
                    InputStream in = c.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                    in.close();
                    JSONArray arr = new JSONArray(bo.toString("UTF-8"));
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String tag = o.optString("tag_name", "");
                        if (tag.startsWith("director-v")) {
                            try { best = Math.max(best, Integer.parseInt(tag.substring(10))); } catch (Exception ignored) { }
                        }
                    }
                }
                c.disconnect();
            } catch (Throwable ignored) { }
            final int v = best;
            new Handler(Looper.getMainLooper()).post(() -> found.run(v));
        }).start();
    }

    public static long current(Activity a) {
        try { return a.getPackageManager().getPackageInfo(a.getPackageName(), 0).getLongVersionCode(); }
        catch (Exception e) { return 0; }
    }

    private static long dlId = -1;
    private static boolean opened = false;

    /** pornește descărcarea; întoarce false dacă trebuie întâi permisiunea de instalare */
    public static boolean start(Activity a, int version) {
        if (!a.getPackageManager().canRequestPackageInstalls()) {
            Intent st = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName()));
            a.startActivity(st);
            return false;
        }
        DownloadManager dm = (DownloadManager) a.getSystemService(Activity.DOWNLOAD_SERVICE);
        File dir = a.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File old = new File(dir, "Director360-update.apk");
        if (old.exists()) old.delete();
        DownloadManager.Request r = new DownloadManager.Request(Uri.parse(
                "https://github.com/bogdanvele81/Regizor360/releases/download/director-v" + version + "/Director360.apk"));
        r.setTitle("Director360 · actualizare");
        r.setMimeType("application/vnd.android.package-archive");
        r.setDestinationInExternalFilesDir(a, Environment.DIRECTORY_DOWNLOADS, "Director360-update.apk");
        r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        opened = false;
        dlId = dm.enqueue(r);
        return true;
    }

    /** 0–99 se descarcă, 100 gata (deschide instalarea), -1 eroare */
    public static int progress(Activity a) {
        if (dlId < 0) return -1;
        try {
            DownloadManager dm = (DownloadManager) a.getSystemService(Activity.DOWNLOAD_SERVICE);
            Cursor cur = dm.query(new DownloadManager.Query().setFilterById(dlId));
            if (cur == null || !cur.moveToFirst()) { if (cur != null) cur.close(); return -1; }
            int st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
            long done = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
            long tot = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
            cur.close();
            if (st == DownloadManager.STATUS_FAILED) return -1;
            if (st == DownloadManager.STATUS_SUCCESSFUL) {
                if (!opened) {
                    opened = true;
                    Uri u = dm.getUriForDownloadedFile(dlId);
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(u, "application/vnd.android.package-archive");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    a.startActivity(i);
                }
                return 100;
            }
            return tot > 0 ? (int) Math.min(99, done * 100 / tot) : 0;
        } catch (Throwable e) {
            return -1;
        }
    }
}
