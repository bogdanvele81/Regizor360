package ro.director360.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Ecran simplu care arată eroarea de data trecută, ca s-o poți trimite. */
public class CrashActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final String err = getIntent().getStringExtra("err");
        float d = getResources().getDisplayMetrics().density;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF111315);
        box.setPadding((int) (16 * d), (int) (36 * d), (int) (16 * d), (int) (16 * d));
        TextView t = new TextView(this);
        t.setText("Aplicația s-a oprit data trecută din cauza unei erori.\nFă o poză la ecran și trimite-o lui Claude, sau apasă „Copiază eroarea” și lipește textul în conversație.");
        t.setTextColor(0xFFF2F2F0);
        t.setTextSize(16);
        box.addView(t);
        Button copy = new Button(this);
        copy.setText("Copiază eroarea");
        copy.setOnClickListener(v -> {
            try {
                ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("eroare", err));
                Toast.makeText(this, "Copiată", Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) { }
        });
        box.addView(copy);
        Button go = new Button(this);
        go.setText("Pornește aplicația");
        go.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class).putExtra("skipCrash", true));
            finish();
        });
        box.addView(go);
        ScrollView sv = new ScrollView(this);
        TextView e = new TextView(this);
        e.setText(err);
        e.setTextColor(0xFFFFD21F);
        e.setTextSize(12);
        e.setTypeface(android.graphics.Typeface.MONOSPACE);
        e.setTextIsSelectable(true);
        sv.addView(e);
        box.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(box);
    }
}
