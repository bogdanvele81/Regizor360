package ro.director360.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;

import androidx.media3.effect.BitmapOverlay;

import java.util.List;

/** La salvare: pune textele și stickerele peste o bucată din montaj (care începe la g0 ms în film). */
public class OvEffect extends BitmapOverlay {
    private final List<Overlays.Ov> list;
    private final long g0;
    private final int w, h;
    private final Bitmap[] buf = new Bitmap[2];
    private final Bitmap empty = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888);
    private long first = -1;
    private int flip = 0;

    public OvEffect(List<Overlays.Ov> list, long g0, int w, int h) {
        this.list = list;
        this.g0 = g0;
        this.w = w;
        this.h = h;
    }

    @Override
    public Bitmap getBitmap(long presentationTimeUs) {
        if (first < 0) first = presentationTimeUs;
        long T = g0 + (presentationTimeUs - first) / 1000;
        boolean any = false;
        for (Overlays.Ov o : list) if (T >= o.a && T < o.b) { any = true; break; }
        if (!any) return empty;
        flip ^= 1;
        if (buf[flip] == null) buf[flip] = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Bitmap b = buf[flip];
        b.eraseColor(Color.TRANSPARENT);
        Overlays.drawAll(new Canvas(b), list, T, w, h, null);
        return b;
    }
}
