package ro.director360.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import java.util.List;

/** Text și stickere pe film, desenate la fel ca în Regizor 360 (aceleași stiluri, animații, culori). */
public class Overlays {

    public static class Ov {
        public boolean emoji;
        public String text = "Textul tău";
        public String style = "simplu", anim = "pop";
        public int color = Color.WHITE;
        public float x = 0.5f, y = 0.5f, s = 1f, rot = 0f;
        /** de la, până la (ms din tot filmul) */
        public long a = 0, b = 3000;

        public Ov copy() {
            Ov o = new Ov();
            o.emoji = emoji; o.text = text; o.style = style; o.anim = anim; o.color = color;
            o.x = x; o.y = y; o.s = s; o.rot = rot; o.a = a; o.b = b;
            return o;
        }
    }

    public static final String[][] STYLES = {{"simplu", "Simplu"}, {"vlog", "Vlog"}, {"neon", "Neon"}, {"galben", "Galben"}, {"subtitrare", "Subtitrare"}, {"titlu", "Titlu"}};
    public static final String[][] ANIMS = {{"none", "Fără"}, {"pop", "Pop"}, {"fade", "Estompare"}, {"slide", "Alunecare"}, {"bounce", "Săritură"}, {"type", "Mașină de scris"}, {"zoom", "Zoom"}};
    public static final int[] COLORS = {0xFFFFFFFF, 0xFFFFD21F, 0xFFFF6A2B, 0xFFFF3B5C, 0xFFFF5FD2, 0xFF38D6FF, 0xFF5EE38A, 0xFF111111};
    public static final String[] EMOJIS = {"😀", "😂", "😍", "🥰", "😎", "🤩", "😜", "🤪", "😱", "🥳", "😴", "👀", "👍", "👏", "🙌", "💪", "🤙", "✌️", "🔥", "✨", "⭐", "💥", "💯", "❤️", "💛", "💙", "🎉", "🎈", "🎂", "🎁", "🏆", "🥇", "🚗", "🏎️", "🏍️", "🚴", "🔧", "⛰️", "🏖️", "☀️", "🌊", "💦", "🐬", "🌈", "📍", "✈️", "📸", "🎬", "🎵", "➡️", "⬇️", "❗"};

    // ---- șabloanele din Regizor 360 ----
    public static class Tpl {
        public final String id, cat, name, title, ts, an, style, filt;
        public final int dur, g0, g1;
        Tpl(String id, String cat, String name, String title, String ts, String an, String style, int dur, String filt, int g0, int g1) {
            this.id = id; this.cat = cat; this.name = name; this.title = title; this.ts = ts; this.an = an; this.style = style; this.dur = dur; this.filt = filt; this.g0 = g0; this.g1 = g1;
        }
    }

    public static final String[] TPL_CATS = {"Călătorie", "Vlog", "Copii", "Moto", "Bicicletă", "Mașini", "Distracție", "Cinematic"};
    public static final Tpl[] TPLS = {
            new Tpl("vara", "Călătorie", "Vară la mare", "VARĂ ☀️", "galben", "pop", "normal", 30, "warm", 0xFFFFB347, 0xFFFF5E62),
            new Tpl("road", "Călătorie", "Road Trip", "ROAD TRIP", "titlu", "slide", "normal", 45, "cine", 0xFF355C7D, 0xFFC06C84),
            new Tpl("city", "Călătorie", "City Break", "City\nBreak", "vlog", "pop", "fast", 20, "vivid", 0xFF4568DC, 0xFFB06AB3),
            new Tpl("munte", "Călătorie", "Sus pe munte", "SUS PE MUNTE", "titlu", "fade", "calm", 40, "cool", 0xFF2C3E50, 0xFF4CA1AF),
            new Tpl("daily", "Vlog", "Daily Life", "Daily\nLife", "vlog", "pop", "normal", 30, "vivid", 0xFFF857A6, 0xFFFF5858),
            new Tpl("ziua", "Vlog", "Ziua mea", "ZIUA MEA", "galben", "bounce", "fast", 20, "none", 0xFF11998E, 0xFF38EF7D),
            new Tpl("weekend", "Vlog", "Weekend", "Weekend 🎉", "neon", "pop", "normal", 25, "warm", 0xFF8E2DE2, 0xFF4A00E0),
            new Tpl("story", "Vlog", "Story 15 s", "✨ STORY ✨", "titlu", "zoom", "fast", 15, "vivid", 0xFFFC466B, 0xFF3F5EFB),
            new Tpl("pasi", "Copii", "Primii pași", "Primii pași 💛", "simplu", "fade", "calm", 30, "warm", 0xFFF6D365, 0xFFFDA085),
            new Tpl("piscina", "Copii", "La piscină", "SPLASH! 💦", "galben", "bounce", "normal", 25, "vivid", 0xFF00C6FF, 0xFF0072FF),
            new Tpl("bday", "Copii", "La mulți ani", "La mulți ani! 🎂", "neon", "pop", "normal", 30, "warm", 0xFFEE9CA7, 0xFFFFDDE1),
            new Tpl("joaca", "Copii", "Joacă", "JOACĂ 🎈", "vlog", "bounce", "fast", 20, "vivid", 0xFFF7971E, 0xFFFFD200),
            new Tpl("roti", "Moto", "Pe două roți", "PE DOUĂ ROȚI", "titlu", "slide", "fast", 30, "cine", 0xFF232526, 0xFFFF512F),
            new Tpl("gaz", "Moto", "Full gaz", "FULL GAZ 🏍️", "galben", "zoom", "fast", 15, "vivid", 0xFFFF416C, 0xFFFF4B2B),
            new Tpl("serp", "Moto", "Serpentine", "Serpentine", "vlog", "slide", "normal", 40, "cool", 0xFF0F2027, 0xFF2C5364),
            new Tpl("tura", "Bicicletă", "Tură de weekend", "TURĂ 🚴", "vlog", "pop", "normal", 30, "vivid", 0xFF56AB2F, 0xFFA8E063),
            new Tpl("down", "Bicicletă", "Downhill", "DOWNHILL", "galben", "zoom", "fast", 20, "cine", 0xFF3A1C71, 0xFFD76D77),
            new Tpl("pedale", "Bicicletă", "Pedale și soare", "Pedale & soare", "simplu", "fade", "calm", 40, "warm", 0xFFFCEABB, 0xFFF8B500),
            new Tpl("atelier", "Mașini", "În atelier", "ÎN ATELIER 🔧", "titlu", "slide", "normal", 30, "cine", 0xFF141E30, 0xFFFF6A2B),
            new Tpl("inainte", "Mașini", "Înainte / După", "ÎNAINTE ➜ DUPĂ", "galben", "pop", "normal", 25, "vivid", 0xFF000000, 0xFFE74C3C),
            new Tpl("meet", "Mașini", "Car Meet", "CAR MEET", "neon", "zoom", "fast", 20, "night", 0xFF0F0C29, 0xFF302B63),
            new Tpl("party", "Distracție", "Petrecere", "PARTY 🎉", "neon", "bounce", "fast", 20, "vivid", 0xFFDA22FF, 0xFF9733EE),
            new Tpl("sport", "Distracție", "Sport", "GO! 🔥", "galben", "pop", "fast", 20, "vivid", 0xFFF12711, 0xFFF5AF19),
            new Tpl("cine", "Cinematic", "Povestea noastră", "Povestea noastră", "titlu", "fade", "calm", 45, "cine", 0xFF232526, 0xFF414345),
            new Tpl("bw", "Cinematic", "Amintiri", "AMINTIRI", "titlu", "fade", "calm", 30, "bw", 0xFFBDC3C7, 0xFF2C3E50)};

    // ---- desenare ----
    private static float easeOut(float k) { return 1 - (float) Math.pow(1 - k, 3); }
    private static float easeBack(float k) { float c = 1.7f; return 1 + (c + 1) * (float) Math.pow(k - 1, 3) + c * (float) Math.pow(k - 1, 2); }
    private static float easeBounce(float k) {
        float n = 7.5625f, d = 2.75f;
        if (k < 1 / d) return n * k * k;
        if (k < 2 / d) { k -= 1.5f / d; return n * k * k + .75f; }
        if (k < 2.5 / d) { k -= 2.25f / d; return n * k * k + .9375f; }
        k -= 2.625f / d; return n * k * k + .984375f;
    }

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();

    /** desenează toate textele/stickerele active la momentul T (ms) pe o imagine W×H */
    public static synchronized void drawAll(Canvas c, List<Ov> list, long T, int W, int H, Ov selected) {
        if (list == null) return;
        for (Ov o : list) if (T >= o.a && T < o.b) drawOne(c, o, T, W, H, o == selected);
    }

    /** cutia ocupată de un text (pentru atingere): {cx, cy, w, h} */
    public static synchronized float[] box(Ov o, int W, int H) {
        float px = o.s * H * (o.emoji ? 0.2f : o.style.equals("subtitrare") ? 0.06f : 0.1f);
        setFont(o, px);
        String[] lines = lines(o, o.text);
        float bw = 0;
        for (String l : lines) bw = Math.max(bw, P.measureText(l));
        float lh = px * 1.12f;
        return new float[]{o.x * W, o.y * H, Math.max(bw, px) + px * 0.4f, lines.length * lh + px * 0.4f};
    }

    private static String[] lines(Ov o, String txt) {
        String[] ls = txt.split("\n");
        if (!o.emoji && (o.style.equals("galben") || o.style.equals("titlu")))
            for (int i = 0; i < ls.length; i++) ls[i] = ls[i].toUpperCase(new java.util.Locale("ro"));
        return ls;
    }

    private static void setFont(Ov o, float px) {
        P.setTextSize(px);
        P.setLetterSpacing(0);
        if (o.emoji) { P.setTypeface(Typeface.DEFAULT); return; }
        switch (o.style) {
            case "vlog": P.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)); break;
            case "subtitrare": P.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); break;
            case "galben": case "titlu": P.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); if (o.style.equals("titlu")) P.setLetterSpacing(0.12f); break;
            default: P.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        }
    }

    public static synchronized void drawOne(Canvas c, Ov o, long T, int W, int H, boolean sel) {
        float u = (T - o.a) / 1000f, rem = (o.b - T) / 1000f;
        float k = Math.max(0, Math.min(1, u / 0.5f)), out = Math.max(0, Math.min(1, rem / 0.3f));
        float sc = 1, al = out, dx = 0, dy = 0;
        String txt = o.text == null ? "" : o.text;
        switch (o.anim) {
            case "pop": sc = Math.max(0.01f, easeBack(k)); al *= Math.min(1, k * 4); break;
            case "fade": al *= k; break;
            case "slide": dx = -(1 - easeOut(k)) * W * 0.6f; al *= Math.min(1, k * 2); break;
            case "bounce": dy = -(1 - easeBounce(k)) * H * 0.35f; al *= Math.min(1, k * 5); break;
            case "type": {
                int n = txt.codePointCount(0, txt.length());
                int show = (int) Math.ceil(n * Math.min(1, u / Math.max(0.4f, n * 0.07f)));
                txt = txt.substring(0, txt.offsetByCodePoints(0, Math.max(0, Math.min(n, show))));
                break;
            }
            case "zoom": sc = 2.2f - 1.2f * easeOut(k); al *= k; break;
        }
        al = Math.max(0, Math.min(1, al));
        float px = o.s * H * (o.emoji ? 0.2f : o.style.equals("subtitrare") ? 0.06f : 0.1f);
        float cx = o.x * W + dx, cy = o.y * H + dy;
        c.save();
        c.translate(cx, cy);
        if (o.rot != 0) c.rotate((float) Math.toDegrees(o.rot));
        c.scale(sc, sc);
        setFont(o, px);
        P.setTextAlign(Paint.Align.CENTER);
        P.clearShadowLayer();
        String[] ls = lines(o, txt);
        float lh = px * 1.12f, bw = 0;
        for (String l : ls) bw = Math.max(bw, P.measureText(l));
        float bh = ls.length * lh;
        int col = o.color;
        int A = Math.round(255 * al);
        Paint.FontMetrics fm = P.getFontMetrics();
        float mid = -(fm.ascent + fm.descent) / 2f; // centrare verticală
        if (o.emoji) {
            P.setColor(0xFF000000); P.setAlpha(A); P.setStyle(Paint.Style.FILL);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
        } else if (o.style.equals("subtitrare")) {
            for (int i = 0; i < ls.length; i++) {
                float y = (i - (ls.length - 1) / 2f) * lh;
                float w = P.measureText(ls[i]);
                P.setStyle(Paint.Style.FILL); P.setColor(0x9E000000); P.setAlpha(Math.round(0x9E * al));
                R.set(-w / 2 - px * 0.45f, y - lh / 2, w / 2 + px * 0.45f, y + lh / 2);
                c.drawRoundRect(R, px * 0.3f, px * 0.3f, P);
                P.setColor(col); P.setAlpha(A);
                c.drawText(ls[i], 0, y + mid + px * 0.04f, P);
            }
        } else if (o.style.equals("vlog")) {
            c.rotate((float) Math.toDegrees(-0.05));
            P.setStyle(Paint.Style.STROKE); P.setStrokeJoin(Paint.Join.ROUND); P.setStrokeWidth(px * 0.16f); P.setColor(0xFF111111); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            P.setStyle(Paint.Style.FILL); P.setColor(col); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            float tp = px * 0.3f;
            P.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); P.setTextSize(tp); P.setLetterSpacing(0.08f);
            float tw = P.measureText("● VLOG");
            P.setColor(0xFF111111); P.setAlpha(A);
            R.set(-bw / 2, -bh / 2 - tp * 1.5f, -bw / 2 + tw + tp, -bh / 2 - tp * 0.1f);
            c.drawRoundRect(R, tp * 0.5f, tp * 0.5f, P);
            P.setColor(0xFFFFFFFF); P.setAlpha(A); P.setTextAlign(Paint.Align.LEFT);
            c.drawText("● VLOG", -bw / 2 + tp / 2, -bh / 2 - tp * 0.8f + tp * 0.35f, P);
        } else if (o.style.equals("neon")) {
            int glow = col == 0xFFFFFFFF ? 0xFFFF3DF0 : col;
            P.setStyle(Paint.Style.FILL);
            P.setShadowLayer(px * 0.5f, 0, 0, (glow & 0x00FFFFFF) | (A << 24));
            P.setColor(0xFFFFFFFF); P.setAlpha(A);
            for (int r = 0; r < 3; r++) for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            P.clearShadowLayer();
        } else if (o.style.equals("galben")) {
            P.setStyle(Paint.Style.STROKE); P.setStrokeJoin(Paint.Join.ROUND); P.setStrokeWidth(px * 0.18f); P.setColor(0xFF000000); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            P.setStyle(Paint.Style.FILL); P.setColor(col == 0xFFFFFFFF ? 0xFFFFD21F : col); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
        } else if (o.style.equals("titlu")) {
            P.setStyle(Paint.Style.FILL);
            P.setShadowLayer(px * 0.25f, 0, 0, Math.round(0x8C * al) << 24);
            P.setColor(col); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            P.clearShadowLayer();
            P.setColor(0xFFFF6A2B); P.setAlpha(A);
            c.drawRect(-bw * 0.2f, bh / 2 + px * 0.12f, bw * 0.2f, bh / 2 + px * 0.12f + Math.max(2, px * 0.08f), P);
        } else {
            P.setStyle(Paint.Style.FILL);
            P.setShadowLayer(px * 0.2f, 0, px * 0.04f, Math.round(0x99 * al) << 24);
            P.setColor(col); P.setAlpha(A);
            for (int i = 0; i < ls.length; i++) c.drawText(ls[i], 0, (i - (ls.length - 1) / 2f) * lh + mid, P);
            P.clearShadowLayer();
        }
        P.setTextAlign(Paint.Align.LEFT);
        c.restore();
        if (sel) {
            float[] bb = box(o, W, H);
            c.save();
            c.translate(o.x * W, o.y * H);
            Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
            q.setStyle(Paint.Style.STROKE);
            q.setColor(0xF2FFFFFF);
            q.setStrokeWidth(Math.max(1.5f, H / 300f));
            q.setPathEffect(new android.graphics.DashPathEffect(new float[]{12, 10}, 0));
            c.drawRect(-bb[2] / 2, -bb[3] / 2, bb[2] / 2, bb[3] / 2, q);
            q.setPathEffect(null);
            q.setStyle(Paint.Style.FILL);
            q.setColor(0xFFFFFFFF);
            c.drawCircle(bb[2] / 2, bb[3] / 2, Math.max(8, H / 70f), q);
            c.restore();
        }
    }
}
