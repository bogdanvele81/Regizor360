package ro.director360.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_TREE = 11, REQ_PHONE = 12;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private final List<VideoItem> shown = new ArrayList<>();
    private List<VideoItem> cardList = new ArrayList<>(), phoneList = new ArrayList<>();
    private boolean cardMode = true;
    private Adapter adapter;
    private TextView status;
    private ProgressBar loading;
    private MaterialButton btnCard, btnPhone;
    private int newVersion = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        status = findViewById(R.id.status);
        loading = findViewById(R.id.loading);
        btnCard = findViewById(R.id.btnCard);
        btnPhone = findViewById(R.id.btnPhone);
        RecyclerView grid = findViewById(R.id.grid);
        int cols = getResources().getConfiguration().screenWidthDp > 600 ? 4 : 2;
        grid.setLayoutManager(new GridLayoutManager(this, cols));
        adapter = new Adapter();
        grid.setAdapter(adapter);

        btnCard.setOnClickListener(v -> {
            cardMode = true;
            styleTabs();
            String t = prefs.getString("tree", null);
            if (t == null) pickTree(); else if (cardList.isEmpty()) scanCard(); else show(cardList);
        });
        btnCard.setOnLongClickListener(v -> { pickTree(); return true; });
        btnPhone.setOnClickListener(v -> {
            if (!cardMode && !phoneList.isEmpty()) { pickPhone(); return; }
            cardMode = false;
            styleTabs();
            loadPhone();
            if (phoneList.isEmpty()) pickPhone(); else show(phoneList);
        });
        status.setOnClickListener(v -> { if (newVersion > 0) doUpdate(); });

        styleTabs();
        if (prefs.getString("tree", null) != null) scanCard();
        else status.setText("Apasă „Card” și alege folderul DCIM de pe cardul camerei. Sau „Telefon” pentru filmările din telefon.");

        Updater.check(this, v -> {
            if (v > Updater.current(this)) {
                newVersion = v;
                status.setText("⬆ Versiune nouă: 1." + v + " · apasă aici ca să actualizezi");
                status.setTextColor(0xFFFFD21F);
            }
        });
    }

    private void styleTabs() {
        btnCard.setAlpha(cardMode ? 1f : 0.55f);
        btnPhone.setAlpha(cardMode ? 0.55f : 1f);
    }

    private void pickTree() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { toast("Nu pot deschide alegerea folderului."); }
    }

    private void pickPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHONE); } catch (Exception e) { toast("Nu pot deschide galeria."); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_TREE && data.getData() != null) {
            Uri t = data.getData();
            try { getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            prefs.edit().putString("tree", t.toString()).apply();
            cardMode = true;
            styleTabs();
            scanCard();
        } else if (req == REQ_PHONE) {
            Set<String> set = new HashSet<>(prefs.getStringSet("phone", new HashSet<>()));
            List<Uri> got = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) got.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) got.add(data.getData());
            for (Uri u : got) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                set.add(u.toString());
            }
            prefs.edit().putStringSet("phone", set).apply();
            cardMode = false;
            styleTabs();
            loadPhone();
            show(phoneList);
        }
    }

    private void scanCard() {
        String t = prefs.getString("tree", null);
        if (t == null) return;
        loading.setVisibility(View.VISIBLE);
        status.setText("Citesc filmările de pe card…");
        final Uri tree = Uri.parse(t);
        bg.execute(() -> {
            List<VideoItem> l = Library.scanTree(this, tree);
            main.post(() -> {
                loading.setVisibility(View.GONE);
                cardList = l;
                if (l.isEmpty()) status.setText("Nu găsesc filmări. Verifică dacă cititorul cu cardul e conectat, apoi apasă „Card”. Ține apăsat pe „Card” ca să alegi alt folder.");
                else if (newVersion < 0) status.setText(l.size() + " filmări pe card · ține apăsat pe „Card” ca să alegi alt folder");
                if (cardMode) show(l);
            });
        });
    }

    private void loadPhone() {
        phoneList = new ArrayList<>();
        for (String s : prefs.getStringSet("phone", new HashSet<>())) phoneList.add(Library.fromPhone(this, Uri.parse(s)));
        if (newVersion < 0) status.setText(phoneList.size() + " filmări din telefon · apasă din nou „Telefon” ca să adaugi altele");
    }

    private void show(List<VideoItem> l) {
        shown.clear();
        shown.addAll(l);
        adapter.notifyDataSetChanged();
    }

    private void open(VideoItem it) {
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uri", it.uri.toString());
        if (it.lrv != null) i.putExtra("lrv", it.lrv.toString());
        i.putExtra("name", it.name);
        i.putExtra("key", it.key());
        startActivity(i);
    }

    private void doUpdate() {
        if (!Updater.start(this, newVersion)) {
            toast("Pornește „Permite din această sursă” pentru Director360, apoi revino și apasă din nou.");
            return;
        }
        loading.setVisibility(View.VISIBLE);
        final Runnable[] poll = new Runnable[1];
        poll[0] = () -> {
            int p = Updater.progress(this);
            if (p < 0) { loading.setVisibility(View.GONE); status.setText("Descărcarea nu a reușit. Apasă din nou."); return; }
            status.setText(p >= 100 ? "Apasă „Actualizează” în fereastra telefonului." : "Descarc actualizarea… " + p + "%");
            if (p >= 100) { loading.setVisibility(View.GONE); return; }
            main.postDelayed(poll[0], 500);
        };
        main.post(poll[0]);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    static String pretty(String name) {
        // VID_20260827_162848_00_643.mp4 -> 27.08.2026 · 16:28
        try {
            String[] p = name.split("_");
            for (int i = 0; i + 1 < p.length; i++) {
                if (p[i].length() == 8 && p[i].matches("\\d{8}") && p[i + 1].length() >= 6 && p[i + 1].substring(0, 6).matches("\\d{6}")) {
                    String d = p[i], t = p[i + 1];
                    return d.substring(6, 8) + "." + d.substring(4, 6) + "." + d.substring(0, 4) + " · " + t.substring(0, 2) + ":" + t.substring(2, 4);
                }
            }
        } catch (Exception ignored) { }
        return name;
    }

    static String fmtSize(long b) {
        if (b <= 0) return "";
        if (b > 1073741824L) return String.format(Locale.ROOT, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.ROOT, "%.0f MB", b / 1048576.0);
    }

    static String fmtDur(long ms) {
        if (ms < 0) return "⏱ …";
        if (ms == 0) return "";
        long s = ms / 1000;
        return String.format(Locale.ROOT, "⏱ %d:%02d", s / 60, s % 60);
    }

    class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        class VH extends RecyclerView.ViewHolder {
            final ImageView thumb; final TextView title, meta, tag;
            VH(View v) {
                super(v);
                thumb = v.findViewById(R.id.thumb);
                title = v.findViewById(R.id.title);
                meta = v.findViewById(R.id.meta);
                tag = v.findViewById(R.id.tag);
            }
        }

        @Override public VH onCreateViewHolder(ViewGroup p, int t) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_video, p, false));
        }

        @Override public void onBindViewHolder(VH h, int pos) {
            VideoItem it = shown.get(pos);
            h.title.setText(pretty(it.name));
            h.tag.setVisibility(it.is360() ? View.VISIBLE : View.GONE);
            h.meta.setText(fmtDur(it.durationMs) + "  ·  " + fmtSize(it.size));
            Thumbs.load(MainActivity.this, it, h.thumb);
            Thumbs.durationAsync(MainActivity.this, it, () -> {
                int p = shown.indexOf(it);
                if (p >= 0) notifyItemChanged(p);
            });
            h.itemView.setOnClickListener(v -> open(it));
        }

        @Override public int getItemCount() { return shown.size(); }
    }
}
