package ro.director360.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_TREE = 11, REQ_PHONE = 12;
    private static final int F_ALL = 0, F_VIDEO = 1, F_PHOTO = 2;
    private static final Object HEADER = new Object();
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private List<VideoItem> cardList = new ArrayList<>(), phoneList = new ArrayList<>();
    private boolean cardMode = true, bySize = false, scanning = false;
    private int filter = F_ALL;
    private Adapter adapter;
    private View header, selBar, splash, srcCard, libHead, emptyBox;
    private TextView status, stats, srcCardSub, dropTitle, dropSub;
    private ProgressBar loading;
    private com.google.android.material.button.MaterialButton selEdit;
    private final List<VideoItem> selected = new ArrayList<>();
    private final List<Object> rows = new ArrayList<>();
    private java.util.Map<String, long[]> headerSums = new java.util.HashMap<>();
    private int newVersion = -1;
    private final AlertDialogHolder help = new AlertDialogHolder();
    static class AlertDialogHolder { androidx.appcompat.app.AlertDialog d; TextView res; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        java.io.File cf = new java.io.File(getFilesDir(), "crash.txt");
        if (cf.exists() && !getIntent().getBooleanExtra("skipCrash", false)) {
            String err = "";
            try { err = new String(java.nio.file.Files.readAllBytes(cf.toPath()), "UTF-8"); } catch (Exception ignored) { }
            cf.delete();
            startActivity(new Intent(this, CrashActivity.class).putExtra("err", err));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        loading = findViewById(R.id.loading);
        selBar = findViewById(R.id.selBar);
        selEdit = findViewById(R.id.selEdit);
        splash = findViewById(R.id.splash);

        RecyclerView grid = findViewById(R.id.grid);
        header = LayoutInflater.from(this).inflate(R.layout.home_header, new android.widget.FrameLayout(this), false);
        status = header.findViewById(R.id.status);
        stats = header.findViewById(R.id.stats);
        srcCard = header.findViewById(R.id.srcCard);
        srcCardSub = header.findViewById(R.id.srcCardSub);
        libHead = header.findViewById(R.id.libHead);
        emptyBox = header.findViewById(R.id.emptyBox);
        dropTitle = header.findViewById(R.id.dropTitle);
        dropSub = header.findViewById(R.id.dropSub);
        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6A2B), 9, 12, 0);
        ((TextView) header.findViewById(R.id.brand)).setText(brand);
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { ver = "?"; }
        ((TextView) header.findViewById(R.id.verLine)).setText("Director360 · versiunea " + ver);

        final int cols = getResources().getConfiguration().screenWidthDp > 600 ? 4 : 2;
        GridLayoutManager glm = new GridLayoutManager(this, cols);
        glm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int pos) { return pos < rows.size() && !(rows.get(pos) instanceof VideoItem) ? cols : 1; }
        });
        grid.setLayoutManager(glm);
        adapter = new Adapter();
        grid.setAdapter(adapter);

        srcCard.setOnClickListener(v -> goCard());
        srcCard.setOnLongClickListener(v -> { pickTree(); return true; });
        header.findViewById(R.id.dropCard).setOnClickListener(v -> { cardMode = true; pickTree(); });
        header.findViewById(R.id.pickPhone).setOnClickListener(v -> pickPhone());
        View.OnClickListener soon = v -> new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(v.getId() == R.id.srcCam ? "Cameră (Wi-Fi)" : "Cloud")
                .setMessage(v.getId() == R.id.srcCam
                        ? "Citirea filmărilor direct din cameră prin Wi-Fi vine într-o versiune următoare. Până atunci folosește „Card” (cititor de card) sau „Telefon”."
                        : "Salvarea în cloud vine într-o versiune următoare. Până atunci ce salvezi ajunge în telefon, în albumul Director360.")
                .setPositiveButton("Am înțeles", null).show();
        header.findViewById(R.id.srcCam).setOnClickListener(soon);
        header.findViewById(R.id.srcCloud).setOnClickListener(soon);
        header.findViewById(R.id.sortDate).setOnClickListener(v -> { bySize = false; refresh(); });
        header.findViewById(R.id.sortSize).setOnClickListener(v -> { bySize = true; refresh(); });
        status.setOnClickListener(v -> { if (newVersion > 0) doUpdate(); });

        findViewById(R.id.navHome).setOnClickListener(v -> { filter = F_ALL; goCardOrCurrent(); });
        findViewById(R.id.navVideo).setOnClickListener(v -> { filter = F_VIDEO; refresh(); });
        findViewById(R.id.navPhoto).setOnClickListener(v -> { filter = F_PHOTO; refresh(); });
        findViewById(R.id.navPhone).setOnClickListener(v -> {
            if (!cardMode && !phoneList.isEmpty()) { pickPhone(); return; }
            cardMode = false;
            loadPhone();
            if (phoneList.isEmpty()) pickPhone(); else refresh();
        });
        findViewById(R.id.navHelp).setOnClickListener(v -> showHelp());
        findViewById(R.id.selCancel).setOnClickListener(v -> { if (!selected.isEmpty()) open(new ArrayList<>(selected), false); });
        selEdit.setOnClickListener(v -> { if (!selected.isEmpty()) open(new ArrayList<>(selected), true); });

        runSplash();
        startInsertAnim();
        if (prefs.getString("tree", null) != null) scanCard();
        refresh();

        if (getIntent().getBooleanExtra("ciTest", false)) { splash.setVisibility(View.GONE); ciTest(getIntent().getStringExtra("ciOpen")); }

        Updater.check(this, v -> {
            if (v > Updater.current(this)) {
                newVersion = v;
                status.setVisibility(View.VISIBLE);
                status.setText("⬆ Versiune nouă: 1." + v + " · apasă aici ca să actualizezi");
                status.setTextColor(0xFFFFD21F);
            }
        });
    }

    /** doar pentru proba automată de pe GitHub: fișiere de test din folderul aplicației */
    private void ciTest(String what) {
        java.io.File dir = getExternalFilesDir(null);
        java.io.File[] fs = dir == null ? null : dir.listFiles();
        phoneList = new ArrayList<>();
        java.util.Map<String, Uri> lrv = new java.util.HashMap<>();
        if (fs != null) for (java.io.File f : fs) if (f.getName().toLowerCase().endsWith(".lrv")) lrv.put(VideoItem.stem(f.getName()), Uri.fromFile(f));
        if (fs != null) for (java.io.File f : fs) {
            String low = f.getName().toLowerCase();
            if (!f.isFile() || !(low.endsWith(".mp4") || low.endsWith(".insv") || low.endsWith(".insp") || low.endsWith(".jpg"))) continue;
            VideoItem it = new VideoItem(Uri.fromFile(f), f.getName(), f.length(), f.lastModified());
            it.lrv = lrv.get(VideoItem.stem(f.getName()));
            phoneList.add(it);
        }
        cardMode = false;
        refresh();
        if (what == null) return;
        List<VideoItem> vids = new ArrayList<>();
        for (VideoItem it : phoneList) {
            if (what.equals("photo") && it.isPhoto() && !it.is360()) { openPhoto(it); return; }
            if (what.equals("photo360") && it.isPhoto() && it.is360()) { openPhoto(it); return; }
            if (what.equals("video") && !it.isPhoto()) vids.add(it);
        }
        if (!vids.isEmpty()) open(vids, false);
        if (what.equals("auto")) {
            List<VideoItem> v2 = new ArrayList<>();
            for (VideoItem it : phoneList) if (!it.isPhoto()) v2.add(it);
            if (!v2.isEmpty()) open(v2, true);
        }
        if (what.equals("select")) for (VideoItem it : phoneList) if (!it.isPhoto()) toggleSel(it);
    }

    private void startInsertAnim() {
        View sd = header.findViewById(R.id.sdAnim);
        float d = getResources().getDisplayMetrics().density;
        android.animation.ObjectAnimator a = android.animation.ObjectAnimator.ofFloat(sd, "translationY", -18 * d, 6 * d);
        a.setDuration(1200);
        a.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        a.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        a.start();
    }

    private void goCardOrCurrent() {
        if (!cardMode) { cardMode = true; }
        goCard();
    }

    private void goCard() {
        cardMode = true;
        String t = prefs.getString("tree", null);
        if (t == null) { refresh(); pickTree(); }
        else if (cardList.isEmpty() && !scanning) scanCard();
        else refresh();
    }

    private void runSplash() {
        ((SplashView) splash).setOnDone(() -> splash.setVisibility(View.GONE));
    }

    private void showHelp() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { ver = "?"; }
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pd = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pd, pd / 2, pd, 0);
        TextView t = new TextView(this);
        t.setTextColor(0xFFB9BCBF);
        t.setTextSize(15);
        t.setLineSpacing(0, 1.25f);
        t.setText("• Card: conectează cititorul cu cardul camerei și alege folderul DCIM (o singură dată). Ține apăsat pe „Card” ca să alegi alt folder.\n"
                + "• Telefon: alege filmări sau poze din memoria telefonului.\n• Filmări / Poze: arată doar filmările sau doar pozele.\n"
                + "• Atinge filmările pe care le vrei (se numerotează 1, 2, 3), apoi: „Gata” = montaj automat (aplicația alege cele mai vii momente), sau „Editez eu” = le pui tu una după alta. O poză se deschide cu o atingere.\n"
                + "• În editor: trage pe timeline ca să cauți; atinge un clip ca să-l tai de la margini, să-l muți sau să-l ștergi.\n"
                + "• Filmările 360 (marcate „360”) se pot roti cu degetul; dublu-atingere = Tiny Planet.\n\n"
                + "Versiune: " + ver);
        box.addView(t);
        TextView res = new TextView(this);
        res.setTextColor(0xFFFFD21F);
        res.setTextSize(15);
        res.setPadding(0, pd / 2, 0, 0);
        box.addView(res);
        help.res = res;
        help.d = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ajutor")
                .setView(box)
                .setNegativeButton("Închide", null)
                .setPositiveButton("Caută actualizări", null)
                .show();
        help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (newVersion > Updater.current(this)) { help.d.dismiss(); doUpdate(); return; }
            res.setText("Caut…");
            Updater.check(this, nv -> {
                if (nv > Updater.current(this)) {
                    newVersion = nv;
                    res.setText("Există versiunea nouă 1." + nv + ". Apasă din nou ca s-o instalezi.");
                    ((TextView) help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE)).setText("Actualizează");
                } else if (nv < 0) res.setText("Nu pot verifica acum. Verifică internetul.");
                else res.setText("Ai ultima versiune.");
            });
        });
    }

    private void clearSel() {
        selected.clear();
        if (selBar != null) selBar.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void toggleSel(VideoItem it) {
        if (selected.contains(it)) selected.remove(it); else selected.add(it);
        selBar.setVisibility(selected.isEmpty() ? View.GONE : View.VISIBLE);
        int nv = selected.size();
        ((TextView) findViewById(R.id.selCount)).setText((nv == 1 ? "1 filmare aleasă" : nv + " filmări alese") + ", în ordinea atinsă");
        selEdit.setText("Gata (" + nv + ")");
        LinearLayout th = findViewById(R.id.selThumbs);
        th.removeAllViews();
        float dd = getResources().getDisplayMetrics().density;
        for (int k = 0; k < selected.size(); k++) {
            VideoItem s = selected.get(k);
            android.widget.FrameLayout f = new android.widget.FrameLayout(this);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF262A2E);
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), 10 * dd); }
            });
            f.addView(iv, new android.widget.FrameLayout.LayoutParams((int) (72 * dd), (int) (50 * dd)));
            Thumbs.load(this, s, iv);
            TextView num = new TextView(this);
            num.setText(String.valueOf(k + 1));
            num.setTextColor(0xFFFFFFFF);
            num.setTextSize(12);
            num.setTypeface(null, android.graphics.Typeface.BOLD);
            num.setGravity(android.view.Gravity.CENTER);
            num.setBackgroundResource(R.drawable.check_bg);
            android.widget.FrameLayout.LayoutParams np = new android.widget.FrameLayout.LayoutParams((int) (22 * dd), (int) (22 * dd), android.view.Gravity.BOTTOM | android.view.Gravity.START);
            np.setMargins((int) (3 * dd), 0, 0, (int) (3 * dd));
            f.addView(num, np);
            TextView x = new TextView(this);
            x.setText("×");
            x.setTextColor(0xFF111315);
            x.setTextSize(14);
            x.setTypeface(null, android.graphics.Typeface.BOLD);
            x.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable xb = new android.graphics.drawable.GradientDrawable();
            xb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            xb.setColor(0xFFF2F2F0);
            x.setBackground(xb);
            android.widget.FrameLayout.LayoutParams xp = new android.widget.FrameLayout.LayoutParams((int) (22 * dd), (int) (22 * dd), android.view.Gravity.TOP | android.view.Gravity.END);
            f.addView(x, xp);
            f.setOnClickListener(v -> toggleSel(s));
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            fp.setMarginEnd((int) (10 * dd));
            th.addView(f, fp);
        }
        adapter.notifyDataSetChanged();
    }

    private void pickTree() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { toast("Nu pot deschide alegerea folderului."); }
    }

    private void pickPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHONE); } catch (Exception e) { toast("Nu pot deschide memoria telefonului."); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_TREE && data.getData() != null) {
            Uri t = data.getData();
            try { getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            prefs.edit().putString("tree", t.toString()).apply();
            cardMode = true;
            scanCard();
        } else if (req == REQ_PHONE) {
            Set<String> set = new HashSet<>(prefs.getStringSet("phone", new HashSet<>()));
            List<Uri> got = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) got.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) got.add(data.getData());
            for (Uri u : got) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                set.add(u.toString());
            }
            prefs.edit().putStringSet("phone", set).apply();
            cardMode = false;
            loadPhone();
            refresh();
        }
    }

    private void scanCard() {
        String t = prefs.getString("tree", null);
        if (t == null) return;
        scanning = true;
        loading.setVisibility(View.VISIBLE);
        srcCardSub.setText("citesc…");
        final Uri tree = Uri.parse(t);
        bg.execute(() -> {
            List<VideoItem> l = Library.scanTree(this, tree);
            main.post(() -> {
                scanning = false;
                loading.setVisibility(View.GONE);
                cardList = l;
                refresh();
            });
        });
    }

    private void loadPhone() {
        phoneList = new ArrayList<>();
        for (String s : prefs.getStringSet("phone", new HashSet<>())) phoneList.add(Library.fromPhone(this, Uri.parse(s)));
    }

    /** redesenează tot ecranul după sursă, filtru și sortare */
    private void refresh() {
        // Card
        boolean hasTree = prefs.getString("tree", null) != null;
        srcCard.setBackgroundResource(cardMode ? R.drawable.src_on : R.drawable.src_off);
        if (scanning) srcCardSub.setText("citesc…");
        else srcCardSub.setText(!hasTree ? "neconectat" : cardList.isEmpty() ? "nu găsesc cardul" : "conectat");
        // bara de jos
        int on = 0xFFFF6A2B, off = 0xFFB9BCBF;
        int[][] nav = {{R.id.navHomeIcon, R.id.navHomeText, F_ALL}, {R.id.navVideoIcon, R.id.navVideoText, F_VIDEO}, {R.id.navPhotoIcon, R.id.navPhotoText, F_PHOTO}};
        for (int[] n : nav) {
            boolean a = filter == n[2];
            ((ImageView) findViewById(n[0])).setImageTintList(ColorStateList.valueOf(a ? on : off));
            TextView tv = findViewById(n[1]);
            tv.setTextColor(a ? 0xFFF2F2F0 : off);
            tv.setTypeface(null, a ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
        header.findViewById(R.id.sortDate).setSelected(!bySize);
        header.findViewById(R.id.sortSize).setSelected(bySize);

        List<VideoItem> src = cardMode ? cardList : phoneList;
        int nVid = 0, nPh = 0;
        long tot = 0;
        for (VideoItem it : src) { if (it.isPhoto()) nPh++; else nVid++; tot += it.size; }
        List<VideoItem> l = new ArrayList<>();
        for (VideoItem it : src) {
            if (filter == F_VIDEO && it.isPhoto()) continue;
            if (filter == F_PHOTO && !it.isPhoto()) continue;
            l.add(it);
        }
        if (bySize) java.util.Collections.sort(l, (x, y) -> Long.compare(y.size, x.size));
        else java.util.Collections.sort(l, (x, y) -> y.name.compareTo(x.name));

        boolean empty = src.isEmpty();
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        libHead.setVisibility(empty ? View.GONE : View.VISIBLE);
        if (cardMode) {
            if (scanning) { dropTitle.setText("Citesc cardul…"); dropSub.setText("Durează câteva secunde"); }
            else if (hasTree) { dropTitle.setText("Nu găsesc cardul"); dropSub.setText("Conectează cititorul cu cardul și atinge aici. Ține apăsat pe „Card” ca să alegi alt folder."); }
            else { dropTitle.setText("Atinge ca să deschizi cardul"); dropSub.setText("Filmările și pozele apar aici, grupate pe zile"); }
        } else { dropTitle.setText("Nicio filmare din telefon"); dropSub.setText("Apasă butonul de mai jos ca să alegi"); }
        String sv = nVid == 1 ? "1 filmare" : nVid + " filmări", sp = nPh == 1 ? "1 poză" : nPh + " poze";
        stats.setText((cardMode ? "" : "Telefon   ") + sv + "   " + sp + "   " + fmtSize(tot));
        if (newVersion < 0) {
            boolean msg = !empty && l.isEmpty();
            status.setVisibility(msg ? View.VISIBLE : View.GONE);
            status.setTextColor(0xFFB9BCBF);
            if (msg) status.setText(filter == F_PHOTO ? "Nu sunt poze aici." : "Nu sunt filmări aici.");
        }

        rows.clear();
        rows.add(HEADER);
        java.util.Map<String, long[]> sums = new java.util.HashMap<>();
        for (VideoItem it : l) {
            String d = dayOf(it);
            long[] sm = sums.get(d);
            if (sm == null) { sm = new long[2]; sums.put(d, sm); }
            sm[0]++; sm[1] += it.size;
        }
        String last = null;
        for (VideoItem it : l) {
            String d = dayOf(it);
            if (!bySize && !d.equals(last)) { rows.add(d); last = d; }
            rows.add(it);
        }
        headerSums = sums;
        selected.retainAll(l);
        if (selected.isEmpty()) selBar.setVisibility(View.GONE);
        adapter.notifyDataSetChanged();
    }

    /** ziua filmării, din numele fișierului (VID_20260827_...) sau din data fișierului */
    static String dayOf(VideoItem it) {
        java.util.Date date = null;
        try {
            for (String p : it.name.split("_")) {
                if (p.length() == 8 && p.matches("\\d{8}")) { date = new java.text.SimpleDateFormat("yyyyMMdd", Locale.ROOT).parse(p); break; }
            }
        } catch (Exception ignored) { }
        if (date == null && it.modified > 0) date = new java.util.Date(it.modified);
        if (date == null) return "Fără dată";
        String s = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("ro")).format(date);
        return s.substring(0, 1).toUpperCase(new Locale("ro")) + s.substring(1);
    }

    private void open(List<VideoItem> l) { open(l, false); }

    private void open(List<VideoItem> l, boolean autoEdit) {
        List<VideoItem> vids = new ArrayList<>();
        for (VideoItem it : l) if (!it.isPhoto()) vids.add(it);
        if (vids.isEmpty()) return;
        int n = vids.size();
        String[] uris = new String[n], lrvs = new String[n], names = new String[n], keys = new String[n];
        for (int k = 0; k < n; k++) {
            VideoItem it = vids.get(k);
            uris[k] = it.uri.toString();
            lrvs[k] = it.lrv == null ? null : it.lrv.toString();
            names[k] = it.name;
            keys[k] = it.key();
        }
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", uris);
        i.putExtra("lrvs", lrvs);
        i.putExtra("names", names);
        i.putExtra("keys", keys);
        i.putExtra("auto", autoEdit);
        startActivity(i);
        clearSel();
    }

    private void openPhoto(VideoItem it) {
        Intent i = new Intent(this, PhotoActivity.class);
        i.putExtra("uri", it.uri.toString());
        i.putExtra("name", it.name);
        i.putExtra("is360", it.is360());
        startActivity(i);
    }

    private void doUpdate() {
        if (!Updater.start(this, newVersion)) {
            toast("Pornește „Permite din această sursă” pentru Director360, apoi revino și apasă din nou.");
            return;
        }
        loading.setVisibility(View.VISIBLE);
        final Runnable[] poll = new Runnable[1];
        poll[0] = () -> {
            int p = Updater.progress(this);
            status.setVisibility(View.VISIBLE);
            if (p < 0) { loading.setVisibility(View.GONE); status.setText("Descărcarea nu a reușit. Apasă din nou."); return; }
            status.setText(p >= 100 ? "Apasă „Actualizează” în fereastra telefonului." : "Descarc actualizarea… " + p + "%");
            if (p >= 100) { loading.setVisibility(View.GONE); return; }
            main.postDelayed(poll[0], 500);
        };
        main.post(poll[0]);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    static String pretty(String name) {
        // VID_20260827_162848_00_643.mp4 -> 27.08.2026 · 16:28
        try {
            String[] p = name.split("_");
            for (int i = 0; i + 1 < p.length; i++) {
                if (p[i].length() == 8 && p[i].matches("\\d{8}") && p[i + 1].length() >= 6 && p[i + 1].substring(0, 6).matches("\\d{6}")) {
                    String d = p[i], t = p[i + 1];
                    return d.substring(6, 8) + "." + d.substring(4, 6) + "." + d.substring(0, 4) + " · " + t.substring(0, 2) + ":" + t.substring(2, 4);
                }
            }
        } catch (Exception ignored) { }
        return name;
    }

    static String fmtSize(long b) {
        if (b <= 0) return "";
        if (b > 1073741824L) return String.format(Locale.ROOT, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.ROOT, "%.0f MB", b / 1048576.0);
    }

    static String fmtDur(long ms) {
        if (ms < 0) return "⏱ …";
        if (ms == 0) return "";
        long s = ms / 1000;
        return String.format(Locale.ROOT, "⏱ %d:%02d", s / 60, s % 60);
    }

    class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        class VH extends RecyclerView.ViewHolder {
            final ImageView thumb; final TextView title, meta, tag, selNum, dur; final View selRing;
            VH(View v) {
                super(v);
                thumb = v.findViewById(R.id.thumb);
                title = v.findViewById(R.id.title);
                meta = v.findViewById(R.id.meta);
                tag = v.findViewById(R.id.tag);
                dur = v.findViewById(R.id.dur);
                selNum = v.findViewById(R.id.selNum);
                selRing = v.findViewById(R.id.selRing);
            }
        }

        class HV extends RecyclerView.ViewHolder {
            final TextView t, m;
            HV(View v) { super(v); t = v.findViewById(R.id.hTitle); m = v.findViewById(R.id.hMeta); }
        }

        class TopVH extends RecyclerView.ViewHolder { TopVH(View v) { super(v); } }

        @Override public int getItemViewType(int pos) {
            Object o = rows.get(pos);
            return o == HEADER ? 2 : o instanceof String ? 1 : 0;
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
            LayoutInflater inf = LayoutInflater.from(p.getContext());
            if (t == 2) {
                if (header.getParent() instanceof ViewGroup) ((ViewGroup) header.getParent()).removeView(header);
                header.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                return new TopVH(header);
            }
            if (t == 1) return new HV(inf.inflate(R.layout.item_header, p, false));
            return new VH(inf.inflate(R.layout.item_video, p, false));
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder holder, int pos) {
            Object o = rows.get(pos);
            if (o == HEADER) return;
            if (o instanceof String) {
                HV h = (HV) holder;
                h.t.setText((String) o);
                long[] sm = headerSums.get(o);
                h.m.setText(sm == null ? "" : sm[0] + " · " + fmtSize(sm[1]));
                return;
            }
            VH h = (VH) holder;
            VideoItem it = (VideoItem) o;
            String pr = pretty(it.name);
            int dot = pr.indexOf(" · ");
            h.title.setText(dot > 0 ? pr.substring(dot + 3) : pr);
            h.tag.setVisibility(it.is360() ? View.VISIBLE : View.GONE);
            h.meta.setText(it.name + "  ·  " + fmtSize(it.size));
            if (!it.isPhoto() && it.durationMs > 0) {
                long s = it.durationMs / 1000;
                h.dur.setText(String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60));
                h.dur.setVisibility(View.VISIBLE);
            } else h.dur.setVisibility(View.GONE);
            Thumbs.load(MainActivity.this, it, h.thumb);
            Thumbs.durationAsync(MainActivity.this, it, () -> {
                int p = rows.indexOf(it);
                if (p >= 0) notifyItemChanged(p);
            });
            int si = selected.indexOf(it);
            h.selRing.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setText(String.valueOf(si + 1));
            h.itemView.setOnClickListener(v -> { if (it.isPhoto()) openPhoto(it); else toggleSel(it); });
            h.itemView.setOnLongClickListener(v -> { if (it.isPhoto()) openPhoto(it); else { List<VideoItem> one = new ArrayList<>(); one.add(it); open(one, false); } return true; });
        }

        @Override public int getItemCount() { return rows.size(); }
    }
}
