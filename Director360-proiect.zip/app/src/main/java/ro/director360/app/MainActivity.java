package ro.director360.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_TREE = 11, REQ_PHONE = 12;
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private final List<VideoItem> shown = new ArrayList<>();
    private List<VideoItem> cardList = new ArrayList<>(), phoneList = new ArrayList<>();
    private boolean cardMode = true;
    private Adapter adapter;
    private TextView status;
    private ProgressBar loading;
    private View srcCard, selBar, splash;
    private TextView srcCardSub, stats;
    private com.google.android.material.button.MaterialButton selEdit;
    private final List<VideoItem> selected = new ArrayList<>();
    private boolean bySize = false;
    private AlertDialogHolder help = new AlertDialogHolder();
    static class AlertDialogHolder { androidx.appcompat.app.AlertDialog d; TextView res; }
    private final List<Object> rows = new ArrayList<>();
    private int newVersion = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        status = findViewById(R.id.status);
        loading = findViewById(R.id.loading);
        srcCard = findViewById(R.id.srcCard);
        srcCardSub = findViewById(R.id.srcCardSub);
        selBar = findViewById(R.id.selBar);
        selEdit = findViewById(R.id.selEdit);
        splash = findViewById(R.id.splash);
        stats = findViewById(R.id.stats);
        android.text.SpannableString brand = new android.text.SpannableString("Director360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6A2B), 8, 11, 0);
        ((TextView) findViewById(R.id.brand)).setText(brand);
        RecyclerView grid = findViewById(R.id.grid);
        final int cols = getResources().getConfiguration().screenWidthDp > 600 ? 4 : 2;
        GridLayoutManager glm = new GridLayoutManager(this, cols);
        glm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int pos) { return pos < rows.size() && rows.get(pos) instanceof String ? cols : 1; }
        });
        grid.setLayoutManager(glm);
        adapter = new Adapter();
        grid.setAdapter(adapter);

        srcCard.setOnClickListener(v -> goCard());
        srcCard.setOnLongClickListener(v -> { pickTree(); return true; });
        findViewById(R.id.navHome).setOnClickListener(v -> goCard());
        findViewById(R.id.navPhone).setOnClickListener(v -> {
            if (!cardMode && !phoneList.isEmpty()) { pickPhone(); return; }
            cardMode = false;
            styleTabs();
            loadPhone();
            if (phoneList.isEmpty()) pickPhone(); else show(phoneList);
        });
        findViewById(R.id.navHelp).setOnClickListener(v -> showHelp());
        View.OnClickListener soon = v -> new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(v.getId() == R.id.srcCam ? "Cameră (Wi-Fi)" : "Cloud")
                .setMessage(v.getId() == R.id.srcCam
                        ? "Citirea filmărilor direct din cameră prin Wi-Fi vine într-o versiune următoare. Până atunci folosește „Card” (cititor de card) sau „Telefon”."
                        : "Salvarea în cloud vine într-o versiune următoare. Până atunci filmările editate se salvează în telefon, în Filme › Director360.")
                .setPositiveButton("Am înțeles", null).show();
        findViewById(R.id.srcCam).setOnClickListener(soon);
        findViewById(R.id.srcCloud).setOnClickListener(soon);
        ((com.google.android.material.chip.ChipGroup) findViewById(R.id.sortGroup)).setOnCheckedStateChangeListener((g, ids) -> {
            bySize = ids.contains(R.id.sortSize);
            show(new ArrayList<>(shown));
        });
        findViewById(R.id.selCancel).setOnClickListener(v -> clearSel());
        selEdit.setOnClickListener(v -> { if (!selected.isEmpty()) open(new ArrayList<>(selected)); });
        status.setOnClickListener(v -> { if (newVersion > 0) doUpdate(); });
        runSplash();

        styleTabs();
        if (prefs.getString("tree", null) != null) scanCard();
        else status.setText("Apasă „Card” și alege folderul DCIM de pe cardul camerei. Sau „Telefon” pentru filmările din telefon.");

        Updater.check(this, v -> {
            if (v > Updater.current(this)) {
                newVersion = v;
                status.setText("⬆ Versiune nouă: 1." + v + " · apasă aici ca să actualizezi");
                status.setTextColor(0xFFFFD21F);
            }
        });
    }

    private void goCard() {
        cardMode = true;
        styleTabs();
        String t = prefs.getString("tree", null);
        if (t == null) pickTree(); else if (cardList.isEmpty()) scanCard(); else show(cardList);
    }

    private void styleTabs() {
        srcCard.setSelected(cardMode);
        clearSel();
    }

    private void runSplash() {
        View logo = findViewById(R.id.splashLogo);
        TextView name = findViewById(R.id.splashName);
        View tag = findViewById(R.id.splashTag);
        logo.setScaleX(0.3f); logo.setScaleY(0.3f); logo.setAlpha(0f); logo.setRotation(-120f);
        tag.setAlpha(0f);
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).rotation(0f).setDuration(700)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
        final String full = "Director360";
        for (int i = 1; i <= full.length(); i++) {
            final int n = i;
            main.postDelayed(() -> {
                android.text.SpannableString sp = new android.text.SpannableString(full.substring(0, n));
                if (n > 8) sp.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6A2B), 8, n, 0);
                name.setText(sp);
            }, 450 + i * 55L);
        }
        tag.animate().alpha(1f).setStartDelay(1100).setDuration(400).start();
        main.postDelayed(() -> splash.animate().alpha(0f).setDuration(350)
                .withEndAction(() -> splash.setVisibility(View.GONE)).start(), 1900);
    }

    private void showHelp() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { ver = "?"; }
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pd = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pd, pd / 2, pd, 0);
        TextView t = new TextView(this);
        t.setTextColor(0xFFB9BCBF);
        t.setTextSize(15);
        t.setLineSpacing(0, 1.25f);
        t.setText("• Card: conectează cititorul cu cardul camerei și alege folderul DCIM (o singură dată). Ține apăsat pe „Card” ca să alegi alt folder.\n"
                + "• Telefon: alege filmări din galeria telefonului.\n"
                + "• Atinge o filmare ca s-o editezi. Ține apăsat ca să alegi mai multe, apoi „Editează” — se pun una după alta, numerotate 1, 2, 3.\n"
                + "• În editor: trage pe timeline ca să cauți; atinge un clip ca să-l tai de la margini, să-l muți sau să-l ștergi.\n"
                + "• Filmările 360 (marcate „360”) se pot roti cu degetul; dublu-atingere = Tiny Planet.\n\n"
                + "Versiune: " + ver);
        box.addView(t);
        TextView res = new TextView(this);
        res.setTextColor(0xFFFFD21F);
        res.setTextSize(15);
        res.setPadding(0, pd / 2, 0, 0);
        box.addView(res);
        help.res = res;
        help.d = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ajutor")
                .setView(box)
                .setNegativeButton("Închide", null)
                .setPositiveButton("Caută actualizări", null)
                .show();
        help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (newVersion > Updater.current(this)) { help.d.dismiss(); doUpdate(); return; }
            res.setText("Caut…");
            Updater.check(this, nv -> {
                if (nv > Updater.current(this)) {
                    newVersion = nv;
                    res.setText("Există versiunea nouă 1." + nv + ". Apasă din nou ca s-o instalezi.");
                    ((TextView) help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE)).setText("Actualizează");
                } else if (nv < 0) res.setText("Nu pot verifica acum. Verifică internetul.");
                else res.setText("Ai ultima versiune.");
            });
        });
    }

    private void clearSel() {
        selected.clear();
        if (selBar != null) selBar.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void toggleSel(VideoItem it) {
        if (selected.contains(it)) selected.remove(it); else selected.add(it);
        selBar.setVisibility(selected.isEmpty() ? View.GONE : View.VISIBLE);
        selEdit.setText(selected.size() == 1 ? "Editează 1 filmare" : "Editează " + selected.size() + " filmări");
        adapter.notifyDataSetChanged();
    }

    private void pickTree() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { toast("Nu pot deschide alegerea folderului."); }
    }

    private void pickPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHONE); } catch (Exception e) { toast("Nu pot deschide galeria."); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_TREE && data.getData() != null) {
            Uri t = data.getData();
            try { getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            prefs.edit().putString("tree", t.toString()).apply();
            cardMode = true;
            styleTabs();
            scanCard();
        } else if (req == REQ_PHONE) {
            Set<String> set = new HashSet<>(prefs.getStringSet("phone", new HashSet<>()));
            List<Uri> got = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) got.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) got.add(data.getData());
            for (Uri u : got) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                set.add(u.toString());
            }
            prefs.edit().putStringSet("phone", set).apply();
            cardMode = false;
            styleTabs();
            loadPhone();
            show(phoneList);
        }
    }

    private void scanCard() {
        String t = prefs.getString("tree", null);
        if (t == null) return;
        loading.setVisibility(View.VISIBLE);
        status.setText("Citesc filmările de pe card…");
        final Uri tree = Uri.parse(t);
        bg.execute(() -> {
            List<VideoItem> l = Library.scanTree(this, tree);
            main.post(() -> {
                loading.setVisibility(View.GONE);
                cardList = l;
                srcCardSub.setText(l.isEmpty() ? "nu găsesc cardul" : "conectat · " + l.size());
                if (l.isEmpty()) status.setText("Nu găsesc filmări. Verifică dacă cititorul cu cardul e conectat, apoi apasă „Card”. Ține apăsat pe „Card” ca să alegi alt folder.");
                else if (newVersion < 0) status.setText("");
                if (cardMode) show(l);
            });
        });
    }

    private void loadPhone() {
        phoneList = new ArrayList<>();
        for (String s : prefs.getStringSet("phone", new HashSet<>())) phoneList.add(Library.fromPhone(this, Uri.parse(s)));
        if (newVersion < 0) status.setText(phoneList.isEmpty() ? "" : "Filmări din telefon. Apasă din nou „Telefon” ca să adaugi altele.");
    }

    private void show(List<VideoItem> l) {
        l = new ArrayList<>(l);
        if (bySize) java.util.Collections.sort(l, (x, y) -> Long.compare(y.size, x.size));
        else java.util.Collections.sort(l, (x, y) -> y.name.compareTo(x.name));
        shown.clear();
        shown.addAll(l);
        rows.clear();
        long tot = 0;
        String last = null;
        java.util.Map<String, long[]> sums = new java.util.HashMap<>();
        for (VideoItem it : l) {
            String d = dayOf(it);
            long[] sm = sums.get(d);
            if (sm == null) { sm = new long[2]; sums.put(d, sm); }
            sm[0]++; sm[1] += it.size;
        }
        for (VideoItem it : l) {
            String d = dayOf(it);
            if (!bySize && !d.equals(last)) { rows.add(d); last = d; }
            rows.add(it);
            tot += it.size;
        }
        headerSums = sums;
        stats.setText(l.isEmpty() ? "" : l.size() + " filmări   " + fmtSize(tot));
        adapter.notifyDataSetChanged();
    }

    private java.util.Map<String, long[]> headerSums = new java.util.HashMap<>();

    /** ziua filmării, din numele fișierului (VID_20260827_...) sau din data fișierului */
    static String dayOf(VideoItem it) {
        java.util.Date date = null;
        try {
            for (String p : it.name.split("_")) {
                if (p.length() == 8 && p.matches("\\d{8}")) { date = new java.text.SimpleDateFormat("yyyyMMdd", Locale.ROOT).parse(p); break; }
            }
        } catch (Exception ignored) { }
        if (date == null && it.modified > 0) date = new java.util.Date(it.modified);
        if (date == null) return "Fără dată";
        String s = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("ro")).format(date);
        return s.substring(0, 1).toUpperCase(new Locale("ro")) + s.substring(1);
    }

    private void open(List<VideoItem> l) {
        int n = l.size();
        String[] uris = new String[n], lrvs = new String[n], names = new String[n], keys = new String[n];
        for (int k = 0; k < n; k++) {
            VideoItem it = l.get(k);
            uris[k] = it.uri.toString();
            lrvs[k] = it.lrv == null ? null : it.lrv.toString();
            names[k] = it.name;
            keys[k] = it.key();
        }
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", uris);
        i.putExtra("lrvs", lrvs);
        i.putExtra("names", names);
        i.putExtra("keys", keys);
        startActivity(i);
        clearSel();
    }

    private void doUpdate() {
        if (!Updater.start(this, newVersion)) {
            toast("Pornește „Permite din această sursă” pentru Director360, apoi revino și apasă din nou.");
            return;
        }
        loading.setVisibility(View.VISIBLE);
        final Runnable[] poll = new Runnable[1];
        poll[0] = () -> {
            int p = Updater.progress(this);
            if (p < 0) { loading.setVisibility(View.GONE); status.setText("Descărcarea nu a reușit. Apasă din nou."); return; }
            status.setText(p >= 100 ? "Apasă „Actualizează” în fereastra telefonului." : "Descarc actualizarea… " + p + "%");
            if (p >= 100) { loading.setVisibility(View.GONE); return; }
            main.postDelayed(poll[0], 500);
        };
        main.post(poll[0]);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    static String pretty(String name) {
        // VID_20260827_162848_00_643.mp4 -> 27.08.2026 · 16:28
        try {
            String[] p = name.split("_");
            for (int i = 0; i + 1 < p.length; i++) {
                if (p[i].length() == 8 && p[i].matches("\\d{8}") && p[i + 1].length() >= 6 && p[i + 1].substring(0, 6).matches("\\d{6}")) {
                    String d = p[i], t = p[i + 1];
                    return d.substring(6, 8) + "." + d.substring(4, 6) + "." + d.substring(0, 4) + " · " + t.substring(0, 2) + ":" + t.substring(2, 4);
                }
            }
        } catch (Exception ignored) { }
        return name;
    }

    static String fmtSize(long b) {
        if (b <= 0) return "";
        if (b > 1073741824L) return String.format(Locale.ROOT, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.ROOT, "%.0f MB", b / 1048576.0);
    }

    static String fmtDur(long ms) {
        if (ms < 0) return "⏱ …";
        if (ms == 0) return "";
        long s = ms / 1000;
        return String.format(Locale.ROOT, "⏱ %d:%02d", s / 60, s % 60);
    }

    class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        class VH extends RecyclerView.ViewHolder {
            final ImageView thumb; final TextView title, meta, tag, selNum; final View selRing;
            VH(View v) {
                super(v);
                thumb = v.findViewById(R.id.thumb);
                title = v.findViewById(R.id.title);
                meta = v.findViewById(R.id.meta);
                tag = v.findViewById(R.id.tag);
                selNum = v.findViewById(R.id.selNum);
                selRing = v.findViewById(R.id.selRing);
            }
        }

        class HV extends RecyclerView.ViewHolder {
            final TextView t, m;
            HV(View v) { super(v); t = v.findViewById(R.id.hTitle); m = v.findViewById(R.id.hMeta); }
        }

        @Override public int getItemViewType(int pos) { return rows.get(pos) instanceof String ? 1 : 0; }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
            LayoutInflater inf = LayoutInflater.from(p.getContext());
            if (t == 1) return new HV(inf.inflate(R.layout.item_header, p, false));
            return new VH(inf.inflate(R.layout.item_video, p, false));
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder holder, int pos) {
            Object o = rows.get(pos);
            if (o instanceof String) {
                HV h = (HV) holder;
                h.t.setText((String) o);
                long[] sm = headerSums.get(o);
                h.m.setText(sm == null ? "" : sm[0] + " · " + fmtSize(sm[1]));
                return;
            }
            VH h = (VH) holder;
            VideoItem it = (VideoItem) o;
            String pr = pretty(it.name);
            int dot = pr.indexOf(" · ");
            h.title.setText(dot > 0 ? pr.substring(dot + 3) : pr);
            h.tag.setVisibility(it.is360() ? View.VISIBLE : View.GONE);
            h.meta.setText(fmtDur(it.durationMs) + "  ·  " + fmtSize(it.size));
            Thumbs.load(MainActivity.this, it, h.thumb);
            Thumbs.durationAsync(MainActivity.this, it, () -> {
                int p = rows.indexOf(it);
                if (p >= 0) notifyItemChanged(p);
            });
            int si = selected.indexOf(it);
            h.selRing.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setText(String.valueOf(si + 1));
            h.itemView.setOnClickListener(v -> {
                if (!selected.isEmpty()) toggleSel(it);
                else { List<VideoItem> one = new ArrayList<>(); one.add(it); open(one); }
            });
            h.itemView.setOnLongClickListener(v -> { toggleSel(it); return true; });
        }

        @Override public int getItemCount() { return rows.size(); }
    }
}
