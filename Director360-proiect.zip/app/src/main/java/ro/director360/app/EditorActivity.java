package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline.Window;
import androidx.media3.common.VideoSize;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.Presentation;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Editorul ca la Insta360: imaginea sus, banda cu filmele jos, butonul galben de salvare. */
public class EditorActivity extends AppCompatActivity {

    /** o filmare din montaj */
    static class Clip {
        Uri uri, prev;
        String name, key;
        boolean is360;
        float[] view = {0f, 0f, 80f, 0f};
        final Timeline.Clip t = new Timeline.Clip();
        boolean durKnown = false;
    }

    /** o filmare aleasă (sursa), pentru montajul automat */
    static class Src {
        Uri uri, prev;
        String name, key;
        boolean is360;
        long dur = 0;
        float[] score;
        Bitmap[] frames = new Bitmap[0];
    }

    private final List<Clip> clips = new ArrayList<>();
    private final List<Src> srcs = new ArrayList<>();
    private boolean auto = false, analyzing = false;
    private String autoDur = "30", autoStyle = "normal", filt = "none";
    private int filtK = 70, musicVol = 80;
    private boolean origSound = true;
    private Uri music;
    private String musicName;
    private ExoPlayer musicPlayer;
    private String openTool = null;
    private static final int REQ_MUSIC = 31;
    private ExoPlayer player;
    private Video360View view;
    private AspectFrame stage;
    private Timeline timeline;
    private TextView time, hint;
    private MaterialButton btnPlay, btnFormat;
    private MaterialButtonToggleGroup modeGroup;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences edits, prefs;
    private Transformer transformer;
    private AlertDialog progressDlg;
    private TextView progressText;
    private int curIdx = -1;
    private float videoAspect = 16f / 9f;
    private String format = "16:9";

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null && !clips.isEmpty()) {
                int i = player.getCurrentMediaItemIndex();
                long g = timeline.startOf(i) + Math.max(0, player.getCurrentPosition());
                timeline.setPos(g);
                time.setText(fmt(timeline.getPos()) + " / " + fmt(timeline.total()));
                if (i != curIdx) onClipChanged(i);
                if (!auto) fillDurations();
                syncMusic(g);
            }
            main.postDelayed(this, 60);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        String[] uris = getIntent().getStringArrayExtra("uris");
        String[] lrvs = getIntent().getStringArrayExtra("lrvs");
        String[] names = getIntent().getStringArrayExtra("names");
        String[] keys = getIntent().getStringArrayExtra("keys");
        if (uris == null || uris.length == 0) { finish(); return; }
        auto = getIntent().getBooleanExtra("auto", false);
        for (int i = 0; i < uris.length; i++) {
            Src sr = new Src();
            sr.uri = Uri.parse(uris[i]);
            sr.name = names[i];
            sr.key = keys[i];
            sr.prev = (lrvs != null && lrvs[i] != null && !lrvs[i].isEmpty()) ? Uri.parse(lrvs[i]) : sr.uri;
            String low = sr.name.toLowerCase();
            sr.is360 = low.endsWith(".insv") && sr.prev != sr.uri;
            srcs.add(sr);
        }
        for (int i = 0; i < uris.length && !auto; i++) {
            Clip c = new Clip();
            c.uri = Uri.parse(uris[i]);
            c.name = names[i];
            c.key = keys[i];
            c.is360 = c.name.toLowerCase().endsWith(".insv");
            c.prev = (lrvs != null && lrvs[i] != null && !lrvs[i].isEmpty()) ? Uri.parse(lrvs[i]) : c.uri;
            if (c.is360 && c.prev == c.uri) c.is360 = false; // fără fișierul mic nu pot afișa 360
            String sv = edits.getString(c.key + ":view", null);
            if (sv != null) try { String[] q = sv.split(","); c.view = new float[]{Float.parseFloat(q[0]), Float.parseFloat(q[1]), Float.parseFloat(q[2]), q[3].equals("1") ? 1f : 0f}; } catch (Exception ignored) { }
            clips.add(c);
        }

        stage = findViewById(R.id.stage);
        timeline = findViewById(R.id.timeline);
        time = findViewById(R.id.time);
        hint = findViewById(R.id.hint);
        btnPlay = findViewById(R.id.btnPlay);
        btnFormat = findViewById(R.id.btnFormat);
        modeGroup = findViewById(R.id.modeGroup);

        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        player = new ExoPlayer.Builder(this).build();
        view.setOnSurface(s -> { if (player != null) player.setVideoSurface(s); });
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { btnPlay.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play); }
            @Override public void onVideoSizeChanged(VideoSize v) {
                if (v.width > 0 && v.height > 0) {
                    videoAspect = v.width * v.pixelWidthHeightRatio / v.height;
                    Clip c = cur();
                    view.setFlat(c == null || !c.is360, videoAspect);
                    applyFormat();
                }
            }
            @Override public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_ENDED) { player.pause(); player.seekTo(0, 0); }
            }
        });

        format = prefs.getString("format", "16:9");
        btnFormat.setOnClickListener(v -> chooseFormat());
        modeGroup.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked) return;
            Clip c = cur();
            if (c == null || !c.is360) return;
            boolean planet = id == R.id.mPlanet;
            if (planet != view.isPlanet()) view.setPlanet(planet);
            saveView(c);
        });
        findViewById(R.id.btnLevel).setOnClickListener(v -> { view.resetView(); modeGroup.check(R.id.mCustom); Clip c = cur(); if (c != null) saveView(c); });
        btnPlay.setOnClickListener(v -> { if (player.isPlaying()) player.pause(); else { if (timeline.getPos() >= timeline.total() - 150) seekGlobal(0); player.play(); } });
        findViewById(R.id.btnStart).setOnClickListener(v -> { player.pause(); seekGlobal(0); });
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> askSave());
        findViewById(R.id.tLeft).setOnClickListener(v -> moveSel(-1));
        findViewById(R.id.tRight).setOnClickListener(v -> moveSel(1));
        findViewById(R.id.tDel).setOnClickListener(v -> deleteSel());

        timeline.setListener(new Timeline.Listener() {
            @Override public void onScrub(long g, boolean done) { if (player.isPlaying()) player.pause(); seekGlobal(g); }
            @Override public void onSelect(int i) { showTools(i >= 0); if (i >= 0) seekGlobal(timeline.startOf(i) + 50); }
            @Override public void onTrim(int i, boolean left, boolean done) {
                if (player.isPlaying()) player.pause();
                Clip c = clips.get(i);
                if (done) {
                    if (!auto) edits.edit().putString(c.key, c.t.in + "," + c.t.out).apply();
                    rebuildPlayer(timeline.startOf(i) + (left ? 0 : c.t.len() - 300));
                } else {
                    // arată cadrul de la capătul tras
                    if (player.getCurrentMediaItemIndex() == i) {
                        long local = left ? 0 : Math.max(0, c.t.len() - 50);
                        player.seekTo(i, local);
                    }
                }
            }
        });

        findViewById(R.id.autoApply).setOnClickListener(v -> { v.setVisibility(View.GONE); rebuildAuto(); });
        if (auto) {
            findViewById(R.id.autoBox).setVisibility(View.VISIBLE);
            findViewById(R.id.tools).setVisibility(View.GONE);
            buildAutoTools();
            musicPlayer = new ExoPlayer.Builder(this).build();
            musicPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
            hint.setText("Analizez scenele… caut cele mai vii momente din fiecare filmare");
            analyzing = true;
            new Thread(this::analyze).start();
            main.post(tick);
            return;
        }

        // durate și poze pentru bandă, pe un fir separat
        for (Clip c : clips) {
            String s = edits.getString(c.key, null);
            if (s != null) try { String[] p = s.split(","); c.t.in = Long.parseLong(p[0]); c.t.out = Long.parseLong(p[1]); } catch (Exception ignored) { }
        }
        timeline.setClips(timelineClips());
        new Thread(this::loadInfo).start();
        hint.setText(clips.size() > 1 ? "Tragi banda ca să mergi prin filme. Atinge o filmare ca s-o tai din capete sau s-o muți." : "Tragi banda ca să mergi prin film. Atinge filmarea ca s-o tai din capete.");
        rebuildPlayer(0);
        main.post(tick);
    }

    private List<Timeline.Clip> timelineClips() { List<Timeline.Clip> l = new ArrayList<>(); for (Clip c : clips) l.add(c.t); return l; }

    private Clip cur() { return curIdx >= 0 && curIdx < clips.size() ? clips.get(curIdx) : null; }

    private void loadInfo() {
        for (Clip c : clips) {
            long d = Thumbs.duration(this, c.prev);
            if (d <= 0) d = Thumbs.duration(this, c.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, c.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, c.uri);
            if (d > 0) {
                final long dd = d;
                main.post(() -> setDur(c, dd));
            }
        }
        for (Clip c : clips) {
            long d = c.t.dur;
            for (int w = 0; w < 50 && !c.durKnown && !isFinishing(); w++) { try { Thread.sleep(200); } catch (InterruptedException ignored) { } d = c.t.dur; }
            int n = (int) Math.max(4, Math.min(40, d / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * d * 1000);
                    if (c.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                    if (i % 4 == 3 || i == n - 1) { final Bitmap[] cp = frames.clone(); main.post(() -> { c.t.frames = cp; timeline.invalidate(); }); }
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
    }

    private void setDur(Clip c, long d) {
        if (c.durKnown || d <= 0) return;
        c.durKnown = true;
        c.t.dur = d;
        if (c.t.out <= 1 || c.t.out > d) c.t.out = d;
        if (c.t.in >= c.t.out) c.t.in = 0;
        timeline.invalidate();
    }

    /** dacă telefonul n-a dat durata, o iau de la player */
    private void fillDurations() {
        androidx.media3.common.Timeline tl = player.getCurrentTimeline();
        if (tl.isEmpty()) return;
        boolean any = false;
        for (int i = 0; i < clips.size() && i < tl.getWindowCount(); i++) {
            Clip c = clips.get(i);
            if (c.durKnown) continue;
            Window w = tl.getWindow(i, new Window());
            if (w.durationUs != C.TIME_UNSET && w.durationUs > 0) {
                long full = c.t.in + w.durationUs / 1000; // fereastra e deja tăiată la început
                setDur(c, full);
                any = true;
            }
        }
        if (any) timeline.invalidate();
    }

    private void rebuildPlayer(long globalPos) {
        List<MediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            items.add(new MediaItem.Builder().setUri(c.prev).setClippingConfiguration(cb.build()).build());
        }
        int idx = timeline.indexAt(globalPos);
        long local = Math.max(0, globalPos - timeline.startOf(idx));
        player.setMediaItems(items, idx, local);
        player.prepare();
    }

    private void seekGlobal(long g) {
        int i = timeline.indexAt(g);
        player.seekTo(i, Math.max(0, g - timeline.startOf(i)));
    }

    private void onClipChanged(int i) {
        Clip old = cur();
        if (old != null && old.is360) saveView(old);
        curIdx = i;
        Clip c = cur();
        if (c == null) return;
        findViewById(R.id.modes).setVisibility(c.is360 ? View.VISIBLE : View.GONE);
        view.setFlat(!c.is360, videoAspect);
        if (c.is360) {
            view.setView(c.view[0], c.view[1], c.view[2], c.view[3] > 0);
            modeGroup.check(c.view[3] > 0 ? R.id.mPlanet : R.id.mCustom);
        }
        applyFormat();
    }

    private void saveView(Clip c) {
        if (curIdx < 0 || clips.get(curIdx) != c) return;
        c.view = view.getView();
        if (auto) return;
        edits.edit().putString(c.key + ":view", c.view[0] + "," + c.view[1] + "," + c.view[2] + "," + (c.view[3] > 0 ? "1" : "0")).apply();
    }

    private float formatRatio() {
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "orig": return videoAspect;
            default: return 16f / 9f;
        }
    }

    private void applyFormat() {
        btnFormat.setText((format.equals("orig") ? "Original" : format) + " ▾");
        stage.setRatio(formatRatio());
    }

    private void chooseFormat() {
        final String[] ids = {"16:9", "9:16", "1:1", "orig"};
        String[] labels = {"16:9 · YouTube, TV", "9:16 · Reels, TikTok", "1:1 · pătrat", "Original"};
        new AlertDialog.Builder(this).setTitle("Format").setItems(labels, (d, w) -> {
            format = ids[w];
            prefs.edit().putString("format", format).apply();
            applyFormat();
        }).show();
    }

    // ---------------- montaj automat ----------------

    private void analyze() {
        int n = srcs.size();
        for (int i = 0; i < n && !isFinishing(); i++) {
            Src sr = srcs.get(i);
            final int pct = Math.round(i * 60f / n);
            main.post(() -> hint.setText("Analizez scenele " + pct + "% · Video " + (srcs.indexOf(sr) + 1) + " din " + n));
            long d = Thumbs.duration(this, sr.prev);
            if (d <= 0) d = Thumbs.duration(this, sr.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.uri);
            sr.dur = Math.max(0, d);
            sr.score = liveScore(sr, i, n);
        }
        main.post(() -> {
            analyzing = false;
            rebuildAuto();
            new Thread(this::loadSrcFrames).start();
        });
    }

    /** cât de „viu” e fiecare secundă: cât se schimbă imaginea + cât de colorată e */
    private float[] liveScore(Src sr, int idx, int n) {
        int secs = (int) Math.max(1, Math.ceil(sr.dur / 1000.0));
        float[] sc = new float[secs];
        java.util.Arrays.fill(sc, 1f);
        if (sr.dur <= 0) return sc;
        long step = Math.max(1000, sr.dur / 90);
        int samples = (int) Math.max(1, sr.dur / step);
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, sr.prev);
            int[] prev = null;
            float[] val = new float[samples];
            for (int k = 0; k < samples && !isFinishing(); k++) {
                long at = k * step + step / 2;
                Bitmap b = r.getScaledFrameAtTime(at * 1000, MediaMetadataRetriever.OPTION_CLOSEST, 64, 32);
                if (b == null) continue;
                int w = b.getWidth(), h = b.getHeight();
                int[] px = new int[w * h];
                b.getPixels(px, 0, w, 0, 0, w, h);
                b.recycle();
                float diff = 0, col = 0;
                for (int j = 0; j < px.length; j++) {
                    int c = px[j], rr = (c >> 16) & 255, gg = (c >> 8) & 255, bb = c & 255;
                    int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
                    col += mx - mn;
                    if (prev != null && prev.length == px.length) {
                        int p = prev[j];
                        diff += Math.abs(((p >> 16) & 255) - rr) + Math.abs(((p >> 8) & 255) - gg) + Math.abs((p & 255) - bb);
                    }
                }
                val[k] = (prev == null ? 0 : diff / px.length / 3f) + 0.25f * col / px.length;
                prev = px;
                if (k % 8 == 0) {
                    final int pct = Math.round((idx + k / (float) samples) * 60f / n);
                    main.post(() -> hint.setText("Analizez scenele " + pct + "% · Video " + (idx + 1) + " din " + n));
                }
            }
            if (samples > 1) val[0] = val[1];
            for (int s2 = 0; s2 < secs; s2++) {
                int k = (int) Math.min(samples - 1, (s2 * 1000L) / step);
                sc[s2] = 1 + val[k];
            }
        } catch (Throwable ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        return sc;
    }

    /** alege k bucăți de câte S secunde, cele mai vii, care nu se suprapun (ca în Regizor 360) */
    private static List<long[]> pickShots(Src sr, int k, float S) {
        List<long[]> out = new ArrayList<>();
        double D = sr.dur / 1000.0;
        if (D < S + 0.6) { if (D > 1.2) out.add(new long[]{0, sr.dur}); return out; }
        float[] sc = sr.score;
        int n = Math.max(1, Math.round(S));
        List<double[]> win = new ArrayList<>();
        for (int s0 = 0; s0 + n <= sc.length; s0++) {
            if (s0 + S > D - 0.3) break;
            double q = 0;
            for (int j = 0; j < n; j++) q += sc[s0 + j];
            win.add(new double[]{q, s0});
        }
        java.util.Collections.sort(win, (a, b) -> Double.compare(b[0], a[0]));
        List<Integer> starts = new ArrayList<>();
        for (double[] w : win) {
            if (starts.size() >= k) break;
            int s0 = (int) w[1];
            boolean ok = true;
            for (int o : starts) if (Math.abs(o - s0) < S + 0.5) { ok = false; break; }
            if (ok) starts.add(s0);
        }
        java.util.Collections.sort(starts);
        for (int s0 : starts) {
            long a = (long) (Math.max(0, s0 + 0.25) * 1000), z = (long) (Math.min(D, s0 + 0.25 + S) * 1000);
            out.add(new long[]{a, z});
        }
        return out;
    }

    private void rebuildAuto() {
        if (analyzing) return;
        float S = autoStyle.equals("fast") ? 2 : autoStyle.equals("calm") ? 5 : 3;
        List<Src> vids = new ArrayList<>();
        for (Src sr : srcs) if (sr.dur > 0) vids.add(sr);
        if (vids.isEmpty()) { hint.setText("Telefonul nu reușește să citească filmările alese. Verifică dacă e conectat cardul."); return; }
        double sum = 0;
        for (Src sr : vids) sum += sr.dur / 1000.0;
        int durS = Integer.parseInt(autoDur);
        double total = durS > 0 ? durS : sum * 0.35;
        int K = (int) Math.max(vids.size(), Math.round(total / S));
        double ws = 0;
        double[] w = new double[vids.size()];
        for (int i = 0; i < vids.size(); i++) { w[i] = Math.pow(vids.get(i).dur / 1000.0, 0.7); ws += w[i]; }
        if (player != null) player.pause();
        clips.clear();
        for (int i = 0; i < vids.size(); i++) {
            Src sr = vids.get(i);
            int k = (int) Math.max(1, Math.round(K * w[i] / ws));
            for (long[] sh : pickShots(sr, k, S)) {
                Clip c = new Clip();
                c.uri = sr.uri; c.prev = sr.prev; c.is360 = sr.is360; c.name = sr.name;
                c.key = sr.key + "#" + clips.size();
                c.t.dur = sr.dur; c.t.in = sh[0]; c.t.out = sh[1];
                c.t.frames = sr.frames;
                c.durKnown = true;
                c.view = new float[]{0f, -5f, 85f, 0f};
                clips.add(c);
            }
        }
        // la stilul Relaxat începem cu Tiny Planet, ca în Regizor
        if (S >= 5 && !clips.isEmpty() && clips.get(0).is360 && clips.get(0).t.len() > 3500) clips.get(0).view = new float[]{0f, 90f, 150f, 1f};
        if (clips.isEmpty()) { hint.setText("Filmările sunt prea scurte pentru montaj. Alege „Editez eu”."); return; }
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        rebuildPlayer(0);
        long tot = timeline.total();
        hint.setText("Montajul tău automat: " + clips.size() + " cadre din " + vids.size() + (vids.size() == 1 ? " filmare" : " filmări") + " · " + fmt(tot)
                + ". Apasă ▶. Poți schimba Durata, Stilul, Filtrul sau Muzica, ori atinge un cadru pe bandă ca să-l tai, muți sau ștergi.");
        player.play();
    }

    private void loadSrcFrames() {
        for (Src sr : srcs) {
            if (sr.dur <= 0 || isFinishing()) continue;
            int n = (int) Math.max(4, Math.min(40, sr.dur / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, sr.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * sr.dur * 1000);
                    if (sr.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
            main.post(() -> {
                sr.frames = frames;
                for (Clip c : clips) if (c.prev.equals(sr.prev)) c.t.frames = frames;
                timeline.invalidate();
            });
        }
    }

    private TextView chip(String text, boolean on, View.OnClickListener l) {
        TextView t = new TextView(this);
        float dd = getResources().getDisplayMetrics().density;
        t.setText(text);
        t.setTextSize(13.5f);
        t.setGravity(android.view.Gravity.CENTER);
        t.setBackgroundResource(R.drawable.chip_bg);
        t.setTextColor(getResources().getColorStateList(R.color.chip_text, getTheme()));
        t.setPadding((int) (16 * dd), 0, (int) (16 * dd), 0);
        t.setSelected(on);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (38 * dd));
        lp.setMarginEnd((int) (8 * dd));
        t.setLayoutParams(lp);
        return t;
    }

    private void buildAutoTools() {
        LinearLayout row = findViewById(R.id.autoTools);
        row.removeAllViews();
        String[][] tools = {{"dur", "Durată", "⏱"}, {"style", "Stil", "≋"}, {"filt", "Filtru", "◐"}, {"music", "Muzică", "♫"}};
        float dd = getResources().getDisplayMetrics().density;
        for (String[] t : tools) {
            TextView b = new TextView(this);
            boolean on = t[0].equals(openTool);
            String sub = t[0].equals("dur") ? (autoDur.equals("0") ? "Tot" : autoDur + " s")
                    : t[0].equals("style") ? (autoStyle.equals("fast") ? "Rapid" : autoStyle.equals("calm") ? "Relaxat" : "Normal")
                    : t[0].equals("filt") ? Look.NAMES[java.util.Arrays.asList(Look.IDS).indexOf(filt)]
                    : (music == null ? "fără" : "aleasă");
            b.setText(t[2] + "\n" + t[1] + "\n" + sub);
            b.setGravity(android.view.Gravity.CENTER);
            b.setTextSize(12);
            b.setLineSpacing(0, 1.05f);
            b.setTextColor(on ? 0xFFFF6A2B : 0xFFF2F2F0);
            b.setBackgroundResource(on ? R.drawable.src_on : R.drawable.src_off);
            b.setPadding(0, (int) (8 * dd), 0, (int) (8 * dd));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins((int) (4 * dd), 0, (int) (4 * dd), 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> { openTool = t[0].equals(openTool) ? null : t[0]; buildAutoTools(); });
            row.addView(b);
        }
        LinearLayout sub = findViewById(R.id.autoSub);
        LinearLayout extra = findViewById(R.id.autoExtra);
        sub.removeAllViews();
        extra.removeAllViews();
        findViewById(R.id.autoSubScroll).setVisibility(openTool == null ? View.GONE : View.VISIBLE);
        extra.setVisibility(View.GONE);
        if (openTool == null) return;
        switch (openTool) {
            case "dur": {
                String[][] o = {{"15", "15 s"}, {"30", "30 s"}, {"60", "60 s"}, {"0", "Tot"}};
                for (String[] x : o) sub.addView(chip(x[1], x[0].equals(autoDur), v -> { autoDur = x[0]; changed(true); }));
                break;
            }
            case "style": {
                String[][] o = {{"fast", "Rapid · 2 s"}, {"normal", "Normal · 3 s"}, {"calm", "Relaxat · 5 s"}};
                for (String[] x : o) sub.addView(chip(x[1], x[0].equals(autoStyle), v -> { autoStyle = x[0]; changed(true); }));
                break;
            }
            case "filt": {
                for (int i = 0; i < Look.IDS.length; i++) {
                    final String id = Look.IDS[i];
                    LinearLayout it = new LinearLayout(this);
                    it.setOrientation(LinearLayout.VERTICAL);
                    it.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
                    View sw = new View(this);
                    android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                            android.graphics.drawable.GradientDrawable.Orientation.TL_BR, Look.SWATCH[i]);
                    g.setCornerRadius(10 * dd);
                    if (id.equals(filt)) g.setStroke((int) (2.5f * dd), 0xFFFF6A2B);
                    sw.setBackground(g);
                    it.addView(sw, new LinearLayout.LayoutParams((int) (64 * dd), (int) (44 * dd)));
                    TextView l = new TextView(this);
                    l.setText(Look.NAMES[i]);
                    l.setTextSize(12);
                    l.setTextColor(id.equals(filt) ? 0xFFFF6A2B : 0xFFB9BCBF);
                    l.setGravity(android.view.Gravity.CENTER);
                    it.addView(l);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMarginEnd((int) (10 * dd));
                    it.setLayoutParams(lp);
                    it.setOnClickListener(v -> { filt = id; applyLook(); buildAutoTools(); });
                    sub.addView(it);
                }
                extra.setVisibility(View.VISIBLE);
                extra.addView(slider("Tărie", filtK, 100, v -> { filtK = v; applyLook(); }));
                break;
            }
            case "music": {
                sub.addView(chip(music == null ? "＋ Alege o melodie din telefon" : "♫ " + musicName + " · schimbă", music != null, v -> pickMusic()));
                if (music != null) sub.addView(chip("Fără muzică", false, v -> { setMusic(null, null); }));
                extra.setVisibility(View.VISIBLE);
                android.widget.CheckBox cb = new android.widget.CheckBox(this);
                cb.setText("Păstrează sunetul filmărilor");
                cb.setTextColor(0xFFF2F2F0);
                cb.setChecked(origSound);
                cb.setOnCheckedChangeListener((x, on) -> { origSound = on; applyVolumes(); });
                extra.addView(cb);
                if (music != null) extra.addView(slider("Volum muzică", musicVol, 100, v -> { musicVol = v; applyVolumes(); }));
                break;
            }
        }
    }

    interface IntSet { void set(int v); }

    private View slider(String label, int val, int max, IntSet cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFB9BCBF);
        t.setTextSize(13);
        r.addView(t);
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(max);
        sb.setProgress(val);
        TextView v = new TextView(this);
        v.setText(String.valueOf(val));
        v.setTextColor(0xFFB9BCBF);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s1, int p, boolean u) { v.setText(String.valueOf(p)); cb.set(p); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s1) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s1) { }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(v);
        return r;
    }

    private void changed(boolean shots) {
        buildAutoTools();
        if (shots) findViewById(R.id.autoApply).setVisibility(View.VISIBLE);
    }

    private void applyLook() { view.setLook(Look.of(filt, filtK)); }

    private void pickMusic() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        try { startActivityForResult(i, REQ_MUSIC); } catch (Exception e) { Toast.makeText(this, "Nu pot deschide alegerea melodiei.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_MUSIC && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            String n = "melodie";
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) n = c.getString(0).replaceAll("\\.[^.]+$", "");
            } catch (Exception ignored) { }
            setMusic(u, n);
        }
    }

    private void setMusic(Uri u, String name) {
        music = u;
        musicName = name;
        if (musicPlayer != null) {
            musicPlayer.stop();
            if (u != null) { musicPlayer.setMediaItem(MediaItem.fromUri(u)); musicPlayer.prepare(); }
        }
        applyVolumes();
        buildAutoTools();
    }

    private void applyVolumes() {
        if (player != null) player.setVolume(origSound ? 1f : 0f);
        if (musicPlayer != null) musicPlayer.setVolume(musicVol / 100f);
    }

    /** muzica merge odată cu filmul */
    private void syncMusic(long g) {
        if (musicPlayer == null || music == null) return;
        boolean play = player != null && player.isPlaying();
        long md = musicPlayer.getDuration();
        if (!play) { if (musicPlayer.isPlaying()) musicPlayer.pause(); return; }
        if (md <= 0) { if (!musicPlayer.isPlaying()) musicPlayer.play(); return; }
        long want = g % md;
        if (Math.abs(musicPlayer.getCurrentPosition() - want) > 400) musicPlayer.seekTo(want);
        if (!musicPlayer.isPlaying()) musicPlayer.play();
    }

    private void showTools(boolean clipSel) {
        if (auto) findViewById(R.id.tools).setVisibility(clipSel ? View.VISIBLE : View.GONE);
        findViewById(R.id.toolsHint).setVisibility(clipSel ? View.GONE : View.VISIBLE);
        findViewById(R.id.clipTools).setVisibility(clipSel ? View.VISIBLE : View.GONE);
        boolean many = clips.size() > 1;
        findViewById(R.id.tLeft).setEnabled(many);
        findViewById(R.id.tRight).setEnabled(many);
        findViewById(R.id.tDel).setEnabled(many);
    }

    private void moveSel(int dir) {
        int i = timeline.getSelected(), j = i + dir;
        if (i < 0 || j < 0 || j >= clips.size()) return;
        Clip c = clips.remove(i);
        clips.add(j, c);
        timeline.setClips(timelineClips());
        timeline.setSelected(j);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(j) + 50);
    }

    private void deleteSel() {
        int i = timeline.getSelected();
        if (i < 0 || clips.size() < 2) return;
        clips.remove(i);
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        showTools(false);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(Math.min(i, clips.size() - 1)));
    }

    // ---------------- salvare ----------------

    private boolean has360() { for (Clip c : clips) if (c.is360) return true; return false; }

    private void askSave() {
        if (clips.isEmpty()) return;
        final String[] ids = {"720", "1080", "max"};
        boolean h = has360();
        String[] labels = {"Rapid · 720p (bun pentru WhatsApp)", "Normal · 1080p", h ? "Maxim · 1080p (filmările 360)" : "Maxim · calitatea filmării"};
        String q = prefs.getString("quality", "1080");
        int sel = q.equals("720") ? 0 : q.equals("max") ? 2 : 1;
        AlertDialog.Builder bd = new AlertDialog.Builder(this).setTitle("Salvează filmul").setSingleChoiceItems(labels, sel, (d, w) -> prefs.edit().putString("quality", ids[w]).apply())
                .setPositiveButton("Salvează", (d, w) -> save())
                .setNegativeButton("Renunț", null);
        if (h) bd.setMessage(null);
        bd.show();
        if (h) Toast.makeText(this, "Filmările 360 se salvează din fișierul de previzualizare de pe card (până la 1080p).", Toast.LENGTH_LONG).show();
    }

    private void save() {
        if (transformer != null || clips.isEmpty()) return;
        player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        String q = prefs.getString("quality", "1080");
        float ratio = formatRatio();
        int shortSide = q.equals("720") ? 720 : q.equals("1080") ? 1080 : 2160;
        if (has360()) shortSide = Math.min(shortSide, 1080);
        int outW, outH;
        if (ratio >= 1f) { outH = shortSide; outW = Math.round(shortSide * ratio); } else { outW = shortSide; outH = Math.round(shortSide / ratio); }
        outW = outW / 2 * 2; outH = outH / 2 * 2;
        float[] look = Look.of(filt, filtK);
        List<EditedMediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            MediaItem mi = new MediaItem.Builder().setUri(c.is360 ? c.prev : c.uri).setClippingConfiguration(cb.build()).build();
            List<Effect> fx = new ArrayList<>();
            fx.add(new ReframeEffect(c.is360, c.view, look, outW, outH));
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(1f));
            items.add(new EditedMediaItem.Builder(mi).setRemoveAudio(!origSound).setEffects(new Effects(ap, fx)).build());
        }
        Composition.Builder cbld;
        if (music != null) {
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(musicVol / 100f));
            EditedMediaItem mus = new EditedMediaItem.Builder(MediaItem.fromUri(music)).setRemoveVideo(true)
                    .setEffects(new Effects(ap, new ArrayList<Effect>())).build();
            List<EditedMediaItem> ml = new ArrayList<>();
            ml.add(mus);
            cbld = new Composition.Builder(new EditedMediaItemSequence(items), new EditedMediaItemSequence(ml, true));
        } else cbld = new Composition.Builder(new EditedMediaItemSequence(items));
        Composition comp = cbld.experimentalSetForceAudioTrack(true).build();
        final File out = new File(getCacheDir(), "director360_" + System.currentTimeMillis() + ".mp4");
        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult result) {
                        transformer = null;
                        setProgressText("Pun filmul în Galerie…");
                        new Thread(() -> publish(out)).start();
                    }

                    @Override public void onError(Composition composition, ExportResult result, ExportException e) {
                        transformer = null;
                        if (progressDlg != null) progressDlg.dismiss();
                        out.delete();
                        new AlertDialog.Builder(EditorActivity.this)
                                .setTitle("Nu am putut face filmul")
                                .setMessage("Încearcă din nou sau alege calitatea „Rapid 720p”.\n\n(cod " + e.errorCode + ")")
                                .setPositiveButton("Bine", null)
                                .show();
                    }
                })
                .build();
        showProgress();
        try {
            transformer.start(comp, out.getAbsolutePath());
        } catch (Throwable e) {
            transformer = null;
            if (progressDlg != null) progressDlg.dismiss();
            Toast.makeText(this, "Nu am putut porni salvarea: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        main.post(new Runnable() {
            @Override public void run() {
                if (transformer == null) return;
                if (transformer.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) setProgressText("Fac filmul… " + ph.progress + "%");
                main.postDelayed(this, 400);
            }
        });
    }

    private static AudioProcessor stereo(float gain) {
        androidx.media3.common.audio.ChannelMixingAudioProcessor m = new androidx.media3.common.audio.ChannelMixingAudioProcessor();
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(1, 2).scaleBy(gain));
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(2, 2).scaleBy(gain));
        return m;
    }

    private void showProgress() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        progressText = new TextView(this);
        progressText.setText("Pregătesc filmul…");
        progressText.setTextSize(17);
        progressText.setTextColor(0xFFF2F2F0);
        progressText.setPadding(0, pad / 2, 0, 0);
        box.addView(pb);
        box.addView(progressText);
        progressDlg = new AlertDialog.Builder(this)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Oprește", (d, w) -> { if (transformer != null) { transformer.cancel(); transformer = null; } })
                .show();
    }

    private void setProgressText(String s) { if (progressText != null) progressText.setText(s); }

    /** pune filmul în Galerie › Movies › Director360 */
    private void publish(File f) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".mp4";
            v.put(MediaStore.Video.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Director360");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) throw new Exception("nu pot crea fișierul");
            try (InputStream in = new FileInputStream(f); OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) throw new Exception("nu pot scrie");
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            v.clear();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            f.delete();
            final Uri done = dst;
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                new AlertDialog.Builder(this)
                        .setTitle("Gata! Filmul e salvat")
                        .setMessage("Îl găsești în Galerie, în albumul Director360.")
                        .setPositiveButton("Deschide", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(done, "video/mp4");
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(i); } catch (Exception ignored) { }
                        })
                        .setNeutralButton("Trimite", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("video/mp4");
                            i.putExtra(Intent.EXTRA_STREAM, done);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(i, "Trimite filmul")); } catch (Exception ignored) { }
                        })
                        .setNegativeButton("Închide", null)
                        .show();
            });
        } catch (Throwable e) {
            final String msg = e.getMessage();
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                Toast.makeText(this, "Nu am putut salva filmul: " + msg, Toast.LENGTH_LONG).show();
            });
        }
    }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        Clip c = cur();
        if (c != null && c.is360) saveView(c);
        if (view != null) view.onPause();
    }

    @Override protected void onResume() { super.onResume(); if (view != null) view.onResume(); }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (transformer != null) { transformer.cancel(); transformer = null; }
        if (player != null) { player.release(); player = null; }
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; }
        if (view != null) view.release();
        super.onDestroy();
    }
}
