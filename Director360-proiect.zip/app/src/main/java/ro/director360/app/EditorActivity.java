package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.Presentation;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.ui.PlayerView;

import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EditorActivity extends AppCompatActivity {

    private ExoPlayer player;
    private TrimBar trim;
    private TextView time;
    private MaterialButton btnPlay, btnQuality;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Uri uri, lrv;
    private String key, name;
    private SharedPreferences edits, prefs;
    private int dispW = 0, dispH = 0;
    private long dur = 0;
    private Transformer transformer;
    private AlertDialog progressDlg;
    private boolean is360;
    private Video360View v360;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null) {
                long p = player.getCurrentPosition();
                trim.setPos(p);
                time.setText(fmt(p) + " / " + fmt(trim.getOut() - trim.getIn()));
                if (player.isPlaying() && p >= trim.getOut()) {
                    player.pause();
                    player.seekTo(trim.getIn());
                }
            }
            main.postDelayed(this, 80);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        uri = Uri.parse(getIntent().getStringExtra("uri"));
        String l = getIntent().getStringExtra("lrv");
        lrv = l == null ? null : Uri.parse(l);
        key = getIntent().getStringExtra("key");
        name = getIntent().getStringExtra("name");
        is360 = name != null && name.toLowerCase().endsWith(".insv");
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        prefs = getSharedPreferences("main", MODE_PRIVATE);

        trim = findViewById(R.id.trim);
        time = findViewById(R.id.time);
        btnPlay = findViewById(R.id.btnPlay);
        btnQuality = findViewById(R.id.btnQuality);
        PlayerView pv = findViewById(R.id.player);
        TextView hint = findViewById(R.id.hint);
        player = new ExoPlayer.Builder(this).build();
        if (is360 && lrv != null) {
            // 360: imaginea se afișează reîncadrată, ca la Insta360
            pv.setVisibility(android.view.View.GONE);
            v360 = new Video360View(this);
            ((android.widget.FrameLayout) findViewById(R.id.playerBox)).addView(v360,
                    new android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
            v360.setOnSurface(s -> { if (player != null) player.setVideoSurface(s); });
            String sv = edits.getString(key + ":view", null);
            if (sv != null) {
                try { String[] q = sv.split(","); v360.setView(Float.parseFloat(q[0]), Float.parseFloat(q[1]), Float.parseFloat(q[2]), q[3].equals("1")); } catch (Exception ignored) { }
            }
            findViewById(R.id.modes).setVisibility(android.view.View.VISIBLE);
            com.google.android.material.button.MaterialButtonToggleGroup g = findViewById(R.id.modeGroup);
            g.check(v360.isPlanet() ? R.id.mPlanet : R.id.mCustom);
            g.addOnButtonCheckedListener((grp, id, checked) -> {
                if (!checked) return;
                v360.setPlanet(id == R.id.mPlanet);
                saveView();
            });
            findViewById(R.id.btnLevel).setOnClickListener(v -> { v360.resetView(); g.check(R.id.mCustom); saveView(); });
            hint.setText("Trage pe film ca să alegi cadrul, cu două degete mărești. Atinge de două ori pentru Tiny Planet.");
        } else {
            pv.setPlayer(player);
            if (is360) hint.setText("Pentru imaginea 360 aplicația are nevoie de fișierul mic LRV de pe card, din același folder cu filmarea.");
        }
        // pentru viteză, în editor folosesc fișierul mic (LRV) dacă există; la salvare folosesc filmarea mare
        player.setMediaItem(MediaItem.fromUri(lrv != null ? lrv : uri));
        player.prepare();
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { btnPlay.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play); }
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY && dur <= 0) {
                    dur = player.getDuration();
                    if (dur > 0) setupTrim();
                }
            }
        });

        btnPlay.setOnClickListener(v -> {
            if (player.isPlaying()) player.pause();
            else {
                long p = player.getCurrentPosition();
                if (p < trim.getIn() || p >= trim.getOut() - 100) player.seekTo(trim.getIn());
                player.play();
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        btnQuality.setText(qualityLabel());
        btnQuality.setOnClickListener(v -> {
            String q = prefs.getString("quality", "1080");
            q = q.equals("720") ? "1080" : q.equals("1080") ? "max" : "720";
            prefs.edit().putString("quality", q).apply();
            btnQuality.setText(qualityLabel());
        });
        findViewById(R.id.btnSave).setOnClickListener(v -> save());

        trim.setListener(new TrimBar.Listener() {
            @Override public void onSeek(long ms) { player.pause(); player.seekTo(ms); }
            @Override public void onTrim(long a, long z, boolean left) { player.pause(); player.seekTo(left ? a : z); }
            @Override public void onTouchEnd() {
                edits.edit().putString(key, trim.getIn() + "," + trim.getOut()).apply();
            }
        });

        new Thread(this::readInfo).start();
        main.post(tick);
    }

    private void saveView() {
        if (v360 == null) return;
        float[] v = v360.getView();
        edits.edit().putString(key + ":view", v[0] + "," + v[1] + "," + v[2] + "," + (v[3] > 0 ? "1" : "0")).apply();
    }

    private String qualityLabel() {
        String q = prefs.getString("quality", "1080");
        return q.equals("720") ? "Rapid 720p" : q.equals("1080") ? "Normal 1080p" : "Maxim";
    }

    private void setupTrim() {
        trim.setDuration(dur);
        String s = edits.getString(key, null);
        long a = 0, z = dur;
        if (s != null) {
            try { String[] p = s.split(","); a = Long.parseLong(p[0]); z = Long.parseLong(p[1]); } catch (Exception ignored) { }
        }
        trim.setRange(a, z);
        player.seekTo(trim.getIn());
    }

    /** dimensiunea filmului și pozele pentru bandă (pe un fir separat) */
    private void readInfo() {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, uri);
            int w = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int h = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            int rot = parse(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            dispW = (rot == 90 || rot == 270) ? h : w;
            dispH = (rot == 90 || rot == 270) ? w : h;
        } catch (Throwable ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        MediaMetadataRetriever f = new MediaMetadataRetriever();
        try {
            f.setDataSource(this, lrv != null ? lrv : uri);
            long d = parse(f.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            int n = 10;
            Bitmap[] frames = new Bitmap[n];
            for (int i = 0; i < n && !isFinishing(); i++) {
                long at = (long) ((i + 0.5) / n * d * 1000);
                if (is360 && lrv != null) {
                    Bitmap sb = f.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                    frames[i] = sb == null ? null : Thumbs.reframe(sb, 160, 100, 120f);
                } else frames[i] = f.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 160, 100);
                final Bitmap[] copy = frames.clone();
                main.post(() -> trim.setFrames(copy));
            }
        } catch (Throwable ignored) {
        } finally {
            try { f.release(); } catch (Exception ignored) { }
        }
    }

    private static int parse(String s) {
        try { return s == null ? 0 : Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    private void save() {
        if (is360) {
            Toast.makeText(this, "Salvarea filmărilor 360 vine în etapa următoare. Acum merg filmările normale.", Toast.LENGTH_LONG).show();
            return;
        }
        if (transformer != null) return;
        player.pause();
        long a = trim.getIn(), z = trim.getOut();
        String q = prefs.getString("quality", "1080");
        List<Effect> fx = new ArrayList<>();
        if (!q.equals("max") && dispW > 0 && dispH > 0) {
            int target = q.equals("720") ? 720 : 1080;
            int shortSide = Math.min(dispW, dispH);
            if (shortSide > target) {
                int outH = dispH >= dispW ? Math.round(target * (dispH / (float) dispW)) : target;
                outH = outH / 2 * 2;
                fx.add(Presentation.createForHeight(outH));
            }
        }
        MediaItem mi = new MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(a)
                        .setEndPositionMs(z)
                        .build())
                .build();
        EditedMediaItem em = new EditedMediaItem.Builder(mi)
                .setEffects(new Effects(new ArrayList<AudioProcessor>(), fx))
                .build();
        final File out = new File(getCacheDir(), "director360_" + System.currentTimeMillis() + ".mp4");
        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult result) {
                        transformer = null;
                        new Thread(() -> publish(out)).start();
                    }

                    @Override public void onError(Composition composition, ExportResult result, ExportException e) {
                        transformer = null;
                        if (progressDlg != null) progressDlg.dismiss();
                        out.delete();
                        new AlertDialog.Builder(EditorActivity.this)
                                .setTitle("Nu am putut face filmul")
                                .setMessage("Încearcă din nou sau alege calitatea „Rapid 720p”.\n\n(" + ("cod " + e.errorCode) + ")")
                                .setPositiveButton("Bine", null)
                                .show();
                    }
                })
                .build();
        showProgress();
        try {
            transformer.start(em, out.getAbsolutePath());
        } catch (Throwable e) {
            transformer = null;
            if (progressDlg != null) progressDlg.dismiss();
            Toast.makeText(this, "Nu am putut porni salvarea: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        main.post(new Runnable() {
            @Override public void run() {
                if (transformer == null) return;
                if (transformer.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) setProgressText("Fac filmul… " + ph.progress + "%");
                main.postDelayed(this, 400);
            }
        });
    }

    private TextView progressText;

    private void showProgress() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        progressText = new TextView(this);
        progressText.setText("Pregătesc filmul…");
        progressText.setTextSize(17);
        progressText.setTextColor(0xFFF2F2F0);
        progressText.setPadding(0, pad / 2, 0, 0);
        box.addView(pb);
        box.addView(progressText);
        progressDlg = new AlertDialog.Builder(this)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Oprește", (d, w) -> {
                    if (transformer != null) { transformer.cancel(); transformer = null; }
                })
                .show();
    }

    private void setProgressText(String s) { if (progressText != null) progressText.setText(s); }

    /** pune filmul în Galerie › Movies › Director360 */
    private void publish(File f) {
        Uri dst = null;
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".mp4";
            v.put(MediaStore.Video.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Director360");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            dst = cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) throw new Exception("nu pot crea fișierul");
            try (InputStream in = new FileInputStream(f); OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) throw new Exception("nu pot scrie");
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            v.clear();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            f.delete();
            final Uri done = dst;
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                new AlertDialog.Builder(this)
                        .setTitle("Gata! Filmul e salvat")
                        .setMessage("Îl găsești în Galerie, în albumul Director360.")
                        .setPositiveButton("Deschide", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(done, "video/mp4");
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(i); } catch (Exception ignored) { }
                        })
                        .setNeutralButton("Trimite", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("video/mp4");
                            i.putExtra(Intent.EXTRA_STREAM, done);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(i, "Trimite filmul")); } catch (Exception ignored) { }
                        })
                        .setNegativeButton("Închide", null)
                        .show();
            });
        } catch (Throwable e) {
            final String msg = e.getMessage();
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                Toast.makeText(this, "Nu am putut salva filmul: " + msg, Toast.LENGTH_LONG).show();
            });
        }
    }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (v360 != null) { saveView(); v360.onPause(); }
    }

    @Override protected void onResume() { super.onResume(); if (v360 != null) v360.onResume(); }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (transformer != null) { transformer.cancel(); transformer = null; }
        if (player != null) { player.release(); player = null; }
        if (v360 != null) v360.release();
        super.onDestroy();
    }
}
