package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline.Window;
import androidx.media3.common.VideoSize;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.TextureOverlay;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.common.collect.ImmutableList;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Editorul ca în Regizor 360 (și Insta360): filmul sus, banda jos, uneltele Template / Text / Sticker / Muzică / Filtru / Împarte. */
public class EditorActivity extends AppCompatActivity implements OverlayLayer.Host {

    /** o bucată din montaj */
    static class Clip {
        Uri uri, prev;
        String name, key;
        boolean is360;
        float[] view = {0f, 0f, 80f, 0f};
        final Timeline.Clip t = new Timeline.Clip();
        boolean durKnown = false;

        Clip copy() {
            Clip c = new Clip();
            c.uri = uri; c.prev = prev; c.name = name; c.key = key; c.is360 = is360;
            c.view = view.clone();
            c.t.dur = t.dur; c.t.in = t.in; c.t.out = t.out; c.t.frames = t.frames;
            c.durKnown = durKnown;
            return c;
        }
    }

    /** o filmare aleasă (sursa) */
    static class Src {
        Uri uri, prev;
        String name, key;
        boolean is360;
        long dur = 0;
        float[] score;
        Bitmap[] frames = new Bitmap[0];
    }

    /** o stare pentru Înapoi / Refă */
    static class Snap {
        List<Clip> clips = new ArrayList<>();
        List<Overlays.Ov> ovs = new ArrayList<>();
        String filt;
        int filtK;
    }

    private final List<Clip> clips = new ArrayList<>();
    private final List<Src> srcs = new ArrayList<>();
    private final List<Overlays.Ov> ovs = new ArrayList<>();
    private final List<Snap> undo = new ArrayList<>(), redo = new ArrayList<>();
    private Overlays.Ov selOv;
    private boolean auto = false, analyzing = false, analyzed = false, framesStarted = false, persist = true, full = false;
    private Runnable afterAnalyze;
    private boolean analyzeCancelled = false;
    private Overlays.Ov tplTitle;
    private String autoDur = "30", autoStyle = "normal", filt = "none";
    private int filtK = 70, musicVol = 80;
    private boolean origSound = true;
    private Uri music;
    private String musicName;
    private ExoPlayer musicPlayer;
    private String tool = null, tplCat = "Călătorie", tplSel = null;
    private static final int REQ_MUSIC = 31;

    private ExoPlayer player;
    private Video360View view;
    private OverlayLayer layer;
    private AspectFrame stage;
    private Timeline timeline;
    private TextView time, hint;
    private MaterialButton btnPlay, btnFormat;
    private MaterialButtonToggleGroup modeGroup;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences edits, prefs;
    private Transformer transformer;
    private int curIdx = -1;
    private float videoAspect = 16f / 9f;
    private String format = "orig";
    private boolean trimming = false;
    private float dd;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null && !clips.isEmpty()) {
                int i = player.getCurrentMediaItemIndex();
                long g = timeline.startOf(i) + Math.max(0, player.getCurrentPosition());
                timeline.setPos(g);
                time.setText(fmt(timeline.getPos()) + " / " + fmt(timeline.total()));
                if (i != curIdx) onClipChanged(i);
                if (!auto) fillDurations();
                syncMusic(g);
                if (!ovs.isEmpty()) layer.invalidate();
            }
            main.postDelayed(this, 40);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        dd = getResources().getDisplayMetrics().density;
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        String[] uris = getIntent().getStringArrayExtra("uris");
        String[] lrvs = getIntent().getStringArrayExtra("lrvs");
        String[] names = getIntent().getStringArrayExtra("names");
        String[] keys = getIntent().getStringArrayExtra("keys");
        if (uris == null || uris.length == 0) { finish(); return; }
        auto = getIntent().getBooleanExtra("auto", false);
        persist = !auto;
        for (int i = 0; i < uris.length; i++) {
            Src sr = new Src();
            sr.uri = Uri.parse(uris[i]);
            sr.name = names[i];
            sr.key = keys[i];
            sr.prev = (lrvs != null && lrvs[i] != null && !lrvs[i].isEmpty()) ? Uri.parse(lrvs[i]) : sr.uri;
            sr.is360 = sr.name.toLowerCase().endsWith(".insv") && sr.prev != sr.uri;
            srcs.add(sr);
            if (!auto) {
                Clip c = new Clip();
                c.uri = sr.uri; c.prev = sr.prev; c.name = sr.name; c.key = sr.key; c.is360 = sr.is360;
                String sv = edits.getString(c.key + ":view", null);
                if (sv != null) try { String[] q = sv.split(","); c.view = new float[]{Float.parseFloat(q[0]), Float.parseFloat(q[1]), Float.parseFloat(q[2]), q[3].equals("1") ? 1f : 0f}; } catch (Exception ignored) { }
                String s = edits.getString(c.key, null);
                if (s != null) try { String[] p = s.split(","); c.t.in = Long.parseLong(p[0]); c.t.out = Long.parseLong(p[1]); } catch (Exception ignored) { }
                clips.add(c);
            }
        }

        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6A2B), 9, 12, 0);
        ((TextView) findViewById(R.id.edBrand)).setText(brand);
        stage = findViewById(R.id.stage);
        timeline = findViewById(R.id.timeline);
        time = findViewById(R.id.time);
        hint = findViewById(R.id.hint);
        btnPlay = findViewById(R.id.btnPlay);
        btnFormat = findViewById(R.id.btnFormat);
        modeGroup = findViewById(R.id.modeGroup);

        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        layer = new OverlayLayer(this);
        layer.setHost(this);
        stage.addView(layer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        player = new ExoPlayer.Builder(this).build();
        view.setOnSurface(s -> { if (player != null) player.setVideoSurface(s); });
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { btnPlay.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play); }
            @Override public void onVideoSizeChanged(VideoSize v) {
                if (v.width > 0 && v.height > 0) {
                    videoAspect = v.width * v.pixelWidthHeightRatio / v.height;
                    Clip c = cur();
                    view.setFlat(c == null || !c.is360, videoAspect);
                    applyFormat();
                }
            }
            @Override public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_ENDED) { player.pause(); player.seekTo(0, 0); }
            }
        });

        format = prefs.getString("format", "orig");
        applyFormat();
        btnFormat.setOnClickListener(v -> chooseFormat());
        modeGroup.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked) return;
            Clip c = cur();
            if (c == null || !c.is360) return;
            boolean planet = id == R.id.mPlanet;
            if (planet != view.isPlanet()) view.setPlanet(planet);
            saveView(c);
        });
        findViewById(R.id.btnLevel).setOnClickListener(v -> { view.resetView(); modeGroup.check(R.id.mCustom); Clip c = cur(); if (c != null) saveView(c); });
        btnPlay.setOnClickListener(v -> { if (clips.isEmpty()) return; if (player.isPlaying()) player.pause(); else { if (timeline.getPos() >= timeline.total() - 150) seekGlobal(0); player.play(); } });
        findViewById(R.id.btnBack).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.btnSave).setOnClickListener(v -> askSave());
        findViewById(R.id.btnUndo).setOnClickListener(v -> doUndo());
        findViewById(R.id.btnRedo).setOnClickListener(v -> doRedo());
        findViewById(R.id.btnFull).setOnClickListener(v -> setFull(!full));
        findViewById(R.id.sheetOk).setOnClickListener(v -> closeSheet());

        timeline.setListener(new Timeline.Listener() {
            @Override public void onScrub(long g, boolean done) { if (player.isPlaying()) player.pause(); seekGlobal(g); }
            @Override public void onSelect(int i) {
                if (i >= 0) { selOv = null; closeSheet(); seekGlobal(timeline.startOf(i) + 50); }
                buildToolbar();
                setHint();
            }
            @Override public void onTrim(int i, boolean left, boolean done) {
                if (player.isPlaying()) player.pause();
                if (!trimming) { trimming = true; pushUndo(); }
                Clip c = clips.get(i);
                if (done) {
                    trimming = false;
                    if (persist) edits.edit().putString(c.key, c.t.in + "," + c.t.out).apply();
                    rebuildPlayer(timeline.startOf(i) + (left ? 0 : c.t.len() - 300));
                } else if (player.getCurrentMediaItemIndex() == i) {
                    player.seekTo(i, left ? 0 : Math.max(0, c.t.len() - 50));
                }
            }
        });

        musicPlayer = new ExoPlayer.Builder(this).build();
        musicPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        buildToolbar();
        updateUndoButtons();
        main.post(tick);

        if (auto) {
            hint.setText("Montajul automat");
            analyzing = true;
            showBusy("Analizez scenele 0%", "Caut cele mai vii momente din fiecare filmare", this::finish);
            new Thread(this::analyze).start();
            return;
        }
        timeline.setClips(timelineClips());
        new Thread(this::loadInfo).start();
        setHint();
        rebuildPlayer(0);
    }

    // ---------------- OverlayLayer.Host ----------------
    @Override public List<Overlays.Ov> overlays() { return ovs; }
    @Override public long now() { return timeline.getPos(); }
    @Override public Overlays.Ov selected() { return selOv; }
    @Override public void select(Overlays.Ov o) {
        if (o != null && o != selOv) pushUndo();
        selOv = o;
        if (o != null) { timeline.setSelected(-1); openSheet(o.emoji ? "sticker" : "text"); }
        else if ("text".equals(tool) || "sticker".equals(tool)) closeSheet();
        buildToolbar();
    }
    @Override public void changed(boolean done) { }

    private List<Timeline.Clip> timelineClips() { List<Timeline.Clip> l = new ArrayList<>(); for (Clip c : clips) l.add(c.t); return l; }

    private Clip cur() { return curIdx >= 0 && curIdx < clips.size() ? clips.get(curIdx) : null; }

    private void setHint() {
        Clip c = cur();
        if (timeline.getSelected() >= 0) hint.setText("Cadrul " + (timeline.getSelected() + 1) + " e ales: trage mânerele albe ca să-l scurtezi, sau jos: Împarte, Mută, Șterge.");
        else if (c != null && c.is360) hint.setText("Trage pe film ca să alegi cadrul · două degete = zoom · atinge de două ori = Tiny Planet. Jos: Template, Text, Sticker, Muzică, Filtru.");
        else hint.setText(clips.size() > 1 ? "Tragi banda ca să mergi prin filme. Atinge un cadru pe bandă ca să-l tai, muți sau ștergi." : "Tragi banda ca să mergi prin film. Atinge filmarea pe bandă ca s-o tai din capete.");
    }

    // ---------------- înapoi / refă ----------------
    private Snap snap() {
        Snap s = new Snap();
        for (Clip c : clips) s.clips.add(c.copy());
        for (Overlays.Ov o : ovs) s.ovs.add(o.copy());
        s.filt = filt; s.filtK = filtK;
        return s;
    }

    private void pushUndo() {
        undo.add(snap());
        if (undo.size() > 40) undo.remove(0);
        redo.clear();
        updateUndoButtons();
    }

    private void restore(Snap s) {
        clips.clear();
        for (Clip c : s.clips) clips.add(c.copy());
        ovs.clear();
        for (Overlays.Ov o : s.ovs) ovs.add(o.copy());
        filt = s.filt; filtK = s.filtK;
        selOv = null;
        applyLook();
        long pos = timeline.getPos();
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        if (!clips.isEmpty()) rebuildPlayer(Math.min(pos, Math.max(0, timeline.total() - 100)));
        closeSheet();
        buildToolbar();
        layer.invalidate();
    }

    private void doUndo() { if (undo.isEmpty()) return; redo.add(snap()); restore(undo.remove(undo.size() - 1)); updateUndoButtons(); }

    private void doRedo() { if (redo.isEmpty()) return; undo.add(snap()); restore(redo.remove(redo.size() - 1)); updateUndoButtons(); }

    private void updateUndoButtons() {
        findViewById(R.id.btnUndo).setAlpha(undo.isEmpty() ? 0.35f : 1f);
        findViewById(R.id.btnRedo).setAlpha(redo.isEmpty() ? 0.35f : 1f);
    }

    // ---------------- ecran mare ----------------
    private void setFull(boolean f) {
        full = f;
        int v = f ? View.GONE : View.VISIBLE;
        for (int id : new int[]{R.id.edHead, R.id.edLine, R.id.edBar, R.id.hint, R.id.timeline, R.id.toolScroll}) findViewById(id).setVisibility(v);
        if (f) { findViewById(R.id.modes).setVisibility(View.GONE); closeSheet(); }
        else { Clip c = cur(); findViewById(R.id.modes).setVisibility(c != null && c.is360 ? View.VISIBLE : View.GONE); }
    }

    @Override
    public void onBackPressed() {
        if (full) { setFull(false); return; }
        if (tool != null) { closeSheet(); return; }
        super.onBackPressed();
    }

    // ---------------- bara de unelte ----------------
    private void buildToolbar() {
        LinearLayout bar = findViewById(R.id.toolbar);
        bar.removeAllViews();
        if (timeline.getSelected() >= 0) {
            addTool(bar, "back", "Înapoi", R.drawable.ic_back);
            addTool(bar, "split", "Împarte", R.drawable.t_split);
            addTool(bar, "left", "Mută stânga", R.drawable.ic_left);
            addTool(bar, "right", "Mută dreapta", R.drawable.ic_right);
            addTool(bar, "del", "Șterge", R.drawable.ic_del);
            return;
        }
        if (auto) addTool(bar, "montaj", "Montaj", R.drawable.t_montage);
        addTool(bar, "template", "Template", R.drawable.t_template);
        addTool(bar, "text", "Text", R.drawable.t_text);
        addTool(bar, "sticker", "Sticker", R.drawable.t_sticker);
        addTool(bar, "music", "Muzică", R.drawable.t_music);
        addTool(bar, "filt", "Filtru", R.drawable.t_filter);
        addTool(bar, "split", "Împarte", R.drawable.t_split);
    }

    private void addTool(LinearLayout bar, String id, String label, int icon) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER);
        t.setContentDescription(label);
        boolean on = id.equals(tool);
        if (on) t.setBackgroundResource(R.drawable.tool_on);
        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        iv.setImageTintList(android.content.res.ColorStateList.valueOf(0xFFF2F2F0));
        t.addView(iv, new LinearLayout.LayoutParams((int) (24 * dd), (int) (24 * dd)));
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(0xFFF2F2F0);
        tv.setTextSize(12);
        tv.setTypeface(null, android.graphics.Typeface.BOLD);
        tv.setPadding(0, (int) (4 * dd), 0, 0);
        tv.setMaxLines(1);
        t.addView(tv);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (78 * dd), (int) (62 * dd));
        lp.setMargins((int) (2 * dd), 0, (int) (2 * dd), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> onTool(id));
        bar.addView(t);
    }

    private void onTool(String id) {
        switch (id) {
            case "back": timeline.setSelected(-1); buildToolbar(); setHint(); return;
            case "split": splitAtPlayhead(); return;
            case "left": moveSel(-1); return;
            case "right": moveSel(1); return;
            case "del": deleteSel(); return;
            case "text":
                if (selOv == null || selOv.emoji) addText();
                openSheet("text");
                return;
            default:
                if (id.equals(tool)) closeSheet(); else openSheet(id);
        }
    }

    // ---------------- foaia de jos ----------------
    private void openSheet(String id) {
        tool = id;
        View sh = findViewById(R.id.sheet);
        sh.setVisibility(View.VISIBLE);
        int maxH = (int) (getResources().getDisplayMetrics().heightPixels * 0.5f);
        View sc = findViewById(R.id.sheetScroll);
        sc.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
        sc.requestLayout();
        sc.post(() -> { if (sc.getHeight() > maxH) { sc.getLayoutParams().height = maxH; sc.requestLayout(); } });
        fillSheet();
        buildToolbar();
    }

    private void closeSheet() {
        tool = null;
        findViewById(R.id.sheet).setVisibility(View.GONE);
        buildToolbar();
    }

    private TextView title(LinearLayout body, String t) {
        TextView l = new TextView(this);
        l.setText(t.toUpperCase(new Locale("ro")));
        l.setTextColor(0xFF7C8186);
        l.setTextSize(11.5f);
        l.setLetterSpacing(0.1f);
        l.setPadding(0, (int) (12 * dd), 0, (int) (6 * dd));
        body.addView(l);
        return l;
    }

    private LinearLayout chipRow(LinearLayout body) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(row);
        body.addView(hs);
        return row;
    }

    private TextView chip(String text, boolean on, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13.5f);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.chip_bg);
        t.setTextColor(getResources().getColorStateList(R.color.chip_text, getTheme()));
        t.setPadding((int) (16 * dd), 0, (int) (16 * dd), 0);
        t.setSelected(on);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (38 * dd));
        lp.setMarginEnd((int) (8 * dd));
        t.setLayoutParams(lp);
        return t;
    }

    private MaterialButton bigButton(LinearLayout body, String text, boolean accent, View.OnClickListener l) {
        MaterialButton b = new MaterialButton(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setCornerRadius((int) (26 * dd));
        if (!accent) {
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF262A2E));
            b.setTextColor(0xFFF2F2F0);
        }
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (54 * dd));
        lp.topMargin = (int) (10 * dd);
        body.addView(b, lp);
        return b;
    }

    private TextView note(LinearLayout body, String t) {
        TextView n = new TextView(this);
        n.setText(t);
        n.setTextColor(0xFFB9BCBF);
        n.setTextSize(13);
        n.setPadding(0, (int) (8 * dd), 0, 0);
        body.addView(n);
        return n;
    }

    private void fillSheet() {
        LinearLayout body = findViewById(R.id.sheetBody);
        body.removeAllViews();
        TextView ttl = findViewById(R.id.sheetTitle);
        if (tool == null) return;
        switch (tool) {
            case "montaj": {
                ttl.setText("Montaj automat");
                title(body, "Cât să dureze");
                LinearLayout r1 = chipRow(body);
                String[][] o = {{"15", "15 s"}, {"30", "30 s"}, {"60", "60 s"}, {"0", "Tot"}};
                for (String[] x : o) r1.addView(chip(x[1], x[0].equals(autoDur), v -> { autoDur = x[0]; fillSheet(); }));
                title(body, "Stil");
                LinearLayout r2 = chipRow(body);
                String[][] st = {{"fast", "Rapid"}, {"normal", "Normal"}, {"calm", "Relaxat"}};
                for (String[] x : st) r2.addView(chip(x[1], x[0].equals(autoStyle), v -> { autoStyle = x[0]; fillSheet(); }));
                note(body, "Aleg din fiecare filmare bucățile cele mai vii (2 s la Rapid, 3 s la Normal, 5 s la Relaxat).");
                bigButton(body, "Refă montajul", true, v -> rebuildAuto());
                break;
            }
            case "template": fillTemplate(body, ttl); break;
            case "text": fillText(body, ttl); break;
            case "sticker": fillSticker(body, ttl); break;
            case "music": fillMusic(body, ttl); break;
            case "filt": fillFilter(body, ttl); break;
        }
    }

    // ---- Template ----
    private Bitmap tplCard(Overlays.Tpl t, int w, int h) {
        Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setShader(new android.graphics.LinearGradient(0, 0, w, h, t.g0, t.g1, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        p.setShader(new android.graphics.LinearGradient(0, h / 2f, 0, h, 0x00000000, 0x59000000, android.graphics.Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);
        Overlays.Ov o = new Overlays.Ov();
        o.text = t.title; o.style = t.ts; o.anim = "none"; o.x = 0.5f; o.y = 0.48f; o.s = 0.95f; o.a = 0; o.b = 99000;
        Overlays.drawOne(c, o, 5000, w, h, false);
        return b;
    }

    private void fillTemplate(LinearLayout body, TextView ttl) {
        ttl.setText("Template");
        LinearLayout tabs = chipRow(body);
        for (String cat : Overlays.TPL_CATS) {
            TextView t = new TextView(this);
            t.setText(cat);
            t.setTextSize(15);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setTextColor(cat.equals(tplCat) ? 0xFFF2F2F0 : 0xFF7C8186);
            t.setPadding(0, (int) (4 * dd), (int) (18 * dd), (int) (8 * dd));
            if (cat.equals(tplCat)) t.setPaintFlags(t.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
            t.setOnClickListener(v -> { tplCat = cat; fillSheet(); });
            tabs.addView(t);
        }
        LinearLayout cards = chipRow(body);
        int cw = (int) (112 * dd), ch = (int) (140 * dd);
        Overlays.Tpl chosen = null;
        for (Overlays.Tpl t : Overlays.TPLS) {
            if (t.id.equals(tplSel)) chosen = t;
            if (!t.cat.equals(tplCat)) continue;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER_HORIZONTAL);
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(tplCard(t, cw, ch));
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), 12 * dd); }
            });
            if (t.id.equals(tplSel)) {
                GradientDrawable g = new GradientDrawable();
                g.setCornerRadius(14 * dd);
                g.setStroke((int) (2.5f * dd), 0xFFF2F2F0);
                card.setBackground(g);
            }
            card.setPadding((int) (3 * dd), (int) (3 * dd), (int) (3 * dd), (int) (3 * dd));
            card.addView(iv, new LinearLayout.LayoutParams(cw, ch));
            TextView n = new TextView(this);
            n.setText(t.name);
            n.setTextColor(t.id.equals(tplSel) ? 0xFFF2F2F0 : 0xFFB9BCBF);
            n.setTextSize(13);
            n.setTypeface(null, t.id.equals(tplSel) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            n.setPadding(0, (int) (6 * dd), 0, 0);
            card.addView(n);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (10 * dd));
            card.setLayoutParams(lp);
            card.setOnClickListener(v -> { tplSel = t.id; fillSheet(); });
            cards.addView(card);
        }
        if (chosen == null) {
            note(body, "Alege un șablon: face singur montajul din filmările tale, cu ritm, filtru și titlu animat. Apoi poți schimba orice.");
            return;
        }
        String sty = chosen.style.equals("fast") ? "ritm rapid" : chosen.style.equals("calm") ? "ritm lent" : "ritm normal";
        String fn = Look.NAMES[java.util.Arrays.asList(Look.IDS).indexOf(chosen.filt)];
        note(body, chosen.name + " · " + sty + " · " + chosen.dur + " s · filtru " + fn + " · titlu animat");
        final Overlays.Tpl tp = chosen;
        bigButton(body, "Folosește șablonul", true, v -> useTemplate(tp));
    }

    private void useTemplate(Overlays.Tpl t) {
        closeSheet();
        autoStyle = t.style;
        autoDur = String.valueOf(t.dur);
        Runnable apply = () -> {
            boolean was = auto;
            auto = true;
            rebuildAuto();
            filt = t.filt;
            applyLook();
            if (tplTitle != null) ovs.remove(tplTitle);
            Overlays.Ov o = new Overlays.Ov();
            tplTitle = o;
            o.text = t.title; o.style = t.ts; o.anim = t.an; o.x = 0.5f; o.y = 0.42f; o.s = 1f;
            o.a = 0; o.b = Math.min(3500, Math.max(1500, timeline.total()));
            ovs.add(o);
            layer.invalidate();
            if (!was) buildToolbar();
            Toast.makeText(this, "Am făcut montajul „" + t.name + "”. Apasă ▶.", Toast.LENGTH_LONG).show();
        };
        if (analyzed) apply.run();
        else {
            afterAnalyze = apply;
            analyzing = true;
            showBusy("Analizez scenele 0%", "Caut cele mai vii momente din fiecare filmare", () -> { afterAnalyze = null; analyzeCancelled = true; });
            new Thread(this::analyze).start();
        }
    }

    // ---- Text ----
    private void addText() {
        pushUndo();
        Overlays.Ov o = new Overlays.Ov();
        o.text = "Textul tău";
        long tot = timeline.total();
        o.a = timeline.getPos();
        if (tot > 0 && o.a > tot - 1500) o.a = Math.max(0, tot - 3000);
        o.b = o.a + 3000;
        ovs.add(o);
        selOv = o;
        layer.invalidate();
    }

    private void fillText(LinearLayout body, TextView ttl) {
        ttl.setText("Text");
        final Overlays.Ov o = selOv;
        if (o == null || o.emoji) { note(body, "Atinge „Text” ca să pui un text nou pe film."); return; }
        EditText et = new EditText(this);
        et.setText(o.text);
        et.setTextColor(0xFFF2F2F0);
        et.setTextSize(17);
        et.setBackgroundResource(R.drawable.src_off);
        et.setPadding((int) (14 * dd), (int) (12 * dd), (int) (14 * dd), (int) (12 * dd));
        et.setMinLines(2);
        et.setSelectAllOnFocus(true);
        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void afterTextChanged(Editable s) { o.text = s.toString(); layer.invalidate(); }
        });
        body.addView(et);
        title(body, "Stil");
        LinearLayout r1 = chipRow(body);
        for (String[] s : Overlays.STYLES) r1.addView(chip(s[1], s[0].equals(o.style), v -> { pushUndo(); o.style = s[0]; if (s[0].equals("subtitrare")) o.y = 0.86f; layer.invalidate(); fillSheet(); }));
        title(body, "Animație la intrare");
        LinearLayout r2 = chipRow(body);
        for (String[] s : Overlays.ANIMS) r2.addView(chip(s[1], s[0].equals(o.anim), v -> { o.anim = s[0]; replayOv(o); fillSheet(); }));
        title(body, "Culoare");
        LinearLayout r3 = chipRow(body);
        for (int col : Overlays.COLORS) {
            View c = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            g.setStroke((int) ((col == o.color ? 3 : 1) * dd), col == o.color ? 0xFFFF6A2B : 0xFF3A4048);
            c.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams((int) (36 * dd), (int) (36 * dd));
            lp.setMarginEnd((int) (10 * dd));
            c.setOnClickListener(v -> { o.color = col; layer.invalidate(); fillSheet(); });
            r3.addView(c, lp);
        }
        durationChips(body, o);
        bigButton(body, "＋ Alt text", false, v -> { addText(); fillSheet(); });
        bigButton(body, "Șterge textul", false, v -> { pushUndo(); ovs.remove(o); selOv = null; layer.invalidate(); closeSheet(); });
    }

    private void durationChips(LinearLayout body, Overlays.Ov o) {
        title(body, "Cât stă pe ecran");
        LinearLayout r = chipRow(body);
        long len = o.b - o.a;
        long[] ds = {2000, 3000, 5000};
        for (long d : ds) r.addView(chip((d / 1000) + " s", Math.abs(len - d) < 50, v -> { o.b = o.a + d; layer.invalidate(); fillSheet(); }));
        long end = Math.max(o.a + 500, timeline.total());
        r.addView(chip("Până la final", o.b >= end - 50, v -> { o.b = Math.max(o.a + 500, timeline.total()); layer.invalidate(); fillSheet(); }));
    }

    /** arată animația din nou: mută filmul la începutul textului */
    private void replayOv(Overlays.Ov o) {
        if (player.isPlaying()) player.pause();
        seekGlobal(o.a);
        timeline.setPos(o.a);
        player.play();
        main.postDelayed(() -> { if (player != null && player.isPlaying() && timeline.getPos() > o.a + 1500) player.pause(); }, 1600);
    }

    // ---- Sticker ----
    private void fillSticker(LinearLayout body, TextView ttl) {
        ttl.setText("Sticker");
        note(body, "Atinge un sticker ca să-l pui pe film. Apoi îl tragi cu degetul și îl mărești cu două degete.");
        LinearLayout row = null;
        for (int i = 0; i < Overlays.EMOJIS.length; i++) {
            if (i % 8 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                body.addView(row);
            }
            final String e = Overlays.EMOJIS[i];
            TextView t = new TextView(this);
            t.setText(e);
            t.setTextSize(26);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> {
                pushUndo();
                Overlays.Ov o = new Overlays.Ov();
                o.emoji = true; o.text = e; o.anim = "pop";
                o.x = 0.5f + (float) (Math.random() - 0.5) * 0.3f; o.y = 0.5f + (float) (Math.random() - 0.5) * 0.3f;
                o.a = timeline.getPos();
                long tot = timeline.total();
                if (tot > 0 && o.a > tot - 1500) o.a = Math.max(0, tot - 3000);
                o.b = o.a + 3000;
                ovs.add(o);
                selOv = o;
                layer.invalidate();
                fillSheet();
            });
            row.addView(t, new LinearLayout.LayoutParams(0, (int) (48 * dd), 1f));
        }
        if (selOv != null && selOv.emoji) {
            final Overlays.Ov o = selOv;
            durationChips(body, o);
            bigButton(body, "Șterge stickerul", false, v -> { pushUndo(); ovs.remove(o); selOv = null; layer.invalidate(); fillSheet(); });
        }
    }

    // ---- Muzică ----
    private void fillMusic(LinearLayout body, TextView ttl) {
        ttl.setText("Sunet și muzică");
        bigButton(body, music == null ? "＋ Alege o melodie din telefon" : "♫ " + musicName + " · schimbă", music == null, v -> pickMusic());
        if (music != null) bigButton(body, "Fără muzică", false, v -> setMusic(null, null));
        android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setText("Păstrează sunetul filmărilor");
        cb.setTextColor(0xFFF2F2F0);
        cb.setTextSize(15);
        cb.setChecked(origSound);
        cb.setPadding(0, (int) (8 * dd), 0, (int) (8 * dd));
        cb.setOnCheckedChangeListener((x, on) -> { origSound = on; applyVolumes(); });
        body.addView(cb);
        if (music != null) body.addView(slider("Volum muzică", musicVol, 100, v -> { musicVol = v; applyVolumes(); }));
    }

    // ---- Filtru ----
    private void fillFilter(LinearLayout body, TextView ttl) {
        ttl.setText("Filtru pentru tot filmul");
        LinearLayout sub = chipRow(body);
        for (int i = 0; i < Look.IDS.length; i++) {
            final String id = Look.IDS[i];
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, Look.SWATCH[i]);
            g.setCornerRadius(12 * dd);
            if (id.equals(filt)) g.setStroke((int) (2.5f * dd), 0xFFFF6A2B);
            sw.setBackground(g);
            it.addView(sw, new LinearLayout.LayoutParams((int) (72 * dd), (int) (52 * dd)));
            TextView l = new TextView(this);
            l.setText(Look.NAMES[i]);
            l.setTextSize(12.5f);
            l.setTextColor(id.equals(filt) ? 0xFFF2F2F0 : 0xFFB9BCBF);
            l.setTypeface(null, id.equals(filt) ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, (int) (5 * dd), 0, 0);
            it.addView(l);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (10 * dd));
            it.setLayoutParams(lp);
            it.setOnClickListener(v -> { pushUndo(); filt = id; applyLook(); fillSheet(); });
            sub.addView(it);
        }
        title(body, "Intensitate");
        body.addView(slider("", filtK, 100, v -> { filtK = v; applyLook(); }));
    }

    interface IntSet { void set(int v); }

    private View slider(String label, int val, int max, IntSet cb) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        if (!label.isEmpty()) {
            TextView t = new TextView(this);
            t.setText(label);
            t.setTextColor(0xFFB9BCBF);
            t.setTextSize(13);
            r.addView(t);
        }
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(max);
        sb.setProgress(val);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        TextView v = new TextView(this);
        v.setText(String.valueOf(val));
        v.setTextColor(0xFFB9BCBF);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s1, int p, boolean u) { v.setText(String.valueOf(p)); cb.set(p); }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s1) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s1) { }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.addView(v);
        return r;
    }

    private void applyLook() { view.setLook(Look.of(filt, filtK)); }

    private void pickMusic() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        try { startActivityForResult(i, REQ_MUSIC); } catch (Exception e) { Toast.makeText(this, "Nu pot deschide alegerea melodiei.", Toast.LENGTH_LONG).show(); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_MUSIC && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            String n = "melodie";
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) n = c.getString(0).replaceAll("\\.[^.]+$", "");
            } catch (Exception ignored) { }
            setMusic(u, n);
        }
    }

    private void setMusic(Uri u, String name) {
        music = u;
        musicName = name;
        if (musicPlayer != null) {
            musicPlayer.stop();
            if (u != null) { musicPlayer.setMediaItem(MediaItem.fromUri(u)); musicPlayer.prepare(); }
        }
        applyVolumes();
        if ("music".equals(tool)) fillSheet();
    }

    private void applyVolumes() {
        if (player != null) player.setVolume(origSound ? 1f : 0f);
        if (musicPlayer != null) musicPlayer.setVolume(musicVol / 100f);
    }

    private void syncMusic(long g) {
        if (musicPlayer == null || music == null) return;
        boolean play = player != null && player.isPlaying();
        long md = musicPlayer.getDuration();
        if (!play) { if (musicPlayer.isPlaying()) musicPlayer.pause(); return; }
        if (md <= 0) { if (!musicPlayer.isPlaying()) musicPlayer.play(); return; }
        long want = g % md;
        if (Math.abs(musicPlayer.getCurrentPosition() - want) > 400) musicPlayer.seekTo(want);
        if (!musicPlayer.isPlaying()) musicPlayer.play();
    }

    // ---------------- cadre: împarte, mută, șterge ----------------
    private void splitAtPlayhead() {
        if (clips.isEmpty()) return;
        long g = timeline.getPos();
        int i = timeline.indexAt(g);
        Clip c = clips.get(i);
        long local = c.t.in + (g - timeline.startOf(i));
        if (local - c.t.in < 400 || c.t.out - local < 400) { Toast.makeText(this, "Mută banda mai spre mijlocul cadrului, apoi apasă „Împarte”.", Toast.LENGTH_LONG).show(); return; }
        pushUndo();
        persist = false;
        Clip n = c.copy();
        n.key = c.key + "#s" + System.currentTimeMillis();
        c.t.out = local;
        n.t.in = local;
        clips.add(i + 1, n);
        timeline.setClips(timelineClips());
        timeline.setSelected(i + 1);
        curIdx = -1;
        rebuildPlayer(g + 10);
        buildToolbar();
        setHint();
    }

    private void moveSel(int dir) {
        int i = timeline.getSelected(), j = i + dir;
        if (i < 0 || j < 0 || j >= clips.size()) return;
        pushUndo();
        Clip c = clips.remove(i);
        clips.add(j, c);
        timeline.setClips(timelineClips());
        timeline.setSelected(j);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(j) + 50);
    }

    private void deleteSel() {
        int i = timeline.getSelected();
        if (i < 0) return;
        if (clips.size() < 2) { Toast.makeText(this, "Montajul are un singur cadru, nu-l pot șterge.", Toast.LENGTH_SHORT).show(); return; }
        pushUndo();
        clips.remove(i);
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(Math.min(i, clips.size() - 1)));
        buildToolbar();
        setHint();
    }

    // ---------------- montaj automat ----------------

    private void analyze() {
        int n = srcs.size();
        for (int i = 0; i < n && !isFinishing(); i++) {
            Src sr = srcs.get(i);
            final int pct = Math.round(i * 60f / n);
            main.post(() -> setBusy("Analizez scenele " + pct + "%", "Citesc Video " + (srcs.indexOf(sr) + 1) + " din " + n));
            long d = Thumbs.duration(this, sr.prev);
            if (d <= 0) d = Thumbs.duration(this, sr.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, sr.uri);
            sr.dur = Math.max(0, d);
            sr.score = liveScore(sr, i, n);
        }
        main.post(() -> {
            if (isDestroyed() || player == null) return;
            analyzing = false;
            analyzed = true;
            setBusy("Analizez scenele 100%", "Am ales cadrele. Fac previzualizarea…");
            main.postDelayed(this::hideBusy, 500);
            Runnable r = afterAnalyze;
            afterAnalyze = null;
            if (analyzeCancelled) analyzeCancelled = false;
            else if (r != null) r.run(); else rebuildAuto();
            if (!framesStarted) { framesStarted = true; new Thread(this::loadSrcFrames).start(); }
        });
    }

    /** cât de „viu” e fiecare secundă: cât se schimbă imaginea + cât de colorată e */
    private float[] liveScore(Src sr, int idx, int n) {
        int secs = (int) Math.max(1, Math.ceil(sr.dur / 1000.0));
        float[] sc = new float[secs];
        java.util.Arrays.fill(sc, 1f);
        if (sr.dur <= 0) return sc;
        long step = Math.max(1000, sr.dur / 90);
        int samples = (int) Math.max(1, sr.dur / step);
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(this, sr.prev);
            int[] prev = null;
            float[] val = new float[samples];
            for (int k = 0; k < samples && !isFinishing(); k++) {
                long at = k * step + step / 2;
                Bitmap b = r.getScaledFrameAtTime(at * 1000, MediaMetadataRetriever.OPTION_CLOSEST, 64, 32);
                if (b == null) continue;
                int w = b.getWidth(), h = b.getHeight();
                int[] px = new int[w * h];
                b.getPixels(px, 0, w, 0, 0, w, h);
                b.recycle();
                float diff = 0, col = 0;
                for (int j = 0; j < px.length; j++) {
                    int c = px[j], rr = (c >> 16) & 255, gg = (c >> 8) & 255, bb = c & 255;
                    int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
                    col += mx - mn;
                    if (prev != null && prev.length == px.length) {
                        int p = prev[j];
                        diff += Math.abs(((p >> 16) & 255) - rr) + Math.abs(((p >> 8) & 255) - gg) + Math.abs((p & 255) - bb);
                    }
                }
                val[k] = (prev == null ? 0 : diff / px.length / 3f) + 0.25f * col / px.length;
                prev = px;
                if (k % 8 == 0) {
                    final int pct = Math.round((idx + k / (float) samples) * 60f / n);
                    main.post(() -> setBusy("Analizez scenele " + pct + "%", "Caut cele mai vii momente din Video " + (idx + 1)));
                }
            }
            if (samples > 1) val[0] = val[1];
            for (int s2 = 0; s2 < secs; s2++) {
                int k = (int) Math.min(samples - 1, (s2 * 1000L) / step);
                sc[s2] = 1 + val[k];
            }
        } catch (Throwable ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        return sc;
    }

    /** alege k bucăți de câte S secunde, cele mai vii, care nu se suprapun (ca în Regizor 360) */
    private static List<long[]> pickShots(Src sr, int k, float S) {
        List<long[]> out = new ArrayList<>();
        double D = sr.dur / 1000.0;
        if (D < S + 0.6) { if (D > 1.2) out.add(new long[]{0, sr.dur}); return out; }
        float[] sc = sr.score;
        int n = Math.max(1, Math.round(S));
        List<double[]> win = new ArrayList<>();
        for (int s0 = 0; s0 + n <= sc.length; s0++) {
            if (s0 + S > D - 0.3) break;
            double q = 0;
            for (int j = 0; j < n; j++) q += sc[s0 + j];
            win.add(new double[]{q, s0});
        }
        java.util.Collections.sort(win, (a, b) -> Double.compare(b[0], a[0]));
        List<Integer> starts = new ArrayList<>();
        for (double[] w : win) {
            if (starts.size() >= k) break;
            int s0 = (int) w[1];
            boolean ok = true;
            for (int o : starts) if (Math.abs(o - s0) < S + 0.5) { ok = false; break; }
            if (ok) starts.add(s0);
        }
        java.util.Collections.sort(starts);
        for (int s0 : starts) {
            long a = (long) (Math.max(0, s0 + 0.25) * 1000), z = (long) (Math.min(D, s0 + 0.25 + S) * 1000);
            out.add(new long[]{a, z});
        }
        return out;
    }

    private void rebuildAuto() {
        if (analyzing || player == null || isDestroyed()) return;
        float S = autoStyle.equals("fast") ? 2 : autoStyle.equals("calm") ? 5 : 3;
        List<Src> vids = new ArrayList<>();
        for (Src sr : srcs) if (sr.dur > 0) vids.add(sr);
        if (vids.isEmpty()) { hint.setText("Telefonul nu reușește să citească filmările alese. Verifică dacă e conectat cardul."); return; }
        double sum = 0;
        for (Src sr : vids) sum += sr.dur / 1000.0;
        int durS = Integer.parseInt(autoDur);
        double total = durS > 0 ? durS : sum * 0.35;
        int K = (int) Math.max(vids.size(), Math.round(total / S));
        double ws = 0;
        double[] w = new double[vids.size()];
        for (int i = 0; i < vids.size(); i++) { w[i] = Math.pow(vids.get(i).dur / 1000.0, 0.7); ws += w[i]; }
        if (player != null) player.pause();
        pushUndo();
        persist = false;
        clips.clear();
        for (int i = 0; i < vids.size(); i++) {
            Src sr = vids.get(i);
            int k = (int) Math.max(1, Math.round(K * w[i] / ws));
            for (long[] sh : pickShots(sr, k, S)) {
                Clip c = new Clip();
                c.uri = sr.uri; c.prev = sr.prev; c.is360 = sr.is360; c.name = sr.name;
                c.key = sr.key + "#" + clips.size();
                c.t.dur = sr.dur; c.t.in = sh[0]; c.t.out = sh[1];
                c.t.frames = sr.frames;
                c.durKnown = true;
                c.view = new float[]{0f, -5f, 85f, 0f};
                clips.add(c);
            }
        }
        // la stilul Relaxat începem cu Tiny Planet, ca în Regizor
        if (S >= 5 && !clips.isEmpty() && clips.get(0).is360 && clips.get(0).t.len() > 3500) clips.get(0).view = new float[]{0f, 90f, 150f, 1f};
        if (clips.isEmpty()) { hint.setText("Filmările sunt prea scurte pentru montaj. Alege „Editez eu”."); return; }
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        curIdx = -1;
        rebuildPlayer(0);
        long tot = timeline.total();
        hint.setText("Montajul tău automat: " + clips.size() + " cadre din " + vids.size() + (vids.size() == 1 ? " filmare" : " filmări") + " · " + fmt(tot)
                + ". Apasă ▶. Jos: Montaj, Template, Text, Sticker, Muzică, Filtru. Atinge un cadru pe bandă ca să-l tai, muți sau ștergi.");
        buildToolbar();
        player.play();
    }

    private void loadSrcFrames() {
        for (Src sr : srcs) {
            if (sr.dur <= 0 || isFinishing()) continue;
            int n = (int) Math.max(4, Math.min(40, sr.dur / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, sr.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * sr.dur * 1000);
                    if (sr.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
            main.post(() -> {
                sr.frames = frames;
                for (Clip c : clips) if (c.prev.equals(sr.prev)) c.t.frames = frames;
                timeline.invalidate();
            });
        }
    }

    private void loadInfo() {
        for (Clip c : clips) {
            long d = Thumbs.duration(this, c.prev);
            if (d <= 0) d = Thumbs.duration(this, c.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, c.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, c.uri);
            if (d > 0) {
                final long dd2 = d;
                main.post(() -> setDur(c, dd2));
            }
        }
        for (Clip c : new ArrayList<>(clips)) {
            long d = c.t.dur;
            for (int w = 0; w < 50 && !c.durKnown && !isFinishing(); w++) { try { Thread.sleep(200); } catch (InterruptedException ignored) { } d = c.t.dur; }
            int n = (int) Math.max(4, Math.min(40, d / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * d * 1000);
                    if (c.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                    if (i % 4 == 3 || i == n - 1) {
                        final Bitmap[] cp = frames.clone();
                        main.post(() -> { for (Clip k : clips) if (k.prev.equals(c.prev)) k.t.frames = cp; timeline.invalidate(); });
                    }
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
    }

    private void setDur(Clip c, long d) {
        if (c.durKnown || d <= 0) return;
        c.durKnown = true;
        c.t.dur = d;
        if (c.t.out <= 1 || c.t.out > d) c.t.out = d;
        if (c.t.in >= c.t.out) c.t.in = 0;
        for (Src s : srcs) if (s.prev.equals(c.prev) && s.dur <= 0) s.dur = d;
        timeline.invalidate();
    }

    private void fillDurations() {
        androidx.media3.common.Timeline tl = player.getCurrentTimeline();
        if (tl.isEmpty()) return;
        boolean any = false;
        for (int i = 0; i < clips.size() && i < tl.getWindowCount(); i++) {
            Clip c = clips.get(i);
            if (c.durKnown) continue;
            Window w = tl.getWindow(i, new Window());
            if (w.durationUs != C.TIME_UNSET && w.durationUs > 0) {
                setDur(c, c.t.in + w.durationUs / 1000);
                any = true;
            }
        }
        if (any) timeline.invalidate();
    }

    private void rebuildPlayer(long globalPos) {
        if (clips.isEmpty() || player == null) return;
        List<MediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            items.add(new MediaItem.Builder().setUri(c.prev).setClippingConfiguration(cb.build()).build());
        }
        int idx = timeline.indexAt(globalPos);
        long local = Math.max(0, globalPos - timeline.startOf(idx));
        player.setMediaItems(items, idx, local);
        player.prepare();
        applyVolumes();
    }

    private void seekGlobal(long g) {
        if (clips.isEmpty()) return;
        int i = timeline.indexAt(g);
        player.seekTo(i, Math.max(0, g - timeline.startOf(i)));
    }

    private void onClipChanged(int i) {
        Clip old = cur();
        if (old != null && old.is360) saveView(old);
        curIdx = i;
        Clip c = cur();
        if (c == null) return;
        if (!full) findViewById(R.id.modes).setVisibility(c.is360 ? View.VISIBLE : View.GONE);
        view.setFlat(!c.is360, videoAspect);
        if (c.is360) {
            view.setView(c.view[0], c.view[1], c.view[2], c.view[3] > 0);
            modeGroup.check(c.view[3] > 0 ? R.id.mPlanet : R.id.mCustom);
        }
        applyFormat();
        if (timeline.getSelected() < 0 && tool == null) setHint();
    }

    private void saveView(Clip c) {
        if (curIdx < 0 || curIdx >= clips.size() || clips.get(curIdx) != c) return;
        c.view = view.getView();
        if (!persist) return;
        edits.edit().putString(c.key + ":view", c.view[0] + "," + c.view[1] + "," + c.view[2] + "," + (c.view[3] > 0 ? "1" : "0")).apply();
    }

    private float formatRatio() {
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "16:9": return 16f / 9f;
            default: return has360() ? 16f / 9f : videoAspect;
        }
    }

    private void applyFormat() {
        btnFormat.setText((format.equals("orig") ? "Original" : format) + " ▾");
        stage.setRatio(formatRatio());
    }

    private void chooseFormat() {
        final String[] ids = {"orig", "16:9", "9:16", "1:1"};
        String[] labels = {"Original", "16:9 · YouTube, TV", "9:16 · Reels, TikTok", "1:1 · pătrat"};
        new AlertDialog.Builder(this).setTitle("Format").setItems(labels, (d, w) -> {
            format = ids[w];
            prefs.edit().putString("format", format).apply();
            applyFormat();
        }).show();
    }

    // ---------------- salvare ----------------
    private boolean has360() { for (Clip c : clips) if (c.is360) return true; return false; }

    private void askSave() {
        if (clips.isEmpty()) return;
        final String[] ids = {"720", "1080", "max"};
        boolean h = has360();
        String[] labels = {"Rapid · 720p (bun pentru WhatsApp)", "Normal · 1080p", h ? "Maxim · 1080p (filmările 360)" : "Maxim · calitatea filmării"};
        String q = prefs.getString("quality", "1080");
        int sel = q.equals("720") ? 0 : q.equals("max") ? 2 : 1;
        new AlertDialog.Builder(this).setTitle("Salvează filmul").setSingleChoiceItems(labels, sel, (d, w) -> prefs.edit().putString("quality", ids[w]).apply())
                .setPositiveButton("Salvează", (d, w) -> save())
                .setNegativeButton("Renunț", null).show();
        if (h) Toast.makeText(this, "Filmările 360 se salvează din fișierul de previzualizare de pe card (până la 1080p).", Toast.LENGTH_LONG).show();
    }

    private void save() {
        if (ExportService.running || clips.isEmpty()) { if (ExportService.running) showBusy("Fac filmul " + ExportService.progress + "%", "Un film se face deja. Te anunț când e gata.", ExportService::cancel); return; }
        player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        selOv = null;
        String q = prefs.getString("quality", "1080");
        float ratio = formatRatio();
        int shortSide = q.equals("720") ? 720 : q.equals("1080") ? 1080 : 2160;
        if (has360()) shortSide = Math.min(shortSide, 1080);
        int outW, outH;
        if (ratio >= 1f) { outH = shortSide; outW = Math.round(shortSide * ratio); } else { outW = shortSide; outH = Math.round(shortSide / ratio); }
        outW = outW / 2 * 2; outH = outH / 2 * 2;
        float[] look = Look.of(filt, filtK);
        List<Overlays.Ov> ovCopy = new ArrayList<>();
        for (Overlays.Ov o : ovs) ovCopy.add(o.copy());
        List<EditedMediaItem> items = new ArrayList<>();
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            MediaItem mi = new MediaItem.Builder().setUri(c.is360 ? c.prev : c.uri).setClippingConfiguration(cb.build()).build();
            List<Effect> fx = new ArrayList<>();
            fx.add(new ReframeEffect(c.is360, c.view, look, outW, outH));
            long g0 = timeline.startOf(i), g1 = g0 + c.t.len();
            boolean anyOv = false;
            for (Overlays.Ov o : ovCopy) if (o.a < g1 && o.b > g0) { anyOv = true; break; }
            if (anyOv) fx.add(new OverlayEffect(ImmutableList.<TextureOverlay>of(new OvEffect(ovCopy, g0, outW, outH))));
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(1f));
            items.add(new EditedMediaItem.Builder(mi).setRemoveAudio(!origSound).setEffects(new Effects(ap, fx)).build());
        }
        Composition.Builder cbld;
        if (music != null) {
            List<AudioProcessor> ap = new ArrayList<>();
            ap.add(stereo(musicVol / 100f));
            EditedMediaItem mus = new EditedMediaItem.Builder(MediaItem.fromUri(music)).setRemoveVideo(true)
                    .setEffects(new Effects(ap, new ArrayList<Effect>())).build();
            List<EditedMediaItem> ml = new ArrayList<>();
            ml.add(mus);
            cbld = new Composition.Builder(new EditedMediaItemSequence(items), new EditedMediaItemSequence(ml, true));
        } else cbld = new Composition.Builder(new EditedMediaItemSequence(items));
        Composition comp = cbld.experimentalSetForceAudioTrack(true).build();
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7);
        ExportService.ui = exportUi;
        ExportService.start(this, comp);
        showBusy("Fac filmul 0%", "Poți ieși din aplicație: filmul se face mai departe și te anunț în notificări când e gata.", ExportService::cancel);
    }

    private final ExportService.UI exportUi = new ExportService.UI() {
        @Override public void progress(int p) { main.post(() -> setBusy(p >= 100 ? "Gata 100%" : "Fac filmul " + p + "%", p >= 100 ? "Pun filmul în Galerie…" : null)); }
        @Override public void done(Uri u) { main.post(() -> { hideBusy(); showSaved(u); }); }
        @Override public void error(String msg) {
            main.post(() -> {
                hideBusy();
                new AlertDialog.Builder(EditorActivity.this).setTitle("Nu am putut face filmul").setMessage(msg).setPositiveButton("Bine", null).show();
            });
        }
    };

    private void showSaved(Uri done) {
        if (isFinishing() || isDestroyed()) return;
        new AlertDialog.Builder(this)
                .setTitle("Gata! Filmul e salvat")
                .setMessage("Îl găsești în Galerie, în albumul Director360.")
                .setPositiveButton("Deschide", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(done, "video/mp4");
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(i); } catch (Exception ignored) { }
                })
                .setNeutralButton("Trimite", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("video/mp4");
                    i.putExtra(Intent.EXTRA_STREAM, done);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(i, "Trimite filmul")); } catch (Exception ignored) { }
                })
                .setNegativeButton("Închide", null)
                .show();
    }

    private static AudioProcessor stereo(float gain) {
        androidx.media3.common.audio.ChannelMixingAudioProcessor m = new androidx.media3.common.audio.ChannelMixingAudioProcessor();
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(1, 2).scaleBy(gain));
        m.putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(2, 2).scaleBy(gain));
        return m;
    }

    // ---- ecranul de lucru (ca în Regizor 360): inelul care se rotește, titlu, explicație, Anulează ----
    private View busy;
    private TextView busyTitle, busySub;
    private Runnable busyCancel;

    private void showBusy(String title, String sub, Runnable onCancel) {
        busyCancel = onCancel;
        if (busy == null) {
            float dd = getResources().getDisplayMetrics().density;
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(android.view.Gravity.CENTER);
            box.setBackgroundColor(0xEB0C0D0F);
            box.setClickable(true);
            box.setElevation(30 * dd);
            LoaderView lv = new LoaderView(this);
            box.addView(lv, new LinearLayout.LayoutParams((int) (150 * dd), (int) (150 * dd)));
            busyTitle = new TextView(this);
            busyTitle.setTextColor(0xFFF2F2F0);
            busyTitle.setTextSize(26);
            busyTitle.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD));
            busyTitle.setGravity(android.view.Gravity.CENTER);
            busyTitle.setPadding((int) (20 * dd), (int) (18 * dd), (int) (20 * dd), 0);
            box.addView(busyTitle);
            busySub = new TextView(this);
            busySub.setTextColor(0xFFB9BCBF);
            busySub.setTextSize(15);
            busySub.setGravity(android.view.Gravity.CENTER);
            busySub.setPadding((int) (28 * dd), (int) (10 * dd), (int) (28 * dd), (int) (22 * dd));
            box.addView(busySub);
            TextView cancel = new TextView(this);
            cancel.setText("Anulează");
            cancel.setTextColor(0xFFF2F2F0);
            cancel.setTextSize(17);
            cancel.setTypeface(null, android.graphics.Typeface.BOLD);
            cancel.setGravity(android.view.Gravity.CENTER);
            cancel.setBackgroundResource(R.drawable.pill_bg);
            cancel.setOnClickListener(v -> { Runnable r = busyCancel; hideBusy(); if (r != null) r.run(); });
            box.addView(cancel, new LinearLayout.LayoutParams((int) (170 * dd), (int) (54 * dd)));
            addContentView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            busy = box;
        }
        busy.setVisibility(View.VISIBLE);
        busy.setAlpha(0f);
        busy.animate().alpha(1f).setDuration(200).start();
        setBusy(title, sub);
    }

    private void setBusy(String title, String sub) {
        if (busyTitle == null) return;
        if (title != null) busyTitle.setText(title);
        if (sub != null) busySub.setText(sub);
    }

    private void hideBusy() { if (busy != null) busy.setVisibility(View.GONE); }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        if (musicPlayer != null) musicPlayer.pause();
        Clip c = cur();
        if (c != null && c.is360) saveView(c);
        if (view != null) view.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (view != null) view.onResume();
        ExportService.ui = exportUi;
        if (ExportService.running) showBusy("Fac filmul " + ExportService.progress + "%", "Poți ieși din aplicație: filmul se face mai departe și te anunț în notificări când e gata.", ExportService::cancel);
        else if (ExportService.doneUri != null) { Uri u = ExportService.doneUri; ExportService.doneUri = null; hideBusy(); showSaved(u); }
        else if (ExportService.doneErr != null) { String e = ExportService.doneErr; ExportService.doneErr = null; hideBusy(); exportUi.error(e); }
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (ExportService.ui == exportUi) ExportService.ui = null;
        if (player != null) { player.release(); player = null; }
        if (musicPlayer != null) { musicPlayer.release(); musicPlayer = null; }
        if (view != null) view.release();
        super.onDestroy();
    }
}
