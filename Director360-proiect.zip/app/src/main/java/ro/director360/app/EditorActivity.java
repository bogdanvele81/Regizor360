package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.Player;
import androidx.media3.common.Timeline.Window;
import androidx.media3.common.VideoSize;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.effect.Presentation;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Editorul ca la Insta360: imaginea sus, banda cu filmele jos, butonul galben de salvare. */
public class EditorActivity extends AppCompatActivity {

    /** o filmare din montaj */
    static class Clip {
        Uri uri, prev;
        String name, key;
        boolean is360;
        float[] view = {0f, 0f, 80f, 0f};
        final Timeline.Clip t = new Timeline.Clip();
        boolean durKnown = false;
    }

    private final List<Clip> clips = new ArrayList<>();
    private ExoPlayer player;
    private Video360View view;
    private AspectFrame stage;
    private Timeline timeline;
    private TextView time, hint;
    private MaterialButton btnPlay, btnFormat;
    private MaterialButtonToggleGroup modeGroup;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences edits, prefs;
    private Transformer transformer;
    private AlertDialog progressDlg;
    private TextView progressText;
    private int curIdx = -1;
    private float videoAspect = 16f / 9f;
    private String format = "16:9";

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null && !clips.isEmpty()) {
                int i = player.getCurrentMediaItemIndex();
                long g = timeline.startOf(i) + Math.max(0, player.getCurrentPosition());
                timeline.setPos(g);
                time.setText(fmt(timeline.getPos()) + " / " + fmt(timeline.total()));
                if (i != curIdx) onClipChanged(i);
                fillDurations();
            }
            main.postDelayed(this, 60);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_editor);
        edits = getSharedPreferences("edits", MODE_PRIVATE);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        String[] uris = getIntent().getStringArrayExtra("uris");
        String[] lrvs = getIntent().getStringArrayExtra("lrvs");
        String[] names = getIntent().getStringArrayExtra("names");
        String[] keys = getIntent().getStringArrayExtra("keys");
        if (uris == null || uris.length == 0) { finish(); return; }
        for (int i = 0; i < uris.length; i++) {
            Clip c = new Clip();
            c.uri = Uri.parse(uris[i]);
            c.name = names[i];
            c.key = keys[i];
            c.is360 = c.name.toLowerCase().endsWith(".insv");
            c.prev = (lrvs != null && lrvs[i] != null && !lrvs[i].isEmpty()) ? Uri.parse(lrvs[i]) : c.uri;
            if (c.is360 && c.prev == c.uri) c.is360 = false; // fără fișierul mic nu pot afișa 360
            String sv = edits.getString(c.key + ":view", null);
            if (sv != null) try { String[] q = sv.split(","); c.view = new float[]{Float.parseFloat(q[0]), Float.parseFloat(q[1]), Float.parseFloat(q[2]), q[3].equals("1") ? 1f : 0f}; } catch (Exception ignored) { }
            clips.add(c);
        }

        stage = findViewById(R.id.stage);
        timeline = findViewById(R.id.timeline);
        time = findViewById(R.id.time);
        hint = findViewById(R.id.hint);
        btnPlay = findViewById(R.id.btnPlay);
        btnFormat = findViewById(R.id.btnFormat);
        modeGroup = findViewById(R.id.modeGroup);

        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        player = new ExoPlayer.Builder(this).build();
        view.setOnSurface(s -> { if (player != null) player.setVideoSurface(s); });
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { btnPlay.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play); }
            @Override public void onVideoSizeChanged(VideoSize v) {
                if (v.width > 0 && v.height > 0) {
                    videoAspect = v.width * v.pixelWidthHeightRatio / v.height;
                    Clip c = cur();
                    view.setFlat(c == null || !c.is360, videoAspect);
                    applyFormat();
                }
            }
            @Override public void onPlaybackStateChanged(int st) {
                if (st == Player.STATE_ENDED) { player.pause(); player.seekTo(0, 0); }
            }
        });

        format = prefs.getString("format", "16:9");
        btnFormat.setOnClickListener(v -> chooseFormat());
        modeGroup.addOnButtonCheckedListener((g, id, checked) -> {
            if (!checked) return;
            Clip c = cur();
            if (c == null || !c.is360) return;
            boolean planet = id == R.id.mPlanet;
            if (planet != view.isPlanet()) view.setPlanet(planet);
            saveView(c);
        });
        findViewById(R.id.btnLevel).setOnClickListener(v -> { view.resetView(); modeGroup.check(R.id.mCustom); Clip c = cur(); if (c != null) saveView(c); });
        btnPlay.setOnClickListener(v -> { if (player.isPlaying()) player.pause(); else { if (timeline.getPos() >= timeline.total() - 150) seekGlobal(0); player.play(); } });
        findViewById(R.id.btnStart).setOnClickListener(v -> { player.pause(); seekGlobal(0); });
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> askSave());
        findViewById(R.id.tLeft).setOnClickListener(v -> moveSel(-1));
        findViewById(R.id.tRight).setOnClickListener(v -> moveSel(1));
        findViewById(R.id.tDel).setOnClickListener(v -> deleteSel());

        timeline.setListener(new Timeline.Listener() {
            @Override public void onScrub(long g, boolean done) { if (player.isPlaying()) player.pause(); seekGlobal(g); }
            @Override public void onSelect(int i) { showTools(i >= 0); if (i >= 0) seekGlobal(timeline.startOf(i) + 50); }
            @Override public void onTrim(int i, boolean left, boolean done) {
                if (player.isPlaying()) player.pause();
                Clip c = clips.get(i);
                if (done) {
                    edits.edit().putString(c.key, c.t.in + "," + c.t.out).apply();
                    rebuildPlayer(timeline.startOf(i) + (left ? 0 : c.t.len() - 300));
                } else {
                    // arată cadrul de la capătul tras
                    if (player.getCurrentMediaItemIndex() == i) {
                        long local = left ? 0 : Math.max(0, c.t.len() - 50);
                        player.seekTo(i, local);
                    }
                }
            }
        });

        // durate și poze pentru bandă, pe un fir separat
        for (Clip c : clips) {
            String s = edits.getString(c.key, null);
            if (s != null) try { String[] p = s.split(","); c.t.in = Long.parseLong(p[0]); c.t.out = Long.parseLong(p[1]); } catch (Exception ignored) { }
        }
        timeline.setClips(timelineClips());
        new Thread(this::loadInfo).start();
        hint.setText(clips.size() > 1 ? "Tragi banda ca să mergi prin filme. Atinge o filmare ca s-o tai din capete sau s-o muți." : "Tragi banda ca să mergi prin film. Atinge filmarea ca s-o tai din capete.");
        rebuildPlayer(0);
        main.post(tick);
    }

    private List<Timeline.Clip> timelineClips() { List<Timeline.Clip> l = new ArrayList<>(); for (Clip c : clips) l.add(c.t); return l; }

    private Clip cur() { return curIdx >= 0 && curIdx < clips.size() ? clips.get(curIdx) : null; }

    private void loadInfo() {
        for (Clip c : clips) {
            long d = Thumbs.duration(this, c.prev);
            if (d <= 0) d = Thumbs.duration(this, c.uri);
            if (d <= 0) d = Mp4Info.durationMs(this, c.prev);
            if (d <= 0) d = Mp4Info.durationMs(this, c.uri);
            if (d > 0) {
                final long dd = d;
                main.post(() -> setDur(c, dd));
            }
        }
        for (Clip c : clips) {
            long d = c.t.dur;
            for (int w = 0; w < 50 && !c.durKnown && !isFinishing(); w++) { try { Thread.sleep(200); } catch (InterruptedException ignored) { } d = c.t.dur; }
            int n = (int) Math.max(4, Math.min(40, d / 2000));
            Bitmap[] frames = new Bitmap[n];
            MediaMetadataRetriever r = new MediaMetadataRetriever();
            try {
                r.setDataSource(this, c.prev);
                for (int i = 0; i < n && !isFinishing(); i++) {
                    long at = (long) ((i + 0.5) / n * d * 1000);
                    if (c.is360) {
                        Bitmap sb = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
                        frames[i] = sb == null ? null : Thumbs.reframe(sb, 120, 80, 110f);
                    } else frames[i] = r.getScaledFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 120, 80);
                    if (i % 4 == 3 || i == n - 1) { final Bitmap[] cp = frames.clone(); main.post(() -> { c.t.frames = cp; timeline.invalidate(); }); }
                }
            } catch (Throwable ignored) {
            } finally {
                try { r.release(); } catch (Exception ignored) { }
            }
        }
    }

    private void setDur(Clip c, long d) {
        if (c.durKnown || d <= 0) return;
        c.durKnown = true;
        c.t.dur = d;
        if (c.t.out <= 1 || c.t.out > d) c.t.out = d;
        if (c.t.in >= c.t.out) c.t.in = 0;
        timeline.invalidate();
    }

    /** dacă telefonul n-a dat durata, o iau de la player */
    private void fillDurations() {
        androidx.media3.common.Timeline tl = player.getCurrentTimeline();
        if (tl.isEmpty()) return;
        boolean any = false;
        for (int i = 0; i < clips.size() && i < tl.getWindowCount(); i++) {
            Clip c = clips.get(i);
            if (c.durKnown) continue;
            Window w = tl.getWindow(i, new Window());
            if (w.durationUs != C.TIME_UNSET && w.durationUs > 0) {
                long full = c.t.in + w.durationUs / 1000; // fereastra e deja tăiată la început
                setDur(c, full);
                any = true;
            }
        }
        if (any) timeline.invalidate();
    }

    private void rebuildPlayer(long globalPos) {
        List<MediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            items.add(new MediaItem.Builder().setUri(c.prev).setClippingConfiguration(cb.build()).build());
        }
        int idx = timeline.indexAt(globalPos);
        long local = Math.max(0, globalPos - timeline.startOf(idx));
        player.setMediaItems(items, idx, local);
        player.prepare();
    }

    private void seekGlobal(long g) {
        int i = timeline.indexAt(g);
        player.seekTo(i, Math.max(0, g - timeline.startOf(i)));
    }

    private void onClipChanged(int i) {
        Clip old = cur();
        if (old != null && old.is360) saveView(old);
        curIdx = i;
        Clip c = cur();
        if (c == null) return;
        findViewById(R.id.modes).setVisibility(c.is360 ? View.VISIBLE : View.GONE);
        view.setFlat(!c.is360, videoAspect);
        if (c.is360) {
            view.setView(c.view[0], c.view[1], c.view[2], c.view[3] > 0);
            modeGroup.check(c.view[3] > 0 ? R.id.mPlanet : R.id.mCustom);
        }
        applyFormat();
    }

    private void saveView(Clip c) {
        if (curIdx < 0 || clips.get(curIdx) != c) return;
        c.view = view.getView();
        edits.edit().putString(c.key + ":view", c.view[0] + "," + c.view[1] + "," + c.view[2] + "," + (c.view[3] > 0 ? "1" : "0")).apply();
    }

    private float formatRatio() {
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "orig": return videoAspect;
            default: return 16f / 9f;
        }
    }

    private void applyFormat() {
        btnFormat.setText((format.equals("orig") ? "Original" : format) + " ▾");
        stage.setRatio(formatRatio());
    }

    private void chooseFormat() {
        final String[] ids = {"16:9", "9:16", "1:1", "orig"};
        String[] labels = {"16:9 · YouTube, TV", "9:16 · Reels, TikTok", "1:1 · pătrat", "Original"};
        new AlertDialog.Builder(this).setTitle("Format").setItems(labels, (d, w) -> {
            format = ids[w];
            prefs.edit().putString("format", format).apply();
            applyFormat();
        }).show();
    }

    private void showTools(boolean clipSel) {
        findViewById(R.id.toolsHint).setVisibility(clipSel ? View.GONE : View.VISIBLE);
        findViewById(R.id.clipTools).setVisibility(clipSel ? View.VISIBLE : View.GONE);
        boolean many = clips.size() > 1;
        findViewById(R.id.tLeft).setEnabled(many);
        findViewById(R.id.tRight).setEnabled(many);
        findViewById(R.id.tDel).setEnabled(many);
    }

    private void moveSel(int dir) {
        int i = timeline.getSelected(), j = i + dir;
        if (i < 0 || j < 0 || j >= clips.size()) return;
        Clip c = clips.remove(i);
        clips.add(j, c);
        timeline.setClips(timelineClips());
        timeline.setSelected(j);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(j) + 50);
    }

    private void deleteSel() {
        int i = timeline.getSelected();
        if (i < 0 || clips.size() < 2) return;
        clips.remove(i);
        timeline.setClips(timelineClips());
        timeline.setSelected(-1);
        showTools(false);
        curIdx = -1;
        rebuildPlayer(timeline.startOf(Math.min(i, clips.size() - 1)));
    }

    // ---------------- salvare ----------------

    private void askSave() {
        for (Clip c : clips) if (c.is360) {
            new AlertDialog.Builder(this).setTitle("Salvarea 360 vine în curând")
                    .setMessage("Montajul are filmări 360. Salvarea lor cu cadrul ales vine în etapa următoare. Acum se pot salva filmările normale.")
                    .setPositiveButton("Bine", null).show();
            return;
        }
        final String[] ids = {"720", "1080", "max"};
        String[] labels = {"Rapid · 720p (bun pentru WhatsApp)", "Normal · 1080p", "Maxim · calitatea filmării"};
        String q = prefs.getString("quality", "1080");
        int sel = q.equals("720") ? 0 : q.equals("max") ? 2 : 1;
        new AlertDialog.Builder(this).setTitle("Salvează filmul").setSingleChoiceItems(labels, sel, (d, w) -> prefs.edit().putString("quality", ids[w]).apply())
                .setPositiveButton("Salvează", (d, w) -> save())
                .setNegativeButton("Renunț", null).show();
    }

    private void save() {
        if (transformer != null) return;
        player.pause();
        String q = prefs.getString("quality", "1080");
        float ratio = formatRatio();
        List<Effect> fx = new ArrayList<>();
        fx.add(Presentation.createForAspectRatio(ratio, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP));
        int shortSide = q.equals("720") ? 720 : q.equals("1080") ? 1080 : 2160;
        int outH = ratio >= 1f ? shortSide : Math.round(shortSide / ratio);
        fx.add(Presentation.createForHeight(outH / 2 * 2));
        List<EditedMediaItem> items = new ArrayList<>();
        for (Clip c : clips) {
            MediaItem.ClippingConfiguration.Builder cb = new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.t.in);
            if (c.durKnown && c.t.out < c.t.dur) cb.setEndPositionMs(c.t.out);
            MediaItem mi = new MediaItem.Builder().setUri(c.uri).setClippingConfiguration(cb.build()).build();
            items.add(new EditedMediaItem.Builder(mi).setEffects(new Effects(new ArrayList<AudioProcessor>(), fx)).build());
        }
        Composition comp = new Composition.Builder(new EditedMediaItemSequence(items)).build();
        final File out = new File(getCacheDir(), "director360_" + System.currentTimeMillis() + ".mp4");
        transformer = new Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(new Transformer.Listener() {
                    @Override public void onCompleted(Composition composition, ExportResult result) {
                        transformer = null;
                        setProgressText("Pun filmul în Galerie…");
                        new Thread(() -> publish(out)).start();
                    }

                    @Override public void onError(Composition composition, ExportResult result, ExportException e) {
                        transformer = null;
                        if (progressDlg != null) progressDlg.dismiss();
                        out.delete();
                        new AlertDialog.Builder(EditorActivity.this)
                                .setTitle("Nu am putut face filmul")
                                .setMessage("Încearcă din nou sau alege calitatea „Rapid 720p”.\n\n(cod " + e.errorCode + ")")
                                .setPositiveButton("Bine", null)
                                .show();
                    }
                })
                .build();
        showProgress();
        try {
            transformer.start(comp, out.getAbsolutePath());
        } catch (Throwable e) {
            transformer = null;
            if (progressDlg != null) progressDlg.dismiss();
            Toast.makeText(this, "Nu am putut porni salvarea: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }
        final ProgressHolder ph = new ProgressHolder();
        main.post(new Runnable() {
            @Override public void run() {
                if (transformer == null) return;
                if (transformer.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) setProgressText("Fac filmul… " + ph.progress + "%");
                main.postDelayed(this, 400);
            }
        });
    }

    private void showProgress() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);
        box.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        progressText = new TextView(this);
        progressText.setText("Pregătesc filmul…");
        progressText.setTextSize(17);
        progressText.setTextColor(0xFFF2F2F0);
        progressText.setPadding(0, pad / 2, 0, 0);
        box.addView(pb);
        box.addView(progressText);
        progressDlg = new AlertDialog.Builder(this)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Oprește", (d, w) -> { if (transformer != null) { transformer.cancel(); transformer = null; } })
                .show();
    }

    private void setProgressText(String s) { if (progressText != null) progressText.setText(s); }

    /** pune filmul în Galerie › Movies › Director360 */
    private void publish(File f) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".mp4";
            v.put(MediaStore.Video.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Director360");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) throw new Exception("nu pot crea fișierul");
            try (InputStream in = new FileInputStream(f); OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) throw new Exception("nu pot scrie");
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            }
            v.clear();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            f.delete();
            final Uri done = dst;
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                new AlertDialog.Builder(this)
                        .setTitle("Gata! Filmul e salvat")
                        .setMessage("Îl găsești în Galerie, în albumul Director360.")
                        .setPositiveButton("Deschide", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(done, "video/mp4");
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(i); } catch (Exception ignored) { }
                        })
                        .setNeutralButton("Trimite", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_SEND);
                            i.setType("video/mp4");
                            i.putExtra(Intent.EXTRA_STREAM, done);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            try { startActivity(Intent.createChooser(i, "Trimite filmul")); } catch (Exception ignored) { }
                        })
                        .setNegativeButton("Închide", null)
                        .show();
            });
        } catch (Throwable e) {
            final String msg = e.getMessage();
            main.post(() -> {
                if (progressDlg != null) progressDlg.dismiss();
                Toast.makeText(this, "Nu am putut salva filmul: " + msg, Toast.LENGTH_LONG).show();
            });
        }
    }

    private static String fmt(long ms) {
        if (ms < 0) ms = 0;
        long s = ms / 1000;
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }

    @Override protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
        Clip c = cur();
        if (c != null && c.is360) saveView(c);
        if (view != null) view.onPause();
    }

    @Override protected void onResume() { super.onResume(); if (view != null) view.onResume(); }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        if (transformer != null) { transformer.cancel(); transformer = null; }
        if (player != null) { player.release(); player = null; }
        if (view != null) view.release();
        super.onDestroy();
    }
}
