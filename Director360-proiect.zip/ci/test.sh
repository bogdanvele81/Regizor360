#!/bin/bash
# Proba automată: pornește Director360 pe un telefon virtual, face poze la ecran și caută erori.
# Problemele de infrastructură NU opresc construirea; doar o eroare a aplicației o oprește.
APK="$1"
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
OUT="$REPO/director-test"
PKG=ro.director360.app
rm -rf "$OUT"; mkdir -p "$OUT"
log(){ echo "[proba] $*"; echo "$*" >> "$OUT/pasi.txt"; }
SDK="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"; AVDM="$SDK/cmdline-tools/latest/bin/avdmanager"
[ -x "$SDKM" ] || { SDKM=$(ls "$SDK"/cmdline-tools/*/bin/sdkmanager | head -1); AVDM=$(dirname "$SDKM")/avdmanager; }
ADB="$SDK/platform-tools/adb"

publish(){
  cd "$REPO" || return
  git config user.name "build-bot"; git config user.email "build-bot@users.noreply.github.com"
  git add -f director-test >/dev/null 2>&1
  git commit -q -m "Proba Director360 pe telefon virtual [skip ci]" && git push -q || log "nu pot urca rezultatele"
}

if [ ! -e /dev/kvm ]; then log "fără KVM: sar peste probă"; publish; exit 0; fi
sudo chmod 666 /dev/kvm || true
IMG="system-images;android-34;google_apis;x86_64"
export ANDROID_AVD_HOME="$HOME/.android/avd"; mkdir -p "$ANDROID_AVD_HOME"
yes | "$SDKM" --sdk_root="$SDK" --licenses > /dev/null 2>&1
"$SDKM" --sdk_root="$SDK" --install emulator platform-tools "$IMG" > "$OUT/sdk.txt" 2>&1 || { log "nu pot instala telefonul virtual"; tail -20 "$OUT/sdk.txt"; publish; exit 0; }
echo no | "$AVDM" create avd -n proba -k "$IMG" --force > "$OUT/avd.txt" 2>&1
ls "$ANDROID_AVD_HOME" >> "$OUT/avd.txt" 2>&1
"$SDK/emulator/emulator" -avd proba -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader_indirect -memory 3072 > "$OUT/emulator.txt" 2>&1 &
timeout 300 "$ADB" wait-for-device || { log "telefonul virtual nu pornește"; publish; exit 0; }
ok=0
for i in $(seq 1 100); do [ "$("$ADB" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && { ok=1; break; }; sleep 3; done
[ $ok = 1 ] || { log "telefonul virtual nu a terminat pornirea"; publish; exit 0; }
"$ADB" shell settings put global window_animation_scale 0
"$ADB" shell settings put global transition_animation_scale 0
"$ADB" shell settings put global animator_duration_scale 0
"$ADB" shell input keyevent 82
log "telefon virtual pornit (Android 14)"

"$ADB" install -r -g "$APK" > "$OUT/instalare.txt" 2>&1 || { log "INSTALAREA A EȘUAT"; cat "$OUT/instalare.txt"; publish; exit 1; }
log "instalat"
"$ADB" logcat -c

shot(){ sleep "${2:-3}"; "$ADB" exec-out screencap -p > "$OUT/$1.png"; log "poză: $1"; }
start(){ "$ADB" shell am force-stop $PKG; "$ADB" shell am start -W -n $PKG/.MainActivity "$@" > /dev/null; }
alive(){ "$ADB" shell pidof $PKG > /dev/null; }
tap_text(){
  "$ADB" shell uiautomator dump /sdcard/u.xml > /dev/null 2>&1; "$ADB" pull /sdcard/u.xml /tmp/u.xml > /dev/null 2>&1
  xy=$(python3 - "$1" <<'P'
import re,sys,html
t=sys.argv[1].lower(); s=open('/tmp/u.xml',encoding='utf8').read()
best=None
for m in re.finditer(r'<node [^>]*>',s):
    n=m.group(0)
    tx=html.unescape((re.search(r' text="([^"]*)"',n) or [None,''])[1]).lower()
    cd=html.unescape((re.search(r'content-desc="([^"]*)"',n) or [None,''])[1]).lower()
    b=re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"',n)
    if not b: continue
    x1,y1,x2,y2=map(int,b.groups()); xy="%d %d"%((x1+x2)//2,(y1+y2)//2)
    if tx==t or cd==t: best=xy; break
    if best is None and (t in tx or t in cd): best=xy
if best: print(best)
P
)
  if [ -n "$xy" ]; then "$ADB" shell input tap $xy; log "atins: $1"; else log "nu găsesc pe ecran: $1"; fi
}

# 1. pornire fără nimic
start; shot 01-pornire 0.8; shot 01-pornire-b 1; shot 01-pornire-c 1; shot 01-pornire-d 1.2; shot 02-acasa 4.5
alive || log "APLICAȚIA S-A OPRIT LA PORNIRE"
tap_text "Filmări"; shot 03-filmari 2
tap_text "Poze"; shot 04-poze 2
tap_text "Ajutor"; shot 05-ajutor 2; "$ADB" shell input keyevent 4
tap_text "Cameră"; shot 06-camera 2; "$ADB" shell input keyevent 4

# 2. fișiere de probă: filmări normale cu sunet, o filmare 360 (cu fișierul mic LRV), poze
start --ez ciTest true; sleep 3
command -v ffmpeg > /dev/null || { sudo apt-get update -qq > /dev/null 2>&1; sudo apt-get install -y -qq ffmpeg > /dev/null 2>&1; }
T=/tmp/media; rm -rf $T; mkdir -p $T
if command -v ffmpeg > /dev/null; then
  F="ffmpeg -loglevel error -y"
  $F -f lavfi -i testsrc2=size=1920x1080:rate=30 -f lavfi -i sine=frequency=440 -t 12 -pix_fmt yuv420p -c:v libx264 -c:a aac -shortest $T/VID_20260905_130400_00_001.mp4
  $F -f lavfi -i "mandelbrot=size=1280x720:rate=30" -f lavfi -i sine=frequency=660 -t 10 -pix_fmt yuv420p -c:v libx264 -c:a aac -shortest $T/VID_20260904_120000_00_002.mp4
  $F -f lavfi -i "testsrc2=size=1920x960:rate=30" -f lavfi -i sine=frequency=330 -t 10 -vf "v360=input=e:output=dfisheye:ih_fov=360:iv_fov=180:h_fov=197:v_fov=197,format=yuv420p" -c:v libx264 -c:a aac -shortest $T/VID_20260905_130700_00_005.insv || log "nu pot face filmarea 360 de probă"
  cp $T/VID_20260905_130700_00_005.insv $T/LRV_20260905_130700_01_005.lrv
  $F -f lavfi -i "testsrc2=size=4000x2000" -frames:v 1 -vf "v360=input=e:output=dfisheye:h_fov=197:v_fov=197" -f image2 $T/IMG_20260905_130500_00_003.insp || log "nu pot face poza 360 de probă"
  $F -f lavfi -i smptebars=size=1600x1200 -frames:v 1 $T/IMG_20260905_130600.jpg
  ls -la $T >> "$OUT/pasi.txt"
else log "fără ffmpeg: fără fișiere de probă"; fi
DST=/sdcard/Android/data/$PKG/files
"$ADB" shell mkdir -p $DST
for f in $T/*; do "$ADB" push "$f" $DST/ > /dev/null 2>&1 || log "nu pot pune $f"; done
start --ez ciTest true; shot 07-lista 6
alive || log "APLICAȚIA S-A OPRIT CU LISTA"
tap_text "Poze"; shot 08-lista-poze 2
tap_text "Filmări"; shot 09-lista-filmari 2
start --ez ciTest true --es ciOpen select; shot 10-alese 5

# 3. editor „Editez eu” cu filmările
start --ez ciTest true --es ciOpen video; shot 11-editor 8
alive || log "APLICAȚIA S-A OPRIT ÎN EDITOR"
tap_text "Pornește"; shot 12-editor-play 3

# 4. montaj automat (Gata), filtru, salvare
"$ADB" shell rm -rf /sdcard/Movies/Director360 > /dev/null 2>&1
start --ez ciTest true --es ciOpen auto; shot 13-montaj 20
alive || log "APLICAȚIA S-A OPRIT LA MONTAJUL AUTOMAT"
tap_text "Montaj"; shot 14-montaj-foaie 2
tap_text "Gata"; sleep 1
tap_text "Filtru"; shot 15-filtru 2
tap_text "Viu"; shot 16-filtru-viu 2
tap_text "Gata"; sleep 1
tap_text "Template"; shot 17-template 3
tap_text "Road Trip"; sleep 1
tap_text "Folosește șablonul"; shot 18-template-folosit 6
tap_text "Text"; shot 19-text 3
tap_text "Vlog"; shot 20-text-vlog 2
tap_text "Gata"; sleep 1
tap_text "Sticker"; shot 21-sticker 2
tap_text "🔥"; shot 22-sticker-pus 2
tap_text "Gata"; sleep 1
tap_text "Salvează"; sleep 2
tap_text "Salvează"; shot 23-salvez 15
for i in $(seq 1 20); do "$ADB" shell ls /sdcard/Movies/Director360 2>/dev/null | grep -q mp4 && break; sleep 5; done
shot 24-salvat 2
SAVED=$("$ADB" shell ls -l /sdcard/Movies/Director360 2>/dev/null)
log "fișiere salvate: $SAVED"
F1=$("$ADB" shell ls /sdcard/Movies/Director360 2>/dev/null | tr -d '\r' | head -1)
if [ -n "$F1" ]; then
  "$ADB" pull "/sdcard/Movies/Director360/$F1" /tmp/salvat.mp4 > /dev/null 2>&1
  if command -v ffprobe > /dev/null; then ffprobe -v error -show_entries format=duration:stream=codec_type,width,height -of compact /tmp/salvat.mp4 >> "$OUT/pasi.txt" 2>&1; fi
  for k in 0.5 1.5 3 6; do ffmpeg -loglevel error -y -ss $k -i /tmp/salvat.mp4 -frames:v 1 -vf scale=480:-2 "$OUT/salvat-$k.png" 2>/dev/null; done
else log "NU S-A SALVAT NICIUN FILM"; fi

# 5. poza 360 și poza normală
start --ez ciTest true --es ciOpen photo360; shot 25-poza360 6
alive || log "APLICAȚIA S-A OPRIT LA POZA 360"
start --ez ciTest true --es ciOpen photo; shot 26-poza 5

# erori
"$ADB" logcat -d -b crash > "$OUT/erori.txt" 2>&1
"$ADB" logcat -d -t 4000 > "$OUT/jurnal.txt" 2>&1
if grep -q "$PKG" "$OUT/erori.txt"; then
  log "EROARE ÎN APLICAȚIE (vezi erori.txt)"
  echo "===== EROARE APLICAȚIE ====="; grep -A 40 "FATAL EXCEPTION" "$OUT/erori.txt" | head -150
  publish; exit 1
fi
: > "$OUT/erori.txt"
log "fără erori"
publish
exit 0
