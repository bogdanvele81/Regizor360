#!/bin/bash
# Proba automată: pornește Director360 pe un telefon virtual, face poze la ecran și caută erori.
# Problemele de infrastructură NU opresc construirea; doar o eroare a aplicației o oprește.
APK="$1"
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
OUT="$REPO/director-test"
PKG=ro.director360.app
rm -rf "$OUT"; mkdir -p "$OUT"
log(){ echo "[proba] $*"; echo "$*" >> "$OUT/pasi.txt"; }
SDK="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"; AVDM="$SDK/cmdline-tools/latest/bin/avdmanager"
[ -x "$SDKM" ] || { SDKM=$(ls "$SDK"/cmdline-tools/*/bin/sdkmanager | head -1); AVDM=$(dirname "$SDKM")/avdmanager; }
ADB="$SDK/platform-tools/adb"

publish(){
  cd "$REPO" || return
  git config user.name "build-bot"; git config user.email "build-bot@users.noreply.github.com"
  git add -f director-test >/dev/null 2>&1
  git commit -q -m "Proba Director360 pe telefon virtual [skip ci]" && git push -q || log "nu pot urca rezultatele"
}

if [ ! -e /dev/kvm ]; then log "fără KVM: sar peste probă"; publish; exit 0; fi
sudo chmod 666 /dev/kvm || true
IMG="system-images;android-34;google_apis;x86_64"
yes | "$SDKM" --install emulator platform-tools "$IMG" > /dev/null 2>&1 || { log "nu pot instala telefonul virtual"; publish; exit 0; }
echo no | "$AVDM" create avd -n proba -k "$IMG" -d pixel_6 --force > /dev/null 2>&1
"$SDK/emulator/emulator" -avd proba -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader_indirect -memory 3072 > "$OUT/emulator.txt" 2>&1 &
timeout 300 "$ADB" wait-for-device || { log "telefonul virtual nu pornește"; publish; exit 0; }
ok=0
for i in $(seq 1 100); do [ "$("$ADB" shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = 1 ] && { ok=1; break; }; sleep 3; done
[ $ok = 1 ] || { log "telefonul virtual nu a terminat pornirea"; publish; exit 0; }
"$ADB" shell settings put global window_animation_scale 0
"$ADB" shell settings put global transition_animation_scale 0
"$ADB" shell settings put global animator_duration_scale 0
"$ADB" shell input keyevent 82
log "telefon virtual pornit (Android 14)"

"$ADB" install -r -g "$APK" > "$OUT/instalare.txt" 2>&1 || { log "INSTALAREA A EȘUAT"; cat "$OUT/instalare.txt"; publish; exit 1; }
log "instalat"
"$ADB" logcat -c

shot(){ sleep "${2:-3}"; "$ADB" exec-out screencap -p > "$OUT/$1.png"; log "poză: $1"; }
start(){ "$ADB" shell am force-stop $PKG; "$ADB" shell am start -W -n $PKG/.MainActivity "$@" > /dev/null; }
alive(){ "$ADB" shell pidof $PKG > /dev/null; }
tap_text(){
  "$ADB" shell uiautomator dump /sdcard/u.xml > /dev/null 2>&1; "$ADB" pull /sdcard/u.xml /tmp/u.xml > /dev/null 2>&1
  xy=$(python3 - "$1" <<'P'
import re,sys
t=sys.argv[1]; s=open('/tmp/u.xml',encoding='utf8').read()
for m in re.finditer(r'<node [^>]*>',s):
    n=m.group(0)
    if 'text="%s"'%t in n or 'content-desc="%s"'%t in n:
        b=re.search(r'bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"',n)
        if b:
            x1,y1,x2,y2=map(int,b.groups()); print((x1+x2)//2,(y1+y2)//2); break
P
)
  if [ -n "$xy" ]; then "$ADB" shell input tap $xy; log "atins: $1"; else log "nu găsesc pe ecran: $1"; fi
}

# 1. pornire fără nimic
start; shot 01-pornire 1; shot 02-acasa 4
alive || log "APLICAȚIA S-A OPRIT LA PORNIRE"
tap_text "Filmări"; shot 03-filmari 2
tap_text "Poze"; shot 04-poze 2
tap_text "Ajutor"; shot 05-ajutor 2; "$ADB" shell input keyevent 4
tap_text "Cameră"; shot 06-camera 2; "$ADB" shell input keyevent 4

# 2. fișiere de probă (o filmare, o poză 360, o poză normală)
start --ez ciTest true; sleep 3
T=/tmp/media; mkdir -p $T
if command -v ffmpeg > /dev/null; then
  ffmpeg -loglevel error -y -f lavfi -i testsrc2=size=1920x1080:rate=30 -t 6 -pix_fmt yuv420p -c:v libx264 $T/VID_20260905_130400_00_001.mp4
  ffmpeg -loglevel error -y -f lavfi -i testsrc=size=1280x720:rate=30 -t 4 -pix_fmt yuv420p -c:v libx264 $T/VID_20260904_120000_00_002.mp4
  ffmpeg -loglevel error -y -f lavfi -i testsrc2=size=4000x2000 -frames:v 1 $T/IMG_20260905_130500_00_003.insp.jpg && mv $T/IMG_20260905_130500_00_003.insp.jpg $T/IMG_20260905_130500_00_003.insp
  ffmpeg -loglevel error -y -f lavfi -i smptebars=size=1600x1200 -frames:v 1 $T/IMG_20260905_130600.jpg
else log "fără ffmpeg: fără fișiere de probă"; fi
DST=/sdcard/Android/data/$PKG/files
"$ADB" shell mkdir -p $DST
for f in $T/*; do "$ADB" push "$f" $DST/ > /dev/null 2>&1 || log "nu pot pune $f"; done
start --ez ciTest true; shot 07-lista 5
alive || log "APLICAȚIA S-A OPRIT CU LISTA"
tap_text "Poze"; shot 08-lista-poze 2
tap_text "Filmări"; shot 09-lista-filmari 2

# 3. editor cu două filmări
start --ez ciTest true --es ciOpen video; shot 10-editor 7
alive || log "APLICAȚIA S-A OPRIT ÎN EDITOR"
tap_text "Pornește"; shot 11-editor-play 3

# 4. poza 360 și poza normală
start --ez ciTest true --es ciOpen photo360; shot 12-poza360 6
alive || log "APLICAȚIA S-A OPRIT LA POZA 360"
start --ez ciTest true --es ciOpen photo; shot 13-poza 5

# erori
"$ADB" logcat -d -b crash > "$OUT/erori.txt" 2>&1
"$ADB" logcat -d -t 4000 > "$OUT/jurnal.txt" 2>&1
if grep -q "$PKG" "$OUT/erori.txt"; then
  log "EROARE ÎN APLICAȚIE (vezi erori.txt)"
  echo "===== EROARE APLICAȚIE ====="; grep -A 40 "FATAL EXCEPTION" "$OUT/erori.txt" | head -150
  publish; exit 1
fi
: > "$OUT/erori.txt"
log "fără erori"
publish
exit 0
