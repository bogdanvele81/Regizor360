package ro.director360.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/**
 * Editarea unei poze, ca în Regizor 360: Ce să facă (Cadru / Tiny Planet / Panoramă 360), Format, Unghi de vedere,
 * Rotire, filtre și reglaje cu sfaturi, Horizon Lock, Salvează poza.
 */
public class PhotoActivity extends AppCompatActivity {

    private Video360View view;
    private AspectFrame stage;
    private LinearLayout body;
    private SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private float dd;

    private Uri uri;
    private String name;
    private boolean is360, loaded = false, gyroOn = true, comparing = false;
    private float photoAspect = 4f / 3f;
    private int srcW = 0, srcH = 0;
    private Insp insp;
    private String mode = "frame"; // frame / planet / pano
    private String format = "16:9";
    private String pfilt = "none";
    private final float[] adj = new float[9];
    private int adjK = Look.CON;
    private String loadErr;

    // sfaturi (ca în Regizor)
    private String tipId;
    private float[] tipUndo;
    private final java.util.Set<String> tipSkip = new java.util.HashSet<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_photo);
        dd = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        uri = Uri.parse(getIntent().getStringExtra("uri"));
        name = getIntent().getStringExtra("name");
        is360 = getIntent().getBooleanExtra("is360", false);
        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6A2B), 9, 12, 0);
        ((TextView) findViewById(R.id.phBrand)).setText(brand);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        stage = findViewById(R.id.stage);
        body = findViewById(R.id.phBody);
        View box = findViewById(R.id.stageBox);
        box.getLayoutParams().height = (int) (getResources().getDisplayMetrics().heightPixels * 0.34f);
        view = new Video360View(this);
        stage.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        format = prefs.getString("photoFormat", "16:9");
        applyFormat();
        render();

        new Thread(() -> {
            Bitmap bmp = decode(uri, 6144);
            Insp ip = is360 ? Insp.read(this, uri) : null;
            main.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (bmp == null) { render(); return; }
                photoAspect = bmp.getWidth() / (float) bmp.getHeight();
                if (photoAspect < 1.6f) is360 = false;
                insp = ip;
                if (is360 && insp != null) {
                    view.setCalib(insp.calA, insp.calB);
                    view.setLevel(gyroOn ? insp.level : null);
                }
                view.setFlat(!is360, photoAspect);
                view.setPhoto(bmp);
                loaded = true;
                if (!is360 && format.equals("16:9") && !prefs.contains("photoFormat")) format = "orig";
                applyFormat();
                render();
            });
        }).start();
    }

    // ---------------- citirea pozei (două metode) ----------------
    private Bitmap decode(Uri u, int maxW) {
        Bitmap b = null;
        StringBuilder why = new StringBuilder();
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
            srcW = o.outWidth; srcH = o.outHeight;
            why.append("mărime ").append(o.outWidth).append("×").append(o.outHeight).append(", tip ").append(o.outMimeType);
            if (o.outWidth > 0) {
                int ss = 1;
                while (o.outWidth / ss > maxW) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = ss;
                if (is360) o2.inPreferredConfig = Bitmap.Config.RGB_565;
                try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o2); }
            }
        } catch (Throwable e) { why.append(" · ").append(e.getClass().getSimpleName()); }
        if (b == null) {
            // a doua metodă (merge și la poze HEIF / HDR)
            try {
                android.graphics.ImageDecoder.Source src = android.graphics.ImageDecoder.createSource(getContentResolver(), u);
                b = android.graphics.ImageDecoder.decodeBitmap(src, (dec, info, s) -> {
                    int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                    srcW = w; srcH = h;
                    if (w > maxW) dec.setTargetSize(maxW, Math.max(1, h * maxW / w));
                    dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                });
            } catch (Throwable e) { why.append(" · a doua metodă: ").append(e.getClass().getSimpleName()).append(" ").append(e.getMessage()); }
        }
        if (b == null) {
            long size = -1;
            String head = "";
            try (InputStream in = getContentResolver().openInputStream(u)) {
                byte[] h = new byte[12];
                int n = in.read(h);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < Math.max(0, n); i++) sb.append(String.format(Locale.ROOT, "%02X", h[i]));
                head = sb.toString();
            } catch (Throwable ignored) { }
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) size = c.getLong(0);
            } catch (Throwable ignored) { }
            loadErr = "Nu pot citi poza.\n" + name + "\n" + (size > 0 ? (size / 1048576) + " MB · " : "") + why + "\nînceput: " + head;
            return null;
        }
        if (!is360 || b.getWidth() < b.getHeight() * 1.6f) {
            int rot = 0;
            try (InputStream in = getContentResolver().openInputStream(u)) {
                int or = new androidx.exifinterface.media.ExifInterface(in).getAttributeInt(androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Throwable ignored) { }
            if (rot != 0) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (rot != 180) { int t = srcW; srcW = srcH; srcH = t; }
            }
        }
        return b;
    }

    // ---------------- interfața ----------------
    private float ratio() {
        if (mode.equals("pano")) return 2f;
        switch (format) {
            case "9:16": return 9f / 16f;
            case "1:1": return 1f;
            case "orig": return photoAspect;
            default: return 16f / 9f;
        }
    }

    private void applyFormat() { stage.setRatio(ratio()); }

    private TextView label(String t) {
        TextView l = new TextView(this);
        l.setText(t.toUpperCase(new Locale("ro")));
        l.setTextColor(0xFF9AA0A6);
        l.setTextSize(13);
        l.setLetterSpacing(0.08f);
        l.setPadding(0, (int) (18 * dd), 0, (int) (8 * dd));
        return l;
    }

    private TextView segBtn(String t, boolean on, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setGravity(Gravity.CENTER);
        b.setTextSize(16);
        b.setTextColor(0xFFF2F2F0);
        b.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        b.setBackgroundResource(on ? R.drawable.src_on : R.drawable.src_off);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout segRow(String[][] items, String cur, java.util.function.Consumer<String> pick, int cols) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < items.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                if (i > 0) rp.topMargin = (int) (10 * dd);
                col.addView(row, rp);
            }
            final String id = items[i][0];
            TextView b = segBtn(items[i][1], id.equals(cur), v -> pick.accept(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (52 * dd), 1f);
            if (i % cols > 0) lp.setMarginStart((int) (10 * dd));
            row.addView(b, lp);
        }
        // locuri goale pe ultimul rând, ca butoanele să aibă aceeași lățime
        int rem = items.length % cols;
        if (rem != 0) for (int k = rem; k < cols; k++) {
            View sp = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f);
            lp.setMarginStart((int) (10 * dd));
            row.addView(sp, lp);
        }
        return col;
    }

    private LinearLayout sliderRow(int min, int max, int val, String unit, java.util.function.IntConsumer on, View extra) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(val - min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        TextView v = new TextView(this);
        v.setText(val + unit);
        v.setTextColor(0xFFB9BCBF);
        v.setTextSize(15);
        v.setTypeface(android.graphics.Typeface.MONOSPACE);
        v.setMinWidth((int) (52 * dd));
        v.setGravity(Gravity.END);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) { int x = p + min; v.setText((x > 0 && unit.isEmpty() && min < 0 ? "+" : "") + x + unit); if (u) on.accept(x); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { render(); }
        });
        r.addView(sb, new LinearLayout.LayoutParams(0, (int) (44 * dd), 1f));
        r.addView(v);
        if (extra != null) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
            lp.setMarginStart((int) (10 * dd));
            r.addView(extra, lp);
        }
        return r;
    }

    private void render() {
        body.removeAllViews();
        // camera
        TextView cam = new TextView(this);
        String model = insp != null && insp.model != null ? insp.model : is360 ? "Insta360" : "poză obișnuită";
        android.text.SpannableString cs = new android.text.SpannableString("cameră  " + model);
        cs.setSpan(new android.text.style.ForegroundColorSpan(0xFFF2F2F0), 8, cs.length(), 0);
        cam.setText(cs);
        cam.setTextColor(0xFF9AA0A6);
        cam.setTypeface(android.graphics.Typeface.MONOSPACE);
        cam.setTextSize(14);
        cam.setPadding(0, (int) (14 * dd), 0, (int) (8 * dd));
        body.addView(cam);
        // îndemn / eroare
        TextView hint = new TextView(this);
        hint.setBackgroundResource(R.drawable.hint_bg);
        hint.setTextColor(0xFFE6D9CF);
        hint.setTextSize(15);
        hint.setPadding((int) (14 * dd), (int) (12 * dd), (int) (14 * dd), (int) (12 * dd));
        if (loadErr != null) {
            hint.setText(loadErr + "\n\nFă o poză la ecranul ăsta și trimite-o lui Claude.");
            hint.setTextIsSelectable(true);
            body.addView(hint);
            return;
        }
        hint.setText(!loaded ? "Se încarcă poza…" : mode.equals("pano") ? "Panorama întreagă 360 (2:1). Trage stânga-dreapta ca să alegi ce e la mijloc, apoi salvează."
                : is360 ? "Trage cu degetul ca să alegi cadrul, apoi salvează." : "Alege formatul, apoi salvează. Poza se taie pe mijloc.");
        body.addView(hint);
        if (!loaded) return;

        if (is360) {
            body.addView(label("Ce să facă"));
            body.addView(segRow(new String[][]{{"frame", "Cadru"}, {"planet", "Tiny Planet"}, {"pano", "Panoramă 360"}}, mode, id -> {
                mode = id;
                view.setPano(id.equals("pano"));
                if (!id.equals("pano")) { boolean pl = id.equals("planet"); if (pl != view.isPlanet()) view.setPlanet(pl); }
                applyFormat();
                render();
            }, 2));
        }
        if (!mode.equals("pano")) {
            body.addView(label("Format"));
            String[][] fm = is360 ? new String[][]{{"16:9", "16:9"}, {"9:16", "9:16 Reels"}, {"1:1", "1:1"}}
                    : new String[][]{{"orig", "Original"}, {"16:9", "16:9"}, {"9:16", "9:16 Reels"}, {"1:1", "1:1"}};
            body.addView(segRow(fm, format, id -> { format = id; prefs.edit().putString("photoFormat", id).apply(); applyFormat(); render(); }, fm.length));
        }
        if (is360 && !mode.equals("pano")) {
            body.addView(label("Unghi de vedere"));
            int fov = Math.round(view.getFov());
            body.addView(sliderRow(10, mode.equals("planet") ? 170 : 140, Math.max(10, Math.min(170, fov)), "°", x -> view.setFov(x), null));
            body.addView(label("Rotire"));
            MaterialButton rs = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            rs.setText("Îndreaptă");
            rs.setAllCaps(false);
            rs.setTextColor(0xFFF2F2F0);
            rs.setCornerRadius((int) (24 * dd));
            rs.setOnClickListener(v -> { view.setRoll(0); render(); });
            body.addView(sliderRow(-180, 180, Math.round(view.getRoll()), "°", x -> view.setRoll(x), rs));
        }
        addTip();
        addAdjust();
        if (is360) addHorizon();
        MaterialButton save = new MaterialButton(this);
        save.setText("Salvează poza");
        save.setAllCaps(false);
        save.setTextSize(17);
        save.setTypeface(null, android.graphics.Typeface.BOLD);
        save.setTextColor(0xFF1A0A00);
        save.setCornerRadius((int) (30 * dd));
        save.setOnClickListener(v -> save());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (60 * dd));
        sp.topMargin = (int) (22 * dd);
        body.addView(save, sp);
    }

    // ---------------- reglaje ----------------
    private static final int[] ICONS = {R.drawable.a_exp, R.drawable.a_con, R.drawable.a_sh, R.drawable.a_hi, R.drawable.a_sat, R.drawable.a_warm, R.drawable.a_cla, R.drawable.a_dns, R.drawable.a_vig};

    private void applyLook() { view.setLook(comparing ? Look.NONE : adj.clone()); }

    private static String sgn(float v) { int i = Math.round(v); return i > 0 ? "+" + i : String.valueOf(i); }

    private ImageView miniTool(int icon, String desc, View.OnClickListener l) {
        ImageView b = new ImageView(this);
        b.setImageResource(icon);
        b.setContentDescription(desc);
        b.setBackgroundResource(R.drawable.tile_off);
        int p = (int) (14 * dd);
        b.setPadding(p, p, p, p);
        b.setOnClickListener(l);
        return b;
    }

    private void addAdjust() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundResource(R.drawable.box_bg);
        int p = (int) (16 * dd);
        box.setPadding(p, p, p, p);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView nm = new TextView(this);
        nm.setText(Look.ADJ_NAMES[adjK].toUpperCase(new Locale("ro")));
        nm.setTextColor(0xFF9AA0A6);
        nm.setTextSize(13);
        nm.setLetterSpacing(0.08f);
        head.addView(nm, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        int ts = (int) (52 * dd);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ts, ts);
        tp.setMarginStart((int) (8 * dd));
        head.addView(miniTool(R.drawable.a_auto, "Auto: îmbunătățește singur", v -> { System.arraycopy(Look.AUTO, 0, adj, 0, 9); pfilt = "none"; tipReset(); applyLook(); render(); }), tp);
        ImageView cmp = miniTool(R.drawable.a_cmp, "Ține apăsat ca să vezi originalul", null);
        cmp.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { comparing = true; applyLook(); }
            else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { comparing = false; applyLook(); }
            return true;
        });
        head.addView(cmp, new LinearLayout.LayoutParams(tp));
        head.addView(miniTool(R.drawable.a_reset, "Resetează reglajele", v -> { java.util.Arrays.fill(adj, 0); pfilt = "none"; tipReset(); applyLook(); render(); }), new LinearLayout.LayoutParams(tp));
        box.addView(head);

        // filtrele
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout fl = new LinearLayout(this);
        fl.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Look.IDS.length; i++) {
            final String id = Look.IDS[i];
            boolean on = id.equals(pfilt);
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER_HORIZONTAL);
            GradientDrawable frame = new GradientDrawable();
            frame.setCornerRadius(16 * dd);
            if (on) frame.setStroke((int) (2.5f * dd), 0xFFFF6A2B);
            it.setBackground(frame);
            it.setPadding((int) (3 * dd), (int) (3 * dd), (int) (3 * dd), (int) (8 * dd));
            View sw = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, Look.SWATCH[i]);
            g.setCornerRadii(new float[]{14 * dd, 14 * dd, 14 * dd, 14 * dd, 0, 0, 0, 0});
            sw.setBackground(g);
            it.addView(sw, new LinearLayout.LayoutParams((int) (88 * dd), (int) (54 * dd)));
            TextView l = new TextView(this);
            l.setText(Look.NAMES[i]);
            l.setTextSize(15);
            l.setTextColor(0xFFF2F2F0);
            l.setTypeface(null, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            l.setGravity(Gravity.CENTER);
            l.setPadding(0, (int) (8 * dd), 0, 0);
            it.addView(l);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd((int) (12 * dd));
            it.setOnClickListener(v -> {
                pfilt = id;
                float[] f = Look.of(id, 100);
                System.arraycopy(f, 0, adj, 0, 9);
                tipReset();
                applyLook();
                render();
            });
            fl.addView(it, lp);
        }
        hs.addView(fl);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = (int) (14 * dd);
        box.addView(hs, hp);

        // reglajele: 5 pe rând
        LinearLayout row = null;
        for (int i = 0; i < 9; i++) {
            if (i % 5 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.topMargin = (int) (12 * dd);
                box.addView(row, rp);
            }
            final int k = i;
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setGravity(Gravity.CENTER);
            t.setBackgroundResource(k == adjK ? R.drawable.tile_on : R.drawable.tile_off);
            t.setContentDescription(Look.ADJ_NAMES[k]);
            ImageView ic = new ImageView(this);
            ic.setImageResource(ICONS[k]);
            t.addView(ic, new LinearLayout.LayoutParams((int) (26 * dd), (int) (26 * dd)));
            TextView v = new TextView(this);
            v.setText(Math.round(adj[k]) != 0 ? sgn(adj[k]) : " ");
            v.setTextColor(0xFFFF6A2B);
            v.setTextSize(13);
            v.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
            v.setPadding(0, (int) (4 * dd), 0, 0);
            t.addView(v);
            t.setOnClickListener(x -> { adjK = k; render(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (68 * dd), 1f);
            if (i % 5 > 0) lp.setMarginStart((int) (8 * dd));
            row.addView(t, lp);
        }
        for (int k = 9; k < 10; k++) { View sp = new View(this); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 1, 1f); lp.setMarginStart((int) (8 * dd)); row.addView(sp, lp); }

        LinearLayout sr = sliderRow(adjK == Look.DNS || adjK == Look.VIG ? 0 : -100, 100, Math.round(adj[adjK]), "", x -> { adj[adjK] = x; applyLook(); }, null);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = (int) (12 * dd);
        box.addView(sr, sp);
    }

    // ---------------- sfaturi ----------------
    private String tipText(String id) {
        float[] A = adj;
        switch (id) {
            case "noise": {
                StringBuilder w = new StringBuilder();
                int n = 0;
                if (A[Look.CLA] > 25) { w.append("Claritate ").append(sgn(A[Look.CLA])); n++; }
                if (A[Look.EXP] > 30) { if (n > 0) w.append(" și "); w.append("Luminozitate ").append(sgn(A[Look.EXP])); n++; }
                return "Ai mărit mult poza. " + w + (n > 1 ? " scot" : " scoate") + " la iveală purecii (zgomotul). Sfatul meu: claritate cel mult +20" + (A[Look.EXP] > 30 ? ", luminozitate +25" : "") + " și reducere zgomot 35.";
            }
            case "burn": return "Cu Luminozitate " + sgn(A[Look.EXP]) + ", cerul și hainele albe se ard (devin alb complet). Sfatul meu: luminozitate +25 și Lumini −30, ca să păstrezi detaliile.";
            case "warm": return "Căldura " + sgn(A[Look.WARM]) + " colorează prea tare pielea" + (A[Look.WARM] > 0 ? " (iese portocalie)" : " (iese vânătă)") + ". Sfatul meu: " + (A[Look.WARM] > 0 ? "+20" : "−20") + ".";
            case "sat": return "Saturație " + sgn(A[Look.SAT]) + ": culorile sunt prea țipătoare și fețele arată nenatural. Sfatul meu: +25.";
            case "con": return "Contrast " + sgn(A[Look.CON]) + " înnegrește umbrele și fețele din umbră se pierd. Sfatul meu: contrast +30 și Umbre +25.";
            case "vig": return "Vignetare " + Math.round(A[Look.VIG]) + ": colțurile ies prea negre. Sfatul meu: 30.";
            default: return "Poza a ieșit prea întunecată. Sfatul meu: luminozitate −20 și Umbre +20.";
        }
    }

    private String findTip() {
        float[] A = adj;
        float fov = is360 ? view.getFov() : 90;
        String[] order = {"noise", "burn", "warm", "sat", "con", "vig", "dark"};
        for (String id : order) {
            if (tipSkip.contains(id)) continue;
            boolean w;
            switch (id) {
                case "noise": w = fov <= 55 && (A[Look.CLA] > 25 || A[Look.EXP] > 30) && A[Look.DNS] < 25; break;
                case "burn": w = A[Look.EXP] > 45 && A[Look.HI] > -20; break;
                case "warm": w = Math.abs(A[Look.WARM]) > 55; break;
                case "sat": w = A[Look.SAT] > 55; break;
                case "con": w = A[Look.CON] > 50 && A[Look.SH] < 15; break;
                case "vig": w = A[Look.VIG] > 65; break;
                default: w = A[Look.EXP] < -45 && A[Look.SH] < 20;
            }
            if (w) return id;
        }
        return null;
    }

    private void fixTip(String id) {
        float[] A = adj;
        switch (id) {
            case "noise": A[Look.CLA] = Math.min(A[Look.CLA], 20); if (A[Look.EXP] > 30) A[Look.EXP] = 25; A[Look.DNS] = Math.max(A[Look.DNS], 35); break;
            case "burn": A[Look.EXP] = 25; A[Look.HI] = -30; break;
            case "warm": A[Look.WARM] = A[Look.WARM] > 0 ? 20 : -20; break;
            case "sat": A[Look.SAT] = 25; break;
            case "con": A[Look.CON] = 30; A[Look.SH] = Math.max(A[Look.SH], 25); break;
            case "vig": A[Look.VIG] = 30; break;
            default: A[Look.EXP] = -20; A[Look.SH] = 20;
        }
    }

    private void tipReset() { tipId = null; tipUndo = null; tipSkip.clear(); }

    private void addTip() {
        if (mode.equals("pano")) return;
        String text;
        boolean applied = tipUndo != null;
        if (applied) text = "Am aplicat sfatul. Compară: poți reveni oricând la varianta ta.";
        else {
            tipId = findTip();
            if (tipId == null) return;
            text = tipText(tipId);
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF2A1810);
        g.setCornerRadius(20 * dd);
        g.setStroke((int) (1.5f * dd), 0xFFFF6A2B);
        box.setBackground(g);
        int p = (int) (16 * dd);
        box.setPadding(p, p, p, p);
        TextView t = new TextView(this);
        t.setText("💡  " + text);
        t.setTextColor(0xFFF2F2F0);
        t.setTextSize(16);
        box.addView(t);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, (int) (12 * dd), 0, 0);
        if (!applied) {
            TextView yes = segBtn("Fă cum zici tu", true, v -> { tipUndo = adj.clone(); fixTip(tipId); applyLook(); render(); });
            GradientDrawable yg = new GradientDrawable();
            yg.setColor(0xFFFF6A2B);
            yg.setCornerRadius(26 * dd);
            yes.setBackground(yg);
            yes.setTextColor(0xFF1A0A00);
            yes.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
            row.addView(yes, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd)));
        }
        TextView no = segBtn(applied ? "Înapoi la varianta mea" : "Lasă cum am făcut eu", false, v -> {
            if (tipUndo != null) { System.arraycopy(tipUndo, 0, adj, 0, 9); tipUndo = null; if (tipId != null) tipSkip.add(tipId); applyLook(); }
            else if (tipId != null) tipSkip.add(tipId);
            render();
        });
        GradientDrawable ng = new GradientDrawable();
        ng.setCornerRadius(26 * dd);
        ng.setStroke((int) (1 * dd), 0xFF3A4048);
        no.setBackground(ng);
        no.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
        if (!applied) np.setMarginStart((int) (10 * dd));
        row.addView(no, np);
        if (applied) {
            TextView ok = segBtn("Bine", false, v -> { tipUndo = null; if (tipId != null) tipSkip.add(tipId); render(); });
            ok.setPadding((int) (18 * dd), 0, (int) (18 * dd), 0);
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (48 * dd));
            op.setMarginStart((int) (10 * dd));
            row.addView(ok, op);
        }
        box.addView(row);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);
    }

    // ---------------- Horizon Lock ----------------
    private void addHorizon() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackgroundResource(R.drawable.box_bg);
        int p = (int) (18 * dd);
        box.setPadding(p, p, p, p);
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView t1 = new TextView(this);
        t1.setText("Horizon Lock (orizont drept)");
        t1.setTextColor(0xFFF2F2F0);
        t1.setTextSize(17);
        TextView t2 = new TextView(this);
        boolean has = insp != null && insp.level != null;
        t2.setText(has ? "îndreptat din senzorul camerei" : "poza nu are date de la senzor");
        t2.setTextColor(0xFF9AA0A6);
        t2.setTextSize(14);
        tx.addView(t1);
        tx.addView(t2);
        box.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        android.widget.CheckBox cb = new android.widget.CheckBox(this);
        cb.setChecked(has && gyroOn);
        cb.setEnabled(has);
        cb.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFFFF6A2B));
        cb.setOnCheckedChangeListener((b, on) -> { gyroOn = on; view.setLevel(on && insp != null ? insp.level : null); });
        box.addView(cb);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = (int) (18 * dd);
        body.addView(box, bp);
    }

    // ---------------- salvare ----------------
    private void save() {
        if (!loaded) { Toast.makeText(this, "Așteaptă să se încarce poza.", Toast.LENGTH_SHORT).show(); return; }
        comparing = false;
        applyLook();
        float r = ratio();
        int w, h;
        if (mode.equals("pano")) { w = 4096; h = 2048; }
        else {
            int longSide;
            if (is360) longSide = 3840;
            else {
                int cw = srcW, ch = srcH;
                if (photoAspect > r) cw = Math.round(ch * r); else ch = Math.round(cw / r);
                longSide = Math.min(4096, Math.max(cw, ch));
            }
            if (r >= 1) { w = longSide; h = Math.round(longSide / r); } else { h = longSide; w = Math.round(longSide * r); }
        }
        w = Math.max(2, w & ~1); h = Math.max(2, h & ~1);
        final int fw = w, fh = h;
        Toast.makeText(this, "Salvez poza…", Toast.LENGTH_SHORT).show();
        view.capture(fw, fh, bmp -> {
            if (bmp == null) { Toast.makeText(this, "Nu am reușit să salvez. Încearcă din nou.", Toast.LENGTH_LONG).show(); return; }
            new Thread(() -> {
                Uri dst = publish(bmp);
                main.post(() -> {
                    if (dst == null) { Toast.makeText(this, "Nu am reușit să salvez în Galerie.", Toast.LENGTH_LONG).show(); return; }
                    new AlertDialog.Builder(this)
                            .setTitle("Gata! Poza e salvată")
                            .setMessage("O găsești în Galerie, în albumul Director360." + (mode.equals("pano") ? " Fiind panoramă 360, o poți urca pe Facebook ca poză 360." : ""))
                            .setPositiveButton("Deschide", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_VIEW);
                                i.setDataAndType(dst, "image/jpeg");
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(i); } catch (Exception ignored) { }
                            })
                            .setNeutralButton("Trimite", (d, x) -> {
                                Intent i = new Intent(Intent.ACTION_SEND);
                                i.setType("image/jpeg");
                                i.putExtra(Intent.EXTRA_STREAM, dst);
                                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                try { startActivity(Intent.createChooser(i, "Trimite poza")); } catch (Exception ignored) { }
                            })
                            .setNegativeButton("Închide", null)
                            .show();
                });
            }).start();
        });
    }

    private Uri publish(Bitmap bmp) {
        try {
            ContentResolver cr = getContentResolver();
            ContentValues v = new ContentValues();
            String n = "Director360_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new java.util.Date()) + ".jpg";
            v.put(MediaStore.Images.Media.DISPLAY_NAME, n);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Director360");
            v.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri dst = cr.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v);
            if (dst == null) return null;
            try (OutputStream o = cr.openOutputStream(dst)) {
                if (o == null) return null;
                bmp.compress(Bitmap.CompressFormat.JPEG, 93, o);
            }
            v.clear();
            v.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(dst, v, null, null);
            return dst;
        } catch (Exception e) {
            return null;
        }
    }

    @Override protected void onResume() { super.onResume(); view.onResume(); }
    @Override protected void onPause() { view.onPause(); super.onPause(); }
}
