package ro.director360.app;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.HashMap;

/** Limba aplicației: RO / EN / IT / ES / DE / FR. Textele vizibile se traduc automat pe ecran. */
public class I18n {
    public static final String[] LANGS = {"ro", "en", "it", "es", "de", "fr"};
    public static final String[] NAMES = {"Română", "English", "Italiano", "Español", "Deutsch", "Français"};

    // ro, en, it, es, de, fr
    private static final String[][] D = {
            {"Acasă", "Home", "Home", "Inicio", "Start", "Accueil"},
            {"Filmări", "Videos", "Video", "Vídeos", "Videos", "Vidéos"},
            {"Telefon", "Phone", "Telefono", "Teléfono", "Handy", "Téléphone"},
            {"Poze", "Photos", "Foto", "Fotos", "Fotos", "Photos"},
            {"Ajutor", "Help", "Aiuto", "Ayuda", "Hilfe", "Aide"},
            {"Card", "Card", "Scheda", "Tarjeta", "Karte", "Carte"},
            {"neconectat", "not connected", "non collegata", "no conectada", "nicht verbunden", "non connectée"},
            {"Cameră", "Camera", "Fotocamera", "Cámara", "Kamera", "Caméra"},
            {"prin Wi-Fi", "via Wi-Fi", "via Wi-Fi", "por Wi-Fi", "über WLAN", "via Wi-Fi"},
            {"în curând", "coming soon", "in arrivo", "próximamente", "bald", "bientôt"},
            {"SORTEAZĂ", "SORT", "ORDINA", "ORDENAR", "SORTIEREN", "TRIER"},
            {"După dată", "By date", "Per data", "Por fecha", "Nach Datum", "Par date"},
            {"După mărime", "By size", "Per dimensione", "Por tamaño", "Nach Größe", "Par taille"},
            {"Șterge-le", "Delete them", "Eliminale", "Bórralas", "Löschen", "Les supprimer"},
            {"Atinge ca să deschizi cardul", "Tap to open the card", "Tocca per aprire la scheda", "Toca para abrir la tarjeta", "Tippen, um die Karte zu öffnen", "Touchez pour ouvrir la carte"},
            {"Filmările și pozele apar aici, grupate pe zile", "Videos and photos appear here, grouped by day", "Video e foto appaiono qui, raggruppati per giorno", "Los vídeos y fotos aparecen aquí, agrupados por día", "Videos und Fotos erscheinen hier, nach Tagen sortiert", "Vidéos et photos apparaissent ici, groupées par jour"},
            {"Sau alege din memoria telefonului", "Or pick from phone storage", "Oppure scegli dalla memoria del telefono", "O elige de la memoria del teléfono", "Oder aus dem Handyspeicher wählen", "Ou choisissez dans la mémoire du téléphone"},
            {"Gata = montaj automat", "Done = automatic edit", "Fatto = montaggio automatico", "Listo = montaje automático", "Fertig = automatischer Schnitt", "OK = montage automatique"},
            {"Editez eu", "I'll edit", "Modifico io", "Edito yo", "Ich schneide selbst", "Je monte moi-même"},
            {"Gata", "Done", "Fatto", "Listo", "Fertig", "OK"},
            {"Salvează", "Save", "Salva", "Guardar", "Speichern", "Enregistrer"},
            {"Îndreaptă", "Level", "Livella", "Nivelar", "Ausrichten", "Redresser"},
            {"Mută stânga", "Move left", "Sposta a sinistra", "Mover a la izquierda", "Nach links", "Déplacer à gauche"},
            {"Mută dreapta", "Move right", "Sposta a destra", "Mover a la derecha", "Nach rechts", "Déplacer à droite"},
            {"Șterge", "Delete", "Elimina", "Borrar", "Löschen", "Supprimer"},
            {"Povestea", "Story", "La storia", "La historia", "Die Geschichte", "L'histoire"},
            {"Montaj", "Edit", "Montaggio", "Montaje", "Schnitt", "Montage"},
            {"Voce", "Voice", "Voce", "Voz", "Stimme", "Voix"},
            {"Efecte", "Effects", "Effetti", "Efectos", "Effekte", "Effets"},
            {"Muzică", "Music", "Musica", "Música", "Musik", "Musique"},
            {"Filtru și desen", "Filter & draw", "Filtro e disegno", "Filtro y dibujo", "Filter & Zeichnen", "Filtre et dessin"},
            {"Împarte", "Split", "Dividi", "Dividir", "Teilen", "Couper"},
            {"Sunet", "Sound", "Audio", "Sonido", "Ton", "Son"},
            {"Renunță", "Cancel", "Annulla", "Cancelar", "Abbrechen", "Annuler"},
            {"Toate", "All", "Tutti", "Todos", "Alle", "Tous"},
            {"Idei AI", "AI ideas", "Idee AI", "Ideas IA", "KI-Ideen", "Idées IA"},
            {"Planeta zilei", "Planet of the day", "Pianeta del giorno", "Planeta del día", "Planet des Tages", "Planète du jour"},
            {"o poză Tiny Planet", "a Tiny Planet photo", "una foto Tiny Planet", "una foto Tiny Planet", "ein Tiny-Planet-Foto", "une photo Tiny Planet"},
            {"Cele mai bune poze", "Best photos", "Le foto migliori", "Las mejores fotos", "Die besten Fotos", "Meilleures photos"},
            {"toate pozele", "all photos", "tutte le foto", "todas las fotos", "alle Fotos", "toutes les photos"},
            {"Povestea ultimei zile", "Story of the last day", "Storia dell'ultimo giorno", "Historia del último día", "Geschichte des letzten Tages", "Histoire du dernier jour"},
            {"film după oră", "film in time order", "film in ordine di tempo", "película por hora", "Film nach Uhrzeit", "film dans l'ordre"},
            {"Povestea zilei", "Story of the day", "Storia del giorno", "Historia del día", "Geschichte des Tages", "Histoire du jour"},
            {"O zi frumoasă", "A beautiful day", "Una bella giornata", "Un día bonito", "Ein schöner Tag", "Une belle journée"},
            {"filmări", "videos", "video", "vídeos", "Videos", "vidéos"},
            {"poze", "photos", "foto", "fotos", "Fotos", "photos"},
            {"Pregătesc povestea zilei…", "Preparing the story of the day…", "Preparo la storia del giorno…", "Preparando la historia del día…", "Bereite die Geschichte des Tages vor…", "Je prépare l'histoire du jour…"},
            {"Nu am găsit încă o poză 360.", "No 360 photo found yet.", "Nessuna foto 360 trovata.", "Aún no hay fotos 360.", "Noch kein 360-Foto gefunden.", "Aucune photo 360 trouvée."},
            {"Conectează cardul sau camera și îți fac singur filme frumoase din fiecare zi.", "Connect the card or camera and I'll make beautiful films from each day.", "Collega la scheda o la fotocamera e creerò bei film di ogni giorno.", "Conecta la tarjeta o la cámara y haré películas bonitas de cada día.", "Verbinde Karte oder Kamera und ich mache schöne Filme von jedem Tag.", "Connectez la carte ou la caméra et je ferai de beaux films de chaque jour."},
            {"Lucrările mele", "My work", "I miei lavori", "Mis trabajos", "Meine Projekte", "Mes projets"},
            {"bucăți", "clips", "clip", "clips", "Clips", "clips"},
            {"Ștergi lucrarea din listă? Filmările de pe card rămân neatinse.", "Remove this project? Files on the card stay untouched.", "Eliminare il progetto? I file sulla scheda restano intatti.", "¿Quitar el proyecto? Los archivos de la tarjeta no se tocan.", "Projekt entfernen? Die Dateien auf der Karte bleiben unberührt.", "Supprimer le projet ? Les fichiers de la carte restent intacts."},
            {"📍 După loc", "📍 By place", "📍 Per luogo", "📍 Por lugar", "📍 Nach Ort", "📍 Par lieu"},
            {"Fără locație", "No location", "Senza posizione", "Sin ubicación", "Ohne Ort", "Sans lieu"},
            {"Continuă", "Continue", "Continua", "Continuar", "Weiter", "Continuer"},
            {"Limba aplicației", "App language", "Lingua dell'app", "Idioma de la app", "App-Sprache", "Langue de l'app"},
            {"Caută actualizări", "Check for updates", "Cerca aggiornamenti", "Buscar actualizaciones", "Nach Updates suchen", "Rechercher des mises à jour"},
            {"🔍  Caută camera", "🔍  Find camera", "🔍  Cerca fotocamera", "🔍  Buscar cámara", "🔍  Kamera suchen", "🔍  Chercher la caméra"},
            {"✨ Auto AI", "✨ Auto AI", "✨ Auto AI", "✨ Auto IA", "✨ Auto KI", "✨ Auto IA"},
            {"▶ Vezi rezultatul", "▶ See result", "▶ Vedi risultato", "▶ Ver resultado", "▶ Ergebnis ansehen", "▶ Voir le résultat"},
            {"Video", "Video", "Video", "Vídeo", "Video", "Vidéo"},
            {"Poză", "Photo", "Foto", "Foto", "Foto", "Photo"},
    };

    private static HashMap<String, String[]> map;
    private static String cur;

    private static synchronized HashMap<String, String[]> map() {
        if (map == null) {
            map = new HashMap<>();
            for (String[] r : D) map.put(r[0], r);
        }
        return map;
    }

    public static String lang(Context c) {
        if (cur == null) cur = c.getSharedPreferences("director", Context.MODE_PRIVATE).getString("appLang", "ro");
        return cur;
    }

    public static void setLang(Context c, String l) {
        cur = l;
        c.getSharedPreferences("director", Context.MODE_PRIVATE).edit().putString("appLang", l).apply();
    }

    private static int idx(String l) {
        for (int i = 0; i < LANGS.length; i++) if (LANGS[i].equals(l)) return i;
        return 0;
    }

    public static String t(Context c, String ro) {
        int i = idx(lang(c));
        if (i == 0 || ro == null) return ro;
        String[] r = map().get(ro);
        return r == null ? ro : r[i];
    }

    /** traduce toate textele cunoscute dintr-un ecran */
    public static void apply(View v) {
        if (v == null) return;
        int i = idx(lang(v.getContext()));
        if (i == 0) return;
        walk(v, i);
    }

    private static void walk(View v, int i) {
        if (v instanceof TextView) {
            CharSequence s = ((TextView) v).getText();
            if (s != null && s.length() > 0 && s.length() < 200) {
                String[] r = map().get(s.toString());
                if (r != null && !r[i].equals(s.toString())) ((TextView) v).setText(r[i]);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int k = 0; k < g.getChildCount(); k++) walk(g.getChildAt(k), i);
        }
    }

    /** urmărește ecranul și traduce și ce apare mai târziu (butoane, panouri) */
    public static void watch(Activity a) {
        if (idx(lang(a)) == 0) return;
        final View root = a.getWindow().getDecorView();
        final boolean[] queued = {false};
        root.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            if (queued[0]) return;
            queued[0] = true;
            root.postDelayed(() -> { queued[0] = false; apply(root); }, 120);
        });
        apply(root);
    }
}
