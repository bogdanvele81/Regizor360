package ro.director360.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Locul unde s-a filmat / s-a făcut poza:
 *  - poze (.insp/.jpg): coordonatele GPS din datele pozei
 *  - filmări .insv: înregistrarea GPS de la capătul fișierului (camera o scrie când e legată de telefon sau de telecomanda GPS)
 *  - filmări din telefon (.mp4): locația salvată de telefon
 * Fișierele fără loc îl primesc de la cea mai apropiată poză / filmare (ca oră) care are loc.
 */
public class Geo {
    private static final String MAGIC = "8db42d694ccc418790edff439fe026bf";
    private static final long NEAR_MS = 3L * 3600 * 1000;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("geo", Context.MODE_PRIVATE); }

    /** {lat, lon} sau null; folosește ce s-a citit deja */
    public static double[] of(Context ctx, VideoItem it) {
        SharedPreferences p = prefs(ctx);
        String k = it.key();
        String s = p.getString(k, null);
        if (s != null) return s.equals("-") ? null : parse(s);
        double[] r = null;
        try { r = read(ctx, it.uri, it.name); } catch (Throwable ignored) { }
        if (r != null && (Math.abs(r[0]) < 1e-6 && Math.abs(r[1]) < 1e-6)) r = null;
        p.edit().putString(k, r == null ? "-" : String.format(Locale.ROOT, "%.6f,%.6f", r[0], r[1])).apply();
        return r;
    }

    public static boolean cached(Context ctx, VideoItem it) { return prefs(ctx).contains(it.key()); }

    private static double[] parse(String s) {
        try { String[] a = s.split(","); return new double[]{Double.parseDouble(a[0]), Double.parseDouble(a[1])}; } catch (Exception e) { return null; }
    }

    static double[] read(Context ctx, Uri uri, String name) throws Exception {
        String low = name.toLowerCase(Locale.ROOT);
        boolean http = "http".equals(uri.getScheme()) || "https".equals(uri.getScheme());
        if (low.endsWith(".insp") || low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".heic") || low.endsWith(".webp") || low.endsWith(".png")) {
            java.io.InputStream in = http ? new java.io.ByteArrayInputStream(range(uri.toString(), 0, 262144, true)) : ctx.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try (java.io.InputStream i2 = in) {
                androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(i2);
                double[] ll = ex.getLatLong();
                return ll;
            }
        }
        if (low.endsWith(".insv")) return http ? insvHttp(uri.toString()) : insvLocal(ctx, uri);
        if (low.endsWith(".mp4") || low.endsWith(".mov") || low.endsWith(".3gp")) {
            if (http) return null;
            android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
            try {
                r.setDataSource(ctx, uri);
                String loc = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_LOCATION); // +45.1234+025.5678/
                if (loc == null) return null;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("([+-]\\d+(?:\\.\\d+)?)([+-]\\d+(?:\\.\\d+)?)").matcher(loc);
                if (m.find()) return new double[]{Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2))};
            } finally { try { r.release(); } catch (Exception ignored) { } }
        }
        return null;
    }

    private static double[] insvLocal(Context ctx, Uri uri) throws Exception {
        try (ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
             FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
             FileChannel ch = fis.getChannel()) {
            long n = ch.size();
            if (n < 200) return null;
            ByteBuffer tail = ByteBuffer.allocate(72).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(tail, n - 72);
            if (!new String(tail.array(), 40, 32, "ISO-8859-1").equals(MAGIC)) return null;
            long size = tail.getInt(32) & 0xFFFFFFFFL;
            if (size <= 72 || size > n || size > 80L * 1048576) return null;
            ByteBuffer tb = ByteBuffer.allocate((int) size).order(ByteOrder.LITTLE_ENDIAN);
            ch.read(tb, n - size);
            return gps(tb);
        }
    }

    private static long lastTotal;

    private static double[] insvHttp(String url) throws Exception {
        byte[] tail = range(url, -1, 72, false);
        if (tail == null || tail.length != 72) return null;
        if (!new String(tail, 40, 32, "ISO-8859-1").equals(MAGIC)) return null;
        long n = lastTotal;
        long size = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).getInt(32) & 0xFFFFFFFFL;
        if (size <= 72 || n <= 0 || size > n || size > 12L * 1048576) return null; // prin Wi-Fi: nu citim cozi uriașe
        byte[] b = range(url, n - size, (int) size, false);
        if (b == null) return null;
        return gps(ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN));
    }

    /** înregistrarea 0x0700 = GPS: câte 53 de octeți (timp, A/V, lat, N/S, lon, E/W, viteză, direcție, altitudine) */
    static double[] gps(ByteBuffer tb) {
        byte[] b = tb.array();
        for (int i = b.length; i >= 6; i--) {
            if (b[i - 6] != 0x00 || b[i - 5] != 0x07) continue;
            long sz = tb.getInt(i - 4) & 0xFFFFFFFFL;
            if (sz < 53 || sz > i - 6 || sz % 53 != 0) continue;
            int s = (int) (i - 6 - sz), cnt = (int) (sz / 53);
            double sl = 0, so = 0;
            int good = 0;
            for (int k = 0; k < cnt; k++) {
                int o = s + 53 * k;
                char st = (char) b[o + 10], ns = (char) b[o + 19], ew = (char) b[o + 28];
                if (st != 'A' || (ns != 'N' && ns != 'S') || (ew != 'E' && ew != 'W')) continue;
                double lat = tb.getDouble(o + 11), lon = tb.getDouble(o + 20);
                if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180 || (lat == 0 && lon == 0)) continue;
                if (ns == 'S') lat = -lat;
                if (ew == 'W') lon = -lon;
                sl += lat; so += lon; good++;
                if (good >= 20) break;
            }
            if (good > 0) return new double[]{sl / good, so / good};
        }
        return null;
    }

    private static byte[] range(String url, long from, int len, boolean partialOk) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Range", from < 0 ? "bytes=-" + len : "bytes=" + from + "-" + (from + len - 1));
        try {
            if (c.getResponseCode() != 206 && !partialOk) return null;
            String cr = c.getHeaderField("Content-Range");
            if (cr != null && cr.contains("/")) try { lastTotal = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim()); } catch (Exception ignored) { }
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while (bo.size() < len && (r = in.read(buf, 0, Math.min(buf.length, len - bo.size()))) > 0) bo.write(buf, 0, r);
            byte[] out = bo.toByteArray();
            return partialOk || out.length == len ? out : null;
        } finally { c.disconnect(); }
    }

    /** numele locului (oraș · zonă); are nevoie de internet prima dată, apoi îl ține minte */
    public static String placeName(Context ctx, double lat, double lon) {
        String k = String.format(Locale.ROOT, "n%.2f,%.2f", lat, lon);
        SharedPreferences p = prefs(ctx);
        String s = p.getString(k, null);
        if (s != null) return s;
        String name = null;
        try {
            if (android.location.Geocoder.isPresent()) {
                List<android.location.Address> l = new android.location.Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1);
                if (l != null && !l.isEmpty()) {
                    android.location.Address a = l.get(0);
                    String city = a.getLocality() != null ? a.getLocality() : a.getSubAdminArea() != null ? a.getSubAdminArea() : a.getAdminArea();
                    String sub = a.getSubLocality();
                    if (city == null) city = a.getCountryName();
                    if (city != null) name = sub != null && !sub.equals(city) ? city + " · " + sub : city;
                }
            }
        } catch (Exception ignored) { }
        if (name != null) { p.edit().putString(k, name).apply(); return name; }
        // fără internet: arătăm coordonatele scurte, numele vine data viitoare
        return String.format(Locale.ROOT, "%.3f, %.3f", lat, lon);
    }

    /** citește locul pentru toată lista; cele fără loc îl primesc de la cel mai apropiat fișier (ca oră) care are */
    public static void scan(Context ctx, List<VideoItem> list, Runnable progress) {
        List<VideoItem> l = new ArrayList<>(list);
        int done = 0;
        for (VideoItem it : l) {
            double[] g = of(ctx, it);
            if (g != null) { it.lat = g[0]; it.lon = g[1]; it.geo = 1; }
            else it.geo = -1;
            if (++done % 15 == 0 && progress != null) progress.run();
        }
        // locul de la pozele / filmările din aceeași perioadă
        long[] t = new long[l.size()];
        for (int i = 0; i < l.size(); i++) { t[i] = Story.timeOf(ctx, l.get(i).name, null); if (t[i] <= 0) t[i] = l.get(i).modified; }
        for (int i = 0; i < l.size(); i++) {
            VideoItem it = l.get(i);
            if (it.geo == 1) continue;
            long best = Long.MAX_VALUE;
            VideoItem from = null;
            for (int j = 0; j < l.size(); j++) {
                VideoItem o = l.get(j);
                if (o.geo != 1 || t[i] <= 0 || t[j] <= 0) continue;
                long d = Math.abs(t[i] - t[j]);
                if (d < best) { best = d; from = o; }
            }
            if (from != null && best <= NEAR_MS) { it.lat = from.lat; it.lon = from.lon; it.geo = 2; }
        }
        for (VideoItem it : l) if (it.geo > 0) it.place = placeName(ctx, it.lat, it.lon);
        if (progress != null) progress.run();
    }

    public static int countExact(List<VideoItem> l) { int n = 0; for (VideoItem it : l) if (it.geo == 1) n++; return n; }
    public static int countAny(List<VideoItem> l) { int n = 0; for (VideoItem it : l) if (it.geo > 0) n++; return n; }
}
