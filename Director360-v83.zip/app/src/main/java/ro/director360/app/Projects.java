package ro.director360.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** „Lucrările mele”: fiecare montaj e salvat singur în telefon, ca să poți continua de unde ai rămas. */
public class Projects {
    public static class Info {
        public String id, title;
        public long updated;
        public int clips;
        public File thumb;
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "projects");
        d.mkdirs();
        return d;
    }

    public static File thumb(Context c, String id) { return new File(dir(c), id + ".t2.jpg"); } // .t2 = poza mică refăcută (cea veche arăta două lentile)

    public static synchronized void save(Context c, String id, JSONObject o) {
        try {
            File tmp = new File(dir(c), id + ".tmp");
            try (FileOutputStream f = new FileOutputStream(tmp)) { f.write(o.toString().getBytes(StandardCharsets.UTF_8)); }
            File dst = new File(dir(c), id + ".json");
            if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst); }
        } catch (Exception ignored) { }
    }

    public static JSONObject load(Context c, String id) {
        try {
            File f = new File(dir(c), id + ".json");
            byte[] b = new byte[(int) f.length()];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                int n = 0;
                while (n < b.length) { int r = in.read(b, n, b.length - n); if (r < 0) break; n += r; }
            }
            return new JSONObject(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) { return null; }
    }

    public static void delete(Context c, String id) {
        new File(dir(c), id + ".json").delete();
        thumb(c, id).delete();
        new File(dir(c), id + ".jpg").delete();
    }

    public static List<Info> list(Context c) {
        List<Info> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".json"));
        if (fs == null) return out;
        Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        for (File f : fs) {
            String id = f.getName().replace(".json", "");
            JSONObject o = load(c, id);
            if (o == null) continue;
            Info i = new Info();
            i.id = id;
            i.title = o.optString("title", "Montaj");
            i.updated = f.lastModified();
            i.clips = o.optJSONArray("clips") == null ? 0 : o.optJSONArray("clips").length();
            File t = thumb(c, id);
            i.thumb = t.exists() ? t : null;
            if (i.clips > 0) out.add(i);
            if (out.size() >= 12) break;
        }
        return out;
    }
}
