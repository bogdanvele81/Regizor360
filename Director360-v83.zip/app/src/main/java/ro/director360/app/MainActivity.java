package ro.director360.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_TREE = 11, REQ_PHONE = 12;
    private static final int F_ALL = 0, F_VIDEO = 1, F_PHOTO = 2;
    private static final Object HEADER = new Object();
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private List<VideoItem> cardList = new ArrayList<>(), phoneList = new ArrayList<>();
    private boolean cardMode = true, bySize = false, scanning = false, byPlace = false;
    private final java.util.Set<List<VideoItem>> geoDone = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());
    private String geoSig = "";
    private TextView sortPlace, geoLine;
    private int filter = F_ALL;
    private Adapter adapter;
    private View header, selBar, splash, srcCard, libHead, emptyBox;
    private TextView status, stats, srcCardSub, dropTitle, dropSub;
    private ProgressBar loading;
    private com.google.android.material.button.MaterialButton selEdit;
    private final List<VideoItem> selected = new ArrayList<>();
    private final List<Object> rows = new ArrayList<>();
    private java.util.Map<String, long[]> headerSums = new java.util.HashMap<>();
    private int newVersion = -1;
    private final AlertDialogHolder help = new AlertDialogHolder();
    static class AlertDialogHolder { androidx.appcompat.app.AlertDialog d; TextView res; }

    @Override
    protected void onCreate(Bundle b) {
        Th.apply(this);
        super.onCreate(b);
        java.io.File cf = new java.io.File(getFilesDir(), "crash.txt");
        if (cf.exists() && !getIntent().getBooleanExtra("skipCrash", false)) {
            String err = "";
            try { err = new String(java.nio.file.Files.readAllBytes(cf.toPath()), "UTF-8"); } catch (Exception ignored) { }
            cf.delete();
            startActivity(new Intent(this, CrashActivity.class).putExtra("err", err));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        I18n.watch(this);
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        loading = findViewById(R.id.loading);
        selBar = findViewById(R.id.selBar);
        selEdit = findViewById(R.id.selEdit);
        splash = findViewById(R.id.splash);

        RecyclerView grid = findViewById(R.id.grid);
        header = LayoutInflater.from(this).inflate(R.layout.home_header, new android.widget.FrameLayout(this), false);
        status = header.findViewById(R.id.status);
        stats = header.findViewById(R.id.stats);
        srcCard = header.findViewById(R.id.srcCard);
        srcCardSub = header.findViewById(R.id.srcCardSub);
        libHead = header.findViewById(R.id.libHead);
        emptyBox = header.findViewById(R.id.emptyBox);
        dropTitle = header.findViewById(R.id.dropTitle);
        dropSub = header.findViewById(R.id.dropSub);
        android.text.SpannableString brand = new android.text.SpannableString("Director 360");
        brand.setSpan(new android.text.style.ForegroundColorSpan(Th.A), 9, 12, 0);
        ((TextView) header.findViewById(R.id.brand)).setText(brand);
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { ver = "?"; }
        ((TextView) header.findViewById(R.id.verLine)).setText("Director360 · versiunea " + ver);
        // limba aplicației: doar iconița, sus în dreapta
        TextView langBtn = new TextView(this);
        langBtn.setText("🌐");
        langBtn.setTextSize(20);
        langBtn.setGravity(android.view.Gravity.CENTER);
        langBtn.setContentDescription(I18n.t(this, "Limba aplicației"));
        android.graphics.drawable.GradientDrawable lb = new android.graphics.drawable.GradientDrawable();
        lb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        lb.setColor(0xFF1C1E22);
        langBtn.setBackground(lb);
        LinearLayout brandRow = (LinearLayout) header.findViewById(R.id.brand).getParent();
        brandRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(dp(42), dp(42));
        llp.setMarginEnd(dp(4));
        brandRow.addView(langBtn, llp);
        langBtn.setOnClickListener(v -> new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(I18n.t(this, "Limba aplicației"))
                .setItems(I18n.NAMES, (d, w) -> { I18n.setLang(this, I18n.LANGS[w]); recreate(); })
                .show());

        final int cols = getResources().getConfiguration().screenWidthDp > 600 ? 4 : 2;
        GridLayoutManager glm = new GridLayoutManager(this, cols);
        glm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int pos) { return pos < rows.size() && !(rows.get(pos) instanceof VideoItem) ? cols : 1; }
        });
        grid.setLayoutManager(glm);
        adapter = new Adapter();
        grid.setAdapter(adapter);

        // „Director 360 Moments” + „Idei AI”, între surse și listă
        momentsBox = new LinearLayout(this);
        momentsBox.setOrientation(LinearLayout.VERTICAL);
        ViewGroup hp = (ViewGroup) libHead.getParent();
        hp.addView(momentsBox, hp.indexOfChild(libHead));
        srcCard.setOnClickListener(v -> goCard());
        srcCard.setOnLongClickListener(v -> { pickTree(); return true; });
        header.findViewById(R.id.dropCard).setOnClickListener(v -> { cardMode = true; pickTree(); });
        header.findViewById(R.id.pickPhone).setOnClickListener(v -> pickPhone());
        View.OnClickListener soon = v -> new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(v.getId() == R.id.srcCam ? "Cameră (Wi-Fi)" : "Cloud")
                .setMessage(v.getId() == R.id.srcCam
                        ? "Citirea filmărilor direct din cameră prin Wi-Fi vine într-o versiune următoare. Până atunci folosește „Card” (cititor de card) sau „Telefon”."
                        : "Salvarea în cloud vine într-o versiune următoare. Până atunci ce salvezi ajunge în telefon, în albumul Director360.")
                .setPositiveButton("Am înțeles", null).show();
        header.findViewById(R.id.srcCam).setOnClickListener(v -> startActivity(new Intent(this, CameraActivity.class)));
        header.findViewById(R.id.srcCloud).setOnClickListener(soon);
        header.findViewById(R.id.blackDel).setOnClickListener(v -> askDeleteBlack());
        header.findViewById(R.id.sortDate).setOnClickListener(v -> { bySize = false; byPlace = false; refresh(); });
        header.findViewById(R.id.sortSize).setOnClickListener(v -> { bySize = true; byPlace = false; refresh(); });
        // „📍 După loc”, lângă celelalte
        {
            TextView ss = header.findViewById(R.id.sortSize);
            sortPlace = new TextView(this);
            sortPlace.setText("📍 După loc");
            sortPlace.setBackgroundResource(R.drawable.chip_bg);
            sortPlace.setTextColor(ss.getTextColors());
            sortPlace.setTextSize(13);
            sortPlace.setGravity(android.view.Gravity.CENTER);
            sortPlace.setPadding(dp(14), 0, dp(14), 0);
            ViewGroup sp = (ViewGroup) ss.getParent();
            sp.addView(sortPlace, sp.indexOfChild(ss) + 1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));
            sortPlace.setOnClickListener(v -> { byPlace = true; bySize = false; refresh(); });
            geoLine = new TextView(this);
            geoLine.setTextColor(0xFF9AA0A6);
            geoLine.setTextSize(12);
            geoLine.setPadding(dp(4), dp(6), dp(4), 0);
            geoLine.setVisibility(View.GONE);
            ViewGroup sp2 = (ViewGroup) sp.getParent();
            sp2.addView(geoLine, sp2.indexOfChild(sp) + 1);
        }
        status.setOnClickListener(v -> { if (newVersion > 0) doUpdate(); });

        findViewById(R.id.navHome).setOnClickListener(v -> { filter = F_ALL; goCardOrCurrent(); });
        findViewById(R.id.navVideo).setOnClickListener(v -> { filter = F_VIDEO; refresh(); });
        findViewById(R.id.navPhoto).setOnClickListener(v -> { filter = F_PHOTO; refresh(); });
        findViewById(R.id.navPhone).setOnClickListener(v -> {
            if (!cardMode && !phoneList.isEmpty()) { pickPhone(); return; }
            cardMode = false;
            loadPhone();
            if (phoneList.isEmpty()) pickPhone(); else refresh();
        });
        findViewById(R.id.navHelp).setOnClickListener(v -> showHelp());
        findViewById(R.id.selDel).setOnClickListener(v -> { if (!selected.isEmpty()) askDelete(new ArrayList<>(selected)); });
        findViewById(R.id.selCancel).setOnClickListener(v -> { if (!selected.isEmpty()) open(new ArrayList<>(selected), false); });
        selEdit.setOnClickListener(v -> { if (!selected.isEmpty()) open(new ArrayList<>(selected), true); });
        {
            com.google.android.material.button.MaterialButton ai = new com.google.android.material.button.MaterialButton(this);
            ai.setText("🎙  Spune-i AI-ului ce vrei");
            ai.setTextSize(15);
            ai.setAllCaps(false);
            ai.setCornerRadius(dp(26));
            ai.setBackgroundTintList(ColorStateList.valueOf(Th.A));
            ai.setTextColor(0xFF111111);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
            lp.setMargins(dp(12), dp(4), dp(12), dp(8));
            ((ViewGroup) selBar).addView(ai, lp);
            ai.setOnClickListener(v -> { if (!selected.isEmpty()) askAi(new ArrayList<>(selected)); });
        }

        runSplash();
        startInsertAnim();
        if (prefs.getString("tree", null) != null) scanCard();
        refresh();

        if (getIntent().getBooleanExtra("ciTest", false)) { splash.setVisibility(View.GONE); ciTest(getIntent().getStringExtra("ciOpen")); }

        Updater.check(this, v -> {
            if (v > Updater.current(this)) {
                newVersion = v;
                status.setVisibility(View.VISIBLE);
                status.setText("⬆ Versiune nouă: 1." + v + " · apasă aici ca să actualizezi");
                status.setTextColor(0xFFFFD21F);
            }
        });
    }

    /** doar pentru proba automată de pe GitHub: fișiere de test din folderul aplicației */
    private void ciTest(String what) {
        java.io.File dir = getExternalFilesDir(null);
        java.io.File[] fs = dir == null ? null : dir.listFiles();
        phoneList = new ArrayList<>();
        java.util.Map<String, Uri> lrv = new java.util.HashMap<>();
        if (fs != null) for (java.io.File f : fs) if (f.getName().toLowerCase().endsWith(".lrv")) lrv.put(VideoItem.stem(f.getName()), Uri.fromFile(f));
        if (fs != null) for (java.io.File f : fs) {
            String low = f.getName().toLowerCase();
            if (!f.isFile() || !(low.endsWith(".mp4") || low.endsWith(".insv") || low.endsWith(".insp") || low.endsWith(".jpg"))) continue;
            VideoItem it = new VideoItem(Uri.fromFile(f), f.getName(), f.length(), f.lastModified());
            it.lrv = lrv.get(VideoItem.stem(f.getName()));
            phoneList.add(it);
        }
        cardMode = false;
        refresh();
        if (what == null) return;
        List<VideoItem> vids = new ArrayList<>();
        for (VideoItem it : phoneList) {
            if (what.equals("photo") && it.isPhoto() && !it.is360()) { openPhoto(it); return; }
            if (what.equals("photo360") && it.isPhoto() && it.is360()) { openPhoto(it); return; }
            if (what.equals("video") && !it.isPhoto()) vids.add(it);
        }
        if (!vids.isEmpty()) open(vids, false);
        if (what.equals("auto")) {
            List<VideoItem> v2 = new ArrayList<>();
            for (VideoItem it : phoneList) if (!it.isPhoto()) v2.add(it);
            if (!v2.isEmpty()) open(v2, true);
        }
        if (what.equals("select")) for (VideoItem it : phoneList) if (!it.isPhoto()) toggleSel(it);
    }

    // ---------------- pozele negre (făcute din greșeală) ----------------
    private boolean pendingDelete = false, blackScanning = false;
    private int blackDone = 0, blackTotal = 0;

    private List<VideoItem> blackList() {
        List<VideoItem> l = new ArrayList<>();
        for (VideoItem it : cardList) if (it.isPhoto() && it.isBlack()) l.add(it);
        return l;
    }

    /** caută în spate pozele negre de pe card (citește doar poza mică din fiecare fișier) */
    private void scanBlack() {
        if (blackScanning) return;
        final List<VideoItem> ph = new ArrayList<>();
        for (VideoItem it : cardList) if (it.isPhoto()) ph.add(it);
        if (ph.isEmpty()) return;
        blackScanning = true;
        blackTotal = ph.size();
        blackDone = 0;
        new Thread(() -> {
            for (VideoItem it : ph) {
                if (isFinishing()) break;
                // cât timp se încarcă pozele de pe ecran, aștept
                while (Thumbs.pending() > 0 && !isFinishing()) { try { Thread.sleep(400); } catch (InterruptedException ignored) { } }
                Thumbs.shape(getApplicationContext(), it, false);
                blackDone++;
                if (blackDone % 10 == 0 || blackDone == blackTotal) main.post(this::updateBlackBar);
            }
            blackScanning = false;
            main.post(() -> { updateBlackBar(); if (adapter != null) adapter.notifyDataSetChanged(); });
        }).start();
    }

    private void updateBlackBar() {
        View bar = header.findViewById(R.id.blackBar);
        TextView t = header.findViewById(R.id.blackText);
        View del = header.findViewById(R.id.blackDel);
        int n = blackList().size();
        boolean show = cardMode && filter != F_VIDEO && (n > 0 || blackScanning);
        bar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) return;
        String found = n == 1 ? "1 poză neagră" : n + " poze negre";
        t.setText(blackScanning ? "Caut pozele negre… " + blackDone + "/" + blackTotal + " · am găsit " + found
                : found + " (făcute din greșeală, cu husa pe cameră)");
        del.setVisibility(n > 0 ? View.VISIBLE : View.GONE);
    }

    private void askDeleteBlack() {
        final List<VideoItem> l = blackList();
        if (l.isEmpty()) return;
        long tot = 0;
        for (VideoItem it : l) tot += it.size;
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ștergi " + (l.size() == 1 ? "poza neagră?" : "cele " + l.size() + " poze negre?"))
                .setMessage("Se șterg de pe card și eliberezi " + fmtSize(tot) + ". Nu se mai pot recupera.\n\nSfat: uită-te întâi prin ele în listă, să fii sigur că sunt toate negre.")
                .setPositiveButton("Șterge", (d, w) -> deleteItems(l, true))
                .setNegativeButton("Renunț", null)
                .show();
    }

    // ---------------- meniul ⋮ al fiecărei filmări / poze ----------------
    private void itemMenu(VideoItem it) {
        List<String> labels = new ArrayList<>();
        List<Runnable> acts = new ArrayList<>();
        if (it.isPhoto()) { labels.add("✏️  Editează poza"); acts.add(() -> openPhoto(it)); }
        else {
            labels.add("✏️  Editează (Editez eu)"); acts.add(() -> { List<VideoItem> one = new ArrayList<>(); one.add(it); open(one, false); });
            labels.add("✨  Montaj automat"); acts.add(() -> { List<VideoItem> one = new ArrayList<>(); one.add(it); open(one, true); });
        }
        labels.add("☑️  Alege (pentru mai multe)"); acts.add(() -> toggleSel(it));
        labels.add("📤  Trimite fișierul"); acts.add(() -> shareItem(it));
        labels.add("ℹ️  Detalii"); acts.add(() -> details(it));
        if (cardMode) { labels.add("🗑️  Șterge de pe card"); acts.add(() -> { List<VideoItem> one = new ArrayList<>(); one.add(it); askDelete(one); }); }
        else { labels.add("➖  Scoate din listă"); acts.add(() -> removeFromPhone(it)); }
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(pretty(it.name))
                .setItems(labels.toArray(new String[0]), (d, w) -> acts.get(w).run())
                .setNegativeButton("Închide", null)
                .show();
    }

    private void shareItem(VideoItem it) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(it.isPhoto() ? "image/*" : "video/*");
        i.putExtra(Intent.EXTRA_STREAM, it.uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Trimite")); } catch (Exception e) { toast("Nu pot trimite fișierul."); }
    }

    private void details(VideoItem it) {
        StringBuilder sb = new StringBuilder();
        sb.append("Fișier: ").append(it.name).append("\n");
        sb.append("Mărime: ").append(fmtSize(it.size + extraSize(it))).append("\n");
        sb.append("Data: ").append(dayOf(it)).append(", ").append(pretty(it.name).replaceAll(".* · ", "")).append("\n");
        String kind = it.isBlack() ? "poză neagră (făcută din greșeală)" : it.shape == 3 ? "poză cu o singură lentilă" : it.is360() ? (it.isPhoto() ? "poză 360" : "filmare 360") : (it.isPhoto() ? "poză normală" : "filmare normală");
        sb.append("Fel: ").append(kind).append("\n");
        if (!it.isPhoto() && it.durationMs > 0) { long s = it.durationMs / 1000; sb.append("Durată: ").append(String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)).append("\n"); }
        if (!it.extra.isEmpty()) sb.append("Fișiere legate: ").append(it.extra.size()).append(" (a doua lentilă / previzualizare), se șterg împreună\n");
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this).setTitle("Detalii").setMessage(sb.toString()).setPositiveButton("Bine", null).show();
    }

    private long extraSize(VideoItem it) {
        long t = 0;
        for (Uri u : it.extra) {
            try (android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) t += c.getLong(0);
            } catch (Exception ignored) { }
        }
        return t;
    }

    private void removeFromPhone(VideoItem it) {
        Set<String> set = new HashSet<>(prefs.getStringSet("phone", new HashSet<>()));
        set.remove(it.uri.toString());
        prefs.edit().putStringSet("phone", set).apply();
        phoneList.remove(it);
        selected.remove(it);
        refresh();
    }

    private void askDelete(List<VideoItem> l) {
        if (!cardMode) { for (VideoItem it : l) removeFromPhone(it); clearSel(); return; }
        int nv = 0, np = 0;
        for (VideoItem it : l) if (it.isPhoto()) np++; else nv++;
        String what = nv > 0 && np > 0 ? (nv + (nv == 1 ? " filmare" : " filmări") + " și " + np + (np == 1 ? " poză" : " poze"))
                : nv > 0 ? (nv == 1 ? "filmarea" : "cele " + nv + " filmări") : (np == 1 ? "poza" : "cele " + np + " poze");
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ștergi " + what + "?")
                .setMessage("Se șterg de pe card" + (nv > 0 ? ", împreună cu fișierele lor legate (a doua lentilă și previzualizarea)" : "") + ". Nu se mai pot recupera.")
                .setPositiveButton("Șterge", (d, w) -> deleteItems(l, false))
                .setNegativeButton("Renunț", null)
                .show();
    }

    private void deleteItems(List<VideoItem> l) { deleteItems(l, true); }

    private void deleteItems(List<VideoItem> l, boolean black) {
        loading.setVisibility(View.VISIBLE);
        new Thread(() -> {
            int ok = 0;
            boolean noPerm = false;
            List<VideoItem> gone = new ArrayList<>();
            for (VideoItem it : l) {
                try {
                    if (android.provider.DocumentsContract.deleteDocument(getContentResolver(), it.uri)) {
                        ok++; gone.add(it); Thumbs.forget(this, it);
                        for (Uri x : it.extra) { try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), x); } catch (Exception ignored) { } }
                    }
                } catch (SecurityException e) { noPerm = true; break; }
                catch (Exception ignored) { }
            }
            final int fOk = ok;
            final boolean fNo = noPerm;
            main.post(() -> {
                loading.setVisibility(View.GONE);
                cardList.removeAll(gone);
                selected.removeAll(gone);
                if (selected.isEmpty()) selBar.setVisibility(View.GONE);
                refresh();
                updateBlackBar();
                if (fNo && fOk == 0) {
                    new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                            .setTitle("Am nevoie de voie să șterg")
                            .setMessage("Ca să pot șterge de pe card, alege încă o dată folderul cardului (DCIM) și apasă „Folosește acest folder” / „Permite”. Se face o singură dată.")
                            .setPositiveButton("Alege folderul", (d, w) -> { pendingDelete = true; pickTree(); })
                            .setNegativeButton("Renunț", null)
                            .show();
                } else if (black) toast(fOk == 1 ? "Am șters 1 poză neagră." : "Am șters " + fOk + " poze negre.");
                else toast(fOk == 1 ? "Am șters 1 fișier de pe card." : "Am șters " + fOk + " de pe card.");
            });
        }).start();
    }

    private void startInsertAnim() {
        View sd = header.findViewById(R.id.sdAnim);
        float d = getResources().getDisplayMetrics().density;
        android.animation.ObjectAnimator a = android.animation.ObjectAnimator.ofFloat(sd, "translationY", -18 * d, 6 * d);
        a.setDuration(1200);
        a.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        a.setRepeatMode(android.animation.ValueAnimator.REVERSE);
        a.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        a.start();
    }

    private void goCardOrCurrent() {
        if (!cardMode) { cardMode = true; }
        goCard();
    }

    private void goCard() {
        cardMode = true;
        String t = prefs.getString("tree", null);
        if (t == null) { refresh(); pickTree(); }
        else if (cardList.isEmpty() && !scanning) scanCard();
        else refresh();
    }

    private void runSplash() {
        ((SplashView) splash).setOnDone(() -> splash.setVisibility(View.GONE));
    }

    private View wrapScroll(View v) {
        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.addView(v);
        return sv;
    }

    private void showHelp() {
        String ver;
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { ver = "?"; }
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pd = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pd, pd / 2, pd, 0);
        TextView t = new TextView(this);
        t.setTextColor(0xFFB9BCBF);
        t.setTextSize(15);
        t.setLineSpacing(0, 1.25f);
        t.setText("• Card: conectează cititorul cu cardul camerei și alege folderul DCIM (o singură dată). Ține apăsat pe „Card” ca să alegi alt folder.\n"
                + "• Telefon: alege filmări sau poze din memoria telefonului.\n• Filmări / Poze: arată doar filmările sau doar pozele.\n"
                + "• Atinge filmările pe care le vrei (se numerotează 1, 2, 3), apoi: „Gata” = montaj automat (aplicația alege cele mai vii momente), sau „Editez eu” = le pui tu una după alta. O poză se deschide cu o atingere.\n"
                + "• În editor: trage pe timeline ca să cauți; atinge un clip ca să-l tai de la margini, să-l muți sau să-l ștergi.\n"
                + "• Filmările 360 (marcate „360”) se pot roti cu degetul; dublu-atingere = Tiny Planet.\n\n"
                + "Versiune: " + ver);
        // culoarea aplicației
        TextView ct = new TextView(this);
        ct.setText("CULOAREA APLICAȚIEI");
        ct.setTextColor(0xFF9AA0A6);
        ct.setTextSize(12);
        ct.setLetterSpacing(0.08f);
        ct.setPadding(0, 0, 0, pd / 3);
        box.addView(ct);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        android.widget.LinearLayout cr = new android.widget.LinearLayout(this);
        float dd0 = getResources().getDisplayMetrics().density;
        for (int i = 0; i < Th.ACCENT.length; i++) {
            final int k = i;
            View c = new View(this);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(Th.ACCENT[i]);
            if (i == Th.index()) g.setStroke((int) (3 * dd0), 0xFFF2F2F0);
            c.setBackground(g);
            c.setContentDescription(Th.NAMES[i]);
            c.setOnClickListener(v -> {
                if (k == Th.index()) return;
                Th.set(this, k);
                if (help.d != null) help.d.dismiss();
                recreate();
            });
            android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams((int) (38 * dd0), (int) (38 * dd0));
            lp.setMarginEnd((int) (12 * dd0));
            cr.addView(c, lp);
        }
        hs.addView(cr);
        box.addView(hs);
        View gap = new View(this);
        box.addView(gap, new android.widget.LinearLayout.LayoutParams(1, pd));
        box.addView(t);
        TextView res = new TextView(this);
        res.setTextColor(0xFFFFD21F);
        res.setTextSize(15);
        res.setPadding(0, pd / 2, 0, 0);
        box.addView(res);
        help.res = res;
        help.d = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ajutor")
                .setView(wrapScroll(box))
                .setNegativeButton("Închide", null)
                .setPositiveButton("Caută actualizări", null)
                .show();
        help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (newVersion > Updater.current(this)) { help.d.dismiss(); doUpdate(); return; }
            res.setText("Caut…");
            Updater.check(this, nv -> {
                if (nv > Updater.current(this)) {
                    newVersion = nv;
                    res.setText("Există versiunea nouă 1." + nv + ". Apasă din nou ca s-o instalezi.");
                    ((TextView) help.d.getButton(android.content.DialogInterface.BUTTON_POSITIVE)).setText("Actualizează");
                } else if (nv < 0) res.setText("Nu pot verifica acum. Verifică internetul.");
                else res.setText("Ai ultima versiune.");
            });
        });
    }

    private void clearSel() {
        selected.clear();
        if (selBar != null) selBar.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void toggleSel(VideoItem it) {
        if (selected.contains(it)) selected.remove(it); else selected.add(it);
        selBar.setVisibility(selected.isEmpty() ? View.GONE : View.VISIBLE);
        int nv = 0, nPh = 0;
        for (VideoItem s0 : selected) if (s0.isPhoto()) nPh++; else nv++;
        String txt = nv > 0 ? (nv == 1 ? "1 filmare" : nv + " filmări") : "";
        if (nPh > 0) txt += (txt.isEmpty() ? "" : " și ") + (nPh == 1 ? "1 poză" : nPh + " poze");
        ((TextView) findViewById(R.id.selCount)).setText(txt + (selected.size() == 1 ? " aleasă" : " alese"));
        selEdit.setText("Gata (" + nv + ")");
        selEdit.setEnabled(nv > 0);
        findViewById(R.id.selCancel).setEnabled(nv > 0);
        LinearLayout th = findViewById(R.id.selThumbs);
        th.removeAllViews();
        float dd = getResources().getDisplayMetrics().density;
        for (int k = 0; k < selected.size(); k++) {
            VideoItem s = selected.get(k);
            android.widget.FrameLayout f = new android.widget.FrameLayout(this);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF262A2E);
            iv.setClipToOutline(true);
            iv.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), 10 * dd); }
            });
            f.addView(iv, new android.widget.FrameLayout.LayoutParams((int) (72 * dd), (int) (50 * dd)));
            Thumbs.load(this, s, iv);
            TextView num = new TextView(this);
            num.setText(String.valueOf(k + 1));
            num.setTextColor(0xFFFFFFFF);
            num.setTextSize(12);
            num.setTypeface(null, android.graphics.Typeface.BOLD);
            num.setGravity(android.view.Gravity.CENTER);
            num.setBackgroundResource(R.drawable.check_bg);
            android.widget.FrameLayout.LayoutParams np = new android.widget.FrameLayout.LayoutParams((int) (22 * dd), (int) (22 * dd), android.view.Gravity.BOTTOM | android.view.Gravity.START);
            np.setMargins((int) (3 * dd), 0, 0, (int) (3 * dd));
            f.addView(num, np);
            TextView x = new TextView(this);
            x.setText("×");
            x.setTextColor(0xFF111315);
            x.setTextSize(14);
            x.setTypeface(null, android.graphics.Typeface.BOLD);
            x.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable xb = new android.graphics.drawable.GradientDrawable();
            xb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            xb.setColor(0xFFF2F2F0);
            x.setBackground(xb);
            android.widget.FrameLayout.LayoutParams xp = new android.widget.FrameLayout.LayoutParams((int) (22 * dd), (int) (22 * dd), android.view.Gravity.TOP | android.view.Gravity.END);
            f.addView(x, xp);
            f.setOnClickListener(v -> toggleSel(s));
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            fp.setMarginEnd((int) (10 * dd));
            th.addView(f, fp);
        }
        adapter.notifyDataSetChanged();
    }

    private void pickTree() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_TREE); } catch (Exception e) { toast("Nu pot deschide alegerea folderului."); }
    }

    private void pickPhone() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_PHONE); } catch (Exception e) { toast("Nu pot deschide memoria telefonului."); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == 501) {
            java.util.ArrayList<String> r = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty() && aiText != null) { aiText.setText(r.get(0)); aiParse(r.get(0)); }
            return;
        }
        if (req == REQ_TREE && data.getData() != null) {
            Uri t = data.getData();
            try { getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
            catch (Exception e) { try { getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { } }
            prefs.edit().putString("tree", t.toString()).apply();
            if (pendingDelete) { pendingDelete = false; main.postDelayed(this::askDeleteBlack, 1500); }
            cardMode = true;
            scanCard();
        } else if (req == REQ_PHONE) {
            Set<String> set = new HashSet<>(prefs.getStringSet("phone", new HashSet<>()));
            List<Uri> got = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) got.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) got.add(data.getData());
            for (Uri u : got) {
                try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                set.add(u.toString());
            }
            prefs.edit().putStringSet("phone", set).apply();
            cardMode = false;
            loadPhone();
            refresh();
        }
    }

    private void scanCard() {
        String t = prefs.getString("tree", null);
        if (t == null) return;
        scanning = true;
        loading.setVisibility(View.VISIBLE);
        srcCardSub.setText("citesc…");
        final Uri tree = Uri.parse(t);
        bg.execute(() -> {
            List<VideoItem> l = Library.scanTree(this, tree);
            main.post(() -> {
                scanning = false;
                loading.setVisibility(View.GONE);
                cardList = l;
                refresh();
                scanBlack();
            });
        });
    }

    private void loadPhone() {
        phoneList = new ArrayList<>();
        for (String s : prefs.getStringSet("phone", new HashSet<>())) phoneList.add(Library.fromPhone(this, Uri.parse(s)));
    }

    /** redesenează tot ecranul după sursă, filtru și sortare */
    @Override protected void onResume() {
        super.onResume();
        if (momentsBox != null) buildMoments();
    }

    // ---------------- Director 360 Moments ----------------
    private LinearLayout momentsBox;
    private String momentsSig = "";

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    /** un film propus: bucățile lui, titlul și cât de lung să fie */
    static class Moment {
        List<VideoItem> items;
        String title, sub;
        int lenSec;
        boolean whole, first;
        java.util.Set<String> wish = new java.util.HashSet<>();
    }

    /** zilele cu filmări, cele mai noi întâi */
    private List<List<VideoItem>> momentDays(List<VideoItem> src) {
        java.util.LinkedHashMap<String, List<VideoItem>> m = new java.util.LinkedHashMap<>();
        List<VideoItem> sorted = new ArrayList<>(src);
        java.util.Collections.sort(sorted, (x, y) -> y.name.compareTo(x.name));
        for (VideoItem it : sorted) {
            if (it.isBlack()) continue;
            String d = dayOf(it);
            List<VideoItem> l = m.get(d);
            if (l == null) { l = new ArrayList<>(); m.put(d, l); }
            l.add(it);
        }
        List<List<VideoItem>> out = new ArrayList<>();
        for (List<VideoItem> l : m.values()) {
            int v = 0;
            for (VideoItem it : l) if (!it.isPhoto()) v++;
            if (v >= 1 && l.size() >= 2) out.add(l);
            if (out.size() >= 6) break;
        }
        return out;
    }

    /** o zi cu mai multe locuri (obiective) = câte un film pentru fiecare loc + unul scurt cu toată ziua */
    private List<Moment> moments(List<VideoItem> src) {
        List<Moment> out = new ArrayList<>();
        for (List<VideoItem> day : momentDays(src)) {
            String d = dayOf(day.get(0));
            String date = d.contains(",") ? d.substring(d.indexOf(',') + 1).trim() : d;
            // împărțim ziua: după loc (dacă îl știm), altfel după pauzele mari (peste 2 ore)
            java.util.LinkedHashMap<String, List<VideoItem>> parts = new java.util.LinkedHashMap<>();
            boolean hasPlace = false;
            for (VideoItem it : day) if (it.place != null) hasPlace = true;
            if (hasPlace) {
                String lastP = null;
                for (VideoItem it : day) {
                    String p = it.place != null ? it.place : lastP;
                    if (p == null) p = "?";
                    lastP = p;
                    List<VideoItem> q = parts.get(p);
                    if (q == null) { q = new ArrayList<>(); parts.put(p, q); }
                    q.add(it);
                }
            } else {
                long prev = -1; int g = 0;
                for (VideoItem it : day) {
                    long t = Story.timeOf(this, it.name, null);
                    if (t <= 0) t = it.modified;
                    if (prev > 0 && Math.abs(prev - t) > 2L * 3600 * 1000) g++;
                    prev = t;
                    String k = "#" + g;
                    List<VideoItem> q = parts.get(k);
                    if (q == null) { q = new ArrayList<>(); parts.put(k, q); }
                    q.add(it);
                }
            }
            List<String> keys = new ArrayList<>();
            for (java.util.Map.Entry<String, List<VideoItem>> e : parts.entrySet()) {
                int v = 0;
                for (VideoItem it : e.getValue()) if (!it.isPhoto()) v++;
                if (v > 0 && !e.getKey().equals("?")) keys.add(e.getKey());
            }
            String plc = placeOf(day);
            if (keys.size() >= 2) {
                Moment w = new Moment();
                w.items = day; w.whole = true; w.lenSec = 90;
                w.title = (plc != null ? plc : I18n.t(this, "Toată ziua")) + " · " + I18n.t(this, "pe scurt");
                w.sub = date + " · " + keys.size() + " " + I18n.t(this, "locuri");
                out.add(w);
                // locurile, în ordinea zilei (lista e de la cel mai nou la cel mai vechi)
                for (int k = keys.size() - 1; k >= 0; k--) {
                    String key = keys.get(k);
                    Moment m = new Moment();
                    m.items = parts.get(key); m.lenSec = 60;
                    m.title = key.startsWith("#") ? I18n.t(this, "Partea") + " " + (keys.size() - k) : "📍 " + key;
                    m.sub = date + " · " + countText(m.items);
                    out.add(m);
                }
            } else {
                Moment m = new Moment();
                m.items = day; m.lenSec = 120;
                String[] names = {"Povestea zilei", "O zi de povestit", "Amintiri", "Ziua ta, pe scurt", "Ce s-a întâmplat", "O zi frumoasă"};
                String nm = out.isEmpty() ? names[0] : names[1 + Math.abs(d.hashCode()) % (names.length - 1)];
                m.title = plc != null ? "📍 " + plc : I18n.t(this, nm) + " · " + d.split(",")[0];
                m.sub = date + " · " + countText(day);
                out.add(m);
            }
            if (out.size() >= 10) break;
        }
        // zilele: cel mult 4, apoi ideile AI (se schimbă la „🔄 Idei noi”)
        List<Moment> days = out.size() > 4 ? new ArrayList<>(out.subList(0, 4)) : out;
        List<Moment> ideas = ideas(src);
        List<Moment> res = new ArrayList<>(days);
        if (!ideas.isEmpty()) {
            int off = ideasPage % ideas.size();
            for (int q = 0; q < Math.min(4, ideas.size()); q++) res.add(ideas.get((off + q) % ideas.size()));
        }
        if (!res.isEmpty()) res.get(0).first = true;
        return res;
    }

    private int ideasPage = 0;

    private int hourOf(VideoItem it) {
        long t = Story.timeOf(this, it.name, null);
        if (t <= 0) t = it.modified;
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(t);
        return c.get(java.util.Calendar.HOUR_OF_DAY);
    }

    private long timeOfItem(VideoItem it) {
        long t = Story.timeOf(this, it.name, null);
        return t > 0 ? t : it.modified;
    }

    /** idei de filme din toată biblioteca, nu doar pe zile */
    private List<Moment> ideas(List<VideoItem> src) {
        List<Moment> l = new ArrayList<>();
        List<VideoItem> sorted = new ArrayList<>(src);
        java.util.Collections.sort(sorted, (x, y) -> y.name.compareTo(x.name));
        // 1) apusuri și seri (18–22)
        List<VideoItem> eve = new ArrayList<>();
        for (VideoItem it : sorted) { int h = hourOf(it); if (h >= 18 && h <= 21 && !it.isBlack()) eve.add(it); if (eve.size() >= 40) break; }
        addIdea(l, eve, "🌅 " + I18n.t(this, "Apusuri și seri"), I18n.t(this, "lumina caldă de la final de zi"), 60, "land");
        // 2) noaptea (22–4)
        List<VideoItem> night = new ArrayList<>();
        for (VideoItem it : sorted) { int h = hourOf(it); if ((h >= 22 || h <= 4) && !it.isBlack()) night.add(it); if (night.size() >= 40) break; }
        addIdea(l, night, "🌙 " + I18n.t(this, "Noaptea"), I18n.t(this, "luminile orașului, focuri, petreceri"), 60);
        // 3) oamenii tăi: pozele cu oameni + filmările din aceeași oră
        List<VideoItem> ppl = new ArrayList<>(), land = new ArrayList<>(), planets = new ArrayList<>();
        for (VideoItem it : sorted) {
            if (!it.isPhoto()) continue;
            float[] sc = Score.cached(this, it);
            if (sc == null || sc[1] == Score.CAT_BAD) continue;
            if (sc[1] == Score.CAT_PEOPLE && ppl.size() < 12) ppl.add(it);
            if (sc[1] == Score.CAT_LAND && land.size() < 12) land.add(it);
            if (it.is360() && sc[0] > 1.5f && planets.size() < 10) planets.add(it);
        }
        addIdea(l, withVideosNear(sorted, ppl), "😀 " + I18n.t(this, "Oamenii tăi"), I18n.t(this, "fețe, zâmbete, grupuri — cadrul îi urmărește"), 60, "follow");
        addIdea(l, withVideosNear(sorted, land), "🏔 " + I18n.t(this, "Cele mai frumoase peisaje"), I18n.t(this, "munte, mare, orașe — alese de AI"), 60, "land");
        addIdea(l, withVideosNear(sorted, planets), "🌍 " + I18n.t(this, "Planete mici"), I18n.t(this, "pozele 360 ca Tiny Planet"), 30, "planet");
        // 4) acum un an (aceeași perioadă, ±4 zile)
        java.util.Calendar now = java.util.Calendar.getInstance();
        List<VideoItem> ago = new ArrayList<>();
        for (VideoItem it : sorted) {
            java.util.Calendar c = java.util.Calendar.getInstance();
            c.setTimeInMillis(timeOfItem(it));
            if (c.get(java.util.Calendar.YEAR) < now.get(java.util.Calendar.YEAR) && Math.abs(c.get(java.util.Calendar.DAY_OF_YEAR) - now.get(java.util.Calendar.DAY_OF_YEAR)) <= 4) ago.add(it);
        }
        addIdea(l, ago, "📅 " + I18n.t(this, "Pe vremea asta, acum un an"), I18n.t(this, "amintiri din aceeași perioadă"), 60);
        // 5) fiecare loc, din toate zilele
        java.util.LinkedHashMap<String, List<VideoItem>> byPlace = new java.util.LinkedHashMap<>();
        for (VideoItem it : sorted) {
            if (it.place == null) continue;
            String c = it.place.split(" · ")[0];
            List<VideoItem> q = byPlace.get(c);
            if (q == null) { q = new ArrayList<>(); byPlace.put(c, q); }
            if (q.size() < 30) q.add(it);
        }
        int pk = 0;
        for (java.util.Map.Entry<String, List<VideoItem>> e : byPlace.entrySet()) {
            java.util.Set<String> ds = new java.util.HashSet<>();
            for (VideoItem it : e.getValue()) ds.add(dayOf(it));
            if (ds.size() < 2) continue;
            addIdea(l, e.getValue(), "🗺 " + e.getKey(), ds.size() + " " + I18n.t(this, "zile într-un singur film"), 90);
            if (++pk >= 3) break;
        }
        // 6) cele mai stabile filmări (cele deja verificate)
        List<VideoItem> calm = new ArrayList<>();
        for (VideoItem it : sorted) {
            if (it.isPhoto()) continue;
            float j = getSharedPreferences("score", MODE_PRIVATE).getFloat("j:" + it.key(), -1);
            if (j >= 0 && j < 12) calm.add(it);
            if (calm.size() >= 12) break;
        }
        addIdea(l, calm, "🎬 " + I18n.t(this, "Ca la cinema"), I18n.t(this, "doar cadrele line, fără tremurat"), 60);
        return l;
    }

    /** pozele + filmările făcute în aceeași oră cu ele */
    private List<VideoItem> withVideosNear(List<VideoItem> all, List<VideoItem> photos) {
        List<VideoItem> out = new ArrayList<>(photos);
        for (VideoItem p : photos) {
            long tp = timeOfItem(p);
            for (VideoItem v : all) if (!v.isPhoto() && !out.contains(v) && Math.abs(timeOfItem(v) - tp) < 45 * 60000L) { out.add(v); break; }
        }
        java.util.Collections.sort(out, (x, y) -> y.name.compareTo(x.name));
        return out;
    }

    private void addIdea(List<Moment> l, List<VideoItem> items, String title, String sub, int len, String... wish) {
        int nv = 0;
        for (VideoItem it : items) if (!it.isPhoto()) nv++;
        if (items.size() < 3 || (nv == 0 && items.size() < 4)) return;
        Moment m = new Moment();
        m.items = items; m.title = title; m.sub = sub + " · " + countText(items); m.lenSec = len; m.whole = true;
        for (String w : wish) m.wish.add(w);
        l.add(m);
    }

    private String countText(List<VideoItem> l) {
        int nv = 0, np = 0;
        for (VideoItem it : l) if (it.isPhoto()) np++; else nv++;
        return nv + " " + I18n.t(this, "filmări") + (np > 0 ? " + " + np + " " + I18n.t(this, "poze") : "");
    }

    private void buildMoments() {
        List<VideoItem> src = cardMode ? cardList : phoneList;
        List<Projects.Info> projs = Projects.list(this);
        String sig = cardMode + ":" + src.size() + ":" + I18n.lang(this) + ":" + projs.size() + ":" + (projs.isEmpty() ? 0 : projs.get(0).updated);
        if (sig.equals(momentsSig)) return;
        momentsSig = sig;
        momentsBox.removeAllViews();
        if (!projs.isEmpty()) buildMyWork(projs);
        List<Moment> days = moments(src);
        TextView h = new TextView(this);
        h.setText("Director 360 Moments");
        h.setTextColor(0xFFF2F2F0);
        h.setTextSize(20);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout hr = new LinearLayout(this);
        hr.setGravity(android.view.Gravity.CENTER_VERTICAL);
        hr.setPadding(dp(4), dp(18), 0, dp(10));
        hr.addView(h, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView again = new TextView(this);
        again.setText("🔄 " + I18n.t(this, "Idei noi"));
        again.setTextColor(Th.A);
        again.setTextSize(14);
        again.setTypeface(null, android.graphics.Typeface.BOLD);
        again.setPadding(dp(12), dp(8), dp(8), dp(8));
        hr.addView(again);
        again.setOnClickListener(v -> { ideasPage += 4; momentsSig = ""; buildMoments(); });
        momentsBox.addView(hr);
        if (days.isEmpty()) {
            TextView t = new TextView(this);
            t.setText(I18n.t(this, "Conectează cardul sau camera și îți fac singur filme frumoase din fiecare zi."));
            t.setTextColor(0xFF9AA0A6);
            t.setTextSize(14);
            t.setPadding(dp(4), 0, dp(4), dp(8));
            momentsBox.addView(t);
            return;
        }
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        momentsBox.addView(hs);
        int cw = Math.round(getResources().getDisplayMetrics().widthPixels * 0.78f), ch = dp(300);
        for (int k = 0; k < days.size(); k++) {
            Moment mo = days.get(k);
            List<VideoItem> day = mo.items;
            VideoItem cover = null;
            float coverScore = -99;
            for (VideoItem it : day) {
                if (it.isPhoto()) { float[] sc = Score.cached(this, it); if (sc != null && sc[0] > coverScore && sc[0] > 1) { coverScore = sc[0]; cover = it; } }
            }
            if (cover == null) for (VideoItem it : day) if (!it.isPhoto()) { cover = it; break; }
            android.widget.FrameLayout card = new android.widget.FrameLayout(this);
            card.setClipToOutline(true);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(0xFF1C1E22);
            bg.setCornerRadius(dp(22));
            card.setBackground(bg);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(iv, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (cover != null) Thumbs.load(this, cover, iv);
            LinearLayout cap = new LinearLayout(this);
            cap.setOrientation(LinearLayout.VERTICAL);
            cap.setBackgroundColor(0x99000000);
            cap.setPadding(dp(16), dp(10), dp(64), dp(12));
            TextView t1 = new TextView(this);
            t1.setText(mo.title);
            t1.setTextColor(0xFFFFFFFF);
            t1.setTextSize(17);
            t1.setTypeface(null, android.graphics.Typeface.BOLD);
            TextView t2 = new TextView(this);
            t2.setText(mo.sub);
            t2.setTextColor(0xFFE1E1E1);
            t2.setTextSize(12.5f);
            cap.addView(t1); cap.addView(t2);
            card.addView(cap, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.BOTTOM));
            TextView play = new TextView(this);
            play.setText("▶");
            play.setTextColor(0xFFFFFFFF);
            play.setTextSize(18);
            play.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable pb = new android.graphics.drawable.GradientDrawable();
            pb.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            pb.setColor(Th.A);
            play.setBackground(pb);
            android.widget.FrameLayout.LayoutParams pl = new android.widget.FrameLayout.LayoutParams(dp(48), dp(48), android.view.Gravity.BOTTOM | android.view.Gravity.END);
            pl.setMargins(0, 0, dp(12), dp(14));
            card.addView(play, pl);
            TextView badge = new TextView(this);
            badge.setText(mo.first ? "NOU · AI" : mo.whole ? "AI · " + I18n.t(this, "pe scurt") : "AI");
            badge.setTextColor(0xFFFFFFFF);
            badge.setTextSize(11);
            badge.setTypeface(null, android.graphics.Typeface.BOLD);
            badge.setPadding(dp(10), dp(4), dp(10), dp(4));
            android.graphics.drawable.GradientDrawable bb = new android.graphics.drawable.GradientDrawable();
            bb.setColor(0xB3000000);
            bb.setCornerRadius(dp(12));
            badge.setBackground(bb);
            android.widget.FrameLayout.LayoutParams bl = new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.setMargins(dp(12), dp(12), 0, 0);
            card.addView(badge, bl);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
            lp.setMarginEnd(dp(12));
            row.addView(card, lp);
            card.setOnClickListener(v -> openMoment(mo));
        }
        // Idei AI
        TextView h2 = new TextView(this);
        h2.setText(I18n.t(this, "Idei AI"));
        h2.setTextColor(0xFFF2F2F0);
        h2.setTextSize(18);
        h2.setTypeface(null, android.graphics.Typeface.BOLD);
        h2.setPadding(dp(4), dp(18), 0, dp(8));
        momentsBox.addView(h2);
        LinearLayout ideas = new LinearLayout(this);
        momentsBox.addView(ideas);
        // „Planeta zilei”: cea mai bună poză 360 (peisaj sau oameni), niciodată una cu degete pe lentilă
        VideoItem p360 = null;
        float bestS = 0.5f;
        for (VideoItem it : src) {
            if (!it.isPhoto() || !it.is360()) continue;
            float[] sc = Score.cached(this, it);
            if (sc == null || sc[1] == Score.CAT_BAD) continue;
            float v = sc[0] + (sc[1] == Score.CAT_LAND ? 1.5f : 0);
            if (v > bestS) { bestS = v; p360 = it; }
        }
        final VideoItem planet = p360;
        String[][] idea = {{"Planeta zilei", "o poză Tiny Planet"}, {"Cele mai bune poze", "toate pozele"}, {"Povestea ultimei zile", "film după oră"}};
        for (int q = 0; q < idea.length; q++) {
            final int fq = q;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setPadding(dp(14), dp(12), dp(10), dp(12));
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setColor(0xFF1C1E22);
            g.setCornerRadius(dp(18));
            c.setBackground(g);
            TextView a = new TextView(this);
            a.setText(new String[]{"🌍", "⭐", "🎬"}[q] + "  " + I18n.t(this, idea[q][0]));
            a.setTextColor(0xFFF2F2F0);
            a.setTextSize(13.5f);
            a.setTypeface(null, android.graphics.Typeface.BOLD);
            TextView b = new TextView(this);
            b.setText(I18n.t(this, idea[q][1]));
            b.setTextColor(0xFF9AA0A6);
            b.setTextSize(11.5f);
            c.addView(a); c.addView(b);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMarginEnd(q < 2 ? dp(8) : 0);
            ideas.addView(c, lp);
            c.setOnClickListener(v -> {
                if (fq == 0) { if (planet != null) { Intent i = new Intent(this, PhotoActivity.class); i.putExtra("uri", planet.uri.toString()); i.putExtra("name", planet.name); i.putExtra("is360", true); i.putExtra("lens", planet.lens); i.putExtra("planet", true); startActivity(i); } else Toast.makeText(this, I18n.t(this, "Încă analizez pozele 360. Mai încearcă puțin mai târziu."), Toast.LENGTH_SHORT).show(); }
                else if (fq == 1) { filter = F_PHOTO; refresh(); }
                else openMoment(days.get(0));
            });
        }
    }

    private String ago(long t) {
        long m = (System.currentTimeMillis() - t) / 60000;
        if (m < 1) return "chiar acum";
        if (m < 60) return "acum " + m + " min";
        if (m < 24 * 60) return "acum " + (m / 60) + " h";
        return new java.text.SimpleDateFormat("d MMM", new Locale("ro")).format(new java.util.Date(t));
    }

    /** „Lucrările mele”: montajele salvate automat, continui de unde ai rămas */
    private void buildMyWork(List<Projects.Info> projs) {
        TextView h = new TextView(this);
        h.setText(I18n.t(this, "Lucrările mele"));
        h.setTextColor(0xFFF2F2F0);
        h.setTextSize(18);
        h.setTypeface(null, android.graphics.Typeface.BOLD);
        h.setPadding(dp(4), dp(16), 0, dp(8));
        momentsBox.addView(h);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        momentsBox.addView(hs);
        for (Projects.Info p : projs) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setClipToOutline(true);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setColor(0xFF1C1E22);
            bg.setCornerRadius(dp(16));
            card.setBackground(bg);
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF2A2D33);
            if (p.thumb != null) iv.setImageBitmap(android.graphics.BitmapFactory.decodeFile(p.thumb.getAbsolutePath()));
            card.addView(iv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96)));
            TextView t1 = new TextView(this);
            t1.setText(p.title);
            t1.setTextColor(0xFFF2F2F0);
            t1.setTextSize(13.5f);
            t1.setTypeface(null, android.graphics.Typeface.BOLD);
            t1.setSingleLine(true);
            t1.setPadding(dp(10), dp(8), dp(10), 0);
            TextView t2 = new TextView(this);
            t2.setText(ago(p.updated) + " · " + p.clips + " " + I18n.t(this, "bucăți"));
            t2.setTextColor(0xFF9AA0A6);
            t2.setTextSize(11.5f);
            t2.setPadding(dp(10), dp(2), dp(10), 0);
            TextView go = new TextView(this);
            go.setText("▶  " + I18n.t(this, "Continuă"));
            go.setTextColor(Th.A);
            go.setTextSize(13);
            go.setTypeface(null, android.graphics.Typeface.BOLD);
            go.setPadding(dp(10), dp(6), dp(10), dp(10));
            card.addView(t1); card.addView(t2); card.addView(go);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(170), ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(10));
            row.addView(card, lp);
            card.setOnClickListener(v -> {
                Intent i = new Intent(this, EditorActivity.class);
                i.putExtra("project", p.id);
                startActivity(i);
            });
            card.setOnLongClickListener(v -> {
                new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                        .setTitle(p.title)
                        .setMessage(I18n.t(this, "Ștergi lucrarea din listă? Filmările de pe card rămân neatinse."))
                        .setPositiveButton(I18n.t(this, "Șterge"), (d, w) -> { Projects.delete(this, p.id); momentsSig = ""; buildMoments(); })
                        .setNegativeButton(I18n.t(this, "Renunță"), null)
                        .show();
                return true;
            });
        }
    }

    /** locul cel mai des întâlnit în ziua respectivă; dacă sunt mai multe locuri, „A → B” (drum) */
    private String placeOf(List<VideoItem> day) {
        java.util.LinkedHashMap<String, Integer> n = new java.util.LinkedHashMap<>();
        for (VideoItem it : day) if (it.place != null) { String c = it.place.split(" · ")[0]; n.put(c, n.containsKey(c) ? n.get(c) + 1 : 1); }
        if (n.isEmpty()) return null;
        String best = null; int bn = 0;
        for (java.util.Map.Entry<String, Integer> e : n.entrySet()) if (e.getValue() > bn) { bn = e.getValue(); best = e.getKey(); }
        if (n.size() >= 3) {
            // lista e de la cel mai nou la cel mai vechi: primul loc al zilei e ultimul
            List<String> ks = new ArrayList<>(n.keySet());
            return ks.get(ks.size() - 1) + " → " + ks.get(0);
        }
        for (VideoItem it : day) if (it.place != null && it.place.startsWith(best)) return it.place;
        return best;
    }

    /** pornește filmul propus: alege filmările stabile și pozele bune, apoi totul intră în editor */
    private void openMoment(Moment mo) {
        loading.setVisibility(View.VISIBLE);
        Toast.makeText(this, I18n.t(this, "Aleg filmările stabile și pozele bune…") + " " + I18n.t(this, "Poți ieși din aplicație, te anunț când e gata."), Toast.LENGTH_LONG).show();
        Work.begin(this, "Pregătesc filmul „" + mo.title + "”");
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 78);
        android.content.Context app = getApplicationContext();
        new Thread(() -> {
            List<VideoItem> vids = new ArrayList<>(), photos = new ArrayList<>();
            java.util.Map<VideoItem, Float> js = new java.util.HashMap<>(), ps = new java.util.HashMap<>();
            for (VideoItem it : mo.items) {
                if (it.isPhoto()) {
                    if (mo.wish.contains("nophotos")) continue;
                    float[] sc = Score.photo(app, it);
                    float bonus = mo.wish.contains("land") && sc[1] == Score.CAT_LAND ? 3 : mo.wish.contains("follow") && sc[1] == Score.CAT_PEOPLE ? 2 : 0;
                    if (sc[1] != Score.CAT_BAD && sc[0] >= 0.5f) { photos.add(it); ps.put(it, sc[0] + bonus); }
                } else { vids.add(it); js.put(it, Score.shake(app, it)); }
            }
            // filmările care tremură tare ies, dacă rămân destule
            List<VideoItem> calm = new ArrayList<>();
            for (VideoItem v : vids) { float j = js.get(v); if (j < 0 || j < 35) calm.add(v); }
            if (calm.size() >= Math.max(1, vids.size() / 2)) vids = calm;
            if (mo.whole && vids.size() > 10) {
                // pe scurt: cele mai stabile 10, puse înapoi în ordinea zilei
                List<VideoItem> by = new ArrayList<>(vids);
                java.util.Collections.sort(by, (a, b) -> Float.compare(js.get(a) < 0 ? 20 : js.get(a), js.get(b) < 0 ? 20 : js.get(b)));
                java.util.Set<VideoItem> keep = new java.util.HashSet<>(by.subList(0, 10));
                List<VideoItem> v2 = new ArrayList<>();
                for (VideoItem v : vids) if (keep.contains(v)) v2.add(v);
                vids = v2;
            }
            java.util.Collections.sort(photos, (a, b) -> Float.compare(ps.get(b), ps.get(a)));
            int maxP = mo.wish.contains("land") ? 8 : mo.whole ? 6 : 4;
            if (photos.size() > maxP) photos = new ArrayList<>(photos.subList(0, maxP));
            final List<VideoItem> fv = vids, fp = photos;
            runOnUiThread(() -> {
                List<String[]> extra = new ArrayList<>();
                convertPhotos(fp, 0, extra, () -> {
                    loading.setVisibility(View.GONE);
                    int n = fv.size() + extra.size();
                    if (n == 0) { Work.end(this, null, null, null); Toast.makeText(this, I18n.t(this, "Nu am găsit filmări bune aici."), Toast.LENGTH_SHORT).show(); return; }
                    String[] uris = new String[n], lrvs = new String[n], names = new String[n], keys = new String[n];
                    int k = 0;
                    for (VideoItem it : fv) { uris[k] = it.uri.toString(); lrvs[k] = it.lrv == null ? null : it.lrv.toString(); names[k] = it.name; keys[k] = it.key(); k++; }
                    for (String[] e : extra) { uris[k] = e[0]; lrvs[k] = null; names[k] = e[1]; keys[k] = e[1]; k++; }
                    Intent i = new Intent(this, EditorActivity.class);
                    i.putExtra("uris", uris);
                    i.putExtra("lrvs", lrvs);
                    i.putExtra("names", names);
                    i.putExtra("keys", keys);
                    i.putExtra("auto", false);
                    i.putExtra("story", true);
                    i.putExtra("storyLen", mo.lenSec);
                    i.putExtra("wish", mo.wish.toArray(new String[0]));
                    if (Work.inBackground()) Work.end(this, "Filmul e pregătit: " + mo.title, "Atinge ca să-l deschizi și să-l vezi.", i);
                    else { Work.end(this, null, null, null); startActivity(i); }
                });
            });
        }).start();
    }

    // ---------------- „Spune-i AI-ului ce vrei” ----------------
    private android.widget.EditText aiText;
    private final java.util.Map<String, TextView> aiChips = new java.util.LinkedHashMap<>();
    private final java.util.Set<String> aiOn = new java.util.HashSet<>();

    private static final String[][] AI_OPTS = {
            {"len30", "Scurt 30 s"}, {"len60", "1 minut"}, {"len180", "3 minute"},
            {"follow", "Urmărește persoana"}, {"land", "Peisaje"}, {"nophotos", "Fără poze"},
            {"subs", "Subtitrare"}, {"mute", "Fără sunet"}, {"planet", "Tiny Planet la început"}};

    private void aiSet(String k, boolean on) {
        if (on && k.startsWith("len")) for (String[] o : AI_OPTS) if (o[0].startsWith("len")) aiOn.remove(o[0]);
        if (on) aiOn.add(k); else aiOn.remove(k);
        for (java.util.Map.Entry<String, TextView> e : aiChips.entrySet()) {
            boolean a = aiOn.contains(e.getKey());
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setCornerRadius(dp(16));
            g.setColor(a ? Th.A : 0xFF2A2D33);
            e.getValue().setBackground(g);
            e.getValue().setTextColor(a ? 0xFF111111 : 0xFFF2F2F0);
        }
    }

    /** înțelege ce ai spus (în telefon, fără internet): lungime, persoană, peisaje, poze, subtitrare, sunet, planetă */
    private void aiParse(String t) {
        String s = t.toLowerCase(Locale.ROOT);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d+)\\s*(sec|secunde|s\\b|min|minute|minut)").matcher(s);
        if (m.find()) {
            int n = Integer.parseInt(m.group(1));
            int sec = m.group(2).startsWith("min") ? n * 60 : n;
            aiSet(sec <= 40 ? "len30" : sec <= 100 ? "len60" : "len180", true);
            aiCustomLen = sec;
        } else if (s.contains("scurt") || s.contains("short")) { aiSet("len30", true); aiCustomLen = 0; }
        else if (s.contains("un minut") || s.contains("minute") && !s.contains("3")) { aiSet("len60", true); aiCustomLen = 0; }
        else if (s.contains("lung") || s.contains("long") || s.contains("tot ")) { aiSet("len180", true); aiCustomLen = 0; }
        if (s.matches(".*(urmăr|urmar|persoan|băiat|baiat|fată|fata|copil|pe mine|pe el|pe ea|follow|oameni|lume).*")) aiSet("follow", true);
        if (s.matches(".*(peisaj|natur|munte|mare|priveli|landscape).*")) aiSet("land", true);
        if (s.matches(".*(fără poze|fara poze|doar filmări|doar filmari|no photos).*")) aiSet("nophotos", true);
        if (s.matches(".*(subtitr|titrare|text cu ce|ce spun|ce cântă|ce canta).*")) aiSet("subs", true);
        if (s.matches(".*(fără sunet|fara sunet|mut|silent|doar muzic).*")) aiSet("mute", true);
        if (s.matches(".*(planet|planetă|planeta).*")) aiSet("planet", true);
    }

    private int aiCustomLen = 0;

    private void askAi(List<VideoItem> sel) {
        aiChips.clear(); aiOn.clear(); aiCustomLen = 0;
        int nv = 0, np = 0;
        for (VideoItem it : sel) if (it.isPhoto()) np++; else nv++;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(4));
        TextView sub = new TextView(this);
        sub.setText(nv + " " + I18n.t(this, "filmări") + (np > 0 ? " + " + np + " " + I18n.t(this, "poze") : "") + " · le pun în ordinea în care le-ai făcut");
        sub.setTextColor(0xFF9AA0A6);
        sub.setTextSize(13);
        box.addView(sub);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(12), 0, dp(10));
        aiText = new android.widget.EditText(this);
        aiText.setHint("„Fă-l scurt, cu peisaje și urmărește-l pe băiat”");
        aiText.setTextSize(15);
        aiText.setMaxLines(3);
        row.addView(aiText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView mic = new TextView(this);
        mic.setText("🎙");
        mic.setTextSize(24);
        mic.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable mg = new android.graphics.drawable.GradientDrawable();
        mg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        mg.setColor(Th.A);
        mic.setBackground(mg);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(54), dp(54));
        ml.setMarginStart(dp(8));
        row.addView(mic, ml);
        box.addView(row);
        mic.setOnClickListener(v -> {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            String l = I18n.lang(this);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, l.equals("ro") ? "ro-RO" : l);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Spune ce film vrei");
            try { startActivityForResult(i, 501); } catch (Exception e) { Toast.makeText(this, "Telefonul nu are recunoaștere vocală. Scrie ce vrei.", Toast.LENGTH_LONG).show(); }
        });
        aiText.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void onTextChanged(CharSequence a, int b, int c, int d) { }
            @Override public void afterTextChanged(android.text.Editable e) { aiParse(e.toString()); }
        });
        com.google.android.material.chip.ChipGroup flow = new com.google.android.material.chip.ChipGroup(this);
        flow.setChipSpacingHorizontal(dp(6));
        flow.setChipSpacingVertical(dp(6));
        for (String[] o : AI_OPTS) {
            TextView c = new TextView(this);
            c.setText(o[1]);
            c.setTextSize(13);
            c.setPadding(dp(12), dp(7), dp(12), dp(7));
            flow.addView(c);
            aiChips.put(o[0], c);
            c.setOnClickListener(v -> { aiSet(o[0], !aiOn.contains(o[0])); if (o[0].startsWith("len")) aiCustomLen = 0; });
        }
        box.addView(flow);
        aiSet("len60", true);
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Spune-i AI-ului ce vrei")
                .setView(box)
                .setPositiveButton("Fă filmul", (d, w) -> {
                    Moment mo = new Moment();
                    mo.items = new ArrayList<>(sel);
                    java.util.Collections.sort(mo.items, (x, y) -> y.name.compareTo(x.name));
                    mo.lenSec = aiCustomLen > 0 ? aiCustomLen : aiOn.contains("len30") ? 30 : aiOn.contains("len180") ? 180 : 60;
                    mo.whole = mo.lenSec <= 60;
                    mo.wish = new java.util.HashSet<>(aiOn);
                    selected.clear();
                    selBar.setVisibility(View.GONE);
                    adapter.notifyDataSetChanged();
                    openMoment(mo);
                })
                .setNegativeButton(I18n.t(this, "Renunță"), null)
                .show();
    }

    /** notele pozelor 360 (pentru „Planeta zilei” și copertele Moments), în fundal */
    private void startScores(List<VideoItem> src) {
        List<VideoItem> l = new ArrayList<>();
        for (VideoItem it : src) if (it.isPhoto() && !Score.known(this, it)) l.add(it);
        if (l.isEmpty()) return;
        java.util.Collections.sort(l, (x, y) -> y.name.compareTo(x.name));
        final List<VideoItem> todo = l.size() > 80 ? new ArrayList<>(l.subList(0, 80)) : l;
        android.content.Context app = getApplicationContext();
        Work.begin(this, "AI-ul analizează pozele");
        new Thread(() -> {
            for (VideoItem it : todo) Score.photo(app, it);
            runOnUiThread(() -> { Work.end(this, "Moments sunt gata", "Am pregătit filme noi din filmările tale.", null); momentsSig = ""; buildMoments(); });
        }).start();
    }

    /** o poză → 3 secunde de film (cu Media3), una după alta */
    private void convertPhotos(List<VideoItem> photos, int idx, List<String[]> out, Runnable done) {
        if (idx >= photos.size()) { done.run(); return; }
        VideoItem it = photos.get(idx);
        boolean is360 = it.is360();
        String base = it.name.replaceAll("\\.[^.]+$", "");
        java.io.File f = new java.io.File(getCacheDir(), "photo_" + Math.abs(it.key().hashCode()) + ".mp4");
        String name = base + "_poza" + (is360 ? ".insv" : ".mp4");
        if (f.exists() && f.length() > 1000) { out.add(new String[]{Uri.fromFile(f).toString(), name}); convertPhotos(photos, idx + 1, out, done); return; }
        try {
            androidx.media3.common.MediaItem mi = new androidx.media3.common.MediaItem.Builder().setUri(it.uri).setMimeType("image/jpeg").setImageDurationMs(3000).build();
            java.util.List<androidx.media3.common.Effect> fx = new java.util.ArrayList<>();
            fx.add(androidx.media3.effect.Presentation.createForWidthAndHeight(is360 ? 2880 : 1920, is360 ? 1440 : 1080, androidx.media3.effect.Presentation.LAYOUT_SCALE_TO_FIT));
            androidx.media3.transformer.EditedMediaItem em = new androidx.media3.transformer.EditedMediaItem.Builder(mi).setFrameRate(30)
                    .setEffects(new androidx.media3.transformer.Effects(new java.util.ArrayList<>(), fx)).build();
            androidx.media3.transformer.Transformer tr = new androidx.media3.transformer.Transformer.Builder(this)
                    .addListener(new androidx.media3.transformer.Transformer.Listener() {
                        @Override public void onCompleted(@NonNull androidx.media3.transformer.Composition c, @NonNull androidx.media3.transformer.ExportResult r) {
                            out.add(new String[]{Uri.fromFile(f).toString(), name});
                            convertPhotos(photos, idx + 1, out, done);
                        }
                        @Override public void onError(@NonNull androidx.media3.transformer.Composition c, @NonNull androidx.media3.transformer.ExportResult r, @NonNull androidx.media3.transformer.ExportException e) {
                            f.delete();
                            convertPhotos(photos, idx + 1, out, done);
                        }
                    }).build();
            tr.start(em, f.getAbsolutePath());
        } catch (Exception e) { convertPhotos(photos, idx + 1, out, done); }
    }

    private String groupOf(VideoItem it) {
        if (!byPlace) return dayOf(it);
        return it.place == null ? "Fără locație" : "📍 " + it.place;
    }

    /** citește locul fișierelor în fundal, o singură dată pentru fiecare listă */
    private void startGeo(List<VideoItem> src) {
        if (src.isEmpty()) return;
        String sig = System.identityHashCode(src) + ":" + src.size();
        if (sig.equals(geoSig)) return;
        geoSig = sig;
        geoDone.remove(src);
        List<VideoItem> copy = new ArrayList<>(src);
        // pozele din telefon ajută la filmările fără loc: cerem voie o singură dată
        String perm = android.os.Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.READ_MEDIA_IMAGES : android.Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) != android.content.pm.PackageManager.PERMISSION_GRANTED && !prefs.getBoolean("askedPhotos", false)) {
            prefs.edit().putBoolean("askedPhotos", true).apply();
            requestPermissions(new String[]{perm, android.Manifest.permission.ACCESS_MEDIA_LOCATION}, 77);
        }
        Work.begin(this, "Caut locul filmărilor și pozelor");
        new Thread(() -> {
            Geo.scan(getApplicationContext(), copy, () -> runOnUiThread(() -> { momentsSig = ""; refresh(); }));
            runOnUiThread(() -> { Work.end(this, null, null, null); geoDone.add(src); momentsSig = ""; refresh(); startScores(src); });
        }).start();
    }

    private void refresh() {
        buildMoments();
        // Card
        boolean hasTree = prefs.getString("tree", null) != null;
        srcCard.setBackgroundResource(cardMode ? R.drawable.src_on : R.drawable.src_off);
        if (scanning) srcCardSub.setText("citesc…");
        else srcCardSub.setText(!hasTree ? "neconectat" : cardList.isEmpty() ? "nu găsesc cardul" : "conectat");
        // bara de jos
        int on = Th.A, off = 0xFFB9BCBF;
        int[][] nav = {{R.id.navHomeIcon, R.id.navHomeText, F_ALL}, {R.id.navVideoIcon, R.id.navVideoText, F_VIDEO}, {R.id.navPhotoIcon, R.id.navPhotoText, F_PHOTO}};
        for (int[] n : nav) {
            boolean a = filter == n[2];
            ((ImageView) findViewById(n[0])).setImageTintList(ColorStateList.valueOf(a ? on : off));
            TextView tv = findViewById(n[1]);
            tv.setTextColor(a ? 0xFFF2F2F0 : off);
            tv.setTypeface(null, a ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
        header.findViewById(R.id.sortDate).setSelected(!bySize && !byPlace);
        updateBlackBar();
        header.findViewById(R.id.sortSize).setSelected(bySize);
        if (sortPlace != null) sortPlace.setSelected(byPlace);

        List<VideoItem> src = cardMode ? cardList : phoneList;
        int nVid = 0, nPh = 0;
        long tot = 0;
        for (VideoItem it : src) { if (it.isPhoto()) nPh++; else nVid++; tot += it.size; }
        List<VideoItem> l = new ArrayList<>();
        for (VideoItem it : src) {
            if (filter == F_VIDEO && it.isPhoto()) continue;
            if (filter == F_PHOTO && !it.isPhoto()) continue;
            l.add(it);
        }
        startGeo(src);
        if (geoLine != null) {
            int ex = Geo.countExact(src), any = Geo.countAny(src);
            boolean busy = !geoDone.contains(src);
            geoLine.setVisibility(src.isEmpty() ? View.GONE : View.VISIBLE);
            geoLine.setText(busy ? "📍 Caut locul filmărilor și pozelor…" : "📍 " + ex + " din " + src.size() + " fișiere au locație" + (any > ex ? " · încă " + (any - ex) + " primesc locul pozelor din aceeași perioadă" : ""));
        }
        if (bySize) java.util.Collections.sort(l, (x, y) -> Long.compare(y.size, x.size));
        else java.util.Collections.sort(l, (x, y) -> y.name.compareTo(x.name));
        if (byPlace) {
            // locurile, în ordinea celui mai nou fișier din fiecare; „Fără locație” la sfârșit
            java.util.LinkedHashMap<String, List<VideoItem>> g = new java.util.LinkedHashMap<>();
            List<VideoItem> none = new ArrayList<>();
            for (VideoItem it : l) {
                if (it.place == null) { none.add(it); continue; }
                List<VideoItem> q = g.get(it.place);
                if (q == null) { q = new ArrayList<>(); g.put(it.place, q); }
                q.add(it);
            }
            l.clear();
            for (List<VideoItem> q : g.values()) l.addAll(q);
            l.addAll(none);
        }

        boolean empty = src.isEmpty();
        emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        libHead.setVisibility(empty ? View.GONE : View.VISIBLE);
        if (cardMode) {
            if (scanning) { dropTitle.setText("Citesc cardul…"); dropSub.setText("Durează câteva secunde"); }
            else if (hasTree) { dropTitle.setText("Nu găsesc cardul"); dropSub.setText("Conectează cititorul cu cardul și atinge aici. Ține apăsat pe „Card” ca să alegi alt folder."); }
            else { dropTitle.setText("Atinge ca să deschizi cardul"); dropSub.setText("Filmările și pozele apar aici, grupate pe zile"); }
        } else { dropTitle.setText("Nicio filmare din telefon"); dropSub.setText("Apasă butonul de mai jos ca să alegi"); }
        String sv = nVid == 1 ? "1 filmare" : nVid + " filmări", sp = nPh == 1 ? "1 poză" : nPh + " poze";
        stats.setText((cardMode ? "" : "Telefon   ") + sv + "   " + sp + "   " + fmtSize(tot));
        if (newVersion < 0) {
            boolean msg = !empty && l.isEmpty();
            status.setVisibility(msg ? View.VISIBLE : View.GONE);
            status.setTextColor(0xFFB9BCBF);
            if (msg) status.setText(filter == F_PHOTO ? "Nu sunt poze aici." : "Nu sunt filmări aici.");
        }

        rows.clear();
        rows.add(HEADER);
        java.util.Map<String, long[]> sums = new java.util.HashMap<>();
        for (VideoItem it : l) {
            String d = groupOf(it);
            long[] sm = sums.get(d);
            if (sm == null) { sm = new long[2]; sums.put(d, sm); }
            sm[0]++; sm[1] += it.size;
        }
        String last = null;
        for (VideoItem it : l) {
            String d = groupOf(it);
            if (!bySize && !d.equals(last)) { rows.add(d); last = d; }
            rows.add(it);
        }
        headerSums = sums;
        selected.retainAll(l);
        if (selected.isEmpty()) selBar.setVisibility(View.GONE);
        adapter.notifyDataSetChanged();
    }

    /** ziua filmării, din numele fișierului (VID_20260827_...) sau din data fișierului */
    static String dayOf(VideoItem it) {
        java.util.Date date = null;
        try {
            for (String p : it.name.split("_")) {
                if (p.length() == 8 && p.matches("\\d{8}")) { date = new java.text.SimpleDateFormat("yyyyMMdd", Locale.ROOT).parse(p); break; }
            }
        } catch (Exception ignored) { }
        if (date == null && it.modified > 0) date = new java.util.Date(it.modified);
        if (date == null) return "Fără dată";
        String s = new java.text.SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("ro")).format(date);
        return s.substring(0, 1).toUpperCase(new Locale("ro")) + s.substring(1);
    }

    private void open(List<VideoItem> l) { open(l, false); }

    private void open(List<VideoItem> l, boolean autoEdit) {
        List<VideoItem> vids = new ArrayList<>();
        for (VideoItem it : l) if (!it.isPhoto()) vids.add(it);
        if (vids.isEmpty()) return;
        int n = vids.size();
        String[] uris = new String[n], lrvs = new String[n], names = new String[n], keys = new String[n];
        for (int k = 0; k < n; k++) {
            VideoItem it = vids.get(k);
            uris[k] = it.uri.toString();
            lrvs[k] = it.lrv == null ? null : it.lrv.toString();
            names[k] = it.name;
            keys[k] = it.key();
        }
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", uris);
        i.putExtra("lrvs", lrvs);
        i.putExtra("names", names);
        i.putExtra("keys", keys);
        i.putExtra("auto", autoEdit);
        startActivity(i);
        clearSel();
    }

    /** eticheta din colț: „360”, „neagră” (poză din greșeală) sau nimic */
    private void tagFor(TextView tag, VideoItem it) {
        if (it.isBlack()) {
            tag.setText("neagră");
            tag.setTextColor(0xFFB9BCBF);
            tag.setVisibility(View.VISIBLE);
            tag.getBackground().mutate().setTint(0xFF3A4048);
        } else if (it.is360()) {
            tag.setText("360");
            tag.setTextColor(0xFFFFFFFF);
            tag.getBackground().mutate().setTintList(null);
            tag.setVisibility(View.VISIBLE);
        } else tag.setVisibility(View.GONE);
    }

    private void openPhoto(VideoItem it) {
        Intent i = new Intent(this, PhotoActivity.class);
        i.putExtra("uri", it.uri.toString());
        i.putExtra("name", it.name);
        i.putExtra("is360", it.is360());
        i.putExtra("lens", it.lens);
        startActivity(i);
    }

    private void doUpdate() {
        if (!Updater.start(this, newVersion)) {
            toast("Pornește „Permite din această sursă” pentru Director360, apoi revino și apasă din nou.");
            return;
        }
        loading.setVisibility(View.VISIBLE);
        final Runnable[] poll = new Runnable[1];
        poll[0] = () -> {
            int p = Updater.progress(this);
            status.setVisibility(View.VISIBLE);
            if (p < 0) { loading.setVisibility(View.GONE); status.setText("Descărcarea nu a reușit. Apasă din nou."); return; }
            status.setText(p >= 100 ? "Apasă „Actualizează” în fereastra telefonului." : "Descarc actualizarea… " + p + "%");
            if (p >= 100) { loading.setVisibility(View.GONE); return; }
            main.postDelayed(poll[0], 500);
        };
        main.post(poll[0]);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    static String pretty(String name) {
        // VID_20260827_162848_00_643.mp4 -> 27.08.2026 · 16:28
        try {
            String[] p = name.split("_");
            for (int i = 0; i + 1 < p.length; i++) {
                if (p[i].length() == 8 && p[i].matches("\\d{8}") && p[i + 1].length() >= 6 && p[i + 1].substring(0, 6).matches("\\d{6}")) {
                    String d = p[i], t = p[i + 1];
                    return d.substring(6, 8) + "." + d.substring(4, 6) + "." + d.substring(0, 4) + " · " + t.substring(0, 2) + ":" + t.substring(2, 4);
                }
            }
        } catch (Exception ignored) { }
        return name;
    }

    static String fmtSize(long b) {
        if (b <= 0) return "";
        if (b > 1073741824L) return String.format(Locale.ROOT, "%.1f GB", b / 1073741824.0);
        return String.format(Locale.ROOT, "%.0f MB", b / 1048576.0);
    }

    static String fmtDur(long ms) {
        if (ms < 0) return "⏱ …";
        if (ms == 0) return "";
        long s = ms / 1000;
        return String.format(Locale.ROOT, "⏱ %d:%02d", s / 60, s % 60);
    }

    class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        class VH extends RecyclerView.ViewHolder {
            final ImageView thumb; final TextView title, meta, tag, selNum, dur; final View selRing, more;
            VH(View v) {
                super(v);
                thumb = v.findViewById(R.id.thumb);
                title = v.findViewById(R.id.title);
                meta = v.findViewById(R.id.meta);
                tag = v.findViewById(R.id.tag);
                dur = v.findViewById(R.id.dur);
                selNum = v.findViewById(R.id.selNum);
                selRing = v.findViewById(R.id.selRing);
                more = v.findViewById(R.id.more);
            }
        }

        class HV extends RecyclerView.ViewHolder {
            final TextView t, m;
            HV(View v) { super(v); t = v.findViewById(R.id.hTitle); m = v.findViewById(R.id.hMeta); }
        }

        class TopVH extends RecyclerView.ViewHolder { TopVH(View v) { super(v); } }

        @Override public int getItemViewType(int pos) {
            Object o = rows.get(pos);
            return o == HEADER ? 2 : o instanceof String ? 1 : 0;
        }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int t) {
            LayoutInflater inf = LayoutInflater.from(p.getContext());
            if (t == 2) {
                if (header.getParent() instanceof ViewGroup) ((ViewGroup) header.getParent()).removeView(header);
                header.setLayoutParams(new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                return new TopVH(header);
            }
            if (t == 1) return new HV(inf.inflate(R.layout.item_header, p, false));
            return new VH(inf.inflate(R.layout.item_video, p, false));
        }

        @Override public void onBindViewHolder(RecyclerView.ViewHolder holder, int pos) {
            Object o = rows.get(pos);
            if (o == HEADER) return;
            if (o instanceof String) {
                HV h = (HV) holder;
                h.t.setText((String) o);
                long[] sm = headerSums.get(o);
                h.m.setText(sm == null ? "" : sm[0] + " · " + fmtSize(sm[1]));
                return;
            }
            VH h = (VH) holder;
            VideoItem it = (VideoItem) o;
            String pr = pretty(it.name);
            int dot = pr.indexOf(" · ");
            h.title.setText(dot > 0 ? pr.substring(dot + 3) : pr);
            tagFor(h.tag, it);
            h.meta.setMaxLines(it.place != null ? 2 : 1);
            h.meta.setEllipsize(it.place != null ? android.text.TextUtils.TruncateAt.END : android.text.TextUtils.TruncateAt.MIDDLE);
            h.meta.setText(it.name + "  ·  " + fmtSize(it.size) + (it.place != null ? "\n📍 " + it.place + (it.geo == 2 ? " (după poze)" : "") : ""));
            if (!it.isPhoto() && it.durationMs > 0) {
                long s = it.durationMs / 1000;
                h.dur.setText(String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60));
                h.dur.setVisibility(View.VISIBLE);
            } else h.dur.setVisibility(View.GONE);
            Thumbs.load(MainActivity.this, it, h.thumb, () -> tagFor(h.tag, it));
            Thumbs.durationAsync(MainActivity.this, it, () -> {
                int p = rows.indexOf(it);
                if (p >= 0) notifyItemChanged(p);
            });
            int si = selected.indexOf(it);
            h.selRing.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setVisibility(si >= 0 ? View.VISIBLE : View.GONE);
            h.selNum.setText(String.valueOf(si + 1));
            h.more.setVisibility(si >= 0 ? View.GONE : View.VISIBLE);
            h.more.setOnClickListener(v -> itemMenu(it));
            h.itemView.setOnClickListener(v -> {
                if (it.isPhoto() && selected.isEmpty()) openPhoto(it); else toggleSel(it);
            });
            h.itemView.setOnLongClickListener(v -> { toggleSel(it); return true; });
        }

        @Override public int getItemCount() { return rows.size(); }
    }
}
