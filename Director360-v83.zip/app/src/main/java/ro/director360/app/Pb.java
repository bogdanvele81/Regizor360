package ro.director360.app;

/** citește un mesaj protobuf fără să-i știm forma și îl scrie scurt: câmp=valoare, {…} pentru mesaje în mesaj */
final class Pb {
    private Pb() { }

    /** valoarea unui câmp număr de pe primul nivel, sau -1 */
    static long intField(byte[] b, int want) {
        int i = 0;
        while (i < b.length) {
            long[] t = varint(b, i, b.length);
            if (t == null) return -1;
            i = (int) t[1];
            int fn = (int) (t[0] >>> 3), wt = (int) (t[0] & 7);
            if (wt == 0) { long[] v = varint(b, i, b.length); if (v == null) return -1; if (fn == want) return v[0]; i = (int) v[1]; }
            else if (wt == 2) { long[] l = varint(b, i, b.length); if (l == null) return -1; i = (int) l[1] + (int) l[0]; }
            else if (wt == 5) i += 4; else if (wt == 1) i += 8; else return -1;
        }
        return -1;
    }

    static String dump(byte[] b) {
        StringBuilder o = new StringBuilder();
        if (!parse(b, 0, b.length, o, 0)) { o.setLength(0); o.append("hex:").append(hex(b, 0, Math.min(b.length, 48))); }
        return o.toString();
    }

    /** câmpurile de pe primul nivel, fiecare pe rândul lui; câmpul „inner” (dacă e mesaj) e desfăcut și el */
    static java.util.List<String> lines(byte[] b, int inner) {
        java.util.List<String> out = new java.util.ArrayList<>();
        int i = 0;
        while (i < b.length) {
            long[] t = varint(b, i, b.length);
            if (t == null) break;
            int fs = i;
            i = (int) t[1];
            int fn = (int) (t[0] >>> 3), wt = (int) (t[0] & 7);
            int vs = i;
            if (wt == 0) { long[] v = varint(b, i, b.length); if (v == null) break; i = (int) v[1]; }
            else if (wt == 2) {
                long[] l = varint(b, i, b.length); if (l == null) break;
                vs = (int) l[1]; i = vs + (int) l[0];
                if (i > b.length) break;
                if (fn == inner) { out.addAll(lines(java.util.Arrays.copyOfRange(b, vs, i), -1)); continue; }
            } else if (wt == 5) i += 4; else if (wt == 1) i += 8; else break;
            if (i > b.length) break;
            out.add(dump(java.util.Arrays.copyOfRange(b, fs, i)));
        }
        return out;
    }

    private static boolean parse(byte[] b, int off, int end, StringBuilder o, int depth) {
        int i = off;
        int start = o.length();
        while (i < end) {
            long[] t = varint(b, i, end);
            if (t == null) { o.setLength(start); return false; }
            i = (int) t[1];
            int fn = (int) (t[0] >>> 3), wt = (int) (t[0] & 7);
            if (fn <= 0) { o.setLength(start); return false; }
            if (o.length() > start) o.append(' ');
            o.append(fn).append('=');
            if (wt == 0) {
                long[] v = varint(b, i, end);
                if (v == null) { o.setLength(start); return false; }
                o.append(v[0]);
                i = (int) v[1];
            } else if (wt == 2) {
                long[] l = varint(b, i, end);
                if (l == null) { o.setLength(start); return false; }
                int len = (int) l[0];
                i = (int) l[1];
                if (len < 0 || i + len > end) { o.setLength(start); return false; }
                int mark = o.length();
                o.append('{');
                if (len > 0 && depth < 6 && parse(b, i, i + len, o, depth + 1)) o.append('}');
                else {
                    o.setLength(mark);
                    String txt = text(b, i, len);
                    o.append(txt != null ? "\"" + txt + "\"" : "x" + hex(b, i, Math.min(len, 16)) + (len > 16 ? "…" : ""));
                }
                i += len;
            } else if (wt == 5) {
                if (i + 4 > end) { o.setLength(start); return false; }
                o.append("f").append(hex(b, i, 4)); i += 4;
            } else if (wt == 1) {
                if (i + 8 > end) { o.setLength(start); return false; }
                o.append("d").append(hex(b, i, 8)); i += 8;
            } else { o.setLength(start); return false; }
        }
        return true;
    }

    private static long[] varint(byte[] b, int i, int end) {
        long v = 0; int sh = 0;
        while (i < end && sh < 64) {
            int x = b[i++] & 0xFF;
            v |= (long) (x & 0x7F) << sh;
            if ((x & 0x80) == 0) return new long[]{v, i};
            sh += 7;
        }
        return null;
    }

    private static String text(byte[] b, int off, int len) {
        if (len == 0 || len > 80) return null;
        for (int k = off; k < off + len; k++) { int c = b[k] & 0xFF; if (c < 32 || c > 126) return null; }
        return new String(b, off, len, java.nio.charset.StandardCharsets.US_ASCII);
    }

    private static String hex(byte[] b, int off, int n) {
        StringBuilder s = new StringBuilder();
        for (int k = off; k < off + n && k < b.length; k++) s.append(String.format(java.util.Locale.ROOT, "%02x", b[k]));
        return s.toString();
    }
}
