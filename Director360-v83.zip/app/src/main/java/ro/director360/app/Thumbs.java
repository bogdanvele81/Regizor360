package ro.director360.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Pozele mici ale filmărilor: făcute o dată, ținute minte în telefon. */
public class Thumbs {
    /** coadă „ultima cerută, prima făcută”: pozele de pe ecran (unde te-ai oprit) au întâietate */
    static class Lifo<E> extends java.util.concurrent.LinkedBlockingDeque<E> {
        @Override public boolean offer(E e) { return offerFirst(e); }
    }
    private static final ExecutorService POOL = new java.util.concurrent.ThreadPoolExecutor(3, 3, 30, java.util.concurrent.TimeUnit.SECONDS, new Lifo<Runnable>());
    private static final java.util.concurrent.atomic.AtomicInteger PENDING = new java.util.concurrent.atomic.AtomicInteger();

    /** câte poze mici așteaptă (căutarea pozelor negre stă pe loc cât timp sunt) */
    public static int pending() { return PENDING.get(); }
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final android.util.LruCache<String, Bitmap> MEM = new android.util.LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    public interface Done { void run(Bitmap b, long durationMs); }

    public static void load(Context ctx, VideoItem it, ImageView view) { load(ctx, it, view, null); }

    /** după ce știm dacă e 360 sau nu, rulează after (pe firul principal) */
    public static void load(Context ctx, VideoItem it, ImageView view, Runnable after) {
        final String key = it.key();
        view.setTag(key);
        final Context app = ctx.getApplicationContext();
        Bitmap m = MEM.get(key);
        if (m != null && it.shape != 0) { view.setImageBitmap(m); if (after != null) after.run(); return; }
        if (m == null) view.setImageDrawable(null);
        PENDING.incrementAndGet();
        POOL.execute(() -> {
            try { loadNow(app, it, view, key, m, after); } finally { PENDING.decrementAndGet(); }
        });
    }

    private static void loadNow(Context app, VideoItem it, ImageView view, String key, Bitmap m, Runnable after) {
        {
            // dacă ai trecut deja mai departe, nu mai citesc poza asta acum
            if (!key.equals(view.getTag())) return;
            shape(app, it);
            final Bitmap b = m != null ? m : safeGet(app, it);
            FRESH.remove(key);
            if (b != null) MEM.put(key, b);
            MAIN.post(() -> {
                if (!key.equals(view.getTag())) return;
                if (b != null) view.setImageBitmap(b);
                if (after != null) after.run();
            });
        }
    }

    private static final java.util.Map<String, Integer> SHAPES = new java.util.concurrent.ConcurrentHashMap<>();
    /** poza mică scoasă deja din fișier când am aflat forma (ca să nu citim fișierul mare de două ori) */
    private static final java.util.Map<String, Bitmap> FRESH = new java.util.concurrent.ConcurrentHashMap<>();
    private static android.content.SharedPreferences shapePrefs;

    private static synchronized void loadShapes(Context ctx) {
        if (shapePrefs != null) return;
        shapePrefs = ctx.getSharedPreferences("shapes", Context.MODE_PRIVATE);
        for (java.util.Map.Entry<String, ?> e : shapePrefs.getAll().entrySet())
            if (e.getValue() instanceof Integer) SHAPES.put(e.getKey(), (Integer) e.getValue());
    }

    /** pentru ștergere: uită ce știam despre o poză */
    static void forget(Context ctx, VideoItem it) {
        loadShapes(ctx);
        SHAPES.remove(it.key());
        shapePrefs.edit().remove(it.key()).apply();
        MEM.remove(it.key());
        file(ctx, it.key()).delete();
    }

    /** citește poza rapid: întâi poza mică din interiorul fișierului (EXIF), altfel poza întreagă micșorată */
    private static Bitmap quick(Context ctx, Uri uri, int w) {
        try (java.io.InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(in);
            Bitmap t = ex.getThumbnailBitmap();
            if (t != null && t.getWidth() >= t.getHeight() * 1.9f && t.getWidth() >= 160) return t;
        } catch (Throwable ignored) { }
        try (java.io.InputStream in = ctx.getContentResolver().openInputStream(uri)) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            int ss = 1;
            while (w / (ss * 2) >= 1024) ss *= 2;
            o.inSampleSize = ss;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (Throwable e) { return null; }
    }

    /** află dacă o poză e cu două lentile (360): imaginea e de două ori mai lată decât înaltă */
    static void shape(Context ctx, VideoItem it) { shape(ctx, it, true); }

    /** keep = păstrează poza citită pentru poza mică (doar când chiar o afișăm) */
    static void shape(Context ctx, VideoItem it, boolean keep) {
        if (it.shape != 0) return;
        loadShapes(ctx);
        Integer c = SHAPES.get(it.key());
        if (c != null) { it.shape = c / 10; it.lens = c % 10; return; }
        int sh;
        String l = it.name.toLowerCase();
        if (it.isPhotoName()) {
            sh = 2;
            try (java.io.InputStream in = ctx.getContentResolver().openInputStream(it.uri)) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeStream(in, null, o);
                if (o.outWidth > 0 && o.outWidth >= o.outHeight * 1.9f) {
                    sh = 1;
                    // o singură lentilă? toată neagră? (camera lasă jumătăți negre)
                    Bitmap q = quick(ctx, it.uri, o.outWidth);
                    int ln = litLens(q);
                    if (keep && q != null && (q.getWidth() >= 640 || ln < 0)) FRESH.put(it.key(), q);
                    if (ln < 0) sh = 4;
                    else if (ln > 0) { sh = 3; it.lens = ln; }
                }
            } catch (Throwable ignored) { }
        } else sh = (l.endsWith(".insv") && it.lrv != null) ? 1 : 2;
        it.shape = sh;
        SHAPES.put(it.key(), sh * 10 + it.lens);
        shapePrefs.edit().putInt(it.key(), sh * 10 + it.lens).apply();
    }

    /** 0 = ambele lentile au imagine (360); 1 sau 2 = doar lentila din stânga / dreapta; −1 = toată poza e neagră */
    static int litLens(Bitmap b) {
        if (b == null) return 0;
        int W = b.getWidth(), H = b.getHeight();
        int[] px = new int[W * H];
        b.getPixels(px, 0, W, 0, 0, W, H);
        double l = 0, r = 0;
        for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
            int c = px[y * W + x];
            double v = ((c >> 16) & 255) * 0.3 + ((c >> 8) & 255) * 0.59 + (c & 255) * 0.11;
            if (x < W / 2) l += v; else r += v;
        }
        l /= (W / 2.0 * H); r /= (W / 2.0 * H);
        if (l < 12 && r < 12) return -1; // poză neagră (făcută din greșeală, cu husa pe cameră)
        if (r < 6 && l > 25) return 1;
        if (l < 6 && r > 25) return 2;
        return 0;
    }

    private static File file(Context ctx, String key) {
        File d = new File(ctx.getFilesDir(), "thumbs");
        d.mkdirs();
        return new File(d, "v5_" + Integer.toHexString(key.hashCode()) + ".jpg");
    }

    private static Bitmap safeGet(Context ctx, VideoItem it) {
        try { return get(ctx, it); } catch (Throwable e) { return null; }
    }

    private static Bitmap get(Context ctx, VideoItem it) {
        File f = file(ctx, it.key());
        if (f.exists()) {
            Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) return b;
        }
        if (it.isPhoto()) {
            Bitmap fr = FRESH.remove(it.key());
            Bitmap pb = fr != null ? fr : photo(ctx, it.uri, (it.is360() || it.lens > 0 || it.isBlack()) ? 1024 : 480);
            if (pb == null) return null;
            if (it.lens > 0 && pb.getWidth() >= pb.getHeight() * 1.6f) pb = reframe(pb, 360, 220, 120f, it.lens == 2);
            else if (it.is360() && pb.getWidth() >= pb.getHeight() * 1.6f) pb = reframe(pb, 360, 220, 120f);
            else pb = cropTo(pb, 360, 220);
            try (FileOutputStream o = new FileOutputStream(f)) { pb.compress(Bitmap.CompressFormat.JPEG, 82, o); } catch (Exception ignored) { }
            return pb;
        }
        Uri src = it.lrv != null ? it.lrv : it.uri;
        boolean sbs = it.is360() && it.lrv != null;
        Bitmap b = frame(ctx, src, 1_000_000L, sbs ? 1024 : 360, sbs ? 512 : 220);
        if (b == null && src != it.uri) { b = frame(ctx, it.uri, 1_000_000L, 360, 220); sbs = false; }
        if (b == null) return null;
        if (sbs) b = reframe(b, 360, 220, 120f);
        try (FileOutputStream o = new FileOutputStream(f)) {
            b.compress(Bitmap.CompressFormat.JPEG, 82, o);
        } catch (Exception ignored) {
        }
        return b;
    }

    /** din imaginea cu cele două cercuri (LRV) face o imagine normală, privind înainte */
    public static Bitmap reframe(Bitmap src, int w, int h, float fovH) { return reframe(src, w, h, fovH, false); }

    /** privire dreaptă în lentila din stânga (A) sau din dreapta (B) */
    public static Bitmap reframe(Bitmap src, int w, int h, float fovH, boolean lensB) {
        int sw = src.getWidth(), sh = src.getHeight();
        int[] in = new int[sw * sh];
        src.getPixels(in, 0, sw, 0, 0, sw, sh);
        int[] out = new int[w * h];
        double tx = Math.tan(Math.toRadians(fovH / 2)), ty = tx * h / w, fov = Math.toRadians(98.5);
        double cx = 2690.67 / 10752, cy = 2693.78 / 5376, rx = 2640.44 / 10752, ry = 2640.44 / 5376;
        if (lensB) { cx = 8066.88 / 10752; cy = 2690.65 / 5376; rx = 2650.62 / 10752; ry = 2650.62 / 5376; }
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                double qx = ((x + 0.5) / w * 2 - 1) * tx, qy = ((y + 0.5) / h * 2 - 1) * ty;
                double n = Math.sqrt(qx * qx + qy * qy + 1);
                double dx = qx / n, dy = qy / n, dz = 1 / n;
                double th = Math.acos(dz), ph = Math.atan2(dy, dx), r = th / fov;
                int u = (int) ((cx + rx * r * Math.cos(ph)) * sw), v = (int) ((cy + ry * r * Math.sin(ph)) * sh);
                if (u >= 0 && u < sw && v >= 0 && v < sh) out[y * w + x] = in[v * sw + u];
                else out[y * w + x] = 0xFF000000;
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888);
    }

    /** citește o poză micșorată (lățimea cel mult maxW), cu orientarea corectă */
    public static Bitmap photo(Context ctx, Uri uri, int maxW) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (java.io.InputStream in = ctx.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
            int ss = 1;
            while (o.outWidth / (ss * 2) >= maxW) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = ss;
            Bitmap b;
            try (java.io.InputStream in = ctx.getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o2); }
            if (b == null) {
                // a doua metodă (poze HEIF / HDR)
                try {
                    b = android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(ctx.getContentResolver(), uri), (dec, info, src) -> {
                        int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                        if (w > maxW) dec.setTargetSize(maxW, Math.max(1, h * maxW / w));
                        dec.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                    });
                } catch (Throwable e) { b = null; }
            }
            if (b == null) return null;
            if (b.getWidth() > maxW) {
                Bitmap s = Bitmap.createScaledBitmap(b, maxW, Math.max(1, b.getHeight() * maxW / b.getWidth()), true);
                if (s != b) b.recycle();
                b = s;
            }
            int rot = 0;
            try (java.io.InputStream in = ctx.getContentResolver().openInputStream(uri)) {
                int or = new androidx.exifinterface.media.ExifInterface(in).getAttributeInt(
                        androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION, 1);
                rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
            } catch (Throwable ignored) { }
            if (rot != 0 && !uri.toString().toLowerCase().endsWith(".insp")) {
                android.graphics.Matrix m = new android.graphics.Matrix();
                m.postRotate(rot);
                b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            }
            return b;
        } catch (Throwable e) {
            return null;
        }
    }

    static Bitmap cropTo(Bitmap b, int w, int h) {
        float r = w / (float) h, br = b.getWidth() / (float) b.getHeight();
        int cw = b.getWidth(), ch = b.getHeight();
        if (br > r) cw = Math.round(ch * r); else ch = Math.round(cw / r);
        Bitmap c = Bitmap.createBitmap(b, (b.getWidth() - cw) / 2, (b.getHeight() - ch) / 2, cw, ch);
        return Bitmap.createScaledBitmap(c, w, h, true);
    }

    /** un cadru din film, micșorat */
    public static Bitmap frame(Context ctx, Uri uri, long atUs, int w, int h) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            return r.getScaledFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, w, h);
        } catch (Throwable e) {
            return null;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    public static long duration(Context ctx, Uri uri) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, uri);
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? -1 : Long.parseLong(d);
        } catch (Throwable e) {
            return -1;
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
    }

    public static void durationAsync(Context ctx, VideoItem it, Runnable then) {
        if (it.durationMs >= 0) return;
        if (it.isPhoto()) { it.durationMs = 0; return; }
        final Context app = ctx.getApplicationContext();
        POOL.execute(() -> {
            String k = "dur:" + it.key();
            android.content.SharedPreferences sp = app.getSharedPreferences("dur", Context.MODE_PRIVATE);
            long d = sp.getLong(k, -1);
            if (d < 0) {
                d = duration(app, it.lrv != null ? it.lrv : it.uri);
                if (d > 0) sp.edit().putLong(k, d).apply();
            }
            it.durationMs = d < 0 ? 0 : d;
            MAIN.post(then);
        });
    }
}
