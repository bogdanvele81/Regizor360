package ro.director360.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;

/**
 * Ține aplicația pornită cât lucrează (povestea, AI-ul, căutarea locurilor), chiar dacă ieși din ea,
 * și te anunță în notificări când e gata.
 */
public class Work extends Service {
    private static final String CH = "lucru", CH_DONE = "gata";
    private static final int ID = 4401, ID_DONE = 4402;
    private static int count = 0;
    private static String text = "Lucrez…";
    /** câte ecrane ale aplicației sunt deschise acum (0 = ești în altă aplicație) */
    static volatile int visible = 0;

    public static boolean inBackground() { return visible <= 0; }

    /** pornește (sau actualizează) lucrul în fundal */
    public static synchronized void begin(Context c, String what) {
        count++;
        text = what;
        try { c.getApplicationContext().startForegroundService(new Intent(c.getApplicationContext(), Work.class)); } catch (Exception ignored) { }
    }

    public static synchronized void update(Context c, String what) {
        text = what;
        if (count > 0) try {
            c.getApplicationContext().getSystemService(NotificationManager.class).notify(ID, ongoing(c.getApplicationContext()));
        } catch (Exception ignored) { }
    }

    /** gata; dacă ești în altă aplicație, primești notificare (atingi și se deschide `open`) */
    public static synchronized void end(Context c, String doneTitle, String doneText, Intent open) {
        Context a = c.getApplicationContext();
        count = Math.max(0, count - 1);
        if (count == 0) try { a.stopService(new Intent(a, Work.class)); } catch (Exception ignored) { }
        if (doneTitle != null && inBackground()) notifyDone(a, doneTitle, doneText, open);
    }

    static void notifyDone(Context a, String title, String txt, Intent open) {
        try {
            NotificationManager nm = a.getSystemService(NotificationManager.class);
            if (nm.getNotificationChannel(CH_DONE) == null)
                nm.createNotificationChannel(new NotificationChannel(CH_DONE, "Gata", NotificationManager.IMPORTANCE_HIGH));
            if (open == null) open = new Intent(a, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pi = PendingIntent.getActivity(a, (int) (System.currentTimeMillis() & 0xFFFF), open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(a, CH_DONE)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(title)
                    .setContentText(txt)
                    .setColor(Th.A)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            nm.notify(ID_DONE, n);
        } catch (Exception ignored) { }
    }

    private static Notification ongoing(Context a) {
        NotificationManager nm = a.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(new NotificationChannel(CH, "Lucru în fundal", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(a, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return new Notification.Builder(a, CH)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Director360 lucrează")
                .setContentText(text + " · poți ieși din aplicație")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setProgress(0, 0, true)
                .setColor(Th.A)
                .setContentIntent(PendingIntent.getActivity(a, 3, open, PendingIntent.FLAG_IMMUTABLE))
                .build();
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        startForeground(ID, ongoing(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
