package ro.director360.app;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * „Povestea”: ora filmărilor, sunetul (unde sunt pauzele) și sunetul pregătit pentru recunoașterea vorbirii.
 * Totul pe telefon, fără internet.
 */
final class Story {
    private Story() { }

    private static final Pattern TS = Pattern.compile("(20\\d{6})_(\\d{6})");

    /** ora la care a fost făcută filmarea (ms), din nume (VID_20250308_145200) sau din fișier; 0 = necunoscută */
    static long timeOf(Context ctx, String name, Uri uri) {
        if (name != null) {
            Matcher m = TS.matcher(name);
            if (m.find()) {
                try {
                    java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.ROOT);
                    java.util.Date d = f.parse(m.group(1) + m.group(2));
                    if (d != null) return d.getTime();
                } catch (Exception ignored) { }
            }
        }
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try {
            String sc = uri.getScheme();
            if ("http".equals(sc) || "https".equals(sc)) r.setDataSource(uri.toString(), new HashMap<>());
            else r.setDataSource(ctx, uri);
            String d = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DATE);
            if (d != null && d.length() >= 15) {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyyMMdd'T'HHmmss", java.util.Locale.ROOT);
                f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                java.util.Date dt = f.parse(d.substring(0, 15));
                if (dt != null) return dt.getTime();
            }
        } catch (Exception ignored) {
        } finally { try { r.release(); } catch (Exception ignored) { } }
        return 0;
    }

    interface Pcm { void chunk(short[] mono, int n, int rate, long ptsMs); }

    /** decodează sunetul dintre fromMs și toMs și îl dă mai departe, amestecat într-un singur canal */
    static void decode(Context ctx, Uri uri, long fromMs, long toMs, Pcm out) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec dec = null;
        try {
            String sc = uri.getScheme();
            if ("http".equals(sc) || "https".equals(sc)) ex.setDataSource(uri.toString(), new HashMap<>());
            else ex.setDataSource(ctx, uri, null);
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) return;
            ex.selectTrack(track);
            ex.seekTo(fromMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            dec.configure(fmt, null, null, 0);
            dec.start();
            int rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            boolean inDone = false;
            short[] mono = new short[0];
            while (true) {
                if (!inDone) {
                    int ii = dec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = dec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        long pts = ex.getSampleTime();
                        if (n < 0 || pts > toMs * 1000 + 500_000) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                        else { dec.queueInputBuffer(ii, 0, n, pts, 0); ex.advance(); }
                    }
                }
                int oi = dec.dequeueOutputBuffer(bi, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = dec.getOutputFormat();
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                } else if (oi >= 0) {
                    long ptsMs = bi.presentationTimeUs / 1000;
                    if (bi.size > 0 && ptsMs >= fromMs - 50 && ptsMs <= toMs) {
                        ByteBuffer ob = dec.getOutputBuffer(oi);
                        ob.position(bi.offset);
                        ob.limit(bi.offset + bi.size);
                        java.nio.ShortBuffer sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer();
                        int frames = sb.remaining() / Math.max(1, ch);
                        if (mono.length < frames) mono = new short[frames];
                        for (int f = 0; f < frames; f++) {
                            int s = 0;
                            for (int c = 0; c < ch; c++) s += sb.get(f * ch + c);
                            mono[f] = (short) (s / Math.max(1, ch));
                        }
                        out.chunk(mono, frames, rate, ptsMs);
                    }
                    dec.releaseOutputBuffer(oi, false);
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0 || ptsMs > toMs) break;
                }
            }
        } finally {
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) { }
            ex.release();
        }
    }

    /** cât de tare e sunetul, pe bucăți de stepMs (de la fromMs) */
    static float[] loudness(Context ctx, Uri uri, long fromMs, long toMs, int stepMs) {
        int n = (int) Math.max(1, (toMs - fromMs) / stepMs);
        float[] r = new float[n];
        int[] cnt = new int[n];
        try {
            decode(ctx, uri, fromMs, toMs, (mono, k, rate, pts) -> {
                double per = rate / 1000.0;
                for (int i = 0; i < k; i++) {
                    long t = pts + (long) (i / per);
                    int b = (int) ((t - fromMs) / stepMs);
                    if (b < 0 || b >= n) continue;
                    float v = mono[i] / 32768f;
                    r[b] += v * v;
                    cnt[b]++;
                }
            });
        } catch (Exception e) { return null; }
        for (int i = 0; i < n; i++) r[i] = cnt[i] > 0 ? (float) Math.sqrt(r[i] / cnt[i]) : 0f;
        return r;
    }

    /** cel mai liniștit moment (o pauză) lângă t, în ±maxShift ms */
    static long snapToPause(float[] loud, long fromMs, int stepMs, long t, long maxShift, long lo, long hi) {
        if (loud == null) return t;
        long best = t;
        float bv = Float.MAX_VALUE;
        for (long x = Math.max(lo, t - maxShift); x <= Math.min(hi, t + maxShift); x += stepMs) {
            int b = (int) ((x - fromMs) / stepMs);
            if (b < 1 || b >= loud.length - 1) continue;
            // media pe 3 bucăți, ca să nu prindem o pauză de o clipă
            float v = (loud[b - 1] + loud[b] + loud[b + 1]) / 3f + Math.abs(x - t) / (float) maxShift * 0.01f;
            if (v < bv) { bv = v; best = x; }
        }
        return best;
    }

    /** sunet mono la 16 kHz, pentru recunoașterea vorbirii */
    static short[] pcm16k(Context ctx, Uri uri, long fromMs, long toMs) {
        int total = (int) ((toMs - fromMs) * 16);
        short[] out = new short[Math.max(1, total)];
        int[] w = {0};
        try {
            decode(ctx, uri, fromMs, toMs, (mono, k, rate, pts) -> {
                double step = rate / 16000.0;
                long start = Math.max(0, (pts - fromMs) * 16);
                for (int j = 0; ; j++) {
                    int src = (int) (j * step);
                    if (src >= k) break;
                    long pos = start + j;
                    if (pos >= out.length) break;
                    out[(int) pos] = mono[src];
                    w[0] = (int) Math.max(w[0], pos + 1);
                }
            });
        } catch (Exception e) { return null; }
        return w[0] > 0 ? java.util.Arrays.copyOf(out, w[0]) : null;
    }

    static byte[] le(short[] s) {
        ByteBuffer b = ByteBuffer.allocate(s.length * 2).order(ByteOrder.LITTLE_ENDIAN);
        for (short v : s) b.putShort(v);
        return b.array();
    }

    /** o frază recunoscută: în ce bucată (cheie), de la/până la (ms din filmare), textul */
    static final class Line {
        String key; long a, b; String text; boolean keep = true;
        Line(String key, long a, long b, String text) { this.key = key; this.a = a; this.b = b; this.text = text; }
    }
}
