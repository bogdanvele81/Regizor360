package ro.director360.app;

import android.net.Network;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Vorbește cu camera Insta360 prin Wi-Fi, pe calea deschisă „OSC” (Open Spherical Camera):
 * informații, baterie, lista fișierelor, descărcare, ștergere, poză și filmare.
 * Toate apelurile sunt blocante: se cheamă de pe un fir separat.
 */
final class Osc {
    static final String HOST = "http://192.168.42.1";

    static final class Entry {
        String name, url;
        long size;
        String date;
        double dur = -1;
        boolean isPhoto() { String l = name.toLowerCase(); return l.endsWith(".insp") || l.endsWith(".jpg") || l.endsWith(".dng"); }
        boolean isLrv() { String l = name.toLowerCase(); return l.startsWith("lrv_") || l.endsWith(".lrv"); }
    }

    final Network net;

    Osc(Network net) { this.net = net; }

    private HttpURLConnection open(String path, int timeout) throws Exception {
        URL u = new URL(path.startsWith("http") ? path : HOST + path);
        HttpURLConnection c = (HttpURLConnection) (net != null ? net.openConnection(u) : u.openConnection());
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("X-XSRF-Protected", "1");
        return c;
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    JSONObject get(String path) throws Exception {
        HttpURLConnection c = open(path, 5000);
        try { return new JSONObject(read(c.getInputStream())); } finally { c.disconnect(); }
    }

    JSONObject post(String path, JSONObject body, int timeout) throws Exception {
        HttpURLConnection c = open(path, timeout);
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json;charset=utf-8");
            byte[] d = (body == null ? "{}" : body.toString()).getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(d.length);
            OutputStream o = c.getOutputStream();
            o.write(d);
            o.close();
            int code = c.getResponseCode();
            String s = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            return new JSONObject(s);
        } finally { c.disconnect(); }
    }

    JSONObject cmd(String name, JSONObject params) throws Exception {
        JSONObject b = new JSONObject();
        b.put("name", name);
        if (params != null) b.put("parameters", params);
        JSONObject r = post("/osc/commands/execute", b, 15000);
        // comenzile lungi (poză) răspund „inProgress”: aștept până termină
        for (int i = 0; i < 60 && "inProgress".equals(r.optString("state")) && r.has("id"); i++) {
            Thread.sleep(500);
            JSONObject q = new JSONObject();
            q.put("id", r.getString("id"));
            r = post("/osc/commands/status", q, 10000);
        }
        if ("error".equals(r.optString("state"))) {
            JSONObject e = r.optJSONObject("error");
            throw new Exception(e != null ? e.optString("message", e.optString("code")) : "eroare de la cameră");
        }
        return r;
    }

    /** modelul camerei, sau null dacă nu răspunde */
    String model() {
        try { JSONObject i = get("/osc/info"); return i.optString("model", "Insta360"); } catch (Exception e) { return null; }
    }

    /** bateria 0…100, sau -1 */
    int battery() {
        try {
            JSONObject s = post("/osc/state", null, 5000).optJSONObject("state");
            if (s == null) return -1;
            double b = s.optDouble("batteryLevel", -1);
            return b < 0 ? -1 : (int) Math.round(b <= 1 ? b * 100 : b);
        } catch (Exception e) { return -1; }
    }

    /** pozele mici trimise de cameră: nume → octeți JPEG (câte 10 pe rând) */
    java.util.Map<String, byte[]> thumbs(int start, int count, int size) {
        java.util.Map<String, byte[]> m = new java.util.HashMap<>();
        try {
            JSONObject p = new JSONObject();
            p.put("fileType", "all");
            p.put("entryCount", count);
            p.put("maxThumbSize", size);
            p.put("startPosition", start);
            JSONObject res = cmd("camera.listFiles", p).optJSONObject("results");
            JSONArray a = res == null ? null : res.optJSONArray("entries");
            if (a == null) return m;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.getJSONObject(i);
                String t = e.optString("thumbnail", "");
                if (t.isEmpty()) continue;
                String url = e.optString("fileUrl");
                String name = e.optString("name", url.substring(url.lastIndexOf('/') + 1));
                try { m.put(name, android.util.Base64.decode(t, android.util.Base64.DEFAULT)); } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return m;
    }

    /** octeți din număr: camera poate trimite octeți, KB sau MB; ghicesc după mărimea cardului */
    static long[] normSpace(long free, long total) {
        long f = 1;
        if (total > 0 && total < 4_000_000L) f = 1L << 20;          // MB
        else if (total > 0 && total < 4_000_000_000L) f = 1L << 10; // KB
        return new long[]{free * f, total * f};
    }

    /** {liber, total} în octeți, sau null */
    long[] space() {
        try {
            JSONObject p = new JSONObject();
            p.put("optionNames", new JSONArray().put("remainingSpace").put("totalSpace"));
            JSONObject o = cmd("camera.getOptions", p).optJSONObject("results");
            o = o == null ? null : o.optJSONObject("options");
            if (o == null) return null;
            long fr = o.optLong("remainingSpace", -1), tot = o.optLong("totalSpace", -1);
            if (fr < 0) return null;
            return normSpace(fr, tot);
        } catch (Exception e) { return null; }
    }

    /** ce a găsit fiecare metodă de citire (ca să vedem de ce lipsesc fișiere) */
    String diag = "";

    /** toate fișierele: lista OSC (toate / filmări / poze) + folderele cardului citite direct; le unește */
    java.util.List<Entry> list() throws Exception {
        java.util.Map<String, Entry> all = new java.util.LinkedHashMap<>();
        StringBuilder d = new StringBuilder();
        Exception first = null;
        pageInfo = "";
        for (String type : new String[]{"all", "video", "image"}) {
            if (!type.equals("all") && all.size() > 15) continue; // "all" a citit deja tot cardul
            try {
                java.util.List<Entry> l = listType(type);
                int before = all.size();
                for (Entry e : l) if (!all.containsKey(e.name)) all.put(e.name, e);
                d.append(type).append(':').append(l.size()).append("(+").append(all.size() - before).append(") ");
            } catch (Exception e) { if (first == null) first = e; d.append(type).append(":eroare "); }
        }
        try {
            java.util.List<Entry> l = crawl("/DCIM/", 0);
            int before = all.size();
            for (Entry e : l) if (!all.containsKey(e.name)) all.put(e.name, e);
            d.append("foldere:").append(l.size()).append("(+").append(all.size() - before).append(")");
        } catch (Exception e) { d.append("foldere:-"); }
        diag = d.toString() + "\n" + pageInfo.trim() + " · total " + all.size();
        if (all.isEmpty() && first != null) throw first;
        java.util.List<Entry> out = new java.util.ArrayList<>(all.values());
        java.util.Collections.sort(out, (x, y) -> y.name.compareTo(x.name));
        return out;
    }

    /** citește direct folderele cardului (pagina de fișiere a camerei), două niveluri */
    private java.util.List<Entry> crawl(String path, int depth) throws Exception {
        java.util.List<Entry> out = new java.util.ArrayList<>();
        HttpURLConnection c = open(path, 6000);
        String html;
        try {
            if (c.getResponseCode() >= 400) return out;
            html = read(c.getInputStream());
        } finally { c.disconnect(); }
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("href=\"([^\"?#]+)\"", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(html);
        java.util.Set<String> seen = new java.util.HashSet<>();
        while (m.find()) {
            String h = m.group(1);
            if (h.startsWith("..") || h.equals("/") || h.startsWith("http")) continue;
            String full = h.startsWith("/") ? h : path + h;
            if (!seen.add(full)) continue;
            String low = full.toLowerCase();
            if (full.endsWith("/")) {
                if (depth < 2 && full.length() > path.length()) out.addAll(crawl(full, depth + 1));
            } else if (low.endsWith(".insv") || low.endsWith(".insp") || low.endsWith(".mp4") || low.endsWith(".lrv") || low.endsWith(".jpg") || low.endsWith(".dng")) {
                Entry e = new Entry();
                e.url = HOST + full;
                e.name = full.substring(full.lastIndexOf('/') + 1);
                e.date = "";
                out.add(e);
            }
        }
        return out;
    }

    String pageInfo = "";

    private java.util.List<Entry> listType(String fileType) throws Exception {
        java.util.List<Entry> out = new java.util.ArrayList<>();
        java.util.Set<String> seen = new java.util.HashSet<>();
        int start = 0, pages = 0, total = -1;
        String token = null;
        StringBuilder got = new StringBuilder();
        while (pages < 3000) {
            JSONObject p = new JSONObject();
            p.put("fileType", fileType);
            p.put("entryCount", 50);
            p.put("maxThumbSize", 0);
            if (token != null) p.put("continuationToken", token);
            else p.put("startPosition", start);
            JSONObject res = cmd("camera.listFiles", p).optJSONObject("results");
            if (res == null) break;
            pages++;
            if (res.has("totalEntries")) total = res.optInt("totalEntries", -1);
            JSONArray a = res.optJSONArray("entries");
            if (a == null || a.length() == 0) break;
            int fresh = 0;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.getJSONObject(i);
                Entry en = new Entry();
                en.url = e.optString("fileUrl", e.optString("uri", ""));
                en.name = e.optString("name", en.url.substring(en.url.lastIndexOf('/') + 1));
                en.size = e.optLong("size", 0);
                en.date = e.optString("dateTimeZone", e.optString("dateTime", ""));
                en.dur = e.optDouble("_videoDuration", e.optDouble("duration", e.optDouble("_duration", -1)));
                if (en.dur > 100000) en.dur /= 1000.0;
                if (seen.add(en.name)) { out.add(en); fresh++; }
            }
            start += a.length();
            // camera trimite max 15 pe pagină: continuăm cât timp vin fișiere noi
            String t = res.optString("continuationToken", "");
            token = t.isEmpty() ? null : t;
            if (pages <= 3) got.append(pages > 1 ? "," : "").append(a.length()).append('/').append(fresh);
            // camera X5 raportează greșit totalul (15), așa că nu ne oprim după el: doar când nu mai vin fișiere noi
            if (fresh == 0) break;
        }
        pageInfo += fileType + ":" + pages + "p[" + got + "]/" + (total < 0 ? "?" : total) + " ";
        java.util.Collections.sort(out, (x, y) -> y.name.compareTo(x.name));
        return out;
    }

    void delete(String url) throws Exception {
        JSONObject p = new JSONObject();
        p.put("fileUrls", new JSONArray().put(url));
        cmd("camera.delete", p);
    }

    /** opțiunile camerei (ex. „isoSupport”, „iso”) */
    JSONObject options(String... names) throws Exception {
        JSONArray a = new JSONArray();
        for (String n : names) a.put(n);
        JSONObject p = new JSONObject();
        p.put("optionNames", a);
        JSONObject r = cmd("camera.getOptions", p).optJSONObject("results");
        JSONObject o = r == null ? null : r.optJSONObject("options");
        return o == null ? new JSONObject() : o;
    }

    void setOption(String name, Object v) throws Exception {
        JSONObject o = new JSONObject();
        o.put(name, v);
        JSONObject p = new JSONObject();
        p.put("options", o);
        JSONObject r = cmd("camera.setOptions", p);
        if (r.has("error")) throw new Exception(r.optJSONObject("error") != null ? r.optJSONObject("error").optString("message", "eroare") : "eroare");
    }

    interface Frames { boolean frame(byte[] jpeg); }

    /** imaginea live: camera trimite poze JPEG una după alta; ne oprim când frame() întoarce false */
    void livePreview(Frames f) throws Exception {
        HttpURLConnection c = open("/osc/commands/execute", 10000);
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json;charset=utf-8");
            byte[] d = "{\"name\":\"camera.getLivePreview\"}".getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(d.length);
            OutputStream o = c.getOutputStream();
            o.write(d);
            o.close();
            int code = c.getResponseCode();
            String ct = c.getContentType() == null ? "" : c.getContentType();
            if (code >= 400 || ct.contains("json")) {
                String s = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
                JSONObject j = new JSONObject(s);
                JSONObject e = j.optJSONObject("error");
                throw new Exception(e != null ? e.optString("message", e.optString("code", "refuzat")) : "camera nu trimite imagine live");
            }
            InputStream in = new java.io.BufferedInputStream(c.getInputStream(), 65536);
            ByteArrayOutputStream cur = null;
            int prev = -1, b;
            while ((b = in.read()) >= 0) {
                if (cur == null) {
                    if (prev == 0xFF && b == 0xD8) { cur = new ByteArrayOutputStream(120000); cur.write(0xFF); cur.write(0xD8); }
                } else {
                    cur.write(b);
                    if (prev == 0xFF && b == 0xD9) {
                        if (!f.frame(cur.toByteArray())) return;
                        cur = null;
                    } else if (cur.size() > 8_000_000) cur = null;
                }
                prev = b;
            }
        } finally { c.disconnect(); }
    }

    void setMode(boolean video) throws Exception {
        JSONObject o = new JSONObject();
        o.put("captureMode", video ? "video" : "image");
        JSONObject p = new JSONObject();
        p.put("options", o);
        cmd("camera.setOptions", p);
    }

    String takePicture() throws Exception {
        setMode(false);
        JSONObject r = cmd("camera.takePicture", null).optJSONObject("results");
        return r == null ? null : r.optString("fileUrl", null);
    }

    void startVideo() throws Exception { setMode(true); cmd("camera.startCapture", null); }

    void stopVideo() throws Exception { cmd("camera.stopCapture", null); }

    /** fără să schimbe modul (când modul a fost ales prin legătura Insta360) */
    void takePictureKeep() throws Exception { cmd("camera.takePicture", null); }

    void startCaptureKeep() throws Exception { cmd("camera.startCapture", null); }

    interface Progress { boolean step(long done, long total); }

    /** descarcă în fișierul dst; întoarce false dacă s-a oprit la cerere */
    boolean download(String url, long size, File dst, Progress pr) throws Exception {
        File tmp = new File(dst.getPath() + ".part");
        HttpURLConnection c = open(url, 20000);
        try {
            InputStream in = c.getInputStream();
            long tot = c.getContentLengthLong() > 0 ? c.getContentLengthLong() : size;
            OutputStream o = new FileOutputStream(tmp);
            byte[] b = new byte[256 * 1024];
            long done = 0, last = 0;
            int n;
            try {
                while ((n = in.read(b)) > 0) {
                    o.write(b, 0, n);
                    done += n;
                    if (done - last > 1 << 20 || done == tot) {
                        last = done;
                        if (!pr.step(done, tot)) { o.close(); in.close(); tmp.delete(); return false; }
                    }
                }
            } finally { o.close(); in.close(); }
            if (!tmp.renameTo(dst)) throw new Exception("nu pot salva fișierul");
            return true;
        } finally { c.disconnect(); }
    }
}
