package ro.director360.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Notele AI pentru Moments, calculate în telefon:
 *  - poze: peisaj / oameni / ceva clar e bine; degete pe lentilă, neclar, prea întunecat = rău
 *  - filmări: cât de stabile sunt (din giroscop)
 */
public class Score {
    public static final int CAT_NONE = 0, CAT_LAND = 1, CAT_PEOPLE = 2, CAT_BAD = 3;

    private static final Set<String> LAND = new HashSet<>(java.util.Arrays.asList(
            "sky", "mountain", "beach", "lake", "sea", "river", "waterfall", "sunset", "building", "skyscraper", "bridge", "monument",
            "tower", "cathedral", "temple", "castle", "palace", "mosque", "church", "city", "cityscape", "landscape", "cloud", "snow", "field",
            "forest", "tree", "flower", "garden", "park", "desert", "canyon", "cliff", "island", "harbor", "boat", "ship", "road", "night"));
    private static final Set<String> PEOPLE = new HashSet<>(java.util.Arrays.asList(
            "crowd", "team", "selfie", "smile", "fun", "event", "party", "dance", "bride", "groom", "concert", "musician", "person", "people", "child", "baby"));
    private static final Set<String> BAD = new HashSet<>(java.util.Arrays.asList("hand", "nail", "skin", "finger", "flesh", "thumb"));

    private static com.google.mlkit.vision.label.ImageLabeler labeler;

    private static synchronized com.google.mlkit.vision.label.ImageLabeler labeler() {
        if (labeler == null) labeler = com.google.mlkit.vision.label.ImageLabeling.getClient(com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS);
        return labeler;
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("score", Context.MODE_PRIVATE); }

    public static boolean known(Context c, VideoItem it) { return prefs(c).contains(it.key()); }

    /** {nota, categoria}; null dacă nu s-a calculat încă */
    public static float[] cached(Context c, VideoItem it) {
        String s = prefs(c).getString(it.key(), null);
        if (s == null) return null;
        try { String[] a = s.split(","); return new float[]{Float.parseFloat(a[0]), Float.parseFloat(a[1])}; } catch (Exception e) { return null; }
    }

    /** nota unei poze (merge doar din fundal) */
    public static float[] photo(Context ctx, VideoItem it) {
        float[] c = cached(ctx, it);
        if (c != null) return c;
        float score = 0; int cat = CAT_NONE;
        try {
            Bitmap b = Thumbs.photo(ctx, it.uri, 1024);
            if (b == null) return new float[]{-5, CAT_BAD};
            List<Bitmap> views = new ArrayList<>();
            if (it.is360() && b.getWidth() >= b.getHeight() * 1.6f) {
                views.add(Thumbs.reframe(b, 320, 240, 110f, false));
                views.add(Thumbs.reframe(b, 320, 240, 110f, true));
            } else views.add(Bitmap.createScaledBitmap(b, 320, Math.max(1, 320 * b.getHeight() / b.getWidth()), true));
            float best = -99;
            int bestCat = CAT_NONE;
            for (Bitmap v : views) {
                float[] r = view(v);
                if (r[0] > best) { best = r[0]; bestCat = (int) r[1]; }
            }
            // dacă una din lentile e acoperită (degete), nu contează că cealaltă e bună: poza e stricată
            if (views.size() == 2) {
                float[] a = view(views.get(0)), d = view(views.get(1));
                if (a[1] == CAT_BAD || d[1] == CAT_BAD) { best = Math.min(best, -3); bestCat = CAT_BAD; }
            }
            score = best; cat = bestCat;
        } catch (Throwable e) { score = 0; }
        prefs(ctx).edit().putString(it.key(), String.format(Locale.ROOT, "%.2f,%d", score, cat)).apply();
        return new float[]{score, cat};
    }

    /** {nota, categoria} pentru o imagine mică */
    private static float[] view(Bitmap v) {
        int w = v.getWidth(), h = v.getHeight();
        int[] px = new int[w * h];
        v.getPixels(px, 0, w, 0, 0, w, h);
        double sum = 0;
        float[] gray = new float[w * h];
        int[] hue = new int[13];
        float[] hsv = new float[3];
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            int r = (p >> 16) & 255, g = (p >> 8) & 255, bl = p & 255;
            gray[i] = 0.299f * r + 0.587f * g + 0.114f * bl;
            sum += gray[i];
            android.graphics.Color.RGBToHSV(r, g, bl, hsv);
            hue[hsv[1] < 0.15f || hsv[2] < 0.12f ? 12 : Math.min(11, (int) (hsv[0] / 30))]++;
        }
        double mean = sum / px.length;
        // claritatea (Laplace)
        double lap = 0; int ln = 0;
        for (int y = 1; y < h - 1; y++) for (int x = 1; x < w - 1; x++) {
            int i = y * w + x;
            double l = 4 * gray[i] - gray[i - 1] - gray[i + 1] - gray[i - w] - gray[i + w];
            lap += l * l; ln++;
        }
        double sharp = ln == 0 ? 0 : lap / ln;
        int dom = 0;
        for (int k = 0; k < 13; k++) dom = Math.max(dom, hue[k]);
        double domFrac = dom / (double) px.length;
        // ce vede AI-ul
        Set<String> labels = new HashSet<>();
        try {
            List<com.google.mlkit.vision.label.ImageLabel> l = com.google.android.gms.tasks.Tasks.await(
                    labeler().process(com.google.mlkit.vision.common.InputImage.fromBitmap(v, 0)), 8, java.util.concurrent.TimeUnit.SECONDS);
            for (com.google.mlkit.vision.label.ImageLabel x : l) if (x.getConfidence() > 0.55f) labels.add(x.getText().toLowerCase(Locale.ROOT));
        } catch (Exception ignored) { }
        float s = 0;
        int land = 0, people = 0, bad = 0;
        for (String x : labels) { if (LAND.contains(x)) land++; if (PEOPLE.contains(x)) people++; if (BAD.contains(x)) bad++; }
        s += Math.min(2, land) * 1.5f;
        s += Math.min(2, people) * 2f;
        if (mean < 30 || mean > 240) s -= 3;
        if (sharp < 25) s -= 2; else if (sharp > 120) s += 1;
        boolean fingers = bad > 0 && land + people == 0 || (domFrac > 0.62 && sharp < 40 && hue[12] < px.length * 0.5);
        if (fingers) s -= 5;
        int cat = fingers ? CAT_BAD : people > 0 ? CAT_PEOPLE : land > 0 ? CAT_LAND : CAT_NONE;
        return new float[]{s, cat};
    }

    /** cât tremură o filmare (grade/s); -1 = nu știm (fără giroscop) */
    public static float shake(Context ctx, VideoItem it) {
        SharedPreferences p = prefs(ctx);
        String k = "j:" + it.key();
        if (p.contains(k)) return p.getFloat(k, -1);
        float j = -1;
        try {
            if (it.name.toLowerCase(Locale.ROOT).endsWith(".insv")) {
                Gyro g = Gyro.read(ctx, it.uri);
                if (g != null) j = (float) g.jitter();
            }
        } catch (Throwable ignored) { }
        p.edit().putFloat(k, j).apply();
        return j;
    }
}
