package ro.director360.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Locul unde s-a filmat / s-a făcut poza:
 *  - poze (.insp/.jpg): coordonatele GPS din datele pozei
 *  - filmări .insv: înregistrarea GPS de la capătul fișierului (camera o scrie când e legată de telefon sau de telecomanda GPS)
 *  - filmări din telefon (.mp4): locația salvată de telefon
 * Fișierele fără loc îl primesc de la cea mai apropiată poză / filmare (ca oră) care are loc.
 */
public class Geo {
    private static final String MAGIC = "8db42d694ccc418790edff439fe026bf";
    private static final long NEAR_MS = 3L * 3600 * 1000;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("geo2", Context.MODE_PRIVATE); }

    /** {lat, lon} sau null; folosește ce s-a citit deja */
    public static double[] of(Context ctx, VideoItem it) {
        SharedPreferences p = prefs(ctx);
        String k = it.key();
        String s = p.getString(k, null);
        if (s != null) return s.equals("-") ? null : parse(s);
        double[] r = null;
        try { r = read(ctx, it.uri, it.name); } catch (Throwable ignored) { }
        if (r != null && (Math.abs(r[0]) < 1e-6 && Math.abs(r[1]) < 1e-6)) r = null;
        p.edit().putString(k, r == null ? "-" : String.format(Locale.ROOT, "%.6f,%.6f", r[0], r[1])).apply();
        return r;
    }

    public static boolean cached(Context ctx, VideoItem it) { return prefs(ctx).contains(it.key()); }

    private static double[] parse(String s) {
        try { String[] a = s.split(","); return new double[]{Double.parseDouble(a[0]), Double.parseDouble(a[1])}; } catch (Exception e) { return null; }
    }

    static double[] read(Context ctx, Uri uri, String name) throws Exception {
        String low = name.toLowerCase(Locale.ROOT);
        boolean http = "http".equals(uri.getScheme()) || "https".equals(uri.getScheme());
        if (low.endsWith(".insp") || low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".heic") || low.endsWith(".webp") || low.endsWith(".png")) {
            java.io.InputStream in = http ? new java.io.ByteArrayInputStream(range(uri.toString(), 0, 262144, true)) : ctx.getContentResolver().openInputStream(uri);
            if (in == null) return null;
            try (java.io.InputStream i2 = in) {
                androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(i2);
                double[] ll = ex.getLatLong();
                return ll;
            }
        }
        if (low.endsWith(".insv")) return http ? insvHttp(uri.toString()) : insvLocal(ctx, uri);
        if (low.endsWith(".mp4") || low.endsWith(".mov") || low.endsWith(".3gp")) {
            if (http) return null;
            android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
            try {
                r.setDataSource(ctx, uri);
                String loc = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_LOCATION); // +45.1234+025.5678/
                if (loc == null) return null;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("([+-]\\d+(?:\\.\\d+)?)([+-]\\d+(?:\\.\\d+)?)").matcher(loc);
                if (m.find()) return new double[]{Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2))};
            } finally { try { r.release(); } catch (Exception ignored) { } }
        }
        return null;
    }

    interface Bytes { byte[] at(long from, int len) throws Exception; }

    /** sare din înregistrare în înregistrare (doar antetele de 6 octeți) până la cea cu GPS — ca în Regizor 360 */
    private static double[] insvWalk(long n, Bytes rd) throws Exception {
        if (n < 200) return null;
        byte[] tail = rd.at(n - 72, 72);
        if (tail == null || tail.length < 72) return null;
        if (!new String(tail, 40, 32, "ISO-8859-1").equals(MAGIC)) return null;
        long size = ByteBuffer.wrap(tail).order(ByteOrder.LITTLE_ENDIAN).getInt(32) & 0xFFFFFFFFL;
        long start = n - size, pos = n - 72;
        for (int step = 0; step < 60 && pos > start + 6; step++) {
            byte[] h = rd.at(pos - 6, 6);
            if (h == null || h.length < 6) return null;
            int id = (h[0] & 255) | (h[1] & 255) << 8;
            long sz = ((h[2] & 255) | (h[3] & 255) << 8 | (h[4] & 255) << 16 | (long) (h[5] & 255) << 24);
            if (sz <= 0 || sz > pos - 6 - start) return null;
            if (id == 0x700 && sz >= 53) {
                int take = (int) Math.min(sz, 53L * 200);
                take -= take % 53;
                byte[] d = rd.at(pos - 6 - sz, take);
                if (d == null) return null;
                return gpsEntries(ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN), 0, d.length / 53);
            }
            pos -= 6 + sz;
        }
        return null;
    }

    private static double[] insvLocal(Context ctx, Uri uri) throws Exception {
        try (ParcelFileDescriptor pfd = ctx.getContentResolver().openFileDescriptor(uri, "r");
             FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
             FileChannel ch = fis.getChannel()) {
            return insvWalk(ch.size(), (from, len) -> {
                ByteBuffer b = ByteBuffer.allocate(len);
                int got = 0;
                while (got < len) { int r = ch.read(b, from + got); if (r <= 0) break; got += r; }
                return got == len ? b.array() : null;
            });
        }
    }

    private static long lastTotal;

    private static double[] insvHttp(String url) throws Exception {
        byte[] t0 = range(url, -1, 72, false);
        if (t0 == null || lastTotal <= 0) return null;
        long n = lastTotal;
        return insvWalk(n, (from, len) -> range(url, from, len, false));
    }

    private static double[] gpsEntries(ByteBuffer tb, int s, int cnt) {
        byte[] b = tb.array();
        double sl = 0, so = 0;
        int good = 0;
        for (int k = 0; k < cnt; k++) {
            int o = s + 53 * k;
            char st = (char) b[o + 10], ns = (char) b[o + 19], ew = (char) b[o + 28];
            if (st != 'A') continue;
            double lat = tb.getDouble(o + 11), lon = tb.getDouble(o + 20);
            if (Double.isNaN(lat) || Double.isNaN(lon) || lat <= 0 || lat > 90 || lon <= 0 || lon > 180) continue;
            if (ns == 'S') lat = -lat;
            if (ew == 'W') lon = -lon;
            sl += lat; so += lon; good++;
            if (good >= 20) break;
        }
        return good > 0 ? new double[]{sl / good, so / good} : null;
    }

    /** înregistrarea 0x0700 = GPS: câte 53 de octeți (timp, A/V, lat, N/S, lon, E/W, viteză, direcție, altitudine) */
    static double[] gps(ByteBuffer tb) {
        byte[] b = tb.array();
        for (int i = b.length; i >= 6; i--) {
            if (b[i - 6] != 0x00 || b[i - 5] != 0x07) continue;
            long sz = tb.getInt(i - 4) & 0xFFFFFFFFL;
            if (sz < 53 || sz > i - 6 || sz % 53 != 0) continue;
            int s = (int) (i - 6 - sz), cnt = (int) (sz / 53);
            double sl = 0, so = 0;
            int good = 0;
            for (int k = 0; k < cnt; k++) {
                int o = s + 53 * k;
                char st = (char) b[o + 10], ns = (char) b[o + 19], ew = (char) b[o + 28];
                if (st != 'A' || (ns != 'N' && ns != 'S') || (ew != 'E' && ew != 'W')) continue;
                double lat = tb.getDouble(o + 11), lon = tb.getDouble(o + 20);
                if (Double.isNaN(lat) || Double.isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180 || (lat == 0 && lon == 0)) continue;
                if (ns == 'S') lat = -lat;
                if (ew == 'W') lon = -lon;
                sl += lat; so += lon; good++;
                if (good >= 20) break;
            }
            if (good > 0) return new double[]{sl / good, so / good};
        }
        return null;
    }

    private static byte[] range(String url, long from, int len, boolean partialOk) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(6000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Range", from < 0 ? "bytes=-" + len : "bytes=" + from + "-" + (from + len - 1));
        try {
            if (c.getResponseCode() != 206 && !partialOk) return null;
            String cr = c.getHeaderField("Content-Range");
            if (cr != null && cr.contains("/")) try { lastTotal = Long.parseLong(cr.substring(cr.lastIndexOf('/') + 1).trim()); } catch (Exception ignored) { }
            java.io.InputStream in = c.getInputStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while (bo.size() < len && (r = in.read(buf, 0, Math.min(buf.length, len - bo.size()))) > 0) bo.write(buf, 0, r);
            byte[] out = bo.toByteArray();
            return partialOk || out.length == len ? out : null;
        } finally { c.disconnect(); }
    }

    /** numele locului (oraș · zonă); are nevoie de internet prima dată, apoi îl ține minte */
    public static String placeName(Context ctx, double lat, double lon) {
        String k = String.format(Locale.ROOT, "n%.2f,%.2f", lat, lon);
        SharedPreferences p = prefs(ctx);
        String s = p.getString(k, null);
        if (s != null) return s;
        String name = null;
        try {
            if (android.location.Geocoder.isPresent()) {
                List<android.location.Address> l = new android.location.Geocoder(ctx, Locale.getDefault()).getFromLocation(lat, lon, 1);
                if (l != null && !l.isEmpty()) {
                    android.location.Address a = l.get(0);
                    String city = a.getLocality() != null ? a.getLocality() : a.getSubAdminArea() != null ? a.getSubAdminArea() : a.getAdminArea();
                    String sub = a.getSubLocality();
                    if (city == null) city = a.getCountryName();
                    if (city != null) name = sub != null && !sub.equals(city) ? city + " · " + sub : city;
                }
            }
        } catch (Exception ignored) { }
        if (name != null) { p.edit().putString(k, name).apply(); return name; }
        // fără internet: arătăm coordonatele scurte, numele vine data viitoare
        return String.format(Locale.ROOT, "%.3f, %.3f", lat, lon);
    }

    /** locul celei mai apropiate (ca oră) poze din telefon, în ±30 minute; null dacă nu e */
    static double[] phoneNear(Context ctx, long t) {
        if (t <= 0) return null;
        if (android.os.Build.VERSION.SDK_INT >= 33 ? ctx.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) != android.content.pm.PackageManager.PERMISSION_GRANTED
                : ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) return null;
        SharedPreferences p = prefs(ctx);
        String ck = "ph" + (t / 60000);
        if (p.contains(ck)) { String s = p.getString(ck, "-"); return s.equals("-") ? null : parse(s); }
        double[] best = null;
        long bd = Long.MAX_VALUE;
        android.database.Cursor c = null;
        try {
            String[] cols = {android.provider.MediaStore.Images.Media._ID, android.provider.MediaStore.Images.Media.DATE_TAKEN};
            String sel = android.provider.MediaStore.Images.Media.DATE_TAKEN + ">=? AND " + android.provider.MediaStore.Images.Media.DATE_TAKEN + "<=?";
            String[] args = {String.valueOf(t - 30 * 60000L), String.valueOf(t + 30 * 60000L)};
            c = ctx.getContentResolver().query(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols, sel, args, null);
            int n = 0;
            while (c != null && c.moveToNext() && n < 30) {
                n++;
                long id = c.getLong(0), tt = c.getLong(1);
                Uri u = android.content.ContentUris.withAppendedId(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                try { u = android.provider.MediaStore.setRequireOriginal(u); } catch (Exception ignored) { }
                try (java.io.InputStream in = ctx.getContentResolver().openInputStream(u)) {
                    if (in == null) continue;
                    double[] ll = new androidx.exifinterface.media.ExifInterface(in).getLatLong();
                    if (ll != null && (Math.abs(ll[0]) > 0.01 || Math.abs(ll[1]) > 0.01) && Math.abs(tt - t) < bd) { bd = Math.abs(tt - t); best = ll; }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) {
        } finally { if (c != null) c.close(); }
        p.edit().putString(ck, best == null ? "-" : String.format(Locale.ROOT, "%.6f,%.6f", best[0], best[1])).apply();
        return best;
    }

    /**
     * citește locul pentru toată lista: întâi pozele (repede), apoi filmările;
     * cele fără loc îl primesc de la poza de pe card din aceeași oră, apoi de la pozele din telefon (±30 min)
     */
    public static void scan(Context ctx, List<VideoItem> list, Runnable progress) {
        List<VideoItem> l = new ArrayList<>(list);
        List<VideoItem> order = new ArrayList<>();
        for (VideoItem it : l) if (it.isPhoto()) order.add(it);
        for (VideoItem it : l) if (!it.isPhoto()) order.add(it);
        long[] t = new long[l.size()];
        java.util.Map<VideoItem, Integer> idx = new java.util.IdentityHashMap<>();
        for (int i = 0; i < l.size(); i++) { idx.put(l.get(i), i); t[i] = Story.timeOf(ctx, l.get(i).name, null); if (t[i] <= 0) t[i] = l.get(i).modified; }
        int done = 0;
        for (VideoItem it : order) {
            double[] g = of(ctx, it);
            if (g != null) { it.lat = g[0]; it.lon = g[1]; it.geo = 1; it.place = placeName(ctx, g[0], g[1]); }
            else it.geo = -1;
            if (++done % 25 == 0 && progress != null) { infer(ctx, l, t, false); progress.run(); }
        }
        infer(ctx, l, t, true);
        if (progress != null) progress.run();
    }

    private static void infer(Context ctx, List<VideoItem> l, long[] t, boolean phone) {
        for (int i = 0; i < l.size(); i++) {
            VideoItem it = l.get(i);
            if (it.geo == 1) continue;
            long best = Long.MAX_VALUE;
            VideoItem from = null;
            for (int j = 0; j < l.size(); j++) {
                VideoItem o = l.get(j);
                if (o.geo != 1) continue;
                long d = Math.abs(t[i] - t[j]);
                if (d < best) { best = d; from = o; }
            }
            if (from != null && best <= 60 * 60000L) { it.lat = from.lat; it.lon = from.lon; it.geo = 2; it.place = from.place; continue; }
            double[] ph = phone ? phoneNear(ctx, t[i]) : null;
            if (ph != null) { it.lat = ph[0]; it.lon = ph[1]; it.geo = 2; it.place = placeName(ctx, ph[0], ph[1]); continue; }
            if (from != null && best <= NEAR_MS) { it.lat = from.lat; it.lon = from.lon; it.geo = 2; it.place = from.place; }
        }
    }

    public static int countExact(List<VideoItem> l) { int n = 0; for (VideoItem it : l) if (it.geo == 1) n++; return n; }
    public static int countAny(List<VideoItem> l) { int n = 0; for (VideoItem it : l) if (it.geo > 0) n++; return n; }
}
