package ro.director360.app;

import android.app.Application;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

/** Dacă aplicația se oprește din cauza unei erori, eroarea se păstrează și se arată la pornirea următoare. */
public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Th.init(this);
        // știm dacă ești în aplicație sau ai ieșit (ca să te anunțăm în notificări când e gata)
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityStarted(android.app.Activity a) { Work.visible++; }
            @Override public void onActivityStopped(android.app.Activity a) { Work.visible--; }
            @Override public void onActivityCreated(android.app.Activity a, android.os.Bundle b) { }
            @Override public void onActivityResumed(android.app.Activity a) { }
            @Override public void onActivityPaused(android.app.Activity a) { }
            @Override public void onActivitySaveInstanceState(android.app.Activity a, android.os.Bundle b) { }
            @Override public void onActivityDestroyed(android.app.Activity a) { }
        });
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String ver = "?";
                try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception ignored) { }
                try (FileWriter w = new FileWriter(new File(getFilesDir(), "crash.txt"))) {
                    w.write("Director360 " + ver + " · Android " + android.os.Build.VERSION.RELEASE + " · " + android.os.Build.MODEL + "\nFir: " + t.getName() + "\n\n" + sw);
                }
            } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
