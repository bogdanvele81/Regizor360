package ro.director360.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

/**
 * Calitate maximă la 360: filmarea originală X5 are cele două lentile separat (două piste video în același .insv,
 * sau fișierele _00_ și _10_). Le decodăm pe amândouă, le punem una lângă alta (ca în fișierul mic LRV, dar la rezoluție mare)
 * și scriem doar bucata [in, out] într-un fișier temporar, cu sunetul original. Restul (încadrare, filtre, texte) merge ca înainte.
 * Cum e rotită fiecare lentilă se află singur, comparând cu LRV-ul, și se ține minte.
 */
public class LensMerge {
    public interface Prog { void on(int pct); boolean cancelled(); }

    private static final String TAG_ORI = "lensOri2:";

    /** câte piste video are fișierul (2 = lentilele separat) */
    public static int videoTracks(Context ctx, Uri u) {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(ctx, u, null);
            int n = 0;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("video/")) n++;
            }
            return n;
        } catch (Exception e) { return 0; } finally { ex.release(); }
    }

    /** dimensiunea primei piste video {w,h} */
    public static int[] size(Context ctx, Uri u) {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(ctx, u, null);
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("video/")) return new int[]{f.getInteger(MediaFormat.KEY_WIDTH), f.getInteger(MediaFormat.KEY_HEIGHT)};
            }
        } catch (Exception ignored) { } finally { ex.release(); }
        return null;
    }

    /**
     * Fișierul de folosit la filmul final pentru o bucată 360.
     * Întoarce: fișierul unit (lentilele la calitate mare), sau `main` dacă are deja ambele lentile într-o singură imagine,
     * sau null (atunci rămâne LRV-ul, ca înainte).
     */
    public static Uri best(Context ctx, Uri main, Uri second, Uri lrv, long inMs, long outMs, int maxShort, Prog p) {
        try {
            int nt = videoTracks(ctx, main);
            if (second == null && nt <= 1) {
                int[] s = size(ctx, main);
                if (s != null && s[0] >= s[1] * 1.8f && s[0] > 2000) return main; // o singură imagine cu ambele lentile
                return null;
            }
            if (second == null && nt < 2) return null;
            File out = new File(ctx.getCacheDir(), "merge_" + Math.abs((main.toString() + inMs + "_" + outMs + "_" + maxShort).hashCode()) + ".mp4");
            if (out.exists() && out.length() > 100000) return Uri.fromFile(out);
            new LensMerge(ctx).run(main, second, lrv, inMs, outMs, maxShort, out, p);
            return out.exists() && out.length() > 100000 ? Uri.fromFile(out) : null;
        } catch (Throwable e) {
            android.util.Log.w("LensMerge", "nu am putut uni lentilele", e);
            return null;
        }
    }

    public static void cleanup(Context ctx) {
        File[] fs = ctx.getCacheDir().listFiles((d, n) -> n.startsWith("merge_") && n.endsWith(".mp4"));
        if (fs == null) return;
        long now = System.currentTimeMillis();
        for (File f : fs) if (now - f.lastModified() > 6L * 3600 * 1000) f.delete();
    }

    // ------------------------------------------------------------------
    private final Context ctx;
    private EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
    private EGLContext egc = EGL14.EGL_NO_CONTEXT;
    private EGLSurface win = EGL14.EGL_NO_SURFACE, pbuf = EGL14.EGL_NO_SURFACE;
    private EGLConfig cfg;
    private int prog, aPos, aTex, uST, uOri, uTexS;
    private FloatBuffer quad;

    private LensMerge(Context c) { ctx = c.getApplicationContext(); }

    /** o lentilă: extractor + decodor care desenează într-o textură */
    private class Lens {
        MediaExtractor ex;
        MediaCodec dec;
        SurfaceTexture st;
        Surface surf;
        int tex;
        int w, h;
        long pts = -1;
        boolean eosIn, eosOut, ready;
        final float[] m = new float[16];
        final Object lock = new Object();
        boolean avail;

        void open(Uri u, int nth, Handler h) throws Exception {
            ex = new MediaExtractor();
            ex.setDataSource(ctx, u, null);
            int k = -1, seen = 0;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                String mm = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
                if (mm != null && mm.startsWith("video/")) { if (seen == nth) { k = i; break; } seen++; }
            }
            if (k < 0) throw new IllegalStateException("fără pistă video " + nth);
            ex.selectTrack(k);
            MediaFormat f = ex.getTrackFormat(k);
            this.w = f.getInteger(MediaFormat.KEY_WIDTH);
            this.h = f.getInteger(MediaFormat.KEY_HEIGHT);
            int[] t = new int[1];
            GLES20.glGenTextures(1, t, 0);
            tex = t[0];
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            st = new SurfaceTexture(tex);
            st.setOnFrameAvailableListener(s -> { synchronized (lock) { avail = true; lock.notifyAll(); } }, h);
            surf = new Surface(st);
            dec = MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME));
            dec.configure(f, surf, null, 0);
            dec.start();
        }

        void seek(long us) { ex.seekTo(us, MediaExtractor.SEEK_TO_PREVIOUS_SYNC); }

        /** următorul cadru ≥ fromUs, desenat în textură; false = s-a terminat */
        boolean next(long fromUs) throws Exception {
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            while (!eosOut) {
                if (!eosIn) {
                    int ii = dec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer b = dec.getInputBuffer(ii);
                        int n = ex.readSampleData(b, 0);
                        if (n < 0) { dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eosIn = true; }
                        else { dec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0); ex.advance(); }
                    }
                }
                int oi = dec.dequeueOutputBuffer(bi, 5000);
                if (oi < 0) continue;
                if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) { eosOut = true; dec.releaseOutputBuffer(oi, false); return false; }
                boolean show = bi.presentationTimeUs >= fromUs;
                dec.releaseOutputBuffer(oi, show);
                if (!show) continue;
                synchronized (lock) {
                    long until = System.currentTimeMillis() + 3000;
                    while (!avail && System.currentTimeMillis() < until) lock.wait(200);
                    if (!avail) throw new IllegalStateException("cadrul nu a venit");
                    avail = false;
                }
                st.updateTexImage();
                st.getTransformMatrix(m);
                pts = bi.presentationTimeUs;
                ready = true;
                return true;
            }
            return false;
        }

        void release() {
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception ignored) { }
            try { if (ex != null) ex.release(); } catch (Exception ignored) { }
            try { if (surf != null) surf.release(); } catch (Exception ignored) { }
            try { if (st != null) st.release(); } catch (Exception ignored) { }
        }
    }

    private void run(Uri main, Uri second, Uri lrv, long inMs, long outMs, int maxShort, File out, Prog p) throws Exception {
        long inUs = inMs * 1000, outUs = outMs * 1000;
        HandlerThread ht = new HandlerThread("merge");
        ht.start();
        Handler h = new Handler(ht.getLooper());
        Lens A = new Lens(), B = new Lens();
        MediaCodec enc = null;
        MediaMuxer mux = null;
        File tmp = new File(out.getPath() + ".part");
        try {
            initEgl();
            A.open(main, 0, h);
            if (second != null) B.open(second, 0, h); else B.open(main, 1, h);
            int lens = Math.min(Math.min(A.w, A.h), Math.min(B.w, B.h));
            // mărimea fișierului unit: cât suportă codorul telefonului
            String mime = MediaFormat.MIMETYPE_VIDEO_HEVC;
            int S = 0;
            int[] cands = {Math.min(lens, 2880), 2560, 1920, 1440}; // 5760×2880 ajunge din plin pentru un film 4K încadrat
            for (String mm : new String[]{MediaFormat.MIMETYPE_VIDEO_HEVC, MediaFormat.MIMETYPE_VIDEO_AVC}) {
                for (int c : cands) {
                    if (c > lens) continue;
                    int s = c / 16 * 16;
                    if (supported(mm, 2 * s, s)) { S = s; mime = mm; break; }
                }
                if (S > 0) break;
            }
            if (S == 0) throw new IllegalStateException("codorul nu suportă");
            int W = 2 * S, H = S;
            float fps = 30;
            MediaFormat ef = MediaFormat.createVideoFormat(mime, W, H);
            ef.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            int br = (int) Math.min(mime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC) ? 100_000_000L : 120_000_000L, (long) W * H * 30L * (mime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC) ? 0.15 : 0.22));
            ef.setInteger(MediaFormat.KEY_BIT_RATE, clampBitrate(mime, W, H, br));
            ef.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            ef.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            enc = MediaCodec.createEncoderByType(mime);
            enc.configure(ef, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            Surface encIn = enc.createInputSurface();
            int[] sa = {EGL14.EGL_NONE};
            win = EGL14.eglCreateWindowSurface(dpy, cfg, encIn, sa, 0);
            EGL14.eglMakeCurrent(dpy, win, win, egc);
            enc.start();

            A.seek(inUs);
            B.seek(inUs);
            if (!A.next(inUs) || !B.next(inUs)) throw new IllegalStateException("nu am putut citi începutul");

            // cum sunt rotite lentilele (o singură dată, apoi se ține minte)
            int[] ori = orientation(A, B, lrv, inUs);

            mux = new MediaMuxer(tmp.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int vTrack = -1;
            boolean muxing = false;
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            // sunetul original
            MediaExtractor au = new MediaExtractor();
            au.setDataSource(ctx, main, null);
            int aTrack = -1;
            MediaFormat af = null;
            for (int i = 0; i < au.getTrackCount(); i++) {
                MediaFormat f = au.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { aTrack = i; af = f; break; }
            }
            int muxA = -1;

            long total = Math.max(1, outUs - inUs);
            int lastPct = -1;
            while (true) {
                if (p != null && p.cancelled()) throw new InterruptedException();
                // aliniem cele două lentile după timp
                if (A.pts + 20000 < B.pts) { if (!A.next(B.pts - 20000)) break; continue; }
                if (B.pts + 20000 < A.pts) { if (!B.next(A.pts - 20000)) break; continue; }
                if (A.pts > outUs) break;
                GLES20.glViewport(0, 0, W, H);
                GLES20.glClearColor(0, 0, 0, 1);
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
                draw(ori[2] == 0 ? A : B, ori[2] == 0 ? ori[0] : ori[1], -1f, 0f);
                draw(ori[2] == 0 ? B : A, ori[2] == 0 ? ori[1] : ori[0], 0f, 1f);
                EGLExt.eglPresentationTimeANDROID(dpy, win, (A.pts - inUs) * 1000L);
                EGL14.eglSwapBuffers(dpy, win);
                // scoatem ce a codat
                while (true) {
                    int oi = enc.dequeueOutputBuffer(bi, 0);
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        vTrack = mux.addTrack(enc.getOutputFormat());
                        if (af != null) muxA = mux.addTrack(af);
                        mux.start();
                        muxing = true;
                    } else if (oi >= 0) {
                        if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
                        if (bi.size > 0 && muxing) mux.writeSampleData(vTrack, enc.getOutputBuffer(oi), bi);
                        enc.releaseOutputBuffer(oi, false);
                    } else break;
                }
                int pct = (int) Math.min(99, (A.pts - inUs) * 100 / total);
                if (pct != lastPct && p != null) { p.on(pct); lastPct = pct; }
                if (!A.next(A.pts + 1) || !B.next(B.pts + 1)) break;
            }
            enc.signalEndOfInputStream();
            long until = System.currentTimeMillis() + 5000;
            while (System.currentTimeMillis() < until) {
                int oi = enc.dequeueOutputBuffer(bi, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && !muxing) {
                    vTrack = mux.addTrack(enc.getOutputFormat());
                    if (af != null) muxA = mux.addTrack(af);
                    mux.start();
                    muxing = true;
                } else if (oi >= 0) {
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
                    if (bi.size > 0 && muxing) mux.writeSampleData(vTrack, enc.getOutputBuffer(oi), bi);
                    enc.releaseOutputBuffer(oi, false);
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
            // sunetul, pentru aceeași bucată
            if (muxing && muxA >= 0) {
                au.selectTrack(aTrack);
                au.seekTo(inUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
                ByteBuffer buf = ByteBuffer.allocate(1 << 20);
                MediaCodec.BufferInfo ai = new MediaCodec.BufferInfo();
                while (true) {
                    int n = au.readSampleData(buf, 0);
                    if (n < 0) break;
                    long t = au.getSampleTime();
                    if (t > outUs) break;
                    if (t >= inUs) {
                        ai.set(0, n, t - inUs, (au.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0);
                        mux.writeSampleData(muxA, buf, ai);
                    }
                    au.advance();
                }
            }
            au.release();
            if (muxing) { mux.stop(); }
            mux.release();
            mux = null;
            if (muxing && tmp.length() > 100000) tmp.renameTo(out);
            if (p != null) p.on(100);
        } finally {
            A.release();
            B.release();
            try { if (enc != null) { enc.stop(); enc.release(); } } catch (Exception ignored) { }
            try { if (mux != null) mux.release(); } catch (Exception ignored) { }
            tmp.delete();
            releaseEgl();
            ht.quitSafely();
        }
    }

    // ---------------- orientarea lentilelor ----------------

    /** {orientarea lui A, orientarea lui B, 0 = A la stânga / 1 = B la stânga} */
    private int[] orientation(Lens A, Lens B, Uri lrv, long tUs) {
        SharedPreferences sp = ctx.getSharedPreferences("lens", Context.MODE_PRIVATE);
        String key = TAG_ORI + A.w + "x" + A.h;
        String s = sp.getString(key, null);
        if (s != null) try { String[] q = s.split(","); return new int[]{Integer.parseInt(q[0]), Integer.parseInt(q[1]), Integer.parseInt(q[2])}; } catch (Exception ignored) { }
        int[] res = {0, 0, 0};
        if (lrv == null) return res;
        Bitmap ref = null;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(ctx, lrv);
            Bitmap b = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST);
            if (b != null) ref = Bitmap.createScaledBitmap(b, 128, 64, true);
        } catch (Exception ignored) { } finally { try { r.release(); } catch (Exception ignored) { } }
        if (ref == null) return res;
        float[][] left = new float[2][8], right = new float[2][8];
        int[] fb = new int[1], ft = new int[1];
        GLES20.glGenFramebuffers(1, fb, 0);
        GLES20.glGenTextures(1, ft, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ft[0]);
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 64, 64, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0]);
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, ft[0], 0);
        ByteBuffer px = ByteBuffer.allocateDirect(64 * 64 * 4).order(ByteOrder.nativeOrder());
        float[] gl = gray(ref, 0), gr = gray(ref, 64);
        Lens[] L = {A, B};
        for (int l = 0; l < 2; l++) for (int k = 0; k < 8; k++) {
            GLES20.glViewport(0, 0, 64, 64);
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            draw(L[l], k, -1f, 1f);
            px.rewind();
            GLES20.glReadPixels(0, 0, 64, 64, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, px);
            float[] g = new float[64 * 64];
            for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
                int o = ((63 - y) * 64 + x) * 4; // glReadPixels e de jos în sus
                g[y * 64 + x] = 0.299f * (px.get(o) & 255) + 0.587f * (px.get(o + 1) & 255) + 0.114f * (px.get(o + 2) & 255);
            }
            left[l][k] = diff(g, gl);
            right[l][k] = diff(g, gr);
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glDeleteFramebuffers(1, fb, 0);
        GLES20.glDeleteTextures(1, ft, 0);
        int ka = argmin(left[0]), kb = argmin(right[1]), sa = argmin(right[0]), sb = argmin(left[1]);
        float keep = left[0][ka] + right[1][kb], swap = right[0][sa] + left[1][sb];
        res = keep <= swap ? new int[]{ka, kb, 0} : new int[]{sa, sb, 1};
        sp.edit().putString(key, res[0] + "," + res[1] + "," + res[2]).apply();
        return res;
    }

    private static int argmin(float[] a) { int k = 0; for (int i = 1; i < a.length; i++) if (a[i] < a[k]) k = i; return k; }

    private static float[] gray(Bitmap b, int x0) {
        float[] g = new float[64 * 64];
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            int c = b.getPixel(x0 + x, y);
            g[y * 64 + x] = 0.299f * ((c >> 16) & 255) + 0.587f * ((c >> 8) & 255) + 0.114f * (c & 255);
        }
        return g;
    }

    /** diferența după ce scoatem luminozitatea medie (lentilele pot avea expuneri puțin diferite) */
    private static float diff(float[] a, float[] b) {
        float ma = 0, mb = 0;
        for (int i = 0; i < a.length; i++) { ma += a[i]; mb += b[i]; }
        ma /= a.length; mb /= b.length;
        float d = 0;
        for (int i = 0; i < a.length; i++) d += Math.abs((a[i] - ma) - (b[i] - mb));
        return d / a.length;
    }

    // ---------------- desen ----------------

    private static final String VS =
            "attribute vec2 aPos; attribute vec2 aTex; uniform mat4 uST; uniform int uOri; varying vec2 vT;\n" +
            "vec2 ori(vec2 t, int k){ if(k>=4) t.x = 1.0 - t.x; int r = k - (k/4)*4;\n" +
            "  if(r==1) t = vec2(t.y, 1.0-t.x); else if(r==2) t = vec2(1.0-t.x, 1.0-t.y); else if(r==3) t = vec2(1.0-t.y, t.x); return t; }\n" +
            "void main(){ gl_Position = vec4(aPos, 0.0, 1.0); vT = (uST * vec4(ori(aTex, uOri), 0.0, 1.0)).xy; }\n";
    private static final String FS =
            "#extension GL_OES_EGL_image_external : require\nprecision highp float; varying vec2 vT; uniform samplerExternalOES uTexS;\n" +
            "void main(){ gl_FragColor = texture2D(uTexS, vT); }\n";

    /** desenează lentila în banda orizontală [x0, x1] (coordonate -1..1) */
    private void draw(Lens l, int ori, float x0, float x1) {
        GLES20.glUseProgram(prog);
        float[] v = {x0, -1, 0, 0, x1, -1, 1, 0, x0, 1, 0, 1, x1, 1, 1, 1};
        quad.clear();
        quad.put(v).position(0);
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad);
        GLES20.glEnableVertexAttribArray(aPos);
        quad.position(2);
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, quad);
        GLES20.glEnableVertexAttribArray(aTex);
        GLES20.glUniformMatrix4fv(uST, 1, false, l.m, 0);
        GLES20.glUniform1i(uOri, ori);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, l.tex);
        GLES20.glUniform1i(uTexS, 0);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
    }

    private void initEgl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        int[] ver = new int[2];
        EGL14.eglInitialize(dpy, ver, 0, ver, 1);
        int[] at = {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, 0x3142 /* EGL_RECORDABLE_ANDROID */, 1,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT | EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE};
        EGLConfig[] cs = new EGLConfig[1];
        int[] n = new int[1];
        EGL14.eglChooseConfig(dpy, at, 0, cs, 0, 1, n, 0);
        cfg = cs[0];
        egc = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT, new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
        pbuf = EGL14.eglCreatePbufferSurface(dpy, cfg, new int[]{EGL14.EGL_WIDTH, 16, EGL14.EGL_HEIGHT, 16, EGL14.EGL_NONE}, 0);
        EGL14.eglMakeCurrent(dpy, pbuf, pbuf, egc);
        prog = program(VS, FS);
        aPos = GLES20.glGetAttribLocation(prog, "aPos");
        aTex = GLES20.glGetAttribLocation(prog, "aTex");
        uST = GLES20.glGetUniformLocation(prog, "uST");
        uOri = GLES20.glGetUniformLocation(prog, "uOri");
        uTexS = GLES20.glGetUniformLocation(prog, "uTexS");
        quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
    }

    private void releaseEgl() {
        if (dpy == EGL14.EGL_NO_DISPLAY) return;
        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
        if (win != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, win);
        if (pbuf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, pbuf);
        if (egc != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, egc);
        EGL14.eglReleaseThread();
        EGL14.eglTerminate(dpy);
        dpy = EGL14.EGL_NO_DISPLAY;
    }

    private static int program(String vs, String fs) {
        int v = shader(GLES20.GL_VERTEX_SHADER, vs), f = shader(GLES20.GL_FRAGMENT_SHADER, fs);
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, v);
        GLES20.glAttachShader(p, f);
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new IllegalStateException("shader: " + GLES20.glGetProgramInfoLog(p));
        return p;
    }

    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new IllegalStateException("shader: " + GLES20.glGetShaderInfoLog(s));
        return s;
    }

    private static boolean supported(String mime, int w, int h) {
        for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (!ci.isEncoder()) continue;
            for (String t : ci.getSupportedTypes()) {
                if (!t.equalsIgnoreCase(mime)) continue;
                try {
                    MediaCodecInfo.VideoCapabilities vc = ci.getCapabilitiesForType(t).getVideoCapabilities();
                    if (vc != null && vc.isSizeSupported(w, h)) return true;
                } catch (Exception ignored) { }
            }
        }
        return false;
    }

    private static int clampBitrate(String mime, int w, int h, int br) {
        for (MediaCodecInfo ci : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
            if (!ci.isEncoder()) continue;
            for (String t : ci.getSupportedTypes()) {
                if (!t.equalsIgnoreCase(mime)) continue;
                try {
                    MediaCodecInfo.VideoCapabilities vc = ci.getCapabilitiesForType(t).getVideoCapabilities();
                    if (vc != null && vc.isSizeSupported(w, h)) return vc.getBitrateRange().clamp(br);
                } catch (Exception ignored) { }
            }
        }
        return br;
    }
}
