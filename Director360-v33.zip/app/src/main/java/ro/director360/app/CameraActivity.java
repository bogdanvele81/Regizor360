package ro.director360.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PatternMatcher;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Camera Insta360 prin Wi-Fi: conectare, baterie, fișierele de pe card, descărcare, poză și filmare de la distanță. */
public class CameraActivity extends AppCompatActivity {
    private float dd;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService dl = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;
    private Osc osc;
    private boolean recording, video;

    private LinearLayout top;
    private TextView status, info;
    private EditText pass;
    private View connectBtn, remote;
    private TextView shootBtn, modePhoto, modeVideo, listTitle;
    private final List<Osc.Entry> files = new ArrayList<>();
    private final Map<String, Osc.Entry> byName = new HashMap<>();
    private final Map<String, Integer> progress = new HashMap<>();
    private volatile String cancelName;
    private RecyclerView rv;
    private Ad ad;

    private int dp(float v) { return Math.round(v * dd); }

    @Override
    protected void onCreate(Bundle b) {
        Th.apply(this);
        super.onCreate(b);
        dd = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111214);
        root.setPadding(dp(16), dp(12), dp(16), 0);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setBackground(round(0xFF1A1C1F, 22));
        back.setContentDescription("Înapoi");
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = text("Cameră Insta360", 22, 0xFFF2F2F0, true);
        t.setPadding(dp(14), 0, 0, 0);
        head.addView(t);
        root.addView(head);

        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(16), dp(14), dp(16), dp(14));
        top.setBackground(round(0xFF1A1C1F, 18));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(14);
        root.addView(top, tp);

        status = text("Pornește camera, apoi pe cameră: trage de sus în jos → Wi-Fi pornit. Apoi apasă „Conectează camera”.", 14, 0xFFB9BCBF, false);
        top.addView(status);
        info = text("", 15, 0xFFF2F2F0, true);
        info.setVisibility(View.GONE);
        top.addView(info);

        pass = new EditText(this);
        pass.setHint("Parola Wi-Fi a camerei");
        pass.setText(prefs.getString("camPass", "87654320"));
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        pass.setTextColor(0xFFF2F2F0);
        pass.setHintTextColor(0xFF6B7078);
        pass.setSingleLine(true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.topMargin = dp(8);
        top.addView(pass, pp);

        TextView cb0 = button("Conectează camera", true);
        cb0.setOnClickListener(v -> connect());
        connectBtn = cb0;
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        bp.topMargin = dp(10);
        top.addView(cb0, bp);

        // telecomanda
        LinearLayout rm = new LinearLayout(this);
        rm.setOrientation(LinearLayout.VERTICAL);
        rm.setVisibility(View.GONE);
        LinearLayout modes = new LinearLayout(this);
        modePhoto = chip("Poză");
        modeVideo = chip("Filmare");
        modePhoto.setOnClickListener(v -> { if (!recording) { video = false; paintModes(); } });
        modeVideo.setOnClickListener(v -> { if (!recording) { video = true; paintModes(); } });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(40), 1f);
        modes.addView(modePhoto, mp);
        LinearLayout.LayoutParams mp2 = new LinearLayout.LayoutParams(0, dp(40), 1f);
        mp2.setMarginStart(dp(8));
        modes.addView(modeVideo, mp2);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = dp(12);
        rm.addView(modes, mlp);
        shootBtn = button("Fă poza", true);
        shootBtn.setOnClickListener(v -> shoot());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        sp.topMargin = dp(10);
        rm.addView(shootBtn, sp);
        remote = rm;
        top.addView(rm);

        listTitle = text("", 13, 0xFF9AA0A6, false);
        listTitle.setLetterSpacing(0.06f);
        listTitle.setPadding(dp(4), dp(18), 0, dp(6));
        root.addView(listTitle);

        rv = new RecyclerView(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        ad = new Ad();
        rv.setAdapter(ad);
        root.addView(rv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        paintModes();
    }

    // ---------------- conectarea ----------------
    private void connect() {
        String pw = pass.getText().toString().trim();
        if (pw.length() < 8) { Toast.makeText(this, "Parola Wi-Fi are cel puțin 8 caractere. O vezi pe cameră la Setări → Wi-Fi.", Toast.LENGTH_LONG).show(); return; }
        prefs.edit().putString("camPass", pw).apply();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, 7);
            return;
        }
        if (Build.VERSION.SDK_INT < 33 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 7);
            return;
        }
        status.setText("Caut camera…");
        connectBtn.setEnabled(false);
        io.execute(() -> {
            // 1) poate telefonul e deja conectat la Wi-Fi-ul camerei
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities c = cm.getNetworkCapabilities(n);
                if (c == null || !c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                Osc o = new Osc(n);
                String m = o.model();
                if (m != null) { main.post(() -> onConnected(o, m)); return; }
            }
            // 2) cer telefonului să se conecteze la camera (arată o fereastră de confirmare)
            main.post(() -> requestWifi(pw));
        });
    }

    @Override
    public void onRequestPermissionsResult(int rc, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (rc == 7) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) connect();
            else status.setText("Fără permisiunea pentru dispozitive din apropiere nu pot găsi camera. O poți porni din Setări → Aplicații → Director360 → Permisiuni.");
        }
    }

    private void requestWifi(String pw) {
        status.setText("Alege camera în fereastra care apare (numele începe cu „X5” sau se termină cu „.OSC”).");
        WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
                .setSsidPattern(new PatternMatcher(".*OSC", PatternMatcher.PATTERN_SIMPLE_GLOB))
                .setWpa2Passphrase(pw)
                .build();
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build();
        if (cb != null) try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(@NonNull Network n) {
                io.execute(() -> {
                    Osc o = new Osc(n);
                    String m = null;
                    for (int i = 0; i < 6 && m == null; i++) { m = o.model(); if (m == null) try { Thread.sleep(700); } catch (InterruptedException ignored) { } }
                    final String mm = m;
                    main.post(() -> {
                        if (mm != null) onConnected(o, mm);
                        else { status.setText("M-am conectat la Wi-Fi, dar camera nu răspunde. Repornește Wi-Fi-ul pe cameră și încearcă din nou."); connectBtn.setEnabled(true); }
                    });
                });
            }
            @Override public void onUnavailable() {
                main.post(() -> { status.setText("Nu am găsit camera. Verifică: camera pornită, Wi-Fi pornit pe cameră, parola corectă. Apoi încearcă din nou."); connectBtn.setEnabled(true); });
            }
            @Override public void onLost(@NonNull Network n) {
                main.post(() -> { osc = null; showDisconnected("Conexiunea cu camera s-a pierdut. Apasă din nou „Conectează camera”."); });
            }
        };
        try { cm.requestNetwork(req, cb); }
        catch (Exception e) { status.setText("Telefonul nu a putut porni conectarea: " + e.getMessage()); connectBtn.setEnabled(true); }
    }

    private void showDisconnected(String msg) {
        status.setText(msg);
        status.setVisibility(View.VISIBLE);
        info.setVisibility(View.GONE);
        pass.setVisibility(View.VISIBLE);
        connectBtn.setVisibility(View.VISIBLE);
        connectBtn.setEnabled(true);
        remote.setVisibility(View.GONE);
    }

    private void onConnected(Osc o, String model) {
        osc = o;
        status.setVisibility(View.GONE);
        pass.setVisibility(View.GONE);
        connectBtn.setVisibility(View.GONE);
        info.setVisibility(View.VISIBLE);
        info.setText(model + " · conectată");
        remote.setVisibility(View.VISIBLE);
        refreshInfo(model);
        loadFiles();
    }

    private void refreshInfo(String model) {
        Osc o = osc;
        if (o == null) return;
        io.execute(() -> {
            int bat = o.battery();
            long[] sp = o.space();
            main.post(() -> {
                StringBuilder s = new StringBuilder(model);
                if (bat >= 0) s.append(" · baterie ").append(bat).append("%");
                if (sp != null && sp[0] >= 0) s.append(" · liber ").append(gb(sp[0]));
                info.setText(s);
            });
        });
    }

    private void loadFiles() {
        Osc o = osc;
        if (o == null) return;
        listTitle.setText("CITESC CARDUL DIN CAMERĂ…");
        io.execute(() -> {
            try {
                List<Osc.Entry> l = o.list();
                main.post(() -> {
                    files.clear();
                    byName.clear();
                    for (Osc.Entry e : l) byName.put(e.name, e);
                    for (Osc.Entry e : l) if (!e.isLrv() && !e.name.contains("_10_")) files.add(e);
                    int nv = 0, np = 0;
                    for (Osc.Entry e : files) if (e.isPhoto()) np++; else nv++;
                    listTitle.setText("PE CAMERĂ: " + nv + " FILMĂRI · " + np + " POZE");
                    ad.notifyDataSetChanged();
                });
            } catch (Exception e) {
                main.post(() -> listTitle.setText("NU AM PUTUT CITI LISTA: " + e.getMessage()));
            }
        });
    }

    // ---------------- telecomanda ----------------
    private void paintModes() {
        style(modePhoto, !video);
        style(modeVideo, video);
        shootBtn.setText(video ? (recording ? "Oprește filmarea" : "Pornește filmarea") : "Fă poza");
    }

    private void shoot() {
        Osc o = osc;
        if (o == null) return;
        shootBtn.setEnabled(false);
        io.execute(() -> {
            String err = null;
            try {
                if (!video) o.takePicture();
                else if (!recording) { o.startVideo(); recording = true; }
                else { o.stopVideo(); recording = false; }
            } catch (Exception e) { err = e.getMessage(); }
            final String er = err;
            main.post(() -> {
                shootBtn.setEnabled(true);
                paintModes();
                if (er != null) Toast.makeText(this, "Camera a refuzat: " + er, Toast.LENGTH_LONG).show();
                else if (!video) Toast.makeText(this, "Poza e făcută.", Toast.LENGTH_SHORT).show();
                if (er == null && !(video && recording)) { loadFiles(); refreshInfo(info.getText().toString().split(" · ")[0]); }
            });
        });
    }

    // ---------------- fișierele ----------------
    private File dir() {
        File d = new File(getExternalFilesDir(null), "Camera");
        d.mkdirs();
        return d;
    }

    private File local(Osc.Entry e) { return new File(dir(), e.name); }

    /** previzualizarea unei filmări 360: LRV_..._01_... lângă VID_..._00_... */
    private Osc.Entry lrvFor(Osc.Entry e) {
        if (e.isPhoto()) return null;
        String n = e.name;
        int dot = n.lastIndexOf('.');
        String base = (dot > 0 ? n.substring(0, dot) : n).replaceFirst("^VID_", "LRV_").replace("_00_", "_01_");
        Osc.Entry l = byName.get(base + ".lrv");
        if (l == null) l = byName.get(base + ".insv");
        if (l == null) l = byName.get(base + ".mp4");
        return l;
    }

    private void download(Osc.Entry e, boolean openAfter) {
        Osc o = osc;
        if (o == null) { Toast.makeText(this, "Conectează întâi camera.", Toast.LENGTH_SHORT).show(); return; }
        if (progress.containsKey(e.name)) return;
        progress.put(e.name, 0);
        ad.notifyDataSetChanged();
        dl.execute(() -> {
            String err = null;
            boolean ok = true;
            try {
                Osc.Entry l = lrvFor(e);
                long total = e.size + (l != null ? l.size : 0);
                final long[] base = {0};
                Osc.Progress pr = (done, tot) -> {
                    int p = total > 0 ? (int) Math.min(99, (base[0] + done) * 100 / total) : 0;
                    main.post(() -> { progress.put(e.name, p); ad.notifyDataSetChanged(); });
                    return !e.name.equals(cancelName) && !isDestroyed();
                };
                if (l != null && !local(l).exists()) { ok = o.download(l.url, l.size, local(l), pr); base[0] += l.size; }
                if (ok && !local(e).exists()) ok = o.download(e.url, e.size, local(e), pr);
            } catch (Exception ex) { err = ex.getMessage(); }
            final String er = err;
            final boolean fin = ok;
            main.post(() -> {
                progress.remove(e.name);
                if (e.name.equals(cancelName)) cancelName = null;
                ad.notifyDataSetChanged();
                if (er != null) Toast.makeText(this, "Descărcarea nu a reușit: " + er, Toast.LENGTH_LONG).show();
                else if (fin && openAfter) openLocal(e);
            });
        });
    }

    private void openLocal(Osc.Entry e) {
        File f = local(e);
        if (!f.exists()) { download(e, true); return; }
        String low = e.name.toLowerCase();
        if (e.isPhoto()) {
            Intent i = new Intent(this, PhotoActivity.class);
            i.putExtra("uri", Uri.fromFile(f).toString());
            i.putExtra("name", e.name);
            i.putExtra("is360", low.endsWith(".insp"));
            i.putExtra("lens", 0);
            startActivity(i);
            return;
        }
        Osc.Entry l = lrvFor(e);
        File lf = l != null ? local(l) : null;
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", new String[]{Uri.fromFile(f).toString()});
        i.putExtra("lrvs", new String[]{lf != null && lf.exists() ? Uri.fromFile(lf).toString() : null});
        i.putExtra("names", new String[]{e.name});
        i.putExtra("keys", new String[]{"cam:" + e.name});
        i.putExtra("auto", false);
        startActivity(i);
    }

    private void askDelete(Osc.Entry e) {
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ștergi de pe cameră?")
                .setMessage(MainActivity.pretty(e.name) + " · " + gb(e.size) + "\nSe șterge de pe cardul din cameră. Copia descărcată pe telefon rămâne.")
                .setPositiveButton("Șterge", (d, w) -> {
                    Osc o = osc;
                    if (o == null) return;
                    io.execute(() -> {
                        String err = null;
                        try {
                            o.delete(e.url);
                            Osc.Entry l = lrvFor(e);
                            if (l != null) try { o.delete(l.url); } catch (Exception ignored) { }
                        } catch (Exception ex) { err = ex.getMessage(); }
                        final String er = err;
                        main.post(() -> { if (er != null) Toast.makeText(this, "Nu s-a șters: " + er, Toast.LENGTH_LONG).show(); loadFiles(); });
                    });
                })
                .setNegativeButton("Renunță", null).show();
    }

    private void itemMenu(Osc.Entry e) {
        boolean have = local(e).exists();
        List<String> ops = new ArrayList<>();
        ops.add(have ? "Deschide în editor" : "Descarcă și deschide");
        if (!have) ops.add("Doar descarcă");
        if (have) ops.add("Șterge copia de pe telefon");
        ops.add("Șterge de pe cameră");
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(MainActivity.pretty(e.name))
                .setItems(ops.toArray(new String[0]), (d, w) -> {
                    String op = ops.get(w);
                    if (op.startsWith("Deschide") || op.startsWith("Descarcă și")) openLocal(e);
                    else if (op.startsWith("Doar")) download(e, false);
                    else if (op.startsWith("Șterge copia")) { local(e).delete(); Osc.Entry l = lrvFor(e); if (l != null) local(l).delete(); ad.notifyDataSetChanged(); }
                    else askDelete(e);
                }).show();
    }

    private class Ad extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
            LinearLayout row = new LinearLayout(CameraActivity.this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(round(0xFF1A1C1F, 14));
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(8);
            row.setLayoutParams(lp);
            TextView kind = text("", 12, 0xFFF2F2F0, true);
            kind.setGravity(Gravity.CENTER);
            row.addView(kind, new LinearLayout.LayoutParams(dp(46), dp(46)));
            LinearLayout mid = new LinearLayout(CameraActivity.this);
            mid.setOrientation(LinearLayout.VERTICAL);
            mid.setPadding(dp(12), 0, dp(8), 0);
            mid.addView(text("", 15, 0xFFF2F2F0, true));
            mid.addView(text("", 12.5f, 0xFF9AA0A6, false));
            row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView act = button("", false);
            act.setTextSize(13);
            act.setPadding(dp(12), 0, dp(12), 0);
            row.addView(act, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)));
            return new RecyclerView.ViewHolder(row) { };
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int pos) {
            Osc.Entry e = files.get(pos);
            LinearLayout row = (LinearLayout) h.itemView;
            TextView kind = (TextView) row.getChildAt(0);
            LinearLayout mid = (LinearLayout) row.getChildAt(1);
            TextView act = (TextView) row.getChildAt(2);
            String low = e.name.toLowerCase();
            boolean is360 = low.endsWith(".insv") || low.endsWith(".insp");
            kind.setText(e.isPhoto() ? (is360 ? "POZĂ\n360" : "POZĂ") : (is360 ? "FILM\n360" : "FILM"));
            kind.setBackground(round(e.isPhoto() ? 0xFF2A3A4A : 0xFF3A2A22, 12));
            ((TextView) mid.getChildAt(0)).setText(MainActivity.pretty(e.name));
            Integer p = progress.get(e.name);
            boolean have = local(e).exists();
            long tot = e.size;
            Osc.Entry l = lrvFor(e);
            ((TextView) mid.getChildAt(1)).setText(gb(tot) + (have ? " · pe telefon" : "") + (p != null ? " · descarc " + p + "%" : ""));
            if (p != null) { act.setText("Oprește"); act.setOnClickListener(v -> cancelName = e.name); }
            else { act.setText(have ? "Deschide" : "Descarcă"); act.setOnClickListener(v -> openLocal(e)); }
            row.setOnClickListener(v -> itemMenu(e));
        }

        @Override public int getItemCount() { return files.size(); }
    }

    // ---------------- ajutoare de aspect ----------------
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView button(String s, boolean primary) {
        TextView b = text(s, 16, primary ? 0xFF1A0A00 : 0xFFF2F2F0, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(primary ? Th.A : 0xFF2A2C30, 24));
        return b;
    }

    private TextView chip(String s) {
        TextView c = text(s, 14, 0xFFF2F2F0, true);
        c.setGravity(Gravity.CENTER);
        return c;
    }

    private void style(TextView c, boolean on) {
        GradientDrawable g = round(on ? 0xFF2A2C30 : 0xFF16171A, 20);
        if (on) g.setStroke(dp(2), Th.A);
        c.setBackground(g);
        c.setTextColor(on ? 0xFFF2F2F0 : 0xFF9AA0A6);
    }

    static String gb(long b) {
        if (b <= 0) return "?";
        if (b >= 1L << 30) return String.format(java.util.Locale.US, "%.1f GB", b / (double) (1L << 30));
        return String.format(java.util.Locale.US, "%.0f MB", b / (double) (1L << 20));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cancelName = "*";
        if (cb != null) try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        io.shutdownNow();
        dl.shutdownNow();
    }
}
