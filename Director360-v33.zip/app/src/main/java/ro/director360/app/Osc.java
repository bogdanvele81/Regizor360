package ro.director360.app;

import android.net.Network;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Vorbește cu camera Insta360 prin Wi-Fi, pe calea deschisă „OSC” (Open Spherical Camera):
 * informații, baterie, lista fișierelor, descărcare, ștergere, poză și filmare.
 * Toate apelurile sunt blocante: se cheamă de pe un fir separat.
 */
final class Osc {
    static final String HOST = "http://192.168.42.1";

    static final class Entry {
        String name, url;
        long size;
        String date;
        boolean isPhoto() { String l = name.toLowerCase(); return l.endsWith(".insp") || l.endsWith(".jpg") || l.endsWith(".dng"); }
        boolean isLrv() { String l = name.toLowerCase(); return l.startsWith("lrv_") || l.endsWith(".lrv"); }
    }

    private final Network net;

    Osc(Network net) { this.net = net; }

    private HttpURLConnection open(String path, int timeout) throws Exception {
        URL u = new URL(path.startsWith("http") ? path : HOST + path);
        HttpURLConnection c = (HttpURLConnection) (net != null ? net.openConnection(u) : u.openConnection());
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("X-XSRF-Protected", "1");
        return c;
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    JSONObject get(String path) throws Exception {
        HttpURLConnection c = open(path, 5000);
        try { return new JSONObject(read(c.getInputStream())); } finally { c.disconnect(); }
    }

    JSONObject post(String path, JSONObject body, int timeout) throws Exception {
        HttpURLConnection c = open(path, timeout);
        try {
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json;charset=utf-8");
            byte[] d = (body == null ? "{}" : body.toString()).getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(d.length);
            OutputStream o = c.getOutputStream();
            o.write(d);
            o.close();
            int code = c.getResponseCode();
            String s = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            return new JSONObject(s);
        } finally { c.disconnect(); }
    }

    JSONObject cmd(String name, JSONObject params) throws Exception {
        JSONObject b = new JSONObject();
        b.put("name", name);
        if (params != null) b.put("parameters", params);
        JSONObject r = post("/osc/commands/execute", b, 15000);
        // comenzile lungi (poză) răspund „inProgress”: aștept până termină
        for (int i = 0; i < 60 && "inProgress".equals(r.optString("state")) && r.has("id"); i++) {
            Thread.sleep(500);
            JSONObject q = new JSONObject();
            q.put("id", r.getString("id"));
            r = post("/osc/commands/status", q, 10000);
        }
        if ("error".equals(r.optString("state"))) {
            JSONObject e = r.optJSONObject("error");
            throw new Exception(e != null ? e.optString("message", e.optString("code")) : "eroare de la cameră");
        }
        return r;
    }

    /** modelul camerei, sau null dacă nu răspunde */
    String model() {
        try { JSONObject i = get("/osc/info"); return i.optString("model", "Insta360"); } catch (Exception e) { return null; }
    }

    /** bateria 0…100, sau -1 */
    int battery() {
        try {
            JSONObject s = post("/osc/state", null, 5000).optJSONObject("state");
            if (s == null) return -1;
            double b = s.optDouble("batteryLevel", -1);
            return b < 0 ? -1 : (int) Math.round(b <= 1 ? b * 100 : b);
        } catch (Exception e) { return -1; }
    }

    /** {liber, total} în octeți, sau null */
    long[] space() {
        try {
            JSONObject p = new JSONObject();
            p.put("optionNames", new JSONArray().put("remainingSpace").put("totalSpace"));
            JSONObject o = cmd("camera.getOptions", p).optJSONObject("results");
            o = o == null ? null : o.optJSONObject("options");
            if (o == null) return null;
            return new long[]{o.optLong("remainingSpace", -1), o.optLong("totalSpace", -1)};
        } catch (Exception e) { return null; }
    }

    /** toate fișierele de pe card (cele mai noi primele) */
    java.util.List<Entry> list() throws Exception {
        java.util.List<Entry> out = new java.util.ArrayList<>();
        int start = 0, total = Integer.MAX_VALUE;
        while (start < total && start < 5000) {
            JSONObject p = new JSONObject();
            p.put("fileType", "all");
            p.put("entryCount", 50);
            p.put("maxThumbSize", 0);
            p.put("startPosition", start);
            JSONObject res = cmd("camera.listFiles", p).optJSONObject("results");
            if (res == null) break;
            JSONArray a = res.optJSONArray("entries");
            total = res.optInt("totalEntries", 0);
            if (a == null || a.length() == 0) break;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.getJSONObject(i);
                Entry en = new Entry();
                en.url = e.optString("fileUrl");
                en.name = e.optString("name", en.url.substring(en.url.lastIndexOf('/') + 1));
                en.size = e.optLong("size", 0);
                en.date = e.optString("dateTimeZone", e.optString("dateTime", ""));
                out.add(en);
            }
            start += a.length();
            if (!res.has("totalEntries")) break; // camera nu știe de pagini: am primit tot
        }
        java.util.Collections.sort(out, (x, y) -> y.name.compareTo(x.name));
        return out;
    }

    void delete(String url) throws Exception {
        JSONObject p = new JSONObject();
        p.put("fileUrls", new JSONArray().put(url));
        cmd("camera.delete", p);
    }

    void setMode(boolean video) throws Exception {
        JSONObject o = new JSONObject();
        o.put("captureMode", video ? "video" : "image");
        JSONObject p = new JSONObject();
        p.put("options", o);
        cmd("camera.setOptions", p);
    }

    String takePicture() throws Exception {
        setMode(false);
        JSONObject r = cmd("camera.takePicture", null).optJSONObject("results");
        return r == null ? null : r.optString("fileUrl", null);
    }

    void startVideo() throws Exception { setMode(true); cmd("camera.startCapture", null); }

    void stopVideo() throws Exception { cmd("camera.stopCapture", null); }

    interface Progress { boolean step(long done, long total); }

    /** descarcă în fișierul dst; întoarce false dacă s-a oprit la cerere */
    boolean download(String url, long size, File dst, Progress pr) throws Exception {
        File tmp = new File(dst.getPath() + ".part");
        HttpURLConnection c = open(url, 20000);
        try {
            InputStream in = c.getInputStream();
            long tot = c.getContentLengthLong() > 0 ? c.getContentLengthLong() : size;
            OutputStream o = new FileOutputStream(tmp);
            byte[] b = new byte[256 * 1024];
            long done = 0, last = 0;
            int n;
            try {
                while ((n = in.read(b)) > 0) {
                    o.write(b, 0, n);
                    done += n;
                    if (done - last > 1 << 20 || done == tot) {
                        last = done;
                        if (!pr.step(done, tot)) { o.close(); in.close(); tmp.delete(); return false; }
                    }
                }
            } finally { o.close(); in.close(); }
            if (!tmp.renameTo(dst)) throw new Exception("nu pot salva fișierul");
            return true;
        } finally { c.disconnect(); }
    }
}
