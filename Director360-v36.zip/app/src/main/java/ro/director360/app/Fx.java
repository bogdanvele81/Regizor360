package ro.director360.app;

/**
 * Efectele de mișcare ale cadrului (ca la Insta360): calculează pentru fiecare moment
 * {yaw, pitch, roll, unghi de vedere, cât e planetă 0…1}. Aceleași formule pe ecran și la salvare.
 */
public final class Fx {
    public static final String[] IDS = {"none", "barrel", "planetfade", "rollplanet", "timeshift", "flylapse", "freeze"};
    public static final String[] NAMES = {"Fără", "Barrel Roll", "Tiny Planet fade", "Roll Planet", "TimeShift", "Fly Lapse", "Freeze Frame"};

    /** efectele care schimbă viteza filmului */
    public static boolean isSpeed(String fx) { return "timeshift".equals(fx) || "flylapse".equals(fx) || "freeze".equals(fx); }

    /** viteza din cursorul 0…9: TimeShift ×2…×10, Fly Lapse ×4…×12, Freeze Frame ×0,5…×0,1 */
    public static float speedFor(String fx, int k) {
        switch (fx) {
            case "timeshift": return 2f + k * 8f / 9f;
            case "flylapse": return 4f + k * 8f / 9f;
            case "freeze": return 0.5f - k * 0.4f / 9f;
            default: return 1f;
        }
    }

    public static int sliderFor(String fx, float s) {
        switch (fx) {
            case "timeshift": return Math.round((s - 2f) * 9f / 8f);
            case "flylapse": return Math.round((s - 4f) * 9f / 8f);
            case "freeze": return Math.round((0.5f - s) * 9f / 0.4f);
            default: return 4;
        }
    }

    private static double ease(double t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }

    /** base = {yaw, pitch, fov, planet}; t = secunde de la începutul bucății; dur = cât durează efectul */
    public static float[] at(String fx, float dur, double t, float[] base) {
        float yaw = base[0], pitch = base[1], fov = base[2];
        float mix = base[3] > 0 ? 1f : 0f;
        float roll = 0f;
        dur = Math.max(0.5f, dur);
        switch (fx == null ? "none" : fx) {
            case "barrel": {
                // după o mică pauză, imaginea se rostogolește o dată, complet
                double k = ease((t - 0.3) / dur);
                roll = (float) (360.0 * k);
                break;
            }
            case "planetfade": {
                double k = ease((t - 0.2) / dur);
                mix = (float) (1 - k) * 1f + (float) k * mix;
                pitch = (float) (-90 * (1 - k) + pitch * k);
                fov = (float) (160 * (1 - k) + fov * k);
                break;
            }
            case "rollplanet": {
                mix = 1f;
                pitch = -90f;
                fov = 160f;
                yaw = (float) (yaw + 360.0 * (t / (dur * 2)));
                break;
            }
            case "flylapse": {
                // cadrul alunecă lin, ca o dronă (2° pe secundă de filmare)
                yaw = (float) (yaw + 2.0 * t);
                pitch = (float) (pitch - 6 * Math.sin(t * 0.15));
                break;
            }
            case "freeze": {
                // zoom încet spre moment
                fov = (float) Math.max(40, fov - 6 * t);
                break;
            }
            default:
                return null;
        }
        return new float[]{yaw, pitch, roll, fov, mix};
    }

    /** tangenta jumătății de cadru: perspectivă = tan(fov/2), planetă = tan(fov/4); la amestec, între ele */
    public static float tanFor(float fov, float mix) {
        double a = Math.tan(Math.toRadians(fov / 2.0)), b = Math.tan(Math.toRadians(fov / 4.0));
        return (float) (a * (1 - mix) + b * mix);
    }
}
