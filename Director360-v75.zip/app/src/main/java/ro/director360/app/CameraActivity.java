package ro.director360.app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PatternMatcher;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Camera Insta360 prin Wi-Fi: conectare, baterie, fișierele de pe card, descărcare, poză și filmare de la distanță. */
public class CameraActivity extends AppCompatActivity {
    private float dd;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ExecutorService dl = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;
    private Osc osc;
    private boolean recording, video;

    private LinearLayout top;
    private TextView status, info, statusLine, batText, spaceText, countText;
    private View camDot, connected;
    private Bar bat, space;
    private CamPic camPic;
    private LinearLayout tabRow;
    private View tabBox;
    private String camFilter = "all";
    private LinearLayout headRow, headCol, headDotRow;
    private View connectBtn, remote;
    private TextView modePhoto, modeVideo, listTitle, shootHint;
    private Shutter shootBtn;
    private String model = "Insta360";
    private final List<Osc.Entry> files = new ArrayList<>();
    private final List<Object> rows = new ArrayList<>();
    private final Map<String, Osc.Entry> byName = new HashMap<>();
    private final Map<String, Integer> progress = new HashMap<>();
    private final Map<String, android.graphics.Bitmap> thumbs = new HashMap<>();
    private volatile String cancelName;
    private RecyclerView rv;
    private Ad ad;

    private int dp(float v) { return Math.round(v * dd); }

    @Override
    protected void onCreate(Bundle b) {
        Th.apply(this);
        super.onCreate(b);
        dd = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("main", MODE_PRIVATE);
        cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF111214);
        root.setPadding(dp(16), dp(12), dp(16), 0);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = new ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setBackground(round(0xFF1A1C1F, 22));
        back.setContentDescription("Înapoi");
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView t = text("Camera", 24, 0xFFF2F2F0, true);
        t.setPadding(dp(14), 0, 0, 0);
        head.addView(t);
        root.addView(head);

        // ---- cardul cu starea camerei
        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(16), dp(16), dp(16), dp(16));
        top.setBackground(round(0xFF1C1E22, 22));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(14);
        root.addView(top, tp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        camPic = new CamPic(this);
        camPic.setContentDescription("Vezi ce filmează camera");
        camPic.setOnClickListener(v -> { if (osc != null) openLive(); else connect(); });
        row.addView(camPic, new LinearLayout.LayoutParams(dp(36), dp(90)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, 0, 0);
        info = text("Insta360", 20, 0xFFF2F2F0, true);
        col.addView(info);
        LinearLayout sl = new LinearLayout(this);
        sl.setGravity(Gravity.CENTER_VERTICAL);
        camDot = new View(this);
        GradientDrawable dg = new GradientDrawable();
        dg.setShape(GradientDrawable.OVAL);
        dg.setColor(0xFF6B7078);
        camDot.setBackground(dg);
        sl.addView(camDot, new LinearLayout.LayoutParams(dp(9), dp(9)));
        statusLine = text("Neconectată", 13.5f, 0xFF9AA0A6, false);
        statusLine.setPadding(dp(7), 0, 0, 0);
        sl.addView(statusLine);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(3);
        col.addView(sl, slp);
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headRow = row; headCol = col; headDotRow = sl;
        top.addView(row);

        // conectată: baterie, card, număr fișiere
        LinearLayout cn = new LinearLayout(this);
        cn.setOrientation(LinearLayout.VERTICAL);
        cn.setVisibility(View.GONE);
        LinearLayout br = new LinearLayout(this);
        br.setGravity(Gravity.CENTER_VERTICAL);
        bat = new Bar(this, true);
        br.addView(bat, new LinearLayout.LayoutParams(dp(34), dp(17)));
        batText = text("", 15, 0xFFF2F2F0, true);
        batText.setPadding(dp(8), 0, dp(16), 0);
        br.addView(batText);
        spaceText = text("", 13, 0xFF9AA0A6, false);
        br.addView(spaceText);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brp.topMargin = dp(14);
        cn.addView(br, brp);
        space = new Bar(this, false);
        LinearLayout.LayoutParams spp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        spp.topMargin = dp(10);
        cn.addView(space, spp);
        countText = text("", 13, 0xFF9AA0A6, false);
        countText.setPadding(0, dp(8), 0, 0);
        cn.addView(countText);
        connected = cn;
        top.addView(cn);

        // neconectată: instrucțiuni, parolă, buton
        status = text("Pornește camera și Wi-Fi-ul ei (pe cameră: trage de sus în jos → Wi-Fi). Apoi apasă „Caută camera”.", 14, 0xFFB9BCBF, false);
        status.setPadding(0, dp(12), 0, 0);
        top.addView(status);
        TextView cb0 = button("🔍  Caută camera", true);
        cb0.setOnClickListener(v -> connect());
        connectBtn = cb0;
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        bp.topMargin = dp(10);
        top.addView(cb0, bp);
        bigHead(true);

        // ---- telecomanda: Poză / Filmare + declanșator rotund
        LinearLayout rm = new LinearLayout(this);
        rm.setGravity(Gravity.CENTER_VERTICAL);
        rm.setPadding(dp(16), dp(14), dp(16), dp(14));
        rm.setBackground(round(0xFF1C1E22, 22));
        rm.setVisibility(View.GONE);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout seg = new LinearLayout(this);
        seg.setBackground(round(0xFF141518, 20));
        seg.setPadding(dp(3), dp(3), dp(3), dp(3));
        modePhoto = chip("Poză");
        modeVideo = chip("Filmare");
        modePhoto.setOnClickListener(v -> { if (!recording) { video = false; paintModes(); } });
        modeVideo.setOnClickListener(v -> { if (!recording) { video = true; paintModes(); } });
        seg.addView(modePhoto, new LinearLayout.LayoutParams(dp(84), dp(36)));
        seg.addView(modeVideo, new LinearLayout.LayoutParams(dp(84), dp(36)));
        left.addView(seg, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        shootHint = text("", 13, 0xFF9AA0A6, false);
        shootHint.setPadding(dp(2), dp(10), 0, 0);
        left.addView(shootHint);
        rm.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        shootBtn = new Shutter(this);
        shootBtn.setContentDescription("Declanșează");
        shootBtn.setOnClickListener(v -> shoot());
        rm.addView(shootBtn, new LinearLayout.LayoutParams(dp(84), dp(84)));
        remote = rm;
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = dp(12);
        root.addView(rm, rp);

        listTitle = text("", 12.5f, 0xFF9AA0A6, true);
        listTitle.setLetterSpacing(0.08f);
        listTitle.setPadding(dp(4), dp(16), 0, dp(4));
        root.addView(listTitle);

        // Toate / Filmări / Poze, ca pe ecranul camerei
        android.widget.HorizontalScrollView tsv = new android.widget.HorizontalScrollView(this);
        tsv.setHorizontalScrollBarEnabled(false);
        tabRow = new LinearLayout(this);
        tabRow.setPadding(dp(2), dp(4), 0, dp(4));
        tsv.addView(tabRow);
        root.addView(tsv);
        tsv.setVisibility(View.GONE);
        tabBox = tsv;

        rv = new RecyclerView(this);
        androidx.recyclerview.widget.GridLayoutManager gm = new androidx.recyclerview.widget.GridLayoutManager(this, 2);
        gm.setSpanSizeLookup(new androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
            @Override public int getSpanSize(int p) { return rows.get(p) instanceof String ? 2 : 1; }
        });
        rv.setLayoutManager(gm);
        ad = new Ad();
        rv.setAdapter(ad);
        root.addView(rv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
        I18n.watch(this);
        paintModes();
    }

    // ---------------- conectarea ----------------
    private void connect() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.NEARBY_WIFI_DEVICES}, 7);
            return;
        }
        if (Build.VERSION.SDK_INT < 33 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 7);
            return;
        }
        status.setText("Caut camera…");
        connectBtn.setEnabled(false);
        io.execute(() -> {
            // 1) poate telefonul e deja conectat la Wi-Fi-ul camerei
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities c = cm.getNetworkCapabilities(n);
                if (c == null || !c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) continue;
                Osc o = new Osc(n);
                String m = o.model();
                if (m != null) { main.post(() -> onConnected(o, m)); return; }
            }
            // 2) caut Wi-Fi-ul camerei în jur (numele se termină cu .OSC)
            String ssid = findCamSsid();
            main.post(() -> {
                String saved = prefs.getString("camPass", null);
                if (saved != null && saved.length() >= 8) requestWifi(saved);
                else askPass(ssid, false);
            });
        });
    }

    /** numele Wi-Fi al camerei din lista de rețele din jur, sau null */
    private String findCamSsid() {
        try {
            android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wm == null) return null;
            try { wm.startScan(); } catch (Exception ignored) { }
            for (int k = 0; k < 4; k++) {
                for (android.net.wifi.ScanResult r : wm.getScanResults()) {
                    String n = r.SSID;
                    if (n != null && (n.toUpperCase().endsWith(".OSC") || n.toUpperCase().startsWith("X5 "))) return n;
                }
                Thread.sleep(800);
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** fereastra cu parola Wi-Fi a camerei */
    private void askPass(String ssid, boolean wrong) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(18), dp(22), dp(4));
        TextView t1 = text(ssid != null ? "Am găsit camera" : "Parola camerei", 19, 0xFFF2F2F0, true);
        box.addView(t1);
        if (ssid != null) { TextView t2 = text(ssid, 14, Th.A, false); t2.setPadding(0, dp(4), 0, 0); box.addView(t2); }
        if (wrong) { TextView tw = text("Nu m-am putut conecta. Poate parola e greșită.", 13, 0xFFFF6B6B, false); tw.setPadding(0, dp(8), 0, 0); box.addView(tw); }
        TextView lb = text("Parola Wi-Fi a camerei", 12.5f, 0xFF9AA0A6, false);
        lb.setPadding(0, dp(14), 0, dp(6));
        box.addView(lb);
        EditText pw = new EditText(this);
        pw.setSingleLine(true);
        pw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pw.setTextColor(0xFFF2F2F0);
        pw.setHintTextColor(0xFF6B7078);
        pw.setHint("cel puțin 8 caractere");
        pw.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable fb = new GradientDrawable();
        fb.setColor(0xFF141518); fb.setCornerRadius(dp(10)); fb.setStroke(dp(1.5f), Th.A);
        pw.setBackground(fb);
        LinearLayout pr = new LinearLayout(this);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.addView(pw, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView show = text("arată", 13, 0xFF9AA0A6, true);
        show.setPadding(dp(12), dp(10), dp(4), dp(10));
        show.setOnClickListener(v -> {
            boolean hid = (pw.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) == InputType.TYPE_TEXT_VARIATION_PASSWORD;
            pw.setInputType(InputType.TYPE_CLASS_TEXT | (hid ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            pw.setSelection(pw.getText().length());
            show.setText(hid ? "ascunde" : "arată");
        });
        pr.addView(show);
        box.addView(pr);
        TextView hint = text("O vezi pe cameră: trage de sus în jos → Wi-Fi.\nO țin minte, nu ți-o mai cer data viitoare.", 12, 0xFF9AA0A6, false);
        hint.setPadding(0, dp(10), 0, 0);
        box.addView(hint);
        androidx.appcompat.app.AlertDialog d = new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setView(box)
                .setNegativeButton("Renunță", (x, y) -> { status.setText("Apasă „Caută camera” când ești gata."); connectBtn.setEnabled(true); })
                .setPositiveButton("Conectează", null)
                .setOnCancelListener(x -> connectBtn.setEnabled(true))
                .create();
        d.setOnShowListener(x -> d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String p = pw.getText().toString().trim();
            if (p.length() < 8) { pw.setError("Parola are cel puțin 8 caractere"); return; }
            prefs.edit().putString("camPass", p).apply();
            d.dismiss();
            requestWifi(p);
        }));
        d.show();
        pw.requestFocus();
        if (d.getWindow() != null) d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
    }

    /** neconectată: camera mare, centrată; conectată: mică, în stânga */
    private void bigHead(boolean big) {
        headRow.setOrientation(big ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        headRow.setGravity(big ? Gravity.CENTER_HORIZONTAL : Gravity.CENTER_VERTICAL);
        camPic.setLayoutParams(big ? new LinearLayout.LayoutParams(dp(80), dp(200)) : new LinearLayout.LayoutParams(dp(36), dp(90)));
        headCol.setLayoutParams(big ? new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                : new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headCol.setGravity(big ? Gravity.CENTER_HORIZONTAL : Gravity.START);
        headCol.setPadding(big ? 0 : dp(14), big ? dp(10) : 0, 0, 0);
        headDotRow.setGravity(big ? Gravity.CENTER : Gravity.CENTER_VERTICAL);
        status.setGravity(big ? Gravity.CENTER_HORIZONTAL : Gravity.START);
    }

    @Override
    public void onRequestPermissionsResult(int rc, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (rc == 7) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) connect();
            else status.setText("Fără permisiunea pentru dispozitive din apropiere nu pot găsi camera. O poți porni din Setări → Aplicații → Director360 → Permisiuni.");
        }
    }

    private void requestWifi(String pw) {
        status.setText("Alege camera în fereastra care apare (numele începe cu „X5” sau se termină cu „.OSC”).");
        WifiNetworkSpecifier spec = new WifiNetworkSpecifier.Builder()
                .setSsidPattern(new PatternMatcher(".*OSC", PatternMatcher.PATTERN_SIMPLE_GLOB))
                .setWpa2Passphrase(pw)
                .build();
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build();
        if (cb != null) try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        cb = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(@NonNull Network n) {
                io.execute(() -> {
                    Osc o = new Osc(n);
                    String m = null;
                    for (int i = 0; i < 6 && m == null; i++) { m = o.model(); if (m == null) try { Thread.sleep(700); } catch (InterruptedException ignored) { } }
                    final String mm = m;
                    main.post(() -> {
                        if (mm != null) onConnected(o, mm);
                        else { status.setText("M-am conectat la Wi-Fi, dar camera nu răspunde. Repornește Wi-Fi-ul pe cameră și încearcă din nou."); connectBtn.setEnabled(true); }
                    });
                });
            }
            @Override public void onUnavailable() {
                main.post(() -> {
                    status.setText("Nu am găsit camera. Verifică: camera pornită și Wi-Fi pornit pe cameră. Apoi încearcă din nou.");
                    connectBtn.setEnabled(true);
                    if (!isFinishing()) askPass(null, true);
                });
            }
            @Override public void onLost(@NonNull Network n) {
                main.post(() -> { osc = null; showDisconnected("Conexiunea cu camera s-a pierdut. Apasă din nou „Caută camera”."); });
            }
        };
        try { cm.requestNetwork(req, cb); }
        catch (Exception e) { status.setText("Telefonul nu a putut porni conectarea: " + e.getMessage()); connectBtn.setEnabled(true); }
    }

    private void showDisconnected(String msg) {
        status.setText(msg);
        status.setVisibility(View.VISIBLE);
        bigHead(true);
        connectBtn.setVisibility(View.VISIBLE);
        connectBtn.setEnabled(true);
        connected.setVisibility(View.GONE);
        remote.setVisibility(View.GONE);
        statusLine.setText("Neconectată");
        ((GradientDrawable) camDot.getBackground()).setColor(0xFF6B7078);
    }

    private void onConnected(Osc o, String m) {
        osc = o;
        // tot ce face aplicația merge acum prin Wi-Fi-ul camerei: poți reda și edita filmările direct de pe cameră
        if (o.net != null) try { cm.bindProcessToNetwork(o.net); } catch (Exception ignored) { }
        model = m;
        status.setVisibility(View.GONE);
        bigHead(false);
        connectBtn.setVisibility(View.GONE);
        connected.setVisibility(View.VISIBLE);
        remote.setVisibility(View.VISIBLE);
        info.setText(m);
        statusLine.setText("Conectată prin Wi-Fi");
        ((GradientDrawable) camDot.getBackground()).setColor(0xFF2ECC71);
        refreshInfo();
        loadFiles();
    }

    private void refreshInfo() {
        Osc o = osc;
        if (o == null) return;
        io.execute(() -> {
            int b = o.battery();
            long[] sp = o.space();
            main.post(() -> {
                bat.set(b < 0 ? 0 : b / 100f, b >= 0 && b < 20 ? 0xFFFF4D5E : 0xFF2ECC71);
                batText.setText(b >= 0 ? b + "%" : "—");
                if (sp != null && sp[1] > 0) {
                    spaceText.setText("Card: " + gb(sp[0]) + " liberi din " + gb(sp[1]));
                    space.set(1f - sp[0] / (float) sp[1], Th.A);
                    space.setVisibility(View.VISIBLE);
                } else if (sp != null) {
                    spaceText.setText("Card: " + gb(sp[0]) + " liberi");
                    space.setVisibility(View.GONE);
                } else { spaceText.setText(""); space.setVisibility(View.GONE); }
            });
        });
    }

    private void buildTabs(int nv, int np) {
        tabRow.removeAllViews();
        tabBox.setVisibility(files.isEmpty() ? View.GONE : View.VISIBLE);
        String[][] t = {{"all", "Toate " + (nv + np)}, {"video", "Filmări " + nv}, {"photo", "Poze " + np}};
        for (String[] x : t) {
            TextView c = text(x[1], 14, 0xFFF2F2F0, true);
            c.setPadding(dp(16), dp(8), dp(16), dp(8));
            boolean on = x[0].equals(camFilter);
            c.setBackground(round(on ? Th.A : 0xFF202227, 18));
            c.setTextColor(on ? 0xFFFFFFFF : 0xFFB9BCBF);
            c.setOnClickListener(v -> { camFilter = x[0]; buildTabs(nv, np); buildRows(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(dp(8));
            tabRow.addView(c, lp);
        }
    }

    /** rândurile listei: zi (cu număr și mărime, ca la card) + fișierele ei */
    private void buildRows() {
        rows.clear();
        String last = null;
        int hdr = -1, n = 0; long sz = 0;
        for (Osc.Entry e : files) {
            if (camFilter.equals("video") && e.isPhoto()) continue;
            if (camFilter.equals("photo") && !e.isPhoto()) continue;
            String d = day(e.name);
            if (!d.equals(last)) {
                if (hdr >= 0) rows.set(hdr, last + "\n" + n + " · " + gb(sz));
                rows.add(d); hdr = rows.size() - 1; last = d; n = 0; sz = 0;
            }
            rows.add(e); n++; sz += Math.max(0, e.size);
        }
        if (hdr >= 0) rows.set(hdr, last + "\n" + n + " · " + gb(sz));
        ad.notifyDataSetChanged();
    }

    private void loadFiles() {
        Osc o = osc;
        if (o == null) return;
        listTitle.setText("CITESC CARDUL DIN CAMERĂ…");
        io.execute(() -> {
            try {
                List<Osc.Entry> l = o.list();
                main.post(() -> {
                    files.clear();
                    byName.clear();
                    for (Osc.Entry e : l) byName.put(e.name, e);
                    // la fel ca la citirea cardului: doar .insv / .mp4 / .insp / .jpg, o singură lentilă, fără fișierele mici (LRV) și RAW (.dng)
                    for (Osc.Entry e : l) {
                        String low = e.name.toLowerCase();
                        if (e.isLrv() || e.name.contains("_10_")) continue;
                        if (low.endsWith(".insv") || low.endsWith(".mp4") || low.endsWith(".insp") || low.endsWith(".jpg")) files.add(e);
                    }
                    int nv = 0, np = 0;
                    for (Osc.Entry e : files) if (e.isPhoto()) np++; else nv++;
                    countText.setText(nv + " filmări · " + np + " poze pe card");
                    listTitle.setText(files.isEmpty() ? "CARDUL DIN CAMERĂ E GOL" : "PE CAMERĂ");
                    buildTabs(nv, np);
                    buildRows();
                    ad.notifyDataSetChanged();
                    loadThumbs(o, l.size());
                });
            } catch (Exception e) {
                main.post(() -> listTitle.setText("NU AM PUTUT CITI LISTA: " + e.getMessage()));
            }
        });
    }

    /** pozele mici, câte 10 pe rând, în fundal */
    private void loadThumbs(Osc o, int total) {
        io.execute(() -> {
            for (int s = 0; s < total && osc == o && !isDestroyed(); s += 10) {
                Map<String, byte[]> m = o.thumbs(s, 10, 320);
                if (m.isEmpty() && s == 0) { main.post(() -> { cameraThumbsOk = false; ad.notifyDataSetChanged(); }); return; } // camera nu trimite poze mici: le cerem pe rând, pentru ce se vede
                Map<String, android.graphics.Bitmap> bm = new HashMap<>();
                for (Map.Entry<String, byte[]> e : m.entrySet()) {
                    android.graphics.Bitmap x = android.graphics.BitmapFactory.decodeByteArray(e.getValue(), 0, e.getValue().length);
                    if (x != null) bm.put(e.getKey(), x);
                }
                main.post(() -> { thumbs.putAll(bm); ad.notifyDataSetChanged(); });
            }
        });
    }

    // ---- poze mici, cerute pe rând pentru ce se vede pe ecran (cele văzute ultimele primele) ----
    private final java.util.concurrent.LinkedBlockingDeque<Osc.Entry> thumbQ = new java.util.concurrent.LinkedBlockingDeque<>();
    private final java.util.Set<String> thumbAsked = java.util.Collections.synchronizedSet(new java.util.HashSet<>());
    private ExecutorService thumbPool;
    private boolean cameraThumbsOk = true;

    private void askThumb(Osc.Entry e) {
        if (thumbs.containsKey(e.name) || !thumbAsked.add(e.name)) return;
        thumbQ.addFirst(e);
        if (thumbPool == null) {
            thumbPool = Executors.newFixedThreadPool(3);
            for (int i = 0; i < 3; i++) thumbPool.execute(this::thumbWorker);
        }
    }

    private void thumbWorker() {
        while (!isDestroyed()) {
            Osc.Entry e;
            try { e = thumbQ.pollFirst(2, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException x) { return; }
            if (e == null || osc == null) continue;
            android.graphics.Bitmap t = null;
            try { t = e.isPhoto() ? photoThumb(e) : videoThumb(e); } catch (Throwable ignored) { }
            if (t == null) { thumbAsked.remove(e.name); continue; }
            android.graphics.Bitmap ft = t;
            main.post(() -> { thumbs.put(e.name, ft); ad.notifyDataSetChanged(); });
        }
    }

    /** un cadru din filmarea mică (LRV) */
    private android.graphics.Bitmap videoThumb(Osc.Entry e) throws Exception {
        Osc.Entry lv = lrvFor(e);
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try {
            r.setDataSource(lv != null ? lv.url : e.url, new HashMap<>());
            android.graphics.Bitmap f = r.getScaledFrameAtTime(1_000_000, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 640, 320);
            if (f == null) return null;
            return e.name.toLowerCase().endsWith(".insv") ? Thumbs.reframe(f, 400, 300, 110f) : f;
        } finally { try { r.release(); } catch (Exception ignored) { } }
    }

    /** poza mică ascunsă la începutul fișierului de poză (EXIF) — citim doar primii ~256 KB */
    private android.graphics.Bitmap photoThumb(Osc.Entry e) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(e.url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Range", "bytes=0-262143");
        byte[] head;
        try (java.io.InputStream in = c.getInputStream()) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while (bo.size() < 262144 && (n = in.read(buf)) > 0) bo.write(buf, 0, n);
            head = bo.toByteArray();
        } finally { c.disconnect(); }
        androidx.exifinterface.media.ExifInterface ex = new androidx.exifinterface.media.ExifInterface(new java.io.ByteArrayInputStream(head));
        android.graphics.Bitmap b = ex.getThumbnailBitmap();
        if (b == null) return null;
        String low = e.name.toLowerCase();
        // poza 360 are cele două lentile una lângă alta: o întindem ca în celelalte cartonașe
        return low.endsWith(".insp") && b.getWidth() >= b.getHeight() * 1.6f ? Thumbs.reframe(b, 400, 300, 110f) : b;
    }

    private static final String[] ZILE = {"Duminică", "Luni", "Marți", "Miercuri", "Joi", "Vineri", "Sâmbătă"};
    private static final String[] LUNI = {"ianuarie", "februarie", "martie", "aprilie", "mai", "iunie", "iulie", "august", "septembrie", "octombrie", "noiembrie", "decembrie"};

    /** VID_20251023_220400_... → „Joi, 23 octombrie 2025” */
    static String day(String name) {
        try {
            for (String p : name.split("_")) {
                if (p.length() == 8 && p.matches("\\d{8}")) {
                    int y = Integer.parseInt(p.substring(0, 4)), mo = Integer.parseInt(p.substring(4, 6)), d = Integer.parseInt(p.substring(6, 8));
                    java.util.Calendar c = java.util.Calendar.getInstance();
                    c.set(y, mo - 1, d);
                    return ZILE[c.get(java.util.Calendar.DAY_OF_WEEK) - 1] + ", " + d + " " + LUNI[mo - 1] + " " + y;
                }
            }
        } catch (Exception ignored) { }
        return "Alte fișiere";
    }

    static String hour(String name) {
        String p = MainActivity.pretty(name);
        int i = p.indexOf(" · ");
        return i > 0 ? p.substring(i + 3) : p;
    }

    // ---------------- telecomanda ----------------
    private void paintModes() {
        style(modePhoto, !video);
        style(modeVideo, video);
        shootBtn.setMode(video, recording);
        shootHint.setText(video ? (recording ? "Filmează… atinge cercul ca să oprești." : "Atinge cercul ca să pornești filmarea.") : "Atinge cercul ca să faci poza.");
    }

    private void shoot() {
        Osc o = osc;
        if (o == null) return;
        shootBtn.setEnabled(false);
        io.execute(() -> {
            String err = null;
            try {
                boolean keep = insta != null && insta.connected();
                // Interval și Starlapse pornesc și se opresc ca o filmare
                boolean longPhoto = !video && ("Interval".equals(liveMode) || "Starlapse".equals(liveMode));
                if (!video && !longPhoto) { if (keep) o.takePictureKeep(); else o.takePicture(); }
                else if (!recording) { if (keep) o.startCaptureKeep(); else o.startVideo(); recording = true; }
                else { o.stopVideo(); recording = false; }
            } catch (Exception e) { err = e.getMessage(); }
            final String er = err;
            main.post(() -> {
                shootBtn.setEnabled(true);
                paintModes();
                if (er != null) Toast.makeText(this, "Camera a refuzat: " + er, Toast.LENGTH_LONG).show();
                else if (!video) Toast.makeText(this, "Poza e făcută.", Toast.LENGTH_SHORT).show();
                if (er == null && !(video && recording)) { loadFiles(); refreshInfo(); }
            });
        });
    }

    // ---------------- imaginea live + modurile camerei (ca în meniul camerei X5) ----------------
    /** {nume afișat, captureMode cerut camerei (null = doar pe cameră), opțiune extra} */
    // modurile, în ordinea de pe cameră: {nume, captureMode OSC (de rezervă), număr Insta360}
    private static final String[][] PHOTO_MODES = {{"Photo", "image", "0"}, {"Interval", "interval", "2"}, {"Burst", "_burst", "3"}, {"Starlapse", "_starlapse", "7"}};
    private static final String[][] VIDEO_MODES = {{"Video", "video", "0"}, {"PureVideo", "_purevideo", "11"}, {"InstaFrame", "_instaframe", "15"}, {"Timelapse", "_timelapse", "2"}, {"TimeShift", "_timeshift", "4"}, {"Bullet Time", "_bullettime", "1"}, {"Loop Recording", "_looprecording", "6"}, {"Road Mode", "_roadmode", "14"}};
    private volatile boolean liveOn;
    private String liveMode = "Poză";

    private void openLive() {
        Osc o = osc;
        if (o == null) return;
        android.app.Dialog dlg = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(img, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        TextView msg = text("Pornesc imaginea de la cameră…", 15, 0xFFF2F2F0, false);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(dp(30), 0, dp(30), 0);
        root.addView(msg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        // sus: înapoi
        TextView back = text("‹", 30, 0xFFFFFFFF, true);
        back.setGravity(Gravity.CENTER);
        back.setBackground(round(0xB3000000, 22));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.START);
        bl.setMargins(dp(14), dp(30), 0, 0);
        root.addView(back, bl);
        back.setOnClickListener(v -> dlg.dismiss());
        // jos: Poză / Filmare, modurile și declanșatorul
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setBackgroundColor(0xCC0C0D0F);
        bottom.setPadding(dp(12), dp(10), dp(12), dp(18));
        LinearLayout kinds = new LinearLayout(this);
        TextView kp = text("POZĂ", 15, 0xFF9AA0A6, true), kv = text("FILMARE", 15, 0xFF9AA0A6, true);
        kp.setPadding(dp(6), dp(4), dp(18), dp(4));
        kv.setPadding(dp(6), dp(4), dp(18), dp(4));
        kinds.addView(kp); kinds.addView(kv);
        kinds.setGravity(Gravity.CENTER_VERTICAL);
        View grow = new View(this);
        kinds.addView(grow, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView autoB = text("✨ Auto AI", 13, 0xFFFFFFFF, true);
        autoB.setPadding(dp(12), dp(6), dp(12), dp(6));
        autoB.setBackground(round(0xFF24262C, 16));
        kinds.addView(autoB);
        bottom.addView(kinds);
        TextView autoInfo = text("", 12, Th.A, true);
        autoInfo.setVisibility(View.GONE);
        autoInfo.setPadding(dp(6), dp(4), 0, 0);
        bottom.addView(autoInfo);
        // setare separată: ajustare și în timpul filmării (oprește scurt și reia)
        android.widget.CheckBox during = new android.widget.CheckBox(this);
        during.setText("Ajustează și în timpul filmării (pauză scurtă de 1–2 s, apoi filmarea continuă într-un fișier nou)");
        during.setTextColor(0xFFB9BCBF);
        during.setTextSize(12);
        during.setChecked(prefs.getBoolean("autoDuring", false));
        during.setVisibility(View.GONE);
        during.setOnCheckedChangeListener((cb, on) -> { autoDuring = on; prefs.edit().putBoolean("autoDuring", on).apply(); });
        autoDuring = during.isChecked();
        bottom.addView(during);
        autoB.setOnClickListener(v -> {
            autoOn = !autoOn;
            during.setVisibility(autoOn ? View.VISIBLE : View.GONE);
            autoB.setBackground(round(autoOn ? Th.A : 0xFF24262C, 16));
            autoInfo.setVisibility(autoOn ? View.VISIBLE : View.GONE);
            autoInfo.setText(autoOn ? "Auto AI: mă uit la imagine…" : "");
            if (autoOn) startAuto(autoInfo, () -> paintModes2());
        });
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout modes = new LinearLayout(this);
        modes.setPadding(0, dp(8), 0, dp(10));
        hs.addView(modes);
        bottom.addView(hs);
        // rezoluția pozei (doar la Poză): 72MP / 18MP
        LinearLayout resRow = new LinearLayout(this);
        resRow.setGravity(Gravity.CENTER_VERTICAL);
        resRow.setPadding(0, 0, 0, dp(10));
        bottom.addView(resRow);
        Shutter sh = new Shutter(this);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(dp(76), dp(76));
        sl.gravity = Gravity.CENTER_HORIZONTAL;
        bottom.addView(sh, sl);
        root.addView(bottom, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        java.util.Set<String> supported = new java.util.HashSet<>();
        Runnable[] paint = new Runnable[1];
        paint[0] = () -> {
            kp.setTextColor(!video ? Th.A : 0xFF9AA0A6);
            kv.setTextColor(video ? Th.A : 0xFF9AA0A6);
            sh.setMode(video, recording);
            resRow.removeAllViews();
            InstaLive ilr = insta;
            if (!video && ilr != null && ilr.connected()) {
                TextView rl = text("Rezoluție", 13, 0xFF9AA0A6, false);
                rl.setPadding(0, 0, dp(10), 0);
                resRow.addView(rl);
                int[][] rs = {{11, 72}, {12, 18}};
                for (int[] r : rs) {
                    boolean on = ilr.photoSize == r[0];
                    TextView c = text(r[1] + "MP", 13, on ? 0xFF141414 : 0xFFE6E6E6, true);
                    c.setPadding(dp(12), dp(6), dp(12), dp(6));
                    c.setBackground(round(on ? 0xFFFFFFFF : 0xFF24262C, 16));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMarginEnd(dp(8));
                    resRow.addView(c, lp);
                    c.setOnClickListener(v -> { ilr.setPhotoSize(r[0]); ilr.photoSize = r[0]; paint[0].run(); });
                }
            }
            if (video && ilr != null && ilr.connected()) {
                // rezoluțiile și cadrele exact ca pe camera X5 (numerele camerei: sigure la 8K și 5.7K+, deduse la 5.7K și 4K)
                String[] resN = {"8K", "5.7K+", "5.7K", "4K"};
                int[][] fps = {{30, 25, 24}, {30, 25, 24}, {60, 50, 48, 30, 25, 24}, {24, 25, 30, 48, 50, 60, 100, 120}};
                int[][] val = {{167, 166, 165}, {317, 318, 319}, {338, 348, 0, 250, 251, 252}, {12, 11, 10, 19, 20, 97, 98, 208}};
                int curR = -1, curF = -1;
                for (int x = 0; x < val.length; x++) for (int y = 0; y < val[x].length; y++) if (val[x][y] == ilr.videoRes) { curR = x; curF = y; }
                final int cr = curR < 0 ? 0 : curR, cf = curF;
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                LinearLayout r1 = new LinearLayout(this), r2 = new LinearLayout(this);
                r2.setPadding(0, dp(6), 0, 0);
                col.addView(r1);
                android.widget.HorizontalScrollView hs2 = new android.widget.HorizontalScrollView(this);
                hs2.setHorizontalScrollBarEnabled(false);
                hs2.addView(r2);
                col.addView(hs2);
                resRow.addView(col);
                for (int x = 0; x < resN.length; x++) {
                    final int fx = x;
                    boolean on = x == curR;
                    TextView c = text(resN[x], 13, on ? 0xFF141414 : 0xFFE6E6E6, true);
                    c.setPadding(dp(12), dp(6), dp(12), dp(6));
                    c.setBackground(round(on ? 0xFFFFFFFF : 0xFF24262C, 16));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMarginEnd(dp(6));
                    r1.addView(c, lp);
                    c.setOnClickListener(v -> {
                        // păstrăm cadrele dacă există la noua rezoluție, altfel 30
                        int want = cf >= 0 && cr < fps.length ? fps[cr][cf] : 30, idx = -1;
                        for (int y = 0; y < fps[fx].length; y++) if (fps[fx][y] == want) idx = y;
                        if (idx < 0) for (int y = 0; y < fps[fx].length; y++) if (fps[fx][y] == 30) idx = y;
                        int nv = val[fx][idx];
                        ilr.setVideoRes(nv); ilr.videoRes = nv; paint[0].run();
                    });
                }
                for (int y = 0; y < fps[cr].length; y++) {
                    final int fy = y;
                    boolean on = curR == cr && y == curF;
                    TextView c = text(String.valueOf(fps[cr][y]), 13, on ? 0xFF141414 : 0xFFE6E6E6, true);
                    c.setPadding(dp(11), dp(6), dp(11), dp(6));
                    c.setBackground(round(on ? 0xFFFFFFFF : 0xFF24262C, 16));
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMarginEnd(dp(6));
                    r2.addView(c, lp);
                    c.setOnClickListener(v -> { int nv = val[cr][fy]; ilr.setVideoRes(nv); ilr.videoRes = nv; paint[0].run(); });
                }
                // explicația, ca pe cameră: la ce e bună alegerea
                String[] resInfo = {
                        "8K: cea mai mare claritate. Poți apropia mult imaginea la editare. Fișiere mari, camera se încălzește; cel mai bun ziua, pentru peisaje.",
                        "5.7K+: aproape la fel de clar ca 8K, cu fișiere mai mici. Bun ziua, pentru orice.",
                        "5.7K: claritate bună și imagine mai curată în lumină slabă (în casă, seara). Merge până la 60 de cadre.",
                        "4K: mai puțin clar la 360, dar merge până la 120 de cadre, pentru încetinitor."};
                int f = curF >= 0 ? fps[cr][curF] : 30;
                String fpsInfo = f == 24 ? "24 de cadre: aspect de film, ca la cinema."
                        : f == 25 ? "25 de cadre: standardul din Europa; nu pâlpâie sub becuri."
                        : f == 30 ? "30 de cadre: mișcare normală, cel mai folosit."
                        : f <= 60 ? f + " de cadre: mișcare mai fluidă (sport, mașină, mers). Poți încetini de 2 ori."
                        : f + " de cadre: pentru încetinitor de " + (f / 25) + " ori.";
                TextView info = text(resInfo[cr] + "\n" + fpsInfo, 12, 0xFF9AA0A6, false);
                info.setPadding(0, dp(6), 0, 0);
                col.addView(info);
            }
            modes.removeAllViews();
            for (String[] m : video ? VIDEO_MODES : PHOTO_MODES) {
                boolean on = m[0].equals(liveMode);
                boolean ok = (insta != null && insta.connected()) || supported.isEmpty() || supported.contains(m[1]);
                TextView c = text(m[0], 14, on ? 0xFF141414 : ok ? 0xFFE6E6E6 : 0xFF6B7078, true);
                c.setPadding(dp(14), dp(7), dp(14), dp(7));
                c.setBackground(round(on ? 0xFFFFFFFF : 0xFF24262C, 18));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMarginEnd(dp(8));
                modes.addView(c, lp);
                c.setOnClickListener(v -> {
                    if (recording) return;
                    if (!ok) { Toast.makeText(this, "Camera nu lasă modul „" + m[0] + "” să fie ales prin Wi-Fi. Alege-l pe ecranul camerei.", Toast.LENGTH_LONG).show(); return; }
                    liveMode = m[0];
                    paint[0].run();
                    InstaLive il = insta;
                    if (il != null && il.connected()) { il.setMode(video, Integer.parseInt(m[2])); return; }
                    io.execute(() -> {
                        String er = null;
                        try {
                            o.setOption("captureMode", m[1]);

                        } catch (Exception e) { er = e.getMessage(); }
                        String fe = er;
                        if (fe != null) main.post(() -> Toast.makeText(this, "Camera a refuzat modul: " + fe, Toast.LENGTH_LONG).show());
                    });
                });
            }
        };
        kp.setOnClickListener(v -> { if (!recording) { video = false; liveMode = "Photo"; if (insta != null && insta.connected()) insta.setMode(false, 0); paint[0].run(); paintModes(); io.execute(() -> { try { o.setMode(false); } catch (Exception ignored) { } }); } });
        kv.setOnClickListener(v -> { if (!recording) { video = true; liveMode = "Video"; if (insta != null && insta.connected()) insta.setMode(true, 0); paint[0].run(); paintModes(); io.execute(() -> { try { o.setMode(true); } catch (Exception ignored) { } }); } });
        sh.setOnClickListener(v -> { shoot(); sh.postDelayed(paint[0], 1500); });
        liveMode = video ? "Video" : "Photo";
        paintRef = paint[0];
        paint[0].run();
        dlg.setContentView(root);
        dlg.setOnDismissListener(d -> { liveOn = false; autoOn = false; });
        dlg.show();
        // după ce pornește legătura Insta360 apar și rezoluțiile
        root.postDelayed(paint[0], 4000);
        root.postDelayed(paint[0], 9000);
        // ce moduri acceptă camera prin Wi-Fi
        io.execute(() -> {
            try {
                org.json.JSONArray a = o.options("captureModeSupport").optJSONArray("captureModeSupport");
                if (a != null) { java.util.Set<String> ss = new java.util.HashSet<>(); for (int i = 0; i < a.length(); i++) ss.add(a.optString(i)); main.post(() -> { supported.addAll(ss); paint[0].run(); }); }
            } catch (Exception ignored) { }
        });
        // imaginea live, pe un fir separat
        liveOn = true;
        new Thread(() -> {
            final long[] lastShow = {0};
            try {
                o.livePreview(jpeg -> {
                    if (!liveOn) return false;
                    long now = System.currentTimeMillis();
                    if (now - lastShow[0] < 80) return true;   // ~12 imagini pe secundă
                    lastShow[0] = now;
                    android.graphics.Bitmap b = android.graphics.BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
                    if (b == null) return true;
                    // dacă vin cele două lentile una lângă alta, arătăm o imagine normală din fața camerei
                    android.graphics.Bitmap show = b.getWidth() >= b.getHeight() * 1.8f ? Thumbs.reframe(b, 720, 960, 100f) : b;
                    main.post(() -> { msg.setVisibility(View.GONE); img.setImageBitmap(show); });
                    return true;
                });
                if (liveOn) main.post(() -> { msg.setVisibility(View.VISIBLE); msg.setText("Camera a oprit imaginea live."); });
            } catch (Exception e) {
                // legătura standard nu are imagine live: încercăm legătura proprie Insta360
                main.post(() -> startInstaLive(o, root, msg, dlg));
            }
        }).start();
    }

    private InstaLive insta;
    private Video360View liveView;
    private volatile boolean autoOn, autoDuring;
    private Runnable paintRef;

    private void paintModes2() { if (paintRef != null) paintRef.run(); }

    // ---------------- Auto AI: citește imaginea și setează singur camera ----------------
    private int[] prevSmall;
    private String autoLast = "", autoPending = "";
    private int autoStable = 0;
    private final com.google.mlkit.vision.label.ImageLabeler labeler =
            com.google.mlkit.vision.label.ImageLabeling.getClient(com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS);

    private void startAuto(TextView info, Runnable repaint) {
        Runnable[] tick = new Runnable[1];
        tick[0] = () -> {
            if (!autoOn || !liveOn) return;
            Video360View v3 = liveView;
            InstaLive il = insta;
            if (v3 == null || il == null || !il.connected()) { info.setText("Auto AI: aștept imaginea de la cameră…"); main.postDelayed(tick[0], 2000); return; }
            v3.capture(192, 108, bmp -> {
                if (bmp == null) { main.postDelayed(tick[0], 2000); return; }
                // lumina și mișcarea
                int w = bmp.getWidth(), h = bmp.getHeight();
                int[] px = new int[w * h];
                bmp.getPixels(px, 0, w, 0, 0, w, h);
                long sum = 0, diff = 0;
                int[] small = new int[px.length];
                for (int i = 0; i < px.length; i++) {
                    int c = px[i], l = (((c >> 16) & 255) * 3 + ((c >> 8) & 255) * 6 + (c & 255)) / 10;
                    small[i] = l; sum += l;
                    if (prevSmall != null && prevSmall.length == px.length) diff += Math.abs(l - prevSmall[i]);
                }
                boolean first = prevSmall == null;
                prevSmall = small;
                float light = sum / (float) px.length;           // 0..255
                float motion = first ? 0 : diff / (float) px.length; // medie pe pixel
                // ce e în imagine (AI mic, pe telefon)
                labeler.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0))
                        .addOnCompleteListener(t -> {
                            java.util.Set<String> lb = new java.util.HashSet<>();
                            if (t.isSuccessful() && t.getResult() != null)
                                for (com.google.mlkit.vision.label.ImageLabel x : t.getResult()) if (x.getConfidence() > 0.6f) lb.add(x.getText().toLowerCase());
                            decideAuto(il, light, motion, lb, info, repaint);
                            main.postDelayed(tick[0], 2000);
                        });
            });
        };
        main.post(tick[0]);
    }

    private void decideAuto(InstaLive il, float light, float motion, java.util.Set<String> lb, TextView info, Runnable repaint) {
        boolean people = lb.contains("person") || lb.contains("crowd") || lb.contains("selfie") || lb.contains("smile");
        boolean vehicle = lb.contains("car") || lb.contains("vehicle") || lb.contains("bicycle") || lb.contains("motorcycle") || lb.contains("road");
        boolean landscape = lb.contains("sky") || lb.contains("mountain") || lb.contains("lake") || lb.contains("field") || lb.contains("beach") || lb.contains("building") || lb.contains("plant");
        String why; int val;
        if (video) {
            if (light < 55) { why = "Lumină slabă → 5.7K 25 (imagine mai curată)"; val = 251; }
            else if (motion > 28 || vehicle && motion > 14) { why = "Mișcare rapidă → 4K 60 (fluid)"; val = 97; }
            else if (motion > 12 || people) { why = (people ? "Oameni" : "Mișcare") + " → 5.7K+ 30"; val = 317; }
            else { why = (landscape ? "Peisaj" : "Imagine liniștită") + ", lumină bună → 8K 30 (claritate maximă)"; val = 167; }
        } else {
            if (light < 55) { why = "Lumină slabă → 18MP (mai puțin zgomot)"; val = 12; }
            else { why = (landscape ? "Peisaj" : "Lumină bună") + " → 72MP (claritate maximă)"; val = 11; }
        }
        String key = (video ? "v" : "p") + val;
        // schimbăm doar dacă alegerea se păstrează două citiri la rând și nu filmezi acum
        if (key.equals(autoPending)) autoStable++; else { autoPending = key; autoStable = 1; }
        boolean busy = recording;
        if (busy && video && autoDuring && !key.equals(autoLast) && autoStable >= 3 && osc != null) {
            // în timpul filmării: oprim, schimbăm, pornim din nou (fișier nou)
            autoLast = key;
            Osc o = osc;
            info.setText("Auto AI: " + why + " — schimb acum (1–2 s)…");
            io.execute(() -> {
                try {
                    o.stopVideo();
                    il.setVideoRes(val); il.videoRes = val;
                    Thread.sleep(1500);
                    o.startCaptureKeep();
                } catch (Exception e) { main.post(() -> info.setText("Auto AI: n-am putut reporni filmarea: " + e.getMessage())); }
                main.post(repaint);
            });
            return;
        }
        if (!key.equals(autoLast) && autoStable >= 2 && !busy) {
            autoLast = key;
            if (video) { il.setVideoRes(val); il.videoRes = val; } else { il.setPhotoSize(val); il.photoSize = val; }
            repaint.run();
        }
        info.setText("Auto AI: " + why + (busy && !autoDuring && !key.equals(autoLast) ? "  (schimb după ce oprești filmarea)" : ""));
    }

    private void startInstaLive(Osc o, FrameLayout root, TextView msg, android.app.Dialog dlg) {
        if (!liveOn) return;
        msg.setVisibility(View.VISIBLE);
        msg.setText("Încerc legătura proprie Insta360…");
        // imaginea 360 normală (ca în editor): tragi cu degetul ca să te uiți în jur, două degete = zoom
        Video360View v3 = new Video360View(this);
        liveView = v3;
        v3.setVideoSize(2880, 1440);
        v3.setFlat(false, 0f);
        v3.setView(0f, 0f, 95f, false);
        root.addView(v3, 1, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // butonul de test pentru moduri + panoul cu răspunsurile camerei
        TextView test = text("Test moduri", 13, 0xFFFFFFFF, true);
        test.setBackground(round(0xB3000000, 18));
        test.setPadding(dp(14), dp(9), dp(14), dp(9));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        tl.setMargins(0, dp(34), dp(14), 0);
        root.addView(test, tl);
        test.setVisibility(View.GONE); // testul nu mai e necesar
        TextView panel = text("", 10.5f, 0xFFB8F5B8, false);
        panel.setTypeface(Typeface.MONOSPACE);
        panel.setBackgroundColor(0xD9000000);
        panel.setPadding(dp(10), dp(8), dp(10), dp(8));
        panel.setTextIsSelectable(true);
        panel.setVisibility(View.GONE);
        android.widget.ScrollView ps = new android.widget.ScrollView(this);
        ps.addView(panel);
        FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(480), Gravity.TOP);
        pl.setMargins(dp(8), dp(84), dp(8), 0);
        root.addView(ps, pl);
        ps.setVisibility(View.GONE); // ascuns, ca să nu blocheze rotirea imaginii cu degetul
        // butoane de încercare: schimbă modul din aplicație în două feluri
        LinearLayout tries = new LinearLayout(this);
        tries.setVisibility(View.GONE);
        // „Copiază”: tot textul din panou ajunge în telefon, ca să-l lipești în chat
        TextView cp = text("Copiază", 12, 0xFF141414, true);
        cp.setBackground(round(0xFFFFD528, 14));
        cp.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams cpl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cpl.setMarginEnd(dp(8));
        tries.addView(cp, cpl);
        cp.setOnClickListener(v -> {
            InstaLive il = insta;
            String t = il != null ? il.log() : panel.getText().toString();
            android.content.ClipboardManager cm2 = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm2.setPrimaryClip(android.content.ClipData.newPlainText("test camera", t));
            Toast.makeText(this, "Copiat. Lipește-l în mesaj la Claude.", Toast.LENGTH_LONG).show();
        });
        String[][] tr = {{"72MP?", "R11"}, {"18MP?", "R12"}, {"Urmărește", "W0"}};
        for (String[] t : tr) {
            TextView b = text(t[0], 12, 0xFFFFFFFF, true);
            b.setBackground(round(0xE61E3A5F, 14));
            b.setPadding(dp(10), dp(7), dp(10), dp(7));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            blp.setMarginEnd(dp(6));
            tries.addView(b, blp);
            b.setOnClickListener(v -> { InstaLive il = insta; if (il == null) return; if (t[1].charAt(0) == 'R') il.setPhotoSize(Integer.parseInt(t[1].substring(1))); else if (t[1].charAt(0) == 'W') il.watch(); else if (t[1].charAt(0) == 'S') il.scan(); else il.tryMode('A', t[1].charAt(1) == '1'); });
        }
        FrameLayout.LayoutParams trl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
        trl.setMargins(dp(8), dp(570), 0, 0);
        root.addView(tries, trl);
        test.setOnClickListener(v -> {
            InstaLive il = insta;
            if (il == null) { Toast.makeText(this, "Încă nu e legătura cu camera.", Toast.LENGTH_SHORT).show(); return; }
            il.probe();
            boolean show = ps.getVisibility() != View.VISIBLE;
            ps.setVisibility(show ? View.VISIBLE : View.GONE);
            tries.setVisibility(show ? View.VISIBLE : View.GONE);
            if (!show) return;
            panel.setVisibility(View.VISIBLE);
            panel.setText("Întreb camera…");
            panel.postDelayed(new Runnable() { int n = 0; @Override public void run() { String t = il.log(); if (!t.contentEquals(panel.getText())) panel.setText(t); if (++n < 600 && liveOn) panel.postDelayed(this, 1000); } }, 800);
        });
        final boolean[] started = {false};
        v3.setOnSurface(sf -> {
            if (started[0]) return;
            started[0] = true;
            InstaLive il = new InstaLive(o.net);
            insta = il;
            new Thread(() -> il.start(sf, new InstaLive.Listener() {
                @Override public void status(String t) { main.post(() -> { msg.setVisibility(t.isEmpty() ? View.GONE : View.VISIBLE); msg.setText(t); }); }
                @Override public void size(int vw, int vh) { main.post(() -> v3.setVideoSize(vw, vh)); }
            })).start();
        });
        dlg.setOnDismissListener(d -> { liveOn = false; autoOn = false; liveView = null; if (insta != null) { InstaLive il = insta; insta = null; new Thread(il::stop).start(); } });
    }

    // ---------------- fișierele ----------------
    private File dir() {
        File d = new File(getExternalFilesDir(null), "Camera");
        d.mkdirs();
        return d;
    }

    private File local(Osc.Entry e) { return new File(dir(), e.name); }

    /** previzualizarea unei filmări 360: LRV_..._01_... lângă VID_..._00_... */
    private Osc.Entry lrvFor(Osc.Entry e) {
        if (e.isPhoto()) return null;
        String n = e.name;
        int dot = n.lastIndexOf('.');
        String base = (dot > 0 ? n.substring(0, dot) : n).replaceFirst("^VID_", "LRV_").replace("_00_", "_01_");
        Osc.Entry l = byName.get(base + ".lrv");
        if (l == null) l = byName.get(base + ".insv");
        if (l == null) l = byName.get(base + ".mp4");
        return l;
    }

    private void download(Osc.Entry e, boolean openAfter) {
        Osc o = osc;
        if (o == null) { Toast.makeText(this, "Conectează întâi camera.", Toast.LENGTH_SHORT).show(); return; }
        if (progress.containsKey(e.name)) return;
        progress.put(e.name, 0);
        ad.notifyDataSetChanged();
        dl.execute(() -> {
            String err = null;
            boolean ok = true;
            try {
                Osc.Entry l = lrvFor(e);
                long total = e.size + (l != null ? l.size : 0);
                final long[] base = {0};
                Osc.Progress pr = (done, tot) -> {
                    int p = total > 0 ? (int) Math.min(99, (base[0] + done) * 100 / total) : 0;
                    main.post(() -> { progress.put(e.name, p); ad.notifyDataSetChanged(); });
                    return !e.name.equals(cancelName) && !isDestroyed();
                };
                if (l != null && !local(l).exists()) { ok = o.download(l.url, l.size, local(l), pr); base[0] += l.size; }
                if (ok && !local(e).exists()) ok = o.download(e.url, e.size, local(e), pr);
            } catch (Exception ex) { err = ex.getMessage(); }
            final String er = err;
            final boolean fin = ok;
            main.post(() -> {
                progress.remove(e.name);
                if (e.name.equals(cancelName)) cancelName = null;
                ad.notifyDataSetChanged();
                if (er != null) Toast.makeText(this, "Descărcarea nu a reușit: " + er, Toast.LENGTH_LONG).show();
                else if (fin && openAfter) openLocal(e);
            });
        });
    }

    private void openLocal(Osc.Entry e) {
        File f = local(e);
        if (!f.exists()) { download(e, true); return; }
        String low = e.name.toLowerCase();
        if (e.isPhoto()) {
            Intent i = new Intent(this, PhotoActivity.class);
            i.putExtra("uri", Uri.fromFile(f).toString());
            i.putExtra("name", e.name);
            i.putExtra("is360", low.endsWith(".insp"));
            i.putExtra("lens", 0);
            startActivity(i);
            return;
        }
        Osc.Entry l = lrvFor(e);
        File lf = l != null ? local(l) : null;
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", new String[]{Uri.fromFile(f).toString()});
        i.putExtra("lrvs", new String[]{lf != null && lf.exists() ? Uri.fromFile(lf).toString() : null});
        i.putExtra("names", new String[]{e.name});
        i.putExtra("keys", new String[]{"cam:" + e.name});
        i.putExtra("auto", false);
        startActivity(i);
    }

    /** deschide filmarea direct de pe cameră, fără descărcare (se citește prin Wi-Fi) */
    private void openFromCamera(Osc.Entry e) { openFromCamera(e, false); }

    private void openFromCamera(Osc.Entry e, boolean ai) {
        if (!ai && (local(e).exists() || e.isPhoto())) { openLocal(e); return; }
        Osc.Entry l = lrvFor(e);
        Intent i = new Intent(this, EditorActivity.class);
        i.putExtra("uris", new String[]{e.url});
        i.putExtra("lrvs", new String[]{l != null ? l.url : null});
        i.putExtra("names", new String[]{e.name});
        i.putExtra("keys", new String[]{"cam:" + e.name});
        i.putExtra("auto", ai);
        Toast.makeText(this, "Se deschide de pe cameră. Ține Wi-Fi-ul camerei pornit cât editezi și salvezi.", Toast.LENGTH_LONG).show();
        startActivity(i);
    }

    private void askDelete(Osc.Entry e) {
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle("Ștergi de pe cameră?")
                .setMessage(MainActivity.pretty(e.name) + " · " + gb(e.size) + "\nSe șterge de pe cardul din cameră. Copia descărcată pe telefon rămâne.")
                .setPositiveButton("Șterge", (d, w) -> {
                    Osc o = osc;
                    if (o == null) return;
                    io.execute(() -> {
                        String err = null;
                        try {
                            o.delete(e.url);
                            Osc.Entry l = lrvFor(e);
                            if (l != null) try { o.delete(l.url); } catch (Exception ignored) { }
                        } catch (Exception ex) { err = ex.getMessage(); }
                        final String er = err;
                        main.post(() -> { if (er != null) Toast.makeText(this, "Nu s-a șters: " + er, Toast.LENGTH_LONG).show(); loadFiles(); });
                    });
                })
                .setNegativeButton("Renunță", null).show();
    }

    private void itemMenu(Osc.Entry e) {
        boolean have = local(e).exists();
        List<String> ops = new ArrayList<>();
        ops.add("Redă și editează");
        if (!e.isPhoto()) ops.add("Montaj automat AI");
        if (!have) ops.add("Descarcă și deschide");
        if (!have) ops.add("Doar descarcă");
        if (have) ops.add("Șterge copia de pe telefon");
        ops.add("Șterge de pe cameră");
        new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                .setTitle(MainActivity.pretty(e.name))
                .setItems(ops.toArray(new String[0]), (d, w) -> {
                    String op = ops.get(w);
                    if (op.startsWith("Redă")) openFromCamera(e);
                    else if (op.startsWith("Montaj")) openFromCamera(e, true);
                    else if (op.startsWith("Deschide") || op.startsWith("Descarcă și")) openLocal(e);
                    else if (op.startsWith("Doar")) download(e, false);
                    else if (op.startsWith("Șterge copia")) { local(e).delete(); Osc.Entry l = lrvFor(e); if (l != null) local(l).delete(); ad.notifyDataSetChanged(); }
                    else askDelete(e);
                }).show();
    }

    private class Ad extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemViewType(int p) { return rows.get(p) instanceof String ? 0 : 1; }

        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
            if (t == 0) {
                TextView h = text("", 18, 0xFFF2F2F0, true);
                h.setPadding(dp(4), dp(14), 0, dp(8));
                return new RecyclerView.ViewHolder(h) { };
            }
            LinearLayout cell = new LinearLayout(CameraActivity.this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setPadding(dp(4), dp(4), dp(4), dp(10));
            FrameLayout fr = new FrameLayout(CameraActivity.this);
            ImageView iv = new ImageView(CameraActivity.this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(round(0xFF22252A, 16));
            iv.setClipToOutline(true);
            fr.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            TextView dur = text("", 12, 0xFFF2F2F0, true);
            dur.setBackground(round(0xCC000000, 12));
            dur.setPadding(dp(8), dp(3), dp(8), dp(3));
            FrameLayout.LayoutParams dl0 = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
            dl0.setMargins(0, 0, dp(8), dp(8));
            fr.addView(dur, dl0);
            TextView tag = text("360", 12, 0xFFF2F2F0, true);
            tag.setBackground(round(0xCC000000, 12));
            tag.setPadding(dp(8), dp(3), dp(8), dp(3));
            FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START);
            tl.setMargins(dp(8), dp(8), 0, 0);
            fr.addView(tag, tl);
            Dl btn = new Dl(CameraActivity.this);
            FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP | Gravity.END);
            bl.setMargins(0, dp(6), dp(6), 0);
            fr.addView(btn, bl);
            cell.addView(fr, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(136)));
            LinearLayout cap = new LinearLayout(CameraActivity.this);
            cap.setOrientation(LinearLayout.VERTICAL);
            cap.setPadding(dp(2), dp(6), 0, 0);
            cap.addView(text("", 15, 0xFFF2F2F0, true));
            TextView nm = text("", 11, 0xFF9AA0A6, false);
            nm.setSingleLine(true);
            nm.setEllipsize(android.text.TextUtils.TruncateAt.END);
            cap.addView(nm);
            cell.addView(cap);
            return new RecyclerView.ViewHolder(cell) { };
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int pos) {
            Object o = rows.get(pos);
            if (o instanceof String) {
                String hs = (String) o;
                int nl = hs.indexOf('\n');
                android.text.SpannableString sp = new android.text.SpannableString(hs);
                if (nl > 0) {
                    sp.setSpan(new android.text.style.RelativeSizeSpan(0.7f), nl, hs.length(), 0);
                    sp.setSpan(new android.text.style.ForegroundColorSpan(0xFF9AA0A6), nl, hs.length(), 0);
                    sp.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.NORMAL), nl, hs.length(), 0);
                }
                ((TextView) h.itemView).setText(sp);
                return;
            }
            Osc.Entry e = (Osc.Entry) o;
            LinearLayout cell = (LinearLayout) h.itemView;
            FrameLayout fr = (FrameLayout) cell.getChildAt(0);
            ImageView iv = (ImageView) fr.getChildAt(0);
            TextView dur = (TextView) fr.getChildAt(1), tag = (TextView) fr.getChildAt(2);
            Dl btn = (Dl) fr.getChildAt(3);
            LinearLayout cap = (LinearLayout) cell.getChildAt(1);
            String low = e.name.toLowerCase();
            android.graphics.Bitmap bm = thumbs.get(e.name);
            iv.setImageBitmap(bm);
            if (bm == null && !cameraThumbsOk) askThumb(e);
            if (!e.isPhoto() && e.dur > 0) {
                dur.setText(String.format(java.util.Locale.US, "%d:%02d", (int) e.dur / 60, (int) e.dur % 60));
                dur.setVisibility(View.VISIBLE);
            } else dur.setVisibility(View.GONE);
            tag.setVisibility(low.endsWith(".insv") || low.endsWith(".insp") ? View.VISIBLE : View.GONE);
            Integer p = progress.get(e.name);
            boolean have = local(e).exists();
            btn.set(p != null ? p : have ? 101 : -1);
            btn.setOnClickListener(v -> { if (p != null) cancelName = e.name; else if (have) openLocal(e); else download(e, false); });
            iv.setOnClickListener(v -> openFromCamera(e));
            ((TextView) cap.getChildAt(0)).setText(hour(e.name));
            ((TextView) cap.getChildAt(1)).setText(e.name + "  ·  " + gb(e.size) + (have ? " · pe telefon" : ""));
            cell.setOnClickListener(v -> itemMenu(e));
        }

        @Override public int getItemCount() { return rows.size(); }
    }

    /** butonul rotund de pe poză: săgeată = descarcă, cerc = procent, bifă = e pe telefon (deschide) */
    /** camera desenată (aceeași ca la pornirea aplicației) */
    private static class CamPic extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        CamPic(Context c) { super(c); }
        @Override protected void onDraw(Canvas c) {
            float s = Math.min(getWidth() / 120f, getHeight() / 300f);
            SplashView.paintCamera(c, (getWidth() - 120 * s) / 2f, (getHeight() - 300 * s) / 2f, s, p, r, Th.A);
        }
    }

    private static class Dl extends View {
        private int v = -1;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Dl(Context c) { super(c); }
        void set(int x) { v = x; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f, d = getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xCC000000);
            c.drawCircle(w / 2, h / 2, r, p);
            p.setStrokeCap(Paint.Cap.ROUND);
            if (v >= 0 && v <= 100) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(3 * d);
                p.setColor(0x55FFFFFF);
                c.drawCircle(w / 2, h / 2, r - 4 * d, p);
                p.setColor(Th.A);
                c.drawArc(new RectF(4 * d, 4 * d, w - 4 * d, h - 4 * d), -90, 3.6f * v, false, p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFF2F2F0);
                p.setTextSize(10.5f * d);
                p.setTextAlign(Paint.Align.CENTER);
                p.setFakeBoldText(true);
                c.drawText(v + "%", w / 2, h / 2 + 4 * d, p);
                return;
            }
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.6f * d);
            p.setColor(v > 100 ? 0xFF2ECC71 : 0xFFF2F2F0);
            float cx = w / 2, cy = h / 2, k = r * 0.42f;
            if (v > 100) { // bifă
                Path q = new Path();
                q.moveTo(cx - k, cy);
                q.lineTo(cx - k * 0.25f, cy + k * 0.7f);
                q.lineTo(cx + k, cy - k * 0.6f);
                c.drawPath(q, p);
            } else { // săgeată în jos
                c.drawLine(cx, cy - k, cx, cy + k * 0.6f, p);
                c.drawLine(cx - k * 0.6f, cy, cx, cy + k * 0.6f, p);
                c.drawLine(cx + k * 0.6f, cy, cx, cy + k * 0.6f, p);
            }
        }
    }

    /** bară: bateria (cu căpăcel) sau cât e plin cardul */
    private static class Bar extends View {
        private final boolean battery;
        private float f;
        private int col = 0xFF2ECC71;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bar(Context c, boolean battery) { super(c); this.battery = battery; }
        void set(float f, int col) { this.f = Math.max(0, Math.min(1, f)); this.col = col; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
            if (battery) {
                float cap = 3 * d, sw = 1.8f * d;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(sw);
                p.setColor(0xFFF2F2F0);
                c.drawRoundRect(new RectF(sw, sw, w - cap - sw, h - sw), 3 * d, 3 * d, p);
                p.setStyle(Paint.Style.FILL);
                c.drawRect(w - cap, h * 0.32f, w, h * 0.68f, p);
                p.setColor(col);
                float in = sw + 2 * d;
                c.drawRoundRect(new RectF(in, in, in + (w - cap - 2 * in) * f, h - in), 1.5f * d, 1.5f * d, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF3A3D43);
                c.drawRoundRect(new RectF(0, 0, w, h), h / 2, h / 2, p);
                p.setColor(col);
                c.drawRoundRect(new RectF(0, 0, Math.max(h, w * f), h), h / 2, h / 2, p);
            }
        }
    }

    /** declanșatorul: inel alb, cerc portocaliu (poză), roșu (filmare), pătrat roșu când filmează */
    private static class Shutter extends View {
        private boolean video, rec;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Shutter(Context c) { super(c); }
        void setMode(boolean v, boolean r) { video = v; rec = r; invalidate(); }
        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), r = Math.min(w, h) / 2f, d = getResources().getDisplayMetrics().density;
            p.setStyle(Paint.Style.FILL);
            p.setColor(isEnabled() ? 0xFFF2F2F0 : 0x66F2F2F0);
            c.drawCircle(w / 2, h / 2, r, p);
            p.setColor(0xFF1C1E22);
            c.drawCircle(w / 2, h / 2, r - 4 * d, p);
            int col = video ? 0xFFFF3B30 : Th.A;
            p.setColor(col);
            if (rec) { float s = r * 0.42f; c.drawRoundRect(new RectF(w / 2 - s, h / 2 - s, w / 2 + s, h / 2 + s), 6 * d, 6 * d, p); }
            else c.drawCircle(w / 2, h / 2, r - 9 * d, p);
        }
        @Override public void setEnabled(boolean e) { super.setEnabled(e); invalidate(); }
    }

    // ---------------- ajutoare de aspect ----------------
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView button(String s, boolean primary) {
        TextView b = text(s, 16, primary ? 0xFF1A0A00 : 0xFFF2F2F0, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(primary ? Th.A : 0xFF2A2C30, 24));
        return b;
    }

    private TextView chip(String s) {
        TextView c = text(s, 14, 0xFFF2F2F0, true);
        c.setGravity(Gravity.CENTER);
        return c;
    }

    private void style(TextView c, boolean on) {
        c.setBackground(on ? round(0xFF3A3D43, 17) : null);
        c.setTextColor(on ? 0xFFF2F2F0 : 0xFF9AA0A6);
    }

    static String gb(long b) {
        if (b <= 0) return "?";
        if (b >= 1L << 30) return String.format(java.util.Locale.US, "%.1f GB", b / (double) (1L << 30));
        return String.format(java.util.Locale.US, "%.0f MB", b / (double) (1L << 20));
    }

    @Override
    protected void onDestroy() {
        if (thumbPool != null) thumbPool.shutdownNow();
        super.onDestroy();
        cancelName = "*";
        try { cm.bindProcessToNetwork(null); } catch (Exception ignored) { }
        if (cb != null) try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        io.shutdownNow();
        dl.shutdownNow();
    }
}
