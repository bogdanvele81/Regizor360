package ro.regizor360.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.content.ClipData;
import android.content.ContentUris;
import android.media.ExifInterface;
import android.provider.MediaStore;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;

/**
 * Regizor 360: motorul (pagina din assets) rulează într-un WebView.
 * - cardul: utilizatorul alege o singură dată cardul; aplicația îl citește singură apoi
 *   (fișierele sunt servite paginii la /card/<id>, pe bucăți, fără copiere în telefon)
 * - salvarea: utilizatorul alege locul (telefon sau card)
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;
    private static final int REQ_SAVE = 2;
    private static final int REQ_TREE = 3;
    private static final String HOST = "appassets.androidplatform.net";
    private static final String PREFS = "regizor";
    private static final String KEY_TREE = "tree";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private volatile OutputStream saveOut;
    private volatile Uri saveUri;
    private volatile Uri treeUri;
    /** canale deschise spre fișierele de pe card (ultimele 6 folosite) */
    private final LinkedHashMap<String, FileInputStream> open = new LinkedHashMap<String, FileInputStream>(8, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, FileInputStream> e) {
            if (size() > 6) {
                try {
                    e.getValue().close();
                } catch (Exception ignored) {
                }
                return true;
            }
            return false;
        }
    };

    /** când s-a citit ultima dată de pe card */
    private volatile long lastRead = 0;
    private final java.util.concurrent.atomic.AtomicInteger activeReads = new java.util.concurrent.atomic.AtomicInteger(0);
    private final Handler idle = new Handler(Looper.getMainLooper());
    /** Închide fișierele de pe card când nu se citește nimic: dacă scoți cardul, Android nu mai închide aplicația. */
    private synchronized void closeAllCard() {
        for (FileInputStream in : open.values()) {
            try { in.close(); } catch (Exception ignored) { }
        }
        open.clear();
    }
    private final Runnable idleCheck = new Runnable() {
        @Override public void run() {
            if (!open.isEmpty() && activeReads.get() == 0 && SystemClock.uptimeMillis() - lastRead > 2500) closeAllCard();
            idle.postDelayed(this, 1500);
        }
    };
    private final BroadcastReceiver cardGone = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            closeAllCard();
            if (web != null) web.post(() -> web.evaluateJavascript("window.__r360CardGone&&window.__r360CardGone()", null));
        }
    };

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(cardGone); } catch (Throwable ignored) { }
        idle.removeCallbacks(idleCheck);
        closeAllCard();
        super.onDestroy();
    }

    private synchronized FileChannel channelFor(String docId) throws IOException {
        FileInputStream in = open.get(docId);
        if (in == null) {
            Uri tree = treeUri;
            if (tree == null) throw new IOException("no tree");
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(doc, "r");
            if (pfd == null) throw new IOException("no fd");
            in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            open.put(docId, in);
        }
        return in.getChannel();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        idle.postDelayed(idleCheck, 1500);
        try {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_MEDIA_EJECT);
            f.addAction(Intent.ACTION_MEDIA_UNMOUNTED);
            f.addAction(Intent.ACTION_MEDIA_BAD_REMOVAL);
            f.addAction(Intent.ACTION_MEDIA_REMOVED);
            f.addDataScheme("file");
            IntentFilter u = new IntentFilter("android.hardware.usb.action.USB_DEVICE_DETACHED");
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(cardGone, f, Context.RECEIVER_EXPORTED);
                registerReceiver(cardGone, u, Context.RECEIVER_EXPORTED);
            } else {
                registerReceiver(cardGone, f);
                registerReceiver(cardGone, u);
            }
        } catch (Throwable ignored) { }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TREE, null);
        if (saved != null) treeUri = Uri.parse(saved);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);
        // montajul continuă și când aplicația nu e pe ecran
        web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String path = u.getEncodedPath();
                if (HOST.equals(u.getHost()) && path != null && path.startsWith("/card/")) {
                    return serveCard(Uri.decode(path.substring(6)), request.getRequestHeaders());
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public android.graphics.Bitmap getDefaultVideoPoster() {
                return android.graphics.Bitmap.createBitmap(1, 1, android.graphics.Bitmap.Config.ARGB_8888);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean media = false, audio = false;
                try { for (String t : params.getAcceptTypes()) { if (t != null && (t.startsWith("image") || t.startsWith("video"))) media = true; if (t != null && t.startsWith("audio")) audio = true; } } catch (Exception ignored) {}
                Intent i;
                if (audio) {
                    i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("audio/*");
                } else if (media && android.os.Build.VERSION.SDK_INT >= 33) {
                    i = new Intent(android.provider.MediaStore.ACTION_PICK_IMAGES);
                    i.putExtra(android.provider.MediaStore.EXTRA_PICK_IMAGES_MAX, android.provider.MediaStore.getPickImagesMaxLimit());
                } else if (media) {
                    i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                } else {
                    i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    /* ---------- cardul: fișiere servite pe bucăți (Range) ---------- */

    private WebResourceResponse serveCard(String docId, Map<String, String> headers) {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        try {
            Uri tree = treeUri;
            if (tree == null) throw new IOException("no tree");
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(doc, "r");
            if (pfd == null) throw new IOException("no fd");
            long total = pfd.getStatSize();
            FileInputStream in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);

            String range = null;
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
                }
            }
            long start = 0, end = total - 1;
            int code = 200;
            String reason = "OK";
            if (range != null && range.startsWith("bytes=")) {
                String[] p = range.substring(6).split("-", 2);
                if (!p[0].isEmpty()) start = Long.parseLong(p[0].trim());
                if (p.length > 1 && !p[1].trim().isEmpty()) end = Math.min(Long.parseLong(p[1].trim()), total - 1);
                code = 206;
                reason = "Partial Content";
            }
            if (start > 0) in.getChannel().position(start);
            long len = Math.max(0, end - start + 1);
            h.put("Accept-Ranges", "bytes");
            h.put("Content-Length", String.valueOf(len));
            if (code == 206) h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            return new WebResourceResponse(mimeOf(docId), null, code, reason, h, new Limited(in, len));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".mp4") || n.endsWith(".insv") || n.endsWith(".lrv") || n.endsWith(".mov")) return "video/mp4";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".insp")) return "image/jpeg";
        return "application/octet-stream";
    }

    private static class Limited extends InputStream {
        private final InputStream in;
        private long left;

        Limited(InputStream in, long left) {
            this.in = in;
            this.left = left;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int n) throws IOException {
            if (left <= 0) return -1;
            int r = in.read(buf, off, (int) Math.min(n, left));
            if (r > 0) left -= r;
            return r;
        }

        @Override
        public int available() throws IOException {
            return (int) Math.min(in.available(), left);
        }

        @Override
        public void close() throws IOException {
            in.close();
        }
    }

    private boolean treeAccessible() {
        Uri tree = treeUri;
        if (tree == null) return false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(tree) && p.isReadPermission()) return true;
        }
        return false;
    }

    private void listDir(Uri tree, String docId, int depth, JSONArray out) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE};
        Cursor c = null;
        try {
            c = getContentResolver().query(children, cols, null, null, null);
            while (c != null && c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? 0 : c.getLong(3);
                if (name == null) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    if (depth < 3 && !name.equalsIgnoreCase("MISC") && !name.startsWith(".")
                            && !name.equalsIgnoreCase("LOST.DIR") && !name.equalsIgnoreCase("System Volume Information")) {
                        listDir(tree, id, depth + 1, out);
                    }
                } else {
                    JSONObject o = new JSONObject();
                    o.put("id", id);
                    o.put("name", name);
                    o.put("size", size);
                    out.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    result = new Uri[clip.getItemCount()];
                    for (int k = 0; k < clip.getItemCount(); k++) result[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        } else if (requestCode == REQ_SAVE) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    saveUri = data.getData();
                    saveOut = getContentResolver().openOutputStream(saveUri, "w");
                    ok = saveOut != null;
                } catch (Exception e) {
                    ok = false;
                }
            }
            web.evaluateJavascript("window.__saveReady && window.__saveReady(" + ok + ")", null);
        } else if (requestCode == REQ_TREE) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                treeUri = tree;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TREE, tree.toString()).apply();
                ok = true;
            }
            web.evaluateJavascript("window.__folderReady && window.__folderReady(" + ok + ")", null);
        }
    }

    private boolean photoAccess() {
        String read = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        return checkSelfPermission(read) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 8) {
            web.evaluateJavascript("window.__photosPerm && window.__photosPerm(" + photoAccess() + ")", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__r360Back && window.__r360Back()) ? '1' : '0'", value -> {
            if (value == null || !value.contains("1")) finish();
        });
    }

    public class Bridge {
        @JavascriptInterface
        public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { return "?"; }
        }

        /** true dacă aplicația are deja acces la card (ales o dată, păstrat). */
        @JavascriptInterface
        public boolean hasFolder() {
            return treeAccessible();
        }

        /** Deschide alegerea cardului; răspunsul vine prin window.__folderReady(ok). */
        @JavascriptInterface
        public void pickFolder() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    startActivityForResult(i, REQ_TREE);
                } catch (Exception e) {
                    web.evaluateJavascript("window.__folderReady && window.__folderReady(false)", null);
                }
            });
        }

        /** Lista fișierelor de pe card (DCIM și subfoldere, fără MISC), ca JSON. */
        @JavascriptInterface
        public String listFolder() {
            JSONArray out = new JSONArray();
            Uri tree = treeUri;
            if (tree == null) return "{\"ok\":false,\"files\":[]}";
            try {
                String root = DocumentsContract.getTreeDocumentId(tree);
                listDir(tree, root, 0, out);
                return "{\"ok\":true,\"files\":" + out.toString() + "}";
            } catch (Exception e) {
                return "{\"ok\":false,\"files\":[]}";
            }
        }

        /** Pornește lucrul în fundal (serviciu cu notificare). */
        @JavascriptInterface
        public void workStart(String text) {
            Intent i = new Intent(MainActivity.this, WorkService.class);
            i.putExtra("text", text);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
            } catch (Exception ignored) {
            }
        }

        /** Actualizează notificarea cu procentul. */
        @JavascriptInterface
        public void workProgress(String text, int pct) {
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(WorkService.ID, WorkService.build(MainActivity.this, text, pct, true));
            } catch (Exception ignored) {
            }
        }

        /** Gata: oprește serviciul și anunță rezultatul. */
        @JavascriptInterface
        public void workDone(String text) {
            try {
                stopService(new Intent(MainActivity.this, WorkService.class));
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                nm.notify(WorkService.ID_DONE, WorkService.build(MainActivity.this, text, -1, false));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public boolean hasPhotoAccess() {
            return photoAccess();
        }

        /** Cere voie să citească pozele din telefon (doar locul și ora lor). */
        @JavascriptInterface
        public void askPhotoAccess() {
            runOnUiThread(() -> {
                List<String> p = new ArrayList<>();
                p.add(Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE);
                if (Build.VERSION.SDK_INT >= 29) p.add(Manifest.permission.ACCESS_MEDIA_LOCATION);
                requestPermissions(p.toArray(new String[0]), 8);
            });
        }

        /** Pozele din telefon făcute între cele două momente (ms), cu locul lor: [{t,lat,lon}]. */
        @JavascriptInterface
        public String phonePhotosNear(double fromMs, double toMs) {
            JSONArray out = new JSONArray();
            Cursor c = null;
            try {
                String[] cols = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_TAKEN};
                String sel = MediaStore.Images.Media.DATE_TAKEN + ">=? AND " + MediaStore.Images.Media.DATE_TAKEN + "<=?";
                String[] args = new String[]{String.valueOf((long) fromMs), String.valueOf((long) toMs)};
                c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols, sel, args, MediaStore.Images.Media.DATE_TAKEN + " ASC");
                int n = 0;
                while (c != null && c.moveToNext() && n < 30) {
                    long id = c.getLong(0);
                    long t = c.getLong(1);
                    Uri u = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                    if (Build.VERSION.SDK_INT >= 29) {
                        try {
                            u = MediaStore.setRequireOriginal(u);
                        } catch (Exception ignored) {
                        }
                    }
                    InputStream in = null;
                    try {
                        in = getContentResolver().openInputStream(u);
                        if (in == null) continue;
                        ExifInterface ex = new ExifInterface(in);
                        float[] ll = new float[2];
                        if (ex.getLatLong(ll) && (Math.abs(ll[0]) > 0.01 || Math.abs(ll[1]) > 0.01)) {
                            JSONObject o = new JSONObject();
                            o.put("t", t);
                            o.put("lat", (double) ll[0]);
                            o.put("lon", (double) ll[1]);
                            out.put(o);
                            n++;
                        }
                    } catch (Exception ignored) {
                    } finally {
                        try {
                            if (in != null) in.close();
                        } catch (Exception ignored) {
                        }
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.close();
            }
            return out.toString();
        }

        /** Citește o bucată dintr-un fișier de pe card; întoarce base64 ("" la sfârșit, "ERR:..." la eroare). */
        @JavascriptInterface
        public String read(String docId, double offset, int length) {
            lastRead = SystemClock.uptimeMillis();
            activeReads.incrementAndGet();
            try {
                return readOnce(docId, offset, length);
            } catch (Throwable first) {
                // fișierul a fost închis între timp (sau cardul a fost reconectat): îl redeschid o dată
                synchronized (MainActivity.this) {
                    FileInputStream in = open.remove(docId);
                    try { if (in != null) in.close(); } catch (Exception ignored) { }
                }
                try {
                    return readOnce(docId, offset, length);
                } catch (Throwable e) {
                    synchronized (MainActivity.this) {
                        FileInputStream in = open.remove(docId);
                        try { if (in != null) in.close(); } catch (Exception ignored) { }
                    }
                    return "ERR:" + e.getClass().getSimpleName() + " " + e.getMessage();
                }
            } finally {
                activeReads.decrementAndGet();
                lastRead = SystemClock.uptimeMillis();
            }
        }

        private String readOnce(String docId, double offset, int length) throws IOException {
            {
                FileChannel ch = channelFor(docId);
                ByteBuffer buf = ByteBuffer.allocate(length);
                long pos = (long) offset;
                while (buf.hasRemaining()) {
                    int r = ch.read(buf, pos + buf.position());
                    if (r <= 0) break;
                }
                return Base64.encodeToString(buf.array(), 0, buf.position(), Base64.NO_WRAP);
            }
        }

        @JavascriptInterface
        public void beginSave(final String name, final String mime) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    web.evaluateJavascript("window.__saveReady && window.__saveReady(false)", null);
                }
            });
        }

        @JavascriptInterface
        public boolean writeChunk(String b64) {
            try {
                saveOut.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean endSave() {
            try {
                saveOut.flush();
                saveOut.close();
                saveOut = null;
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void abortSave() {
            try {
                if (saveOut != null) saveOut.close();
            } catch (Exception ignored) {
            }
            saveOut = null;
            try {
                if (saveUri != null) DocumentsContract.deleteDocument(getContentResolver(), saveUri);
            } catch (Exception ignored) {
            }
        }
    }
}
