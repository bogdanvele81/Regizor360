package ro.director360.app;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/**
 * La salvare: din imaginea cu cele două lentile (LRV) face cadrul ales (Custom sau Tiny Planet),
 * iar la filmările normale taie pe format. În ambele cazuri pune filtrul de culoare.
 */
public class ReframeEffect implements GlEffect {

    private final boolean is360, planet;
    private final float yaw, pitch, fov;
    private final float[] look;
    private final int outW, outH;

    public ReframeEffect(boolean is360, float[] view, float[] look, int outW, int outH) {
        this.is360 = is360;
        this.yaw = view[0];
        this.pitch = view[1];
        this.fov = view[2];
        this.planet = view[3] > 0;
        this.look = look == null ? Look.NONE : look;
        this.outW = outW;
        this.outH = outH;
    }

    private static final String VS =
            "attribute vec4 aFramePosition;\n" +
            "varying vec2 vUv;\n" +
            "void main(){ gl_Position = aFramePosition; vUv = vec2(aFramePosition.x*0.5+0.5, 0.5-aFramePosition.y*0.5); }\n";

    private static final String FS =
            "precision highp float;\n" +
            "varying vec2 vUv;\n" +
            "uniform sampler2D uTex;\n" +
            "uniform mat3 uV;\n" +
            "uniform mat3 uO;\n" +
            "uniform vec2 uTan;\n" +
            "uniform vec4 uPA;\n" +
            "uniform vec4 uPB;\n" +
            "uniform float uFov;\n" +
            "uniform float uBlend;\n" +
            "uniform int uMode;\n" +
            "uniform int uFlat;\n" +
            "uniform vec2 uCrop;\n" +
            "uniform vec4 uA1;\n" +
            "uniform vec4 uA2;\n" +
            Look.GLSL +
            "vec4 tex(vec2 c){ return texture2D(uTex, vec2(c.x, 1.0 - c.y)); }\n" +
            "vec3 dir(){ vec2 q = (vUv*2.0-1.0)*uTan;\n" +
            "  if(uMode==1){ float r2 = dot(q,q); return uV*(vec3(2.0*q.x, 2.0*q.y, 1.0-r2)/(1.0+r2)); }\n" +
            "  return uV*normalize(vec3(q, 1.0)); }\n" +
            "vec4 lens(vec4 P, vec3 d, out float th){ th = acos(clamp(d.z,-1.0,1.0)); float ph = atan(d.y, d.x); float r = th/uFov;\n" +
            "  return tex(vec2(P.x + P.z*r*cos(ph), P.y + P.w*r*sin(ph))); }\n" +
            "void main(){ if(uFlat==1){ gl_FragColor = vec4(grade(tex(vec2(0.5)+(vUv-vec2(0.5))*uCrop).rgb, uA1, uA2, vUv, 0), 1.0); return; }\n" +
            "  vec3 d = dir(); float ta; float tb; vec4 a = lens(uPA, d, ta); vec4 b = lens(uPB, uO*d, tb);\n" +
            "  float w = clamp((1.5707963 + uBlend - ta)/(2.0*uBlend), 0.0, 1.0); if(ta>uFov) w = 0.0; if(tb>uFov) w = 1.0;\n" +
            "  gl_FragColor = vec4(grade(mix(b.rgb, a.rgb, w), uA1, uA2, vUv, 0), 1.0); }\n";

    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr) throws VideoFrameProcessingException {
        return new Program(useHdr);
    }

    private class Program extends BaseGlShaderProgram {
        private final GlProgram gl;
        private float inAspect = 2f;

        Program(boolean hdr) throws VideoFrameProcessingException {
            super(hdr, 1);
            try {
                gl = new GlProgram(VS, FS);
                gl.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(), GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            inAspect = inputWidth / (float) Math.max(1, inputHeight);
            return new Size(outW, outH);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs) throws VideoFrameProcessingException {
            try {
                gl.use();
                gl.setSamplerTexIdUniform("uTex", inputTexId, 0);
                float ty = planet ? (float) Math.tan(Math.toRadians(fov / 4.0)) : (float) Math.tan(Math.toRadians(fov / 2.0));
                float tx = ty * outW / (float) outH;
                gl.setFloatsUniform("uTan", new float[]{tx, ty});
                gl.setFloatsUniform("uV", Video360View.colMajorPublic(Video360View.viewMatrix(yaw, pitch)));
                gl.setFloatsUniform("uO", Video360View.colMajorPublic(Video360View.lensMatrix()));
                gl.setFloatsUniform("uPA", Video360View.calA());
                gl.setFloatsUniform("uPB", Video360View.calB());
                gl.setFloatUniform("uFov", Video360View.fovRad());
                gl.setFloatUniform("uBlend", (float) Math.toRadians(4));
                gl.setIntUniform("uMode", planet ? 1 : 0);
                gl.setIntUniform("uFlat", is360 ? 0 : 1);
                float sa = outW / (float) outH;
                gl.setFloatsUniform("uCrop", new float[]{Math.min(1f, sa / inAspect), Math.min(1f, inAspect / sa)});
                gl.setFloatsUniform("uA1", Look.a1(look));
                gl.setFloatsUniform("uA2", Look.a2(look));
                gl.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
                GlUtil.checkGlError();
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try { gl.delete(); } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
    }
}
