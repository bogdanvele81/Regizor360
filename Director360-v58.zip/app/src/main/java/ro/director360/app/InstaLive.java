package ro.director360.app;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.net.Network;
import android.view.Surface;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Locale;
import java.util.TreeMap;

/**
 * Încercare: imaginea live prin legătura proprie Insta360 (TCP 6666), după descrierea publicată de
 * Niccolo Rigacci (insta360-wifi-api) și proiectul whitebox-aero/insta360. Nu e documentată oficial.
 * Pachet: lungime (4, little-endian, include cei 4 octeți) + conținut.
 * Comandă telefon: 04 00 00 | cod (2 LE) | 02 | secvență (3 LE) | 80 00 00 | protobuf.
 */
class InstaLive {
    interface Listener { void status(String s); void size(int w, int h); }

    private static final byte[] SYNC = {6, 0, 0, 's', 'y', 'N', 'c', 'e', 'N', 'd', 'i', 'n', 'S'};
    private static final byte[] KEEP = {5, 0, 0};
    private static final int START_LIVE_STREAM = 1, STOP_LIVE_STREAM = 2;

    private final Network net;
    private volatile boolean run = true;
    private Socket sock;
    private OutputStream out;
    private int seq = 1;
    private MediaCodec codec;
    private boolean hevc;
    private final ByteArrayOutputStream es = new ByteArrayOutputStream(); // flux video adunat
    private final TreeMap<String, Integer> kinds = new TreeMap<>();
    private String firstOther = "";
    private int frames = 0;

    InstaLive(Network net) { this.net = net; }

    void stop() {
        run = false;
        try { send(cmd(STOP_LIVE_STREAM, new byte[0])); } catch (Exception ignored) { }
        try { if (sock != null) sock.close(); } catch (Exception ignored) { }
        try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) { }
    }

    private synchronized void send(byte[] payload) throws Exception {
        byte[] p = new byte[payload.length + 4];
        int n = p.length;
        p[0] = (byte) n; p[1] = (byte) (n >> 8); p[2] = (byte) (n >> 16); p[3] = (byte) (n >> 24);
        System.arraycopy(payload, 0, p, 4, payload.length);
        out.write(p);
        out.flush();
    }

    private byte[] cmd(int code, byte[] pb) {
        byte[] h = new byte[12 + pb.length];
        h[0] = 4; h[1] = 0; h[2] = 0;
        h[3] = (byte) code; h[4] = (byte) (code >> 8);
        h[5] = 2;
        int s = seq++;
        h[6] = (byte) s; h[7] = (byte) (s >> 8); h[8] = (byte) (s >> 16);
        h[9] = (byte) 0x80; h[10] = 0; h[11] = 0;
        System.arraycopy(pb, 0, h, 12, pb.length);
        return h;
    }

    private static void varint(ByteArrayOutputStream b, long v) { while ((v & ~0x7FL) != 0) { b.write((int) ((v & 0x7F) | 0x80)); v >>>= 7; } b.write((int) v); }
    private static void field(ByteArrayOutputStream b, int num, long v) { varint(b, ((long) num << 3)); varint(b, v); }

    /** pornește: conectare, sincronizare, cerere de imagine live, apoi citește ce trimite camera */
    void start(Surface surface, Listener l) {
        try {
            sock = net != null ? net.getSocketFactory().createSocket() : new Socket();
            sock.connect(new InetSocketAddress("192.168.42.1", 6666), 6000);
            sock.setSoTimeout(6000);
            out = sock.getOutputStream();
            InputStream in = sock.getInputStream();
            send(SYNC);
            send(KEEP);
            // cerere de imagine live: video pornit (câmpul 1), restul implicit
            ByteArrayOutputStream pb = new ByteArrayOutputStream();
            field(pb, 1, 1);
            send(cmd(START_LIVE_STREAM, pb.toByteArray()));
            l.status("Am cerut imaginea live. Dacă pe ecranul camerei apare o întrebare, apasă „Permite”.");
            new Thread(() -> { while (run) { try { Thread.sleep(2000); send(KEEP); } catch (Exception e) { return; } } }).start();
            byte[] hdr = new byte[4];
            long lastInfo = 0;
            while (run) {
                readFully(in, hdr, 4);
                int len = (hdr[0] & 0xFF) | (hdr[1] & 0xFF) << 8 | (hdr[2] & 0xFF) << 16 | (hdr[3] & 0xFF) << 24;
                if (len < 4 || len > 20_000_000) throw new Exception("pachet ciudat (" + len + ")");
                byte[] p = new byte[len - 4];
                readFully(in, p, p.length);
                String k = p.length >= 3 ? String.format(Locale.ROOT, "%02x%02x%02x", p[0], p[1], p[2]) : "scurt";
                kinds.merge(k, 1, Integer::sum);
                if (!(p.length >= 3 && (p[0] == 4 || p[0] == 5 || p[0] == 6) && p[1] == 0 && p[2] == 0)) {
                    if (firstOther.isEmpty()) firstOther = hex(p, 24);
                    video(p, surface, l);
                } else if (p[0] == 4 && p.length >= 12) {
                    int code = (p[3] & 0xFF) | (p[4] & 0xFF) << 8;
                    int sq = (p[6] & 0xFF) | (p[7] & 0xFF) << 8 | (p[8] & 0xFF) << 16;
                    kinds.merge("răspuns " + code, 1, Integer::sum);
                    Integer asked = sent.get(sq);
                    byte[] bd = java.util.Arrays.copyOfRange(p, 12, p.length);
                    if (code == 8293) { long fm = Pb.intField(bd, 3); if (fm >= 0) { lastFm = (int) fm; lastFmAt = System.currentTimeMillis(); } }
                    if (asked != null && asked == 7) { lastSetCode = code; lastSetAt = System.currentTimeMillis(); }
                    if (scanning && (code == 8293 || code == 8275 || code == 8234 || code == 8252 || (asked != null && asked == 7))) continue;
                    byte[] body = java.util.Arrays.copyOfRange(p, 12, p.length);
                    if (asked != null && asked == 8 && code == 200) {
                        // opțiunile camerei: câte un câmp pe rând (numărul câmpului = tipul opțiunii)
                        // urmărire: notăm doar opțiunile care s-au schimbat de data trecută
                        java.util.Map<String, String> cur = new java.util.TreeMap<>();
                        for (String ln : Pb.lines(body, 2)) { int e = ln.indexOf('='); if (e > 0) cur.put(ln.substring(0, e), ln.substring(e + 1)); }
                        if (prevOpts == null) logLine(now() + " pornit: 40=" + cur.get("40") + " 41=" + cur.get("41"));
                        else for (java.util.Map.Entry<String, String> en : cur.entrySet()) {
                            String k2 = en.getKey();
                            if (k2.equals("1") || k2.equals("29") || k2.equals("11") || k2.equals("19")) continue;
                            String old = prevOpts.get(k2);
                            if (!en.getValue().equals(old)) logLine(now() + " opțiunea " + k2 + ": " + old + " → " + en.getValue());
                        }
                        prevOpts = cur;
                    } else if (asked != null || code != 200) { if (code != 8234 && !(asked != null && asked == 8)) logLine(now() + " " + (asked != null ? "R" + asked : "N") + " c" + code + " " + Pb.dump(body)); }
                }
                long now = System.currentTimeMillis();
                if (frames == 0 && now - lastInfo > 1500) { lastInfo = now; l.status("Camera răspunde, dar încă fără imagine.\n" + info()); }
            }
        } catch (Exception e) {
            if (run) l.status("Legătura Insta360 n-a mers: " + e.getMessage() + "\n" + info());
        }
    }

    // ---- test pentru moduri: întrebăm camera și notăm ce răspunde ----
    private final java.util.Map<Integer, Integer> sent = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.LinkedList<String> log = new java.util.LinkedList<>();

    private synchronized void logLine(String l) { log.add(l.length() > 600 ? l.substring(0, 600) + "…" : l); while (log.size() > 600) log.removeFirst(); }

    private synchronized void logBlock(String l) { log.add(l); while (log.size() > 14) log.removeFirst(); }

    private static String now() { return new java.text.SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new java.util.Date()); }

    /** încercări de schimbare a modului: A = opțiunile 40/41, B = setările de fotografiere cu modul (6 poză, 7 video) */
    void tryMode(char how, boolean video) {
        new Thread(() -> {
            try {
                ByteArrayOutputStream m = new ByteArrayOutputStream();
                if (how == 'A') {
                    ByteArrayOutputStream v = new ByteArrayOutputStream();
                    field(v, 40, video ? 100 : 0);
                    field(v, 41, video ? 0 : 100);
                    field(m, 1, 40); field(m, 1, 41);
                    byte[] vb = v.toByteArray();
                    varint(m, (2 << 3) | 2); varint(m, vb.length); m.write(vb, 0, vb.length);
                    logLine(now() + " încerc A " + (video ? "Video" : "Poză"));
                    ask(7, m.toByteArray());          // SET_OPTIONS (bănuit)
                } else {
                    field(m, 3, video ? 7 : 6);
                    logLine(now() + " încerc B " + (video ? "Video" : "Poză"));
                    ask(9, m.toByteArray());          // SET_PHOTOGRAPHY_OPTIONS (bănuit)
                }
            } catch (Exception e) { logLine("eroare: " + e.getMessage()); }
        }).start();
    }

    /** schimbă modul camerei: opțiunea 40 = modul de poză, 41 = modul de filmare (100 = neales) */
    void setMode(boolean video, int sub) {
        new Thread(() -> {
            try { ask(7, video ? setSub(100, sub) : setSub(sub, 100)); }
            catch (Exception e) { logLine("eroare mod: " + e.getMessage()); }
        }).start();
    }

    boolean connected() { return run && out != null; }

    private java.util.Map<String, String> prevOpts;
    private volatile boolean watching;

    /** la fiecare 2 secunde întreabă opțiunile; în jurnal apar doar schimbările (și anunțurile camerei) */
    void watch() {
        if (watching) { watching = false; logLine(now() + " urmărire oprită"); return; }
        watching = true;
        prevOpts = null;
        logLine(now() + " urmărire pornită: schimbă acum modurile PE CAMERĂ, câte unul, cu 4 secunde pauză");
        new Thread(() -> {
            try {
                ByteArrayOutputStream a = new ByteArrayOutputStream();
                for (int i = 1; i <= 120; i++) field(a, 1, i);
                byte[] req = a.toByteArray();
                while (watching && run) { ask(8, req); Thread.sleep(2000); }
            } catch (Exception e) { logLine("eroare urmărire: " + e.getMessage()); watching = false; }
        }).start();
    }

    private volatile int lastFm = -1, lastSetCode = 0;
    private volatile long lastFmAt = 0, lastSetAt = 0;
    private volatile boolean scanning;

    private static final java.util.Map<Integer, String> FM = new java.util.HashMap<>();
    static {
        String[] n = {"0 normal", "2 Timelapse mobil", "3 Interval", "5 Rafală", "6 Poză", "7 Video", "8 Poză HDR", "9 Video HDR", "10 Video interval", "11 Timelapse", "12 TimeShift", "13 Noapte (AEB)", "17 Buclă", "18 Starlapse"};
        for (String x : n) { int sp = x.indexOf(' '); FM.put(Integer.parseInt(x.substring(0, sp)), x.substring(sp + 1)); }
    }

    private byte[] setSub(int videoVal, int photoVal) {
        ByteArrayOutputStream m = new ByteArrayOutputStream(), v = new ByteArrayOutputStream();
        field(v, 40, videoVal);
        field(v, 41, photoVal);
        field(m, 1, 40); field(m, 1, 41);
        byte[] vb = v.toByteArray();
        varint(m, (2 << 3) | 2); varint(m, vb.length); m.write(vb, 0, vb.length);
        return m.toByteArray();
    }

    /** încearcă pe rând valori pentru opțiunea 40 (filmare) și 41 (poză) și notează ce mod pornește camera */
    void scan() {
        if (scanning) return;
        scanning = true;
        new Thread(() -> {
            try {
                logLine(now() + " scanare pornită (durează câteva minute, nu atinge camera)");
                java.util.List<int[]> tries = new java.util.ArrayList<>();
                for (int x = 0; x <= 40; x++) tries.add(new int[]{0, x});
                for (int x = 90; x <= 130; x++) tries.add(new int[]{0, x});
                for (int x = 0; x <= 40; x++) tries.add(new int[]{1, x});
                for (int x = 90; x <= 130; x++) tries.add(new int[]{1, x});
                int errors = 0, k = 0;
                for (int[] t : tries) {
                    if (!run) return;
                    k++;
                    long t0 = System.currentTimeMillis();
                    int before = lastFm;
                    lastFmAt = 0; lastSetAt = 0;
                    ask(7, t[0] == 0 ? setSub(t[1], 0) : setSub(0, t[1]));
                    while (System.currentTimeMillis() - t0 < 2500 && (lastSetAt == 0 || System.currentTimeMillis() - lastSetAt < 600)) Thread.sleep(50);
                    String kind = t[0] == 0 ? "filmare(40)" : "poză(41)";
                    if (lastSetAt == 0) logLine(kind + "=" + t[1] + " fără răspuns");
                    else if (lastSetCode != 200) errors++;
                    else if (lastFmAt > 0) { String nm = FM.get(lastFm); logLine(kind + "=" + t[1] + " → mod " + lastFm + (nm != null ? " " + nm : "")); }
                    else logLine(kind + "=" + t[1] + " ok, același mod (" + before + ")");
                    if (k % 20 == 0) logLine(now() + " … " + k + "/" + tries.size() + ", refuzate " + errors);
                }
                ask(7, setSub(100, 0));
                logLine(now() + " gata. refuzate: " + errors);
            } catch (Exception e) { logLine("eroare scanare: " + e.getMessage()); }
            finally { scanning = false; }
        }).start();
    }

    synchronized String log() { return android.text.TextUtils.join("\n", log); }

    /** trimite o comandă și ține minte ce cod a avut, ca să recunoaștem răspunsul */
    void ask(int code, byte[] pb) throws Exception {
        int s0 = seq;
        sent.put(s0, code);
        send(cmd(code, pb));
    }

    /** cererile de test: opțiunile camerei (toate tipurile 1..120) și setările de fotografiere */
    void probe() {
        new Thread(() -> {
            try {
                ByteArrayOutputStream a = new ByteArrayOutputStream();
                for (int i = 1; i <= 120; i++) field(a, 1, i);
                logLine("— test " + new java.text.SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new java.util.Date()) + " —");
                ask(8, a.toByteArray());          // GET_OPTIONS (bănuit)
                Thread.sleep(400);
                ByteArrayOutputStream f6 = new ByteArrayOutputStream(); field(f6, 1, 6);
                ask(10, f6.toByteArray());        // setările de fotografiere pentru modul Poză (6)
                Thread.sleep(400);
                ByteArrayOutputStream f7 = new ByteArrayOutputStream(); field(f7, 1, 7);
                ask(10, f7.toByteArray());        // ... și pentru modul Video (7)
                Thread.sleep(400);
                ask(15, new byte[0]);             // starea capturii (bănuit)
            } catch (Exception e) { logLine("eroare test: " + e.getMessage()); }
        }).start();
    }

    String info() {
        StringBuilder b = new StringBuilder();
        for (java.util.Map.Entry<String, Integer> e : kinds.entrySet()) b.append(e.getKey()).append(":").append(e.getValue()).append("  ");
        if (!firstOther.isEmpty()) b.append("\n").append(firstOther);
        b.append("\ncadre: ").append(frames);
        return b.toString();
    }

    private static String hex(byte[] p, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < Math.min(n, p.length); i++) b.append(String.format(Locale.ROOT, "%02x", p[i]));
        return b.toString();
    }

    private static void readFully(InputStream in, byte[] b, int n) throws Exception {
        int got = 0;
        while (got < n) { int r = in.read(b, got, n - got); if (r < 0) throw new Exception("camera a închis legătura"); got += r; }
    }

    /** caută cadrele video (încep cu 00 00 00 01) și le dă decodorului telefonului */
    private void video(byte[] p, Surface surface, Listener l) throws Exception {
        int s = startCode(p, 0);
        if (s < 0) return;
        es.write(p, s, p.length - s);
        byte[] all = es.toByteArray();
        // împărțim în bucăți NAL
        int a = startCode(all, 0);
        while (a >= 0) {
            int b = startCode(all, a + 4);
            if (b < 0) break;
            nal(all, a, b - a, surface, l);
            a = b;
        }
        es.reset();
        if (a >= 0) es.write(all, a, all.length - a);
    }

    private static int startCode(byte[] d, int from) {
        for (int i = from; i + 3 < d.length; i++) if (d[i] == 0 && d[i + 1] == 0 && d[i + 2] == 0 && d[i + 3] == 1) return i;
        return -1;
    }

    private byte[] vps, sps, pps;

    private void nal(byte[] d, int off, int len, Surface surface, Listener l) throws Exception {
        if (len < 5) return;
        int h = d[off + 4] & 0xFF;
        byte[] n = new byte[len];
        System.arraycopy(d, off, n, 0, len);
        if (codec == null) {
            int t264 = h & 0x1F, t265 = (h >> 1) & 0x3F;
            if (t265 == 32) { hevc = true; vps = n; }
            else if (hevc && t265 == 33) sps = n;
            else if (hevc && t265 == 34) pps = n;
            else if (!hevc && t264 == 7) sps = n;
            else if (!hevc && t264 == 8) pps = n;
            if (sps != null && pps != null && (!hevc || vps != null)) {
                MediaFormat f = MediaFormat.createVideoFormat(hevc ? "video/hevc" : "video/avc", 2880, 1440);
                if (hevc) {
                    byte[] csd = new byte[vps.length + sps.length + pps.length];
                    System.arraycopy(vps, 0, csd, 0, vps.length);
                    System.arraycopy(sps, 0, csd, vps.length, sps.length);
                    System.arraycopy(pps, 0, csd, vps.length + sps.length, pps.length);
                    f.setByteBuffer("csd-0", ByteBuffer.wrap(csd));
                } else {
                    f.setByteBuffer("csd-0", ByteBuffer.wrap(sps));
                    f.setByteBuffer("csd-1", ByteBuffer.wrap(pps));
                }
                codec = MediaCodec.createDecoderByType(hevc ? "video/hevc" : "video/avc");
                codec.configure(f, surface, null, 0);
                codec.start();
            }
            return;
        }
        int ii = codec.dequeueInputBuffer(20000);
        if (ii >= 0) {
            ByteBuffer ib = codec.getInputBuffer(ii);
            ib.clear();
            if (n.length <= ib.capacity()) { ib.put(n); codec.queueInputBuffer(ii, 0, n.length, System.nanoTime() / 1000, 0); }
            else codec.queueInputBuffer(ii, 0, 0, 0, 0);
        }
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        int oi;
        while ((oi = codec.dequeueOutputBuffer(bi, 0)) >= 0 || oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                MediaFormat of = codec.getOutputFormat();
                l.size(of.getInteger(MediaFormat.KEY_WIDTH), of.getInteger(MediaFormat.KEY_HEIGHT));
                continue;
            }
            codec.releaseOutputBuffer(oi, true);
            if (frames++ == 0) l.status("");
        }
    }
}
