package ro.director360.app;

/**
 * Culorile pozei și ale filmului, exact ca în Regizor 360.
 * Reglajele (−100…100): luminozitate, contrast, umbre, lumini, saturație, căldură, claritate, reducere zgomot, vignetare.
 */
public class Look {
    public static final int EXP = 0, CON = 1, SH = 2, HI = 3, SAT = 4, WARM = 5, CLA = 6, DNS = 7, VIG = 8;
    public static final String[] ADJ_IDS = {"exp", "con", "sh", "hi", "sat", "warm", "cla", "dns", "vig"};
    public static final String[] ADJ_NAMES = {"Luminozitate", "Contrast", "Umbre", "Lumini", "Saturație", "Căldură", "Claritate", "Reducere zgomot", "Vignetare"};
    public static final float[] NONE = new float[9];
    /** butonul „Auto” din Regizor */
    public static final float[] AUTO = {5, 15, 25, -15, 15, 5, 20, 25, 15};

    public static final String[] IDS = {"none", "vivid", "snow", "warm", "cool", "cine", "night", "bw"};
    public static final String[] NAMES = {"Natural", "Viu", "Zăpadă", "Cald", "Rece", "Cinematic", "Noapte", "Alb-negru"};
    public static final int[][] SWATCH = {
            {0xFF6B8FB5, 0xFFC9B48A}, {0xFF1E90FF, 0xFFFF6A2B}, {0xFFDFE9F3, 0xFF7FB2E5}, {0xFFF6B26B, 0xFFE06C2B},
            {0xFF7FB2E5, 0xFF3D5A80}, {0xFF2B3A42, 0xFFC08552}, {0xFF1B2735, 0xFF5B7A9A}, {0xFFEEEEEE, 0xFF333333}};
    // filtrele din Regizor: exp, con, sh, hi, sat, warm, cla, dns, vig
    private static final float[][] F = {
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {5, 15, 0, 0, 30, 0, 0, 0, 10},
            {-10, 10, 0, -40, 18, 0, 0, 0, 0},
            {0, 10, 0, 0, 10, 40, 0, 0, 0},
            {0, 10, 0, 0, 5, -35, 0, 0, 0},
            {0, 25, 15, -20, -15, 10, 0, 0, 35},
            {35, 5, 45, -20, 0, 0, 0, 40, 0},
            {0, 25, 0, 0, -100, 0, 0, 0, 15}};

    public static int index(String id) {
        for (int j = 0; j < IDS.length; j++) if (IDS[j].equals(id)) return j;
        return 0;
    }

    /** reglajele filtrului (tăria 70 = ca în Regizor) */
    public static float[] of(String id, int k) {
        float[] q = F[index(id)], r = new float[9];
        for (int i = 0; i < 9; i++) r[i] = q[i] * k / 70f;
        if (q[SAT] <= -100) r[SAT] = Math.max(-100, r[SAT]);
        return r;
    }

    /** filtrul plus reglajele mâinii, între −100 și 100 */
    public static float[] sum(float[] a, float[] b) {
        float[] r = new float[9];
        for (int i = 0; i < 9; i++) r[i] = Math.max(-100, Math.min(100, (a == null ? 0 : a[i]) + (b == null ? 0 : b[i])));
        return r;
    }

    /** aceeași formulă ca în Regizor; a1 = (lum, contrast, umbre, lumini)/100, a2 = (saturație, căldură, claritate, vignetare)/100 */
    public static final String GLSL =
            "vec3 grade(vec3 x, vec4 a1, vec4 a2, vec2 uv, int pano){\n" +
            "  x *= exp2(a1.x);\n" +
            "  float L = dot(clamp(x,0.0,1.0), vec3(0.299,0.587,0.114));\n" +
            "  x += a1.z*0.45*(1.0-smoothstep(0.0,0.55,L))*(1.0-L);\n" +
            "  x += a1.w*0.35*smoothstep(0.45,1.0,L);\n" +
            "  x = (x-0.5)*(1.0+a1.y)+0.5;\n" +
            "  L = dot(x, vec3(0.299,0.587,0.114)); x = mix(vec3(L), x, 1.0+a2.x);\n" +
            "  x += vec3(0.07,0.015,-0.07)*a2.y;\n" +
            "  if(pano==0 && a2.w!=0.0){ float r = length(uv-0.5)*1.414; x *= 1.0-a2.w*0.75*smoothstep(0.35,1.0,r); }\n" +
            "  return clamp(x,0.0,1.0); }\n";

    static float[] a1(float[] l) { return new float[]{l[EXP] / 100f, l[CON] / 100f, l[SH] / 100f, l[HI] / 100f}; }
    static float[] a2(float[] l) { return new float[]{l[SAT] / 100f, l[WARM] / 100f, l[CLA] / 100f, l[VIG] / 100f}; }
}
