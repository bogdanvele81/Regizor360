package ro.regizor360.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Regizor 360: motorul (pagina din assets) rulează într-un WebView.
 * - cardul: utilizatorul alege o singură dată cardul; aplicația îl citește singură apoi
 *   (fișierele sunt servite paginii la /card/<id>, pe bucăți, fără copiere în telefon)
 * - salvarea: utilizatorul alege locul (telefon sau card)
 */
public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;
    private static final int REQ_SAVE = 2;
    private static final int REQ_TREE = 3;
    private static final String HOST = "appassets.androidplatform.net";
    private static final String PREFS = "regizor";
    private static final String KEY_TREE = "tree";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private volatile OutputStream saveOut;
    private volatile Uri saveUri;
    private volatile Uri treeUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TREE, null);
        if (saved != null) treeUri = Uri.parse(saved);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String path = u.getEncodedPath();
                if (HOST.equals(u.getHost()) && path != null && path.startsWith("/card/")) {
                    return serveCard(Uri.decode(path.substring(6)), request.getRequestHeaders());
                }
                return loader.shouldInterceptRequest(u);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    /* ---------- cardul: fișiere servite pe bucăți (Range) ---------- */

    private WebResourceResponse serveCard(String docId, Map<String, String> headers) {
        Map<String, String> h = new HashMap<>();
        h.put("Cache-Control", "no-store");
        h.put("Access-Control-Allow-Origin", "*");
        try {
            Uri tree = treeUri;
            if (tree == null) throw new IOException("no tree");
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(doc, "r");
            if (pfd == null) throw new IOException("no fd");
            long total = pfd.getStatSize();
            FileInputStream in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);

            String range = null;
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
                }
            }
            long start = 0, end = total - 1;
            int code = 200;
            String reason = "OK";
            if (range != null && range.startsWith("bytes=")) {
                String[] p = range.substring(6).split("-", 2);
                if (!p[0].isEmpty()) start = Long.parseLong(p[0].trim());
                if (p.length > 1 && !p[1].trim().isEmpty()) end = Math.min(Long.parseLong(p[1].trim()), total - 1);
                code = 206;
                reason = "Partial Content";
            }
            if (start > 0) in.getChannel().position(start);
            long len = Math.max(0, end - start + 1);
            h.put("Accept-Ranges", "bytes");
            h.put("Content-Length", String.valueOf(len));
            if (code == 206) h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            return new WebResourceResponse(mimeOf(docId), null, code, reason, h, new Limited(in, len));
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h, new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".mp4") || n.endsWith(".insv") || n.endsWith(".lrv") || n.endsWith(".mov")) return "video/mp4";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".insp")) return "image/jpeg";
        return "application/octet-stream";
    }

    private static class Limited extends InputStream {
        private final InputStream in;
        private long left;

        Limited(InputStream in, long left) {
            this.in = in;
            this.left = left;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int n) throws IOException {
            if (left <= 0) return -1;
            int r = in.read(buf, off, (int) Math.min(n, left));
            if (r > 0) left -= r;
            return r;
        }

        @Override
        public int available() throws IOException {
            return (int) Math.min(in.available(), left);
        }

        @Override
        public void close() throws IOException {
            in.close();
        }
    }

    private boolean treeAccessible() {
        Uri tree = treeUri;
        if (tree == null) return false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(tree) && p.isReadPermission()) return true;
        }
        return false;
    }

    private void listDir(Uri tree, String docId, int depth, JSONArray out) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        String[] cols = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE};
        Cursor c = null;
        try {
            c = getContentResolver().query(children, cols, null, null, null);
            while (c != null && c.moveToNext()) {
                String id = c.getString(0);
                String name = c.getString(1);
                String mime = c.getString(2);
                long size = c.isNull(3) ? 0 : c.getLong(3);
                if (name == null) continue;
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    if (depth < 3 && !name.equalsIgnoreCase("MISC") && !name.startsWith(".")
                            && !name.equalsIgnoreCase("LOST.DIR") && !name.equalsIgnoreCase("System Volume Information")) {
                        listDir(tree, id, depth + 1, out);
                    }
                } else {
                    JSONObject o = new JSONObject();
                    o.put("id", id);
                    o.put("name", name);
                    o.put("size", size);
                    out.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                ClipData clip = data.getClipData();
                if (clip != null) {
                    result = new Uri[clip.getItemCount()];
                    for (int k = 0; k < clip.getItemCount(); k++) result[k] = clip.getItemAt(k).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        } else if (requestCode == REQ_SAVE) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    saveUri = data.getData();
                    saveOut = getContentResolver().openOutputStream(saveUri, "w");
                    ok = saveOut != null;
                } catch (Exception e) {
                    ok = false;
                }
            }
            web.evaluateJavascript("window.__saveReady && window.__saveReady(" + ok + ")", null);
        } else if (requestCode == REQ_TREE) {
            boolean ok = false;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                treeUri = tree;
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TREE, tree.toString()).apply();
                ok = true;
            }
            web.evaluateJavascript("window.__folderReady && window.__folderReady(" + ok + ")", null);
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__r360Back && window.__r360Back()) ? '1' : '0'", value -> {
            if (value == null || !value.contains("1")) finish();
        });
    }

    public class Bridge {
        @JavascriptInterface
        public String version() {
            return "2";
        }

        /** true dacă aplicația are deja acces la card (ales o dată, păstrat). */
        @JavascriptInterface
        public boolean hasFolder() {
            return treeAccessible();
        }

        /** Deschide alegerea cardului; răspunsul vine prin window.__folderReady(ok). */
        @JavascriptInterface
        public void pickFolder() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try {
                    startActivityForResult(i, REQ_TREE);
                } catch (Exception e) {
                    web.evaluateJavascript("window.__folderReady && window.__folderReady(false)", null);
                }
            });
        }

        /** Lista fișierelor de pe card (DCIM și subfoldere, fără MISC), ca JSON. */
        @JavascriptInterface
        public String listFolder() {
            JSONArray out = new JSONArray();
            Uri tree = treeUri;
            if (tree == null) return "{\"ok\":false,\"files\":[]}";
            try {
                String root = DocumentsContract.getTreeDocumentId(tree);
                listDir(tree, root, 0, out);
                return "{\"ok\":true,\"files\":" + out.toString() + "}";
            } catch (Exception e) {
                return "{\"ok\":false,\"files\":[]}";
            }
        }

        @JavascriptInterface
        public void beginSave(final String name, final String mime) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    web.evaluateJavascript("window.__saveReady && window.__saveReady(false)", null);
                }
            });
        }

        @JavascriptInterface
        public boolean writeChunk(String b64) {
            try {
                saveOut.write(Base64.decode(b64, Base64.DEFAULT));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean endSave() {
            try {
                saveOut.flush();
                saveOut.close();
                saveOut = null;
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void abortSave() {
            try {
                if (saveOut != null) saveOut.close();
            } catch (Exception ignored) {
            }
            saveOut = null;
            try {
                if (saveUri != null) DocumentsContract.deleteDocument(getContentResolver(), saveUri);
            } catch (Exception ignored) {
            }
        }
    }
}
